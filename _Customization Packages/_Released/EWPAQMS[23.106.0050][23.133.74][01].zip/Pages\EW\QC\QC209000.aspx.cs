using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using EW.QC;
using PX.Data;
using PX.Web.UI;

public partial class Page_QC209000 : PX.Web.UI.PXPage
{
  protected void Page_Load(object sender, EventArgs e)
  {
  }
    protected void edOns_RootFieldsNeeded(object sender, PXCallBackEventArgs e)
    {
        //EWQCPlanMaint graph = this.ds.DataGraph as EWQCPlanMaint;
        
        //EWQCVariableMaint graph = PXGraph.CreateInstance<EWQCVariableMaint>();
        //GenericInquiryDesigner graph = this.ds.DataGraph as GenericInquiryDesigner;
        //if (graph != null)
        //{
        //    // graph.TestParameters.Current
        //    // String[] fields = graph.GetFieldsInRelation();
        //    String[] parameters = graph.GetAllParameters();

        //    //e.Result = string.Join(";", parameters.Concat(fields));
        //    e.Result = string.Join(";", parameters);
        //}

    }
}

using EW.QC;
using PX.Data;
using PX.Web.UI;
using System;
public partial class Page_QC204000:PX.Web.UI.PXPage {
  protected void Page_Init(object sender, EventArgs e) {
  }
    protected void edOns_RootFieldsNeeded(object sender, PXCallBackEventArgs e)
    {
        EWQCVariableMaint graph = this.ds.DataGraph as EWQCVariableMaint;



        //EWQCVariableMaint graph = PXGraph.CreateInstance<EWQCVariableMaint>();
        //GenericInquiryDesigner graph = this.ds.DataGraph as GenericInquiryDesigner;
        if (graph != null)
        {
            // graph.TestParameters.Current
            // String[] fields = graph.GetFieldsInRelation();
            String[] parameters = graph.GetAllParameters();

            //e.Result = string.Join(";", parameters.Concat(fields));
            e.Result = string.Join(";", parameters);
        }

    }
}
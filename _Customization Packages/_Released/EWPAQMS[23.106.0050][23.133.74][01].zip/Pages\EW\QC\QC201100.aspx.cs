using EW.QC;
using PX.Data;
using PX.Web.UI;
using System;

public partial class Page_QC201100 : PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void edOns_RootFieldsNeeded(object sender, PXCallBackEventArgs e)
    {
        EWQCSamplingPlanMaint graph = this.ds.DataGraph as EWQCSamplingPlanMaint;

        if (graph != null)
        {
            String[] parameters = graph.GetFunctionsList();

            e.Result = string.Join(";", parameters);
        }
    }
}

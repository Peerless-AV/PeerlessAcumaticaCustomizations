import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.Graph.IGCMUpdateExpeditorInformationProc", primaryView: "Records" })
export class IGCM5096 extends PXScreen {
  Records = createCollection(IGCMPOLandedCost);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Inquiry,
})
export class IGCMPOLandedCost extends PXView {
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox, allowCheckAll: true }) Selected: PXFieldState;
  @columnConfig({ width: 140, hideViewLink: true }) LandedCostNbr: PXFieldState;
  @columnConfig({ width: 90 }) LandedCostDate: PXFieldState;
  @columnConfig({ width: 140 }) ContainerNbr: PXFieldState;
}
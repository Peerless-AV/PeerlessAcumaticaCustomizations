using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Drawing;

public partial class Page_QC301003 : PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e)
    {
        AddStyle(EW.QC.EWQCConstants.RedRowCSSClassName, "Red", "White", false);
        AddStyle(EW.QC.EWQCConstants.GreenRowCSSClassName, "forestgreen", "White", false);
    }

    private void AddStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor))
            style.BackColor = Color.FromName(backColor + " !important");

        if (!string.IsNullOrEmpty(foreColor))
            style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }

    protected void PXGridTestResult_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["ActualResult"].Value;
        if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Fail)
            e.Row.Cells["ActualResult"].Style.CssClass = EW.QC.EWQCConstants.RedRowCSSClassName;
        else if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Pass)
            e.Row.Cells["ActualResult"].Style.CssClass = EW.QC.EWQCConstants.GreenRowCSSClassName;

        value = e.Row.Cells["FinalResult"].Value;
        if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Fail)
            e.Row.Cells["FinalResult"].Style.CssClass = EW.QC.EWQCConstants.RedRowCSSClassName;
        else if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Pass)
            e.Row.Cells["FinalResult"].Style.CssClass = EW.QC.EWQCConstants.GreenRowCSSClassName;
    }

    protected void PXGridPlanDetail_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        int passedCount = Convert.ToInt32(e.Row.Cells["PassedTestCount"].Value);
        if (passedCount > 0)
        {
            e.Row.Cells["PassedTestCount"].Style.CssClass = EW.QC.EWQCConstants.GreenRowCSSClassName;
        }
        else
        {
            e.Row.Cells["PassedTestCount"].Style.CssClass = e.Row.Cells["PassedTestCount"].Style.CssClass.Replace(EW.QC.EWQCConstants.GreenRowCSSClassName, "");
        }

        passedCount = Convert.ToInt32(e.Row.Cells["FailedTestCount"].Value);
        if (passedCount > 0)
        {
            e.Row.Cells["FailedTestCount"].Style.CssClass = EW.QC.EWQCConstants.RedRowCSSClassName;
        }
        else
        {
            e.Row.Cells["FailedTestCount"].Style.CssClass = e.Row.Cells["FailedTestCount"].Style.CssClass.Replace(EW.QC.EWQCConstants.GreenRowCSSClassName, "");

        }
    }
}

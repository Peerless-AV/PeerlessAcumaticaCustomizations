using System;
using System.Collections;
using System.Configuration;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Page_QC301007 : PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e)
    {
        AddStyle("rowred", "Red", "White", false);
        AddStyle("rowgreen", "forestgreen", "White", false);
    }

    private void AddStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor))
            style.BackColor = Color.FromName(backColor + " !important");

        if (!string.IsNullOrEmpty(foreColor))
            style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }
    protected void grid2_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["ActualResult"].Value;
        if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Fail)
            e.Row.Cells["ActualResult"].Style.CssClass = "rowred";
        else if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Pass)
            e.Row.Cells["ActualResult"].Style.CssClass = "rowgreen";

        Object fanalResultValue = e.Row.Cells["FinalResult"].Value;
        if (fanalResultValue != null && Convert.ToString(fanalResultValue) == EW.QC.EWQCResultType.Fail)
            e.Row.Cells["FinalResult"].Style.CssClass = "rowred";
        else if (fanalResultValue != null && Convert.ToString(fanalResultValue) == EW.QC.EWQCResultType.Pass)
            e.Row.Cells["FinalResult"].Style.CssClass = "rowgreen";
    }

}

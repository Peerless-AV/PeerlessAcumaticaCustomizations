﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_QC209016 : PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e)
    {
        AddStyle("rowred", "Red", "White", false);
    }

    private void AddStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor))
            style.BackColor = Color.FromName(backColor + " !important");

        if (!string.IsNullOrEmpty(foreColor))
            style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["PriceScore"].Value;
        Object value1 = e.Row.Cells["RatingScore"].Value;
        if (Convert.ToDecimal(value1) == Convert.ToDecimal(value))
        {
            e.Row.Cells["PriceScore"].Style.CssClass = "rowred";
        }
    }
    protected void grid2_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["QualityScore"].Value;
        Object value1 = e.Row.Cells["RatingScore"].Value;
        if (Convert.ToDecimal(value1) == Convert.ToDecimal(value))
        {
            e.Row.Cells["QualityScore"].Style.CssClass = "rowred";
        }
    }
    protected void grid3_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["QuantitySuppliedScore"].Value;
        Object value1 = e.Row.Cells["RatingScore"].Value;
        if (Convert.ToDecimal(value1) == Convert.ToDecimal(value))
        {
            e.Row.Cells["QuantitySuppliedScore"].Style.CssClass = "rowred";
        }
    }
    protected void grid4_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["OnTimeDeliverScore"].Value;
        Object value1 = e.Row.Cells["RatingScore"].Value;
        if (Convert.ToDecimal(value1) == Convert.ToDecimal(value))
        {
            e.Row.Cells["OnTimeDeliverScore"].Style.CssClass = "rowred";
        }
    }
}
<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="AR301199.aspx.cs" Inherits="Page_AR301199" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="HotFixCPayment.HotFixCPaymentEntry"
        PrimaryView="Documents"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Documents" Width="100%" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ControlSize="M" GroupCaption="" ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule ControlSize="M" LabelsWidth="SM" GroupCaption="Complemento Pago" runat="server" ID="CstPXLayoutRule2" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector6" DataField="RefNbrCP" ></px:PXSelector>
			<px:PXDropDown runat="server" ID="CstPXDropDown28" DataField="StampStatus" ></px:PXDropDown>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule22" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule LabelsWidth="SM" ControlSize="M" runat="server" ID="CstPXLayoutRule23" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule25" StartGroup="True" GroupCaption="CFDI" ></px:PXLayoutRule>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit14" DataField="IssuerPostalCode" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit32" DataField="IssuerRfc" />
			<px:PXTextEdit runat="server" ID="CstPXTextEdit31" DataField="IssuerName" />
			<px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit13" DataField="ReceiverRfc" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit30" DataField="ReceiverName" />
			<px:PXTextEdit runat="server" ID="CstPXTextEdit7" DataField="ReceiverUsoCFDI" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit10" DataField="ReceiverMail" ></px:PXTextEdit>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox29" DataField="Sent" ></px:PXCheckBox>
			<px:PXLayoutRule ControlSize="M" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule24" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule GroupCaption="Timbrado Fiscal Digital" runat="server" ID="CstPXLayoutRule26" StartGroup="True" ></px:PXLayoutRule>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit9" DataField="UUID" ></px:PXTextEdit>
			<px:PXDateTimeEdit Size="M" runat="server" ID="CstPXDateTimeEdit8" DataField="SealDate" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit19" DataField="CancelUUID" ></px:PXTextEdit>
			<px:PXDateTimeEdit Size="M" runat="server" ID="CstPXDateTimeEdit18" DataField="CancelDate" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit20" DataField="CancelStatus" ></px:PXTextEdit>
			<px:PXLayoutRule ControlSize="M" runat="server" ID="CstPXLayoutRule1" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule LabelsWidth="SM" ControlSize="M" GroupCaption="Sello" runat="server" ID="CstPXLayoutRule4" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDateTimeEdit Size="M" runat="server" ID="CstPXDateTimeEdit11" DataField="SealIssue" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit12" DataField="CertificateNbr" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit16" DataField="QrCode" ></px:PXTextEdit>
			<px:PXLayoutRule ControlSize="M" LabelsWidth="SM" GroupCaption="Codigo QR" runat="server" ID="CstPXLayoutRule17" StartColumn="True" StartGroup="True" ></px:PXLayoutRule>
			<px:PXImageView runat="server" Width="200px" Height="200px" DataField="QrCodeImg" ID="edQrCodeImg" Style='width:200px;height:200px;' ></px:PXImageView></Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView>
</asp:Content>


<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200013.aspx.cs" Inherits="Page_FE200013" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEPayMethodSATMaint"
        PrimaryView="Paymethod">
        <CallbackCommands>
        </CallbackCommands>
    
	<ClientEvents CommandPerformed="" ></ClientEvents></px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid FastFilterFields="PayMethodCD,Descrpcion" StatusField="Erpmatica" AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" TabIndex="100" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
        <Levels>
            <px:PXGridLevel DataMember="Paymethod">
                <Columns>
                    <px:PXGridColumn DataField="PayMethodCD" Width="70"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Descrpcion" Width="280"></px:PXGridColumn>
	<px:PXGridColumn DataField="StartDate" Width="90" />
	<px:PXGridColumn DataField="EndDate" Width="90" /></Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
        <ActionBar>
        </ActionBar>

        <Mode AllowUpload="True"></Mode>
    </px:PXGrid></asp:Content>

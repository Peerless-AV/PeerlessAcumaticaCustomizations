<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE203000.aspx.cs" Inherits="Page_FE203000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEVehicleUnitsMaint"
        PrimaryView="VehicleUnits"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="VehicleUnits" Width="100%" Height="50px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ControlSize="M" LabelsWidth="M" runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector21" DataField="UnitCD" />
			<px:PXTextEdit runat="server" ID="CstPXTextEdit17" DataField="Description" ></px:PXTextEdit></Template>
	
		<AutoSize Container="Window" ></AutoSize>
		<AutoSize Enabled="True" ></AutoSize>
		<AutoSize MinHeight="50" ></AutoSize></px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab DataMember="CurrentVehicleUnits" ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
<Items>
			<px:PXTabItem Text="GENERAL" >
				<Template>
					<px:PXLayoutRule ControlSize="M" LabelsWidth="M" StartGroup="True" GroupCaption="Info. Vehiculo" runat="server" ID="CstPXLayoutRule47" StartColumn="True" ></px:PXLayoutRule>
					<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector48" DataField="PermissionSCT" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit1" DataField="PermitNumber" ></px:PXTextEdit>
					<px:PXSelector runat="server" ID="CstPXSelector4" DataField="TransportID" ></px:PXSelector>
					<px:PXNumberEdit runat="server" ID="CstPXNumberEdit35" DataField="VehicleWeight" />
					<px:PXTextEdit runat="server" ID="CstPXTextEdit5" DataField="AutomobileRegistration" ></px:PXTextEdit>
					<px:PXNumberEdit runat="server" ID="CstPXNumberEdit6" DataField="ModelYear" ></px:PXNumberEdit>
					<px:PXDropDown CommitChanges="True" runat="server" ID="CstPXDropDown10" DataField="OwnedOrLeased" ></px:PXDropDown>
					<px:PXSelector CommitChanges="True" runat="server" ID="CstPXSelector11" DataField="ProviderRentTheVehicle" ></px:PXSelector>
					<px:PXSelector runat="server" ID="CstPXSelector31" DataField="PartTransport" ></px:PXSelector>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox7" DataField="IsTrailer" ></px:PXCheckBox>
					<px:PXSelector runat="server" ID="CstPXSelector8" DataField="TypeTrailerID" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit9" DataField="TrailerRegistration" ></px:PXTextEdit>
					<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox33" DataField="IsDoubleTrailer" ></px:PXCheckBox>
					<px:PXSelector runat="server" ID="CstPXSelector34" DataField="TypeDoubleTrailerID" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit32" DataField="DoubleTrailerRegistration" ></px:PXTextEdit>
					<px:PXLayoutRule GroupCaption="Info. Seguros" runat="server" ID="CstPXLayoutRule12" StartColumn="True" StartGroup="True" ControlSize="M" LabelsWidth="M" ></px:PXLayoutRule>
					<px:PXSelector runat="server" ID="CstPXSelector25" DataField="CivilLiabilityInsurerID" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit27" DataField="CivilLiabilityPolicyNumber" ></px:PXTextEdit>
					<px:PXSelector runat="server" ID="CstPXSelector20" DataField="EnvironmentalInsurerID" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit21" DataField="EnvironmentalPolicyNumber" ></px:PXTextEdit>
					<px:PXSelector runat="server" ID="CstPXSelector30" DataField="FreightTransportationInsurerID" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit29" DataField="FreightTransportationPolicyNumber" ></px:PXTextEdit></Template></px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
	</px:PXTab>
</asp:Content>
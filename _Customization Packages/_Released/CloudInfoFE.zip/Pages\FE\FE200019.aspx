<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200019.aspx.cs" Inherits="Page_FE200019" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEMethodpaymentSATMaint"
        PrimaryView="Formapago">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
        <Levels>
            <px:PXGridLevel DataMember="Formapago">
                <Columns>
                    <px:PXGridColumn DataField="Paymentmethod" Width="70"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Description" Width="220"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Banked" Width="70"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Operationnumber" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="AccountIssuer" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="OrderingAccount" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="PatteOrderaccount" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="IssuerBeneficiary" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Beneficiaryaccount" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="BeneficiaryEmployer" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="ChainType" Width="120"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Namebank" Width="220"></px:PXGridColumn>
                    <px:PXGridColumn DataField="StartDate" Width="90"></px:PXGridColumn>
                    <px:PXGridColumn DataField="EndDate" Width="90"></px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
        <ActionBar>
        </ActionBar>
        <Mode AllowUpload="True"></Mode>
    </px:PXGrid>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE504000.aspx.cs" Inherits="Page_FE504000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEInvoiceEntry"
        PrimaryView="Documents"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView SyncPosition="True" DefaultControlID="PXDropDowndoctype" ID="form" runat="server" DataSourceID="ds" DataMember="Documents" Width="100%" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule ColumnWidth="450px" GroupCaption="Type" runat="server" ID="CstPXLayoutRuleType" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDropDown CommitChanges="" Size="s" SelectedIndex="-1" runat="server" ID="PXDropDowndoctype" DataField="DocType" ></px:PXDropDown>
			<px:PXSelector CommitChanges="True" AutoRefresh="True" Size="s" runat="server" ID="CstPXSelectorRefere" DataField="RefNbr">
				<GridProperties FastFilterFields="ARInvoice__InvoiceNbr, CustomerID, CustomerID_Customer_AcctName" ></GridProperties></px:PXSelector>
			<px:PXLayoutRule ColumnWidth="450px" GroupCaption="CFDI" runat="server" ID="CstPXLayoutRuleCFDI" StartRow="True" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector6" DataField="ReceiverUsoCFDI" ></px:PXSelector>
			<px:PXSelector runat="server" ID="CstPXSelector7" DataField="PaymentForm" ></px:PXSelector>
			<px:PXSelector runat="server" ID="CstPXSelector8" DataField="PaymentMethod" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="PostalCode" DataField="PostalCode" ></px:PXTextEdit>
			<px:PXLayoutRule GroupCaption="TIMBRADO FISCAL DIGITAL" runat="server" ID="CstPXLayoutRuleFuiscal" StartColumn="True" ></px:PXLayoutRule>
			<px:PXTextEdit Size="L" Width="" runat="server" ID="CstPXTextEdit9" DataField="UUID" ></px:PXTextEdit>
			<px:PXDateTimeEdit Size="m" runat="server" ID="CstPXDateTimeEdit10" DataField="SealDate" ></px:PXDateTimeEdit>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRuleSello" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule ColumnWidth="450px" GroupCaption="SELLO" ControlSize="" runat="server" ID="CstPXLayoutRulesell" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDateTimeEdit TimeMode="False" runat="server" ID="CstPXDateTimeEdit13" DataField="SealIssue" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit14" DataField="CertificateNbr" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit15" DataField="AmountToWords" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule18" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule GroupCaption="C&amp;Oacute;DIGO QR" ControlSize="" ColumnWidth="200" runat="server" ID="CstPXLayoutRule16" StartGroup="True" ></px:PXLayoutRule>
			<px:PXImageView runat="server" Width="200px" Height="200px" DataField="QrCodeImg" ID="edQrCodeImg" Style='width:200px;height:200px;' ></px:PXImageView></Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView>
</asp:Content>


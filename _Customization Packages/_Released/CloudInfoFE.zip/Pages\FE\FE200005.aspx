<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200005.aspx.cs" Inherits="Page_FE200005" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFECurrencySATMaint"
        PrimaryView="Currency"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid FastFilterFields="CurrencyCD,Description" StatusField="Erpmatica" TabIndex="100" AutoAdjustColumns="True" AllowPaging="True" AdjustPageSize="Auto" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Currency">
			    <Columns>
				<px:PXGridColumn DataField="CurrencyCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Description" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Precision" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Variation" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="StartDate" Width="90" />
				<px:PXGridColumn DataField="EndDate" Width="90" /></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" ></Mode></px:PXGrid>
</asp:Content>

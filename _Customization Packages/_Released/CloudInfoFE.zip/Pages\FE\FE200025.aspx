<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200025.aspx.cs" Inherits="Page_FE200025" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEFederalTrasportationSATMaint"
        PrimaryView="FederalTrasportation"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" AllowSearch="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="FederalTrasportation">
			    <Columns>
				<px:PXGridColumn DataField="NomenclatureCD" Width="84" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Description" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="NumberShafts" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="NumberTires" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Trailer" Width="70" />
				<px:PXGridColumn DataField="StartDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="EndDate" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowAddNew="True" />
		<Mode AllowDelete="True" />
		<Mode AllowUpdate="True" />
		<Mode AllowUpload="True" /></px:PXGrid>
</asp:Content>

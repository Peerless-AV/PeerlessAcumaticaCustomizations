<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE202000.aspx.cs" Inherits="Page_FE202000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEOperatorsMaint"
        PrimaryView="Operators"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Operators" Width="100%" Height="50px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector CommitChanges="" runat="server" ID="CstPXSelector43" DataField="OperatorCD" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit44" DataField="Name" ></px:PXTextEdit></Template>
	
		<AutoSize MinHeight="50" Container="Window" Enabled="True" ></AutoSize>
</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab DataMember="CurrentOperators" ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="GENERAL" >
				<Template>
					<px:PXLayoutRule StartGroup="True" GroupCaption="Direccion" runat="server" ID="CstPXLayoutRule47" StartColumn="True" ></px:PXLayoutRule>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit64" DataField="Street" ></px:PXTextEdit>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit66" DataField="OutNumber" ></px:PXTextEdit>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit67" DataField="IntNumber" ></px:PXTextEdit>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector48" DataField="CountryID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector54" DataField="StateID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector52" DataField="MunicipalityID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector72" DataField="ZipCode" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector70" DataField="SettlementID" ></px:PXSelector>
					<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector53" DataField="LocalityID" ></px:PXSelector>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit71" DataField="Reference" ></px:PXTextEdit>
					<px:PXLayoutRule StartGroup="True" GroupCaption="Info. Operador" runat="server" ID="CstPXLayoutRule49" StartColumn="True" ></px:PXLayoutRule>
					<px:PXMaskEdit runat="server" ID="CstPXMaskEdit74" DataField="RFC" ></px:PXMaskEdit>
					<px:PXTextEdit runat="server" ID="CstPXTextEdit50" DataField="DriverLicense" ></px:PXTextEdit></Template></px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
	</px:PXTab>
</asp:Content>
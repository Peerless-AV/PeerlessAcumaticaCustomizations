<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE502000.aspx.cs" Inherits="Page_FE502000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEInvoiceTimbrar"
        PrimaryView="Document">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewDocument" Visible="false" DependOnGrid="grid" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
        <Levels>
            <px:PXGridLevel DataKeyNames="DocType,RefNbr" DataMember="Document">
                <Columns>
                    <px:PXGridColumn CommitChanges="False" Type="CheckBox" DataField="Selected" Width="60"></px:PXGridColumn>
                    <px:PXGridColumn DataField="CustomerID_description" Width="220"></px:PXGridColumn>
                    <px:PXGridColumn DataField="DocDate" Width="90"></px:PXGridColumn>
	<px:PXGridColumn DataField="DocType" Width="70" ></px:PXGridColumn>
                    <px:PXGridColumn DataField="RefNbr" Width="140"></px:PXGridColumn>
                    <px:PXGridColumn DataField="CuryOrigDocAmt" Width="100"></px:PXGridColumn>
                    <px:PXGridColumn DataField="DocDesc" Width="280"></px:PXGridColumn></Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
        <ActionBar>
        </ActionBar>

        <Mode AllowUpload="True"></Mode>
    </px:PXGrid>
</asp:Content>

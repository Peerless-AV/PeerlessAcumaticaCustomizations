<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200008.aspx.cs" Inherits="Page_FE200008" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFECountrySATMaint"
        PrimaryView="Country"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid FastFilterFields="CountryCD,Name" StatusField="Erpmatica" AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" TabIndex="100" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Country">
			    <Columns>
				<px:PXGridColumn DataField="CountryCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Name" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ZipCodeCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ForfiscalIdentity" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ValfiscalIdentity" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="group" Width="140" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" ></Mode></px:PXGrid>
</asp:Content>

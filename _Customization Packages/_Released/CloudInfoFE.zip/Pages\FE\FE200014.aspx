<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200014.aspx.cs" Inherits="Page_FE200014" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFETypeRelationSATMAint"
        PrimaryView="TypeRelation">
        <CallbackCommands>
        </CallbackCommands>

        <ClientEvents CommandPerformed="ByErpmatica" BeforeRedirect="" Initialize=""></ClientEvents>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid FastFilterFields="TypeRelationCD,Descrpcion" EnableClientScript="True" StatusField="" TabIndex="100" AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
        <Levels>
            <px:PXGridLevel DataMember="TypeRelation">
                <Columns>
                    <px:PXGridColumn DataField="TypeRelationCD" Width="70"></px:PXGridColumn>
                    <px:PXGridColumn DataField="Descrpcion" Width="280"></px:PXGridColumn>
	<px:PXGridColumn DataField="StartDate" Width="90" />
	<px:PXGridColumn DataField="EndDate" Width="90" /></Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
        <ActionBar>
        </ActionBar>
        <Mode AllowUpload="True"></Mode>
    </px:PXGrid>
    <px:PXLiteral Text="" runat="server" ID="s">
        <px:PXJavaScript Script="function ByErpmatica() {  	var gridFooter = document.getElementById(&quot;ctl00_phL_grid_ab&quot;).getElementsByTagName(&quot;nobr&quot;)[0];  	gridFooter.style.color = &#39;gray&#39;; 	var link = document.createElement(&#39;a&#39;);  	var linkText = document.createTextNode(&quot;Powered by ERPMATICA - www.erpmatica.com&quot;);  	link.appendChild(linkText);  	link.href =&quot;http://erpmatica.com&quot;; 	gridFooter.parentNode.replaceChild(link,gridFooter)  }" runat="server" ID="CstJavaScript2" ></px:PXJavaScript>
    </px:PXLiteral>
</asp:Content>

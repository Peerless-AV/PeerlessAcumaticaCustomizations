<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE503000.aspx.cs" Inherits="Page_FE503000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEPaymentTimbar"
        PrimaryView="Payment"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid FastFilterFields="RefNbrCP,CustomerID_Customer_acctName" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataKeyNames="RefNbrCP" DataMember="Payment">
			    <Columns>
				<px:PXGridColumn TextAlign="Center" AllowSort="False" AllowMove="False" AllowCheckAll="True" Type="CheckBox" DataField="Selected" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="False" DataField="PEFEProcessPayment__DocType" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="RefNbrCP" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="DocDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomerID_Customer_acctName" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn DataField="PEFEProcessPayment__CuryOrigDocAmt" Width="100" /></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE900000.aspx.cs" Inherits="Page_FE900000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CI.Objects.FE.FECorrectionInvoicesMaint"
        PrimaryView="CorrectionInvoices"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="CorrectionInvoices">
			    <Columns>
				<px:PXGridColumn DataField="RefNbr" Width="140" />
				<px:PXGridColumn DataField="DocType" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CuryLineTotal" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CuryTaxTotal" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CuryOrigDocAmt" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="IssuerRfc" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ReceiverRfc" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="UUID" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SealDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CancelUUID" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CancelDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CorrectionUUID" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SealCorectionDate" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>

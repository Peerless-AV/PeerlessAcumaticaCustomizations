<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE201000.aspx.cs" Inherits="Page_FE201000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFECtsInformationMaint"
        PrimaryView="PECtsInformations"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid AutoAdjustColumns="True" AllowPaging="True" AdjustPageSize="Auto" FastFilterFields="ReceptionID,InventoryID,SerieID,PetitionID" StatusField="Erpmatica" TabIndex="100" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="PECtsInformations">
			    <Columns>
				<px:PXGridColumn DataField="ReceptionID" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn DataField="InventoryID" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SerieID" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Customs" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ImportDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="PetitionID" Width="220" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" ></Mode></px:PXGrid>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200020.aspx.cs" Inherits="Page_FE200020" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFERateSATMaint"
        PrimaryView="Tarifas"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="Tarifas">
			    <Columns>
				<px:PXGridColumn DataField="Rankcd" Width="96" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Minimumvalue" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Maximumvalue" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Tax" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Factor" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Transfer" Width="72" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Retention" Width="72" ></px:PXGridColumn>
				<px:PXGridColumn DataField="StartDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="EndDate" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" /></px:PXGrid>
</asp:Content>

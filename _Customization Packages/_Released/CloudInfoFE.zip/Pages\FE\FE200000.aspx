<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200000.aspx.cs" Inherits="Page_FE200000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFETaxSATMaint"
        PrimaryView="TaxSATs"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid FastFilterFields="Description" StatusField="Erpmatica" TabIndex="100" AllowSearch="True" AutoAdjustColumns="True" AdjustPageSize="Auto" AllowPaging="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="TaxSATs">
			    <Columns>
				<px:PXGridColumn DataField="TaxCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Description" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="PersonNatural" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="PersonMoral" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="StartDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="EndDate" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
         <Mode AllowAddNew="True" AllowDelete="True" AllowUpdate="True" AllowUpload="True" ></Mode>
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>

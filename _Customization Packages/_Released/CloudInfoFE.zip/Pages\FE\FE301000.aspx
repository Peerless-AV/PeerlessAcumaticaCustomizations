<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE301000.aspx.cs" Inherits="Page_FE301000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEPaymentEntry"
        PrimaryView="Document">
        <CallbackCommands>
	<px:PXDSCallbackCommand Name="ViewPayment" Visible="false" DependOnGrid="PXGridPay" /></CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ActivityIndicator="True" ID="form" runat="server" DataSourceID="ds" DataMember="Document" Width="100%" Height="100px" AllowAutoHide="false">
        <Template>
            <px:PXLayoutRule ID="PXLayoutRuleDocum" runat="server" StartRow="True"></px:PXLayoutRule>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule25" StartColumn="True" ></px:PXLayoutRule>
            <px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector1" DataField="RefNbrCP">
	<GridProperties FastFilterFields="RefNbrCP,ReceiverName" ></GridProperties></px:PXSelector>
            <px:PXSegmentMask AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSegmentMask2" DataField="CustomerID"></px:PXSegmentMask>
            <px:PXDateTimeEdit CommitChanges="True" runat="server" ID="CstPXDateTimeEdit6" DataField="DocDate" ></px:PXDateTimeEdit>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule24" StartColumn="True" ></px:PXLayoutRule>
	<px:PXDropDown runat="server" ID="CstPXDropDown23" DataField="StampStatus" ></px:PXDropDown>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit21" DataField="CancelStatus" ></px:PXTextEdit>
	<px:PXCheckBox Enabled="False" runat="server" ID="CstPXCheckBox22" DataField="Sent" ></px:PXCheckBox></Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab DataMember="" ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
        <Items>
            <px:PXTabItem Text="PAGOS">
                <Template>
                    <px:PXGrid KeepPosition="True" Width="100%" Height="300px" DataSourceID="ds" TabIndex="4000" SyncPosition="True" AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" SkinID="DetailsInTab" runat="server" ID="PXGridPay">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="CustomerID" DataMember="DetailPay">
                                <Columns>
                                    <px:PXGridColumn DataField="DocType" Width="70"></px:PXGridColumn>
                                    <px:PXGridColumn LinkCommand="ViewPayment" CommitChanges="True" DataField="RefNbr" Width="140"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="Curyid" Width="120"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="CuryRate" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="CuryOrigDocAmt" Width="100"></px:PXGridColumn>
                                    <px:PXGridColumn Visible="" DataField="OperationNbr" Width="220"></px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="CFDI">
                <Template>
                    <px:PXFormView DataSourceID="ds" TabIndex="10300" DataMember="Document" runat="server" ID="FormViewCFDI">
                        <Template>
                            <px:PXLayoutRule runat="server" ID="PXLayoutCFDI" StartColumn="True"></px:PXLayoutRule>
                            <px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" runat="server" ID="PXLayoutCaract" StartGroup="True" GroupCaption="CARACTER&amp;Iacute;STICAS"></px:PXLayoutRule>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit20" DataField="ReceiverUsoCFDI" ></px:PXTextEdit>
	<px:PXSelector runat="server" ID="CstPXSelector39" DataField="ReceiverTaxRegime" ></px:PXSelector>
                            <px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" GroupCaption="Sello" runat="server" ID="PXLayoutSello" StartGroup="True"></px:PXLayoutRule>
                            <px:PXTextEdit runat="server" ID="CstPXTextEdit16" DataField="CertificateNbr"></px:PXTextEdit>
	<px:PXDateTimeEdit Size="m" runat="server" ID="CstPXDateTimeEdit18" DataField="SealIssue" ></px:PXDateTimeEdit>
	<px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit19" DataField="AmountToWords" ></px:PXTextEdit>
                            <px:PXLayoutRule runat="server" ID="PXLayoutTimbre" StartColumn="True"></px:PXLayoutRule>
                            <px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" GroupCaption="Timbre Fiscal Digital" runat="server" ID="PXLayoutFiscal" StartGroup="True"></px:PXLayoutRule>
                            <px:PXTextEdit runat="server" ID="CstPXTextEdit13" DataField="Uuid"></px:PXTextEdit>
                            <px:PXDateTimeEdit Size="m" runat="server" ID="CstPXDateTimeEdit14" DataField="SealDate"></px:PXDateTimeEdit>
                            <px:PXLayoutRule GroupCaption="C&amp;Oacute;DIGO QR" ColumnWidth="200" runat="server" ID="PEFEQR" StartGroup="True">
                            </px:PXLayoutRule>
                            <px:PXImageView runat="server" Width="200px" Height="200px" DataField="QrCodeImg" ID="edQrCodeImg" Style='width: 200px; height: 200px;' ></px:PXImageView>
	<px:PXLayoutRule runat="server" ID="CstPXLayoutRule26" StartColumn="True" ></px:PXLayoutRule>
	<px:PXLayoutRule ControlSize="XM" LabelsWidth="SM" GroupCaption="CANCELACION" runat="server" ID="CstPXLayoutRule27" StartGroup="True" ></px:PXLayoutRule>
                            <px:PXDateTimeEdit runat="server" ID="CstPXDateTimeEdit10" DataField="CancelDate"></px:PXDateTimeEdit>
	<px:PXTextEdit runat="server" ID="CstPXTextEdit29" DataField="CancelUUID" ></px:PXTextEdit>
	<px:PXDropDown Enabled="False" runat="server" ID="CstPXDropDown28" DataField="CancelReason" ></px:PXDropDown>
	<px:PXTextEdit Enabled="False" runat="server" ID="CstPXTextEdit30" DataField="ReplacementFolio" ></px:PXTextEdit></Template>
                    </px:PXFormView>
                </Template>
            </px:PXTabItem>
	<px:PXTabItem Text="Documentos Relacionados" >
		<Template>
			<px:PXGrid DataSourceID="ds" SyncPosition="True" SkinID="DetailsInTab" Width="100%" Height="300px" AllowPaging="True" AutoAdjustColumns="True" runat="server" ID="CstPXGrid40">
				<Levels>
					<px:PXGridLevel DataMember="RelatedDocuments" >
						<Columns>
							<px:PXGridColumn CommitChanges="" DataField="RefNbrRela" Width="140" ></px:PXGridColumn>
							<px:PXGridColumn DataField="DocTypeRela" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="Uuid" Width="180" ></px:PXGridColumn>
							<px:PXGridColumn CommitChanges="True" DataField="UsrPEFEreasons" Width="70" ></px:PXGridColumn>
							<px:PXGridColumn DataField="UsrPEFEDescripcion" Width="70" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem></Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150"></AutoSize>
    </px:PXTab>
	<px:PXSmartPanel AcceptButtonID="CancelStampButtonOK" runat="server" ID="CstSmartPanel31" Caption="Cancelacion" CaptionVisible="True" LoadOnDemand="True" Key="popUpCancelStamp" AutoReload="True" AutoRepaint="True" >
		<px:PXFormView DataMember="popUpCancelStamp" RenderStyle="Simple" runat="server" ID="CstFormView32" >
			<Template>
				<px:PXLayoutRule runat="server" ID="CstPXLayoutRule35" StartRow="True" ></px:PXLayoutRule>
				<px:PXLabel Text="Seleccione un motivo de cancelaci&amp;#243;n y folio de sustituci&amp;#243;n en caso de ser necesario." runat="server" ID="CstLabel36" ></px:PXLabel>
				<px:PXDropDown runat="server" ID="CstPXDropDown37" DataField="TempCancelReason" ></px:PXDropDown>
				<px:PXSelector runat="server" ID="CstPXSelector38" DataField="TempReplacementFolio" ></px:PXSelector></Template></px:PXFormView>
		<px:PXPanel RenderStyle="Simple" runat="server" ID="CancelStampButtons">
			<px:PXButton DialogResult="OK" Text="OK" runat="server" ID="CancelStampButtonOK" ></px:PXButton></px:PXPanel></px:PXSmartPanel></asp:Content>

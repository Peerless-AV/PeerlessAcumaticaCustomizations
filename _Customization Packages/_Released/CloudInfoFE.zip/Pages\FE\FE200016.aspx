<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200016.aspx.cs" Inherits="Page_FE200016" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFETypeTaxSATMaint"
        PrimaryView="taxes"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid FastFilterFields="CodTaxCD,Description" AllowSearch="True" AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="taxes">
			    <Columns>
				<px:PXGridColumn DataField="CodTaxCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Description" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="Retention" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn TextAlign="Center" Type="CheckBox" DataField="Transfer" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Localfederal" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="StartDate" Width="90" />
				<px:PXGridColumn DataField="EndDate" Width="90" /></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" ></Mode></px:PXGrid>
</asp:Content>

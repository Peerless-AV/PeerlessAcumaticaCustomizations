<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE101000.aspx.cs" Inherits="Page_FE101000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFESetupMaint"
        PrimaryView="Setup"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView TabIndex="100" ID="form" runat="server" DataSourceID="ds" DataMember="Setup" Width="100%" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule runat="server" StartRow="True" GroupCaption="PROVEEDOR" ControlSize="M" ID="PXLayoutRule1" ></px:PXLayoutRule>
			<px:PXDropDown runat="server" CommitChanges="True" DataField="Provider" ID="CstPXDropDown33" ></px:PXDropDown>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit27" DataField="UserProd" ></px:PXTextEdit>
			<px:PXTextEdit TextMode="Password" runat="server" ID="PwdProd" DataField="PwdProd" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit42" DataField="ApiKey" ></px:PXTextEdit>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox15" DataField="TrialMode" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" StartColumn="True" GroupCaption="Version" ID="CstPXLayoutRule53" ></px:PXLayoutRule>
			<px:PXTextEdit runat="server" LabelWidth="95" Size="S" DataField="Version" ID="CstPXTextEdit52" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" StartRow="True" GroupCaption="Timbrado" ControlSize="M" ID="CstPXLayoutRule43" ></px:PXLayoutRule>
			<px:PXCheckBox Enabled="False" runat="server" DataField="AutoSign" ID="CstPXCheckBox50" ></px:PXCheckBox>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit17" DataField="AdjHour" ></px:PXNumberEdit>
			<px:PXLayoutRule runat="server" StartRow="True" GroupCaption="CONFIGURACI&amp;oacute;N DE ARCHIVOS" ID="CstPXLayoutRule59" ></px:PXLayoutRule>
			<px:PXMaskEdit runat="server" DataField="FilesName" ID="CstPXMaskEdit60" ></px:PXMaskEdit>
			<px:PXLabel Text="FD: Folio Factura" runat="server" ID="CstLabel2" ></px:PXLabel>
			<px:PXLabel Text="CC: Clave Cliente" runat="server" ID="CstLabel3" ></px:PXLabel>
			<px:PXLabel Text="RC: RFC Cliente" runat="server" ID="CstLabel4" ></px:PXLabel>
			<px:PXLabel Text="NC: Nombre Cliente" runat="server" ID="CstLabel5" ></px:PXLabel>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox40" DataField="EnableSeparateSeries" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox41" DataField="EnableRemoveSeries" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule11" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLabel runat="server" ID="CstLabel12" ></px:PXLabel>
			<px:PXLabel runat="server" ID="CstLabel13" ></px:PXLabel>
			<px:PXLabel Text="RE: RFC Emisor" runat="server" ID="CstLabel6" ></px:PXLabel>
			<px:PXLabel Text="NE: Nombre Emisor" runat="server" ID="CstLabel7" ></px:PXLabel>
			<px:PXLabel Text="FT: Fecha Timbrado" runat="server" ID="CstLabel8" ></px:PXLabel>
			<px:PXLabel Text="UU: Uuid" runat="server" ID="CstLabel9" ></px:PXLabel>
			<px:PXLayoutRule runat="server" StartRow="True" GroupCaption="COMPLEMENTO DE PAGOS" ControlSize="M" ID="CstPXLayoutRule58" ></px:PXLayoutRule>
			<px:PXSelector runat="server" DataField="PaymentRefNbr" ID="CstPXSelector57" ></px:PXSelector>
			<px:PXSelector runat="server" ID="CstPXSelector14" DataField="PaymentNotifID" ></px:PXSelector>
			<px:PXLayoutRule EndGroup="True" ControlSize="M" ColumnWidth="330px" GroupCaption="Configuraci&amp;oacute;n de art&amp;Iacute;culos" runat="server" ID="PXLayoutRuleCheck" StartRow="True" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox19" DataField="ChkItem" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule29" StartRow="True" ColumnWidth="330px" ControlSize="M" EndGroup="True" GroupCaption="Configuraci&amp;oacute;n de Complemento Carta Porte" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox31" DataField="CarrierCustomer" ></px:PXCheckBox>
			<px:PXSelector runat="server" ID="CstPXSelector33" DataField="UnitMeasurement" ></px:PXSelector>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox35" DataField="EnableFractionPetition" ></px:PXCheckBox>
            <px:PXLabel runat="server" ID="CstLabel36" Text="* Articulo NO inventariables" ></px:PXLabel>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule34" StartRow="True" GroupCaption="Configuraci&amp;oacute;n de operaci&amp;oacute;n" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox38" DataField="BUsoInfGlobal" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox36" DataField="BCtaTerceros" ></px:PXCheckBox>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox37" DataField="BFacAtrAdq" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule42" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule44" StartGroup="True" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox44" DataField="EnableDonat" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule45" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule46" StartGroup="True" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox47" DataField="EnableIedu" ></px:PXCheckBox>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule48" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule49" StartGroup="True" ></px:PXLayoutRule>
			<px:PXCheckBox runat="server" ID="CstPXCheckBox45" DataField="UsrFEEnableLeyendasFiscales" />
			<px:PXLayoutRule GroupCaption="Configuraci&amp;oacute;n aws s3" ControlSize="M" ColumnWidth="250px" runat="server" ID="CstPXLayoutRule20" StartRow="True" ></px:PXLayoutRule>
			<px:PXTextEdit runat="server" ID="AccessKey" DataField="AccessKey" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="SecretKey" DataField="SecretKey" ></px:PXTextEdit>
			<px:PXDropDown runat="server" ID="Region" DataField="Region" ></px:PXDropDown>
			<px:PXMaskEdit runat="server" ID="Repository" DataField="Repository" ></px:PXMaskEdit>
			<px:PXMaskEdit runat="server" ID="DirectoryName" DataField="DirectoryName" ></px:PXMaskEdit></Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView>
</asp:Content>


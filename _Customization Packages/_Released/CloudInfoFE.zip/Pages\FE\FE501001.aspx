<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE501001.aspx.cs" Inherits="Page_FE501001" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource SkinID="" ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CI.Objects.FE.DW.FEDownloadCFDIProcess"
        PrimaryView="Filter"
        >
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="ViewDocument" Visible="false" DependOnGrid="grid" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%" AllowAutoHide="False" TabIndex="2300">
		<Template>
			<px:PXLayoutRule runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXDropDown runat="server" ID="CstPXDropDown1" DataField="Action" CommitChanges="true"></px:PXDropDown>
		</Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid TabIndex="4500" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="PrimaryInquire" SyncPosition="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataMember="Documents">
			    <Columns>
				    <px:PXGridColumn CommitChanges="True" Type="CheckBox" TextAlign="Center" DataField="Selected" Width="60" AllowCheckAll="True"></px:PXGridColumn>
				    <px:PXGridColumn DataField="TipoDoc" Width="140" ></px:PXGridColumn>
				    <px:PXGridColumn DataField="Referencia" Width="140" LinkCommand="ViewDocument"></px:PXGridColumn>
				    <px:PXGridColumn DataField="Rfc" Width="220" ></px:PXGridColumn>
				    <px:PXGridColumn DataField="Nombre" Width="280" ></px:PXGridColumn>
				    <px:PXGridColumn DataField="Monto" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn TimeMode="False" DataField="SealDate_Date" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Uuid" Width="220" /></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar PagerVisible="Bottom">
        <PagerSettings Mode="NumericCompact" />
    </ActionBar>
	</px:PXGrid>
</asp:Content>

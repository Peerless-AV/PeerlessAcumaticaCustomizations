<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200022.aspx.cs" Inherits="Page_FE200022" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEDangerousMaterialSATMaint"
        PrimaryView="DangerousMaterial"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" AllowSearch="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="DangerousMaterial">
			    <Columns>
				<px:PXGridColumn DataField="DangerousMaterialCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Description" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Division" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SecondaryDanger" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="TechnicalName" Width="70" />
				<px:PXGridColumn DataField="StartDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="EndDate" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowAddNew="True" />
		<Mode AllowDelete="True" />
		<Mode AllowUpdate="True" />
		<Mode AllowUpload="True" /></px:PXGrid>
</asp:Content>

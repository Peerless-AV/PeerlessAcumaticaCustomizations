<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE200011.aspx.cs" Inherits="Page_FE200011" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEZipCodeSATMaint"
        PrimaryView="ZipCodeSAT"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid FastFilterFields="ZipCodeCD,State,Municipality" StatusField="Erpmatica" TabIndex="100" AdjustPageSize="Auto" AllowPaging="True" AutoAdjustColumns="True" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="ZipCodeSAT">
			    <Columns>
				<px:PXGridColumn DataField="ZipCodeCD" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="State" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Municipality" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Location" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="BorderStripStimulus" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="StartDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="EndDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="TimeZoneDescription" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="MonthSummerTimeStart" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="StartDaySummerTime" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SummerTimeDifference" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="MonthStartWinterHours" Width="140" />
				<px:PXGridColumn DataField="StartDayWinterHours" Width="140" />
				<px:PXGridColumn DataField="WinterTimeDifference" Width="70" /></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" ></Mode></px:PXGrid>
</asp:Content>

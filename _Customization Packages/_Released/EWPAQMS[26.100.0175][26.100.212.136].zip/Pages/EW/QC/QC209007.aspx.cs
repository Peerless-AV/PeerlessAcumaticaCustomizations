﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_QC209007 : PX.Web.UI.PXPage {
    protected void Page_Init(object sender, EventArgs e)
    {

    }
}
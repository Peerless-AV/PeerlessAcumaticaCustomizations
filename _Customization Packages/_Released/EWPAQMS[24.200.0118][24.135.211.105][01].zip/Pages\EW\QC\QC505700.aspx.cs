using EW.QC;
using PX.Data;
using System;
using System.Drawing;
using System.Web.UI.WebControls;

public partial class Page_QC505700:PX.Web.UI.PXPage {
	protected void Page_Load(object sender, EventArgs e) {
		EWQCStabilityDataProcess processGraph = PXGraph.CreateInstance<EWQCStabilityDataProcess>();
		processGraph.Stablitydata();
	}
}

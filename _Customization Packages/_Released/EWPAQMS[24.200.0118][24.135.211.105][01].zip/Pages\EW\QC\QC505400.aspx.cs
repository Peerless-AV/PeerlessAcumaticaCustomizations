using System;
using System.Drawing;
using System.Web.UI.WebControls;

public partial class Page_QC505400 : PX.Web.UI.PXPage {
    protected void Page_Init(object sender, EventArgs e)
    {
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        AddStyle("rowred", "Red", "Black", false);
        AddStyle("rowgreen", "forestgreen", "Black", false);
        AddStyle("rowyellow", "Yellow", "Black", false);
        AddStyle("rowblank", "White", "Black", false);
        AddStyle("textred", "White", "Red", false);
    }

    private void AddStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor))
            style.BackColor = Color.FromName(backColor + " !important");

        if (!string.IsNullOrEmpty(foreColor))
            style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        if (e.Row.Cells["RetestStatus"] != null)
        {
            Object value = e.Row.Cells["RetestStatus"].Value;
            if (value != null && Convert.ToString(value) == EW.QC.QCRetestStatus.DueToday)
                e.Row.Cells["RetestStatus"].Style.CssClass = "rowred";
            else if (value != null && Convert.ToString(value) == EW.QC.QCRetestStatus.Upcoming)
                e.Row.Cells["RetestStatus"].Style.CssClass = "rowyellow";
            else if (value != null && Convert.ToString(value) == EW.QC.QCRetestStatus.Overdue)
                e.Row.Cells["RetestStatus"].Style.CssClass = "rowred";
        }

        DateTime? value1 = Convert.ToDateTime(e.Row.Cells["LotExpiryDate"].Value);
        if (value1 != null && value1 < DateTime.Today && value1 != Convert.ToDateTime("01/01/0001"))
            e.Row.Cells["LotExpiryDate"].Style.CssClass = "textred";
    }

}

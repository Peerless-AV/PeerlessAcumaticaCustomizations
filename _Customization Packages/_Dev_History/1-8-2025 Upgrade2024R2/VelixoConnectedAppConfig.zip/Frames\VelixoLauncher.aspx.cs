using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using PX.Common;
using PX.Data;
using PX.SM;
using PX.Web.Controls.Wiki;
using PX.Web.UI;

public partial class Page_Show : PXPage
{
    private static readonly string templateWorkbookUri = "https://secure.velixo.com/egg/velixo-template.xlsx";
    private static readonly string sharedStringsEntryName = "sharedStrings";
    private static readonly string instructionsTemplateString = "{{instructions}}";

    protected void Page_Init(object sender, EventArgs e)
    {
        if (Request.QueryString["action"] != "download")
        {
            return;
        }

        byte[] data = GenerateNewFile();

        Response.ContentType = "application/octet-stream";
        Response.Clear();
        Response.BufferOutput = true;
        Response.AppendHeader("Content-Disposition", $"attachment; filename=Velixo.xlsx");
        Response.BinaryWrite(data);
        Response.Flush();
        Response.SuppressContent = true;
    }

    private static string UnescapeWithPlus(string source) => Uri.UnescapeDataString(source).Replace("+", " ");

    private byte[] GenerateNewFile()
    {
        var websiteDomainRoot = Request.GetWebsiteUrl();
        websiteDomainRoot = websiteDomainRoot.EndsWith("/") ? websiteDomainRoot.Substring(0, websiteDomainRoot.Length - 1) : websiteDomainRoot;

        var requestPath = HttpContext.Current.Request.Url.AbsolutePath;

        var pathToSiteRoot = Regex.Replace(requestPath, @"/frames/.*", "", RegexOptions.IgnoreCase);
        pathToSiteRoot = pathToSiteRoot.StartsWith("/") ? pathToSiteRoot : $"/{pathToSiteRoot}";

        var connectionUri = $"{websiteDomainRoot}{pathToSiteRoot}";

        var connectionType = "acumatica";
        var connectionTenant = PXAccess.GetCompanyName();

        string workbookType = "blank-workbook";

        var instructionsObjectBuilder = new StringBuilder();

        instructionsObjectBuilder.Append("{");
        instructionsObjectBuilder.Append($"\"connectionUri\":\"{connectionUri}\"");
        instructionsObjectBuilder.Append($",\"connectionType\":\"{connectionType}\"");
        instructionsObjectBuilder.Append($",\"connectionTenant\":\"{connectionTenant}\"");
        instructionsObjectBuilder.Append($",\"workbookType\":\"{workbookType}\"");
        instructionsObjectBuilder.Append("}");

        // Download the latest version of the egg file template from Velixo.
        // -
        var request = (HttpWebRequest)WebRequest.Create(templateWorkbookUri);

        using (var response = (HttpWebResponse)request.GetResponse())
        {
            using (var inputStream = response.GetResponseStream())
            {
                using (var outputStream = new MemoryStream())
                {
                    using (var sourceArchive = new ZipArchive(inputStream, ZipArchiveMode.Read))
                    {
                        using (var targetArchive = new ZipArchive(outputStream, ZipArchiveMode.Create))
                        {
                            foreach (var sourceEntry in sourceArchive.Entries)
                            {
                                var targetEntry = targetArchive.CreateEntry(sourceEntry.FullName);

                                using (var sourceEntryStream = sourceEntry.Open())
                                {
                                    using (var targetEntryStream = targetEntry.Open())
                                    {
                                        if (sourceEntry.Name.Contains(sharedStringsEntryName))
                                        {
                                            using (var sourceEntryReader = new StreamReader(sourceEntryStream))
                                            {
                                                var contents = sourceEntryReader.ReadToEnd();

                                                using (var targetEntryWriter = new StreamWriter(targetEntryStream))
                                                {
                                                    targetEntryWriter.Write(contents.Replace(instructionsTemplateString, instructionsObjectBuilder.ToString()));
                                                }
                                            }
                                        }
                                        else
                                        {
                                            sourceEntryStream.CopyTo(targetEntryStream);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    return outputStream.ToArray();
                }
            }
        }
    }
}
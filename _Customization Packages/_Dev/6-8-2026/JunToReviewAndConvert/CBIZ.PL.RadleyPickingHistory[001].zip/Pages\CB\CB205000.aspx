<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CB205000.aspx.cs" Inherits="Page_CB205000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CBIZ.PL.RadleyPickingHistory.CBRadleyPickingHistMaint"
        PrimaryView="MasterView"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="MasterView">
			    <Columns>
				<px:PXGridColumn DataField="TaskID" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="TaskType" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LoginID" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DisplayFormat="G" DataField="StartTime" Width="150" ></px:PXGridColumn>
				<px:PXGridColumn DisplayFormat="G" DataField="EndTime" Width="150" ></px:PXGridColumn>
				<px:PXGridColumn DataField="TotalTime" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ShipmentNbr" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="ShipmentLineNbr" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Quantity" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="OrderType" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="OrderNbr" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="Warehouse" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LocationID" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn Type="CheckBox" DataField="DNSE" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomerID" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CreatedByID" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CreatedDateTime" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode AllowUpload="True" />
		<Mode InitNewRow="True" /></px:PXGrid>
</asp:Content>
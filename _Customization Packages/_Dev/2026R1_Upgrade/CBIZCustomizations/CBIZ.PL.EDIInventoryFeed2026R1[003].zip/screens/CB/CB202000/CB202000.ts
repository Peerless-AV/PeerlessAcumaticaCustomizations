
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,

} from "client-controls";

@graphInfo({ graphType: "CBIZ.PL.EDIInventoryFeed.CBEDIInventoryFeedMaint", primaryView: "FeedCustomer" })
export class CB202000 extends PXScreen {
  FeedCustomer = createSingle(CBEDIInventoryFeedCustomer);
  FeedItems = createCollection(CBEDIInventoryFeedItem);
}
// Views

export class CBEDIInventoryFeedCustomer extends PXView {
  CustomerID: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class CBEDIInventoryFeedItem extends PXView {
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 280,
  })
  Descr: PXFieldState;
  @columnConfig({
    width: 120,
  })
  RecordTag: PXFieldState;
  @columnConfig({
    width: 180,
  })
  CustomerPartNo: PXFieldState;
  @columnConfig({
    width: 70,
  })
  LineNbr: PXFieldState;
  @columnConfig({
    width: 180,
  })
  CustomerSKU: PXFieldState;
  @columnConfig({
    width: 70,
  })
  PartNoStatus: PXFieldState;
  @columnConfig({
    width: 60,
  })
  AvailableFlag: PXFieldState;
  @columnConfig({
    width: 100,
  })
  QtyAvailable: PXFieldState;
  @columnConfig({
    width: 90,
  })
  FutureAvailableDate: PXFieldState;
  @columnConfig({
    width: 100,
  })
  FutureAvailableQty: PXFieldState;
  @columnConfig({
    width: 100,
  })
  UnitPrice: PXFieldState;
  @columnConfig({
    width: 140,
  })
  PriceCode: PXFieldState;
  @columnConfig({
    width: 60,
  })
  DiscontinueFlag: PXFieldState;
  @columnConfig({
    width: 70,
  })
  LeadTimeDays: PXFieldState;
}

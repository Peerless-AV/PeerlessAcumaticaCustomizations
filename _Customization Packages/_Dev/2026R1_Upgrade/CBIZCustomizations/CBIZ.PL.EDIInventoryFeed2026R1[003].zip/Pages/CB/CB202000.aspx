<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CB202000.aspx.cs" Inherits="Page_CB202000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CBIZ.PL.EDIInventoryFeed.CBEDIInventoryFeedMaint"
        PrimaryView="FeedCustomer"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="FeedCustomer" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXSegmentMask runat="server" ID="CstPXSegmentMask1" DataField="CustomerID" /></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Details" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="FeedItems">
			    <Columns>
				<px:PXGridColumn DataField="InventoryID" Width="70" CommitChanges="True" />
				<px:PXGridColumn DataField="Descr" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="RecordTag" Width="120" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomerPartNo" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LineNbr" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CustomerSKU" Width="180" ></px:PXGridColumn>
				<px:PXGridColumn DataField="PartNoStatus" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn Type="CheckBox" DataField="AvailableFlag" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="QtyAvailable" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="FutureAvailableDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="FutureAvailableQty" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="UnitPrice" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="PriceCode" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn Type="CheckBox" DataField="DiscontinueFlag" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LeadTimeDays" Width="70" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>
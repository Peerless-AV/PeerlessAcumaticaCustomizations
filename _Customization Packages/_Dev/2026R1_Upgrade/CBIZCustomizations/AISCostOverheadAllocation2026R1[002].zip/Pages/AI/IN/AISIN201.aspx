<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="AISIN201.aspx.cs" Inherits="Page_AISIN201" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" PrimaryView="LoadRecords" TypeName="AIS.Acumatica.IN.INOverheadMaint" AttributesFound="False" EnableAttributes="False" SuspendUnloading="False">
	    <CallbackCommands>
            <px:PXDSCallbackCommand Name="Save" CommitChanges="True" ></px:PXDSCallbackCommand>  
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="Primary" TabIndex="2100" SyncPosition="True">
		<Levels>
			<px:PXGridLevel SortOrder="OverheadCD,Element" DataKeyNames="OverheadCD" DataMember="LoadRecords">
			    <Columns>  
                    <px:PXGridColumn DataField="OverheadCD" Width="200px">
                    </px:PXGridColumn> 
                    <px:PXGridColumn DataField="Element" Width="150px">
                    </px:PXGridColumn> 
                    <px:PXGridColumn DataField="Descr" Width="300px">
                    </px:PXGridColumn> 
                    <px:PXGridColumn DataField="OvhType" Width="150px">
                    </px:PXGridColumn> 
                    <px:PXGridColumn DataField="OvhValue" Width="150px">
                    </px:PXGridColumn> 
                </Columns>
			</px:PXGridLevel>
		</Levels>
		 <Layout FormViewHeight="250px" ></Layout>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
        <ActionBar PagerVisible="Bottom">
            <PagerSettings Mode="NumericCompact" />
        </ActionBar>
        <Mode AllowFormEdit="True" AllowUpload="True" ></Mode>
        <CallbackCommands>
            <Save PostData="Content" ></Save>
        </CallbackCommands>
	</px:PXGrid>
</asp:Content>
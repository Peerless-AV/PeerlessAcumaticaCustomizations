<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="AISIN501.aspx.cs" Inherits="Page_AISIN501" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="Filter" TypeName="AIS.Acumatica.IN.INCalculatePendingCostMaint">
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" Style="z-index: 100" Width="100%" DataMember="Filter" Caption="Selection" 
        TabIndex="6100" DataSourceID="ds">
        <Activity HighlightColor="" SelectedColor="" Width="" Height=""></Activity>
		<Template> 
            <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartColumn="True" StartRow="True" ControlSize="S">
            </px:PXLayoutRule>  
            <px:PXSelector ID="edUsrAISOverheadCD" runat="server" DataField="UsrAISOverheadCD" CommitChanges="true">
            </px:PXSelector> 
            <px:PXDateTimeEdit ID="edUsrAISLastModifiedDate" runat="server" DataField="UsrAISLastModifiedDate" CommitChanges="true">
            </px:PXDateTimeEdit>
            <px:PXLayoutRule ID="PXLayoutRule2" runat="server" StartColumn="True" ControlSize="S">
            </px:PXLayoutRule>
            <px:PXDateTimeEdit ID="edUsrAISPendingCostDate" runat="server" DataField="UsrAISPendingCostDate" CommitChanges="true">
            </px:PXDateTimeEdit>
        </Template>
	</px:PXFormView>
</asp:Content> 

<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100" 
		Width="100%" Height="150px" SkinID="DetailsWithFilter" TabIndex="-29936" TemporaryFilterCaption="Filter Applied" FilesIndicator="false" NoteIndicator="false">
        
		<Levels>
			<px:PXGridLevel DataKeyNames="InventoryID, InventoryID" DataMember="ItemList">
			    <Columns>  
                    <px:PXGridColumn AllowCheckAll="True" DataField="Selected" TextAlign="Center" Type="CheckBox" Width="60px"/> 
                    <px:PXGridColumn DataField="InventoryCD" Width="150px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ItemClassID" Width="200px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="StkItem" Width="90px" Type="CheckBox" TextAlign="Center">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="OverheadCD" Width="130px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="UsrAISMaterialCost" Width="150px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="PendingStdCost" Width="150px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LastModifiedDateTimeExt" Width="150px">
                    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
        <ActionBar PagerVisible="Bottom">
            <Actions> 
                <AddNew Enabled="False" /> 
                <Delete Enabled="False" /> 
                <EditRecord Enabled="true" />
            </Actions> 
            <PagerSettings Mode="NumericCompact" />
        </ActionBar>
	</px:PXGrid>
</asp:Content>
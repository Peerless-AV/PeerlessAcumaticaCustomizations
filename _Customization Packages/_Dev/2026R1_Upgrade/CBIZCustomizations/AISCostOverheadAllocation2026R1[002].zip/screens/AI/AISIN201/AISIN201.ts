
import {
  createCollection,
  PXScreen,
  graphInfo,
  PXActionState,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "AIS.Acumatica.IN.INOverheadMaint", primaryView: "LoadRecords" })
export class AISIN201 extends PXScreen {
  Save: PXActionState;

  LoadRecords = createCollection(AISINOverhead);
}
// Views

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class AISINOverhead extends PXView {
  @columnConfig({
    width: 200,
  })
  OverheadCD: PXFieldState;
  @columnConfig({
    width: 150,
  })
  Element: PXFieldState;
  @columnConfig({
    width: 300,
  })
  Descr: PXFieldState;
  @columnConfig({
    width: 150,
  })
  OvhType: PXFieldState;
  @columnConfig({
    width: 150,
  })
  OvhValue: PXFieldState;
}

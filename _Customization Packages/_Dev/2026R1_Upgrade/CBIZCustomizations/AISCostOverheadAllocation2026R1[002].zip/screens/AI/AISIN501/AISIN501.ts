import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  viewInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "AIS.Acumatica.IN.INCalculatePendingCostMaint", primaryView: "Filter" })
export class AISIN501 extends PXScreen {
  @viewInfo({ containerName: "Selection" })
  Filter = createSingle(INFilter);
  ItemList = createCollection(AISINItemPending);
}
// Views

export class INFilter extends PXView {
  UsrAISOverheadCD: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrAISLastModifiedDate: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrAISPendingCostDate: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class AISINItemPending extends PXView {
  @columnConfig({
    width: 60,
  })
  Selected: PXFieldState;
  @columnConfig({
    width: 150,
  })
  InventoryCD: PXFieldState;
  @columnConfig({
    width: 200,
  })
  ItemClassID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StkItem: PXFieldState;
  @columnConfig({
    width: 130,
  })
  OverheadCD: PXFieldState;
  @columnConfig({
    width: 150,
  })
  UsrAISMaterialCost: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 150,
  })
  PendingStdCost: PXFieldState;
  @columnConfig({
    width: 150,
  })
  LastModifiedDateTimeExt: PXFieldState;
}

﻿import {
  PXFieldState,
  
} from "client-controls";
import { IN202000, ItemSettings } from "src/screens/IN/IN202000/IN202000";

export interface IN202000_AISCostOverheadAllocation_converted extends IN202000 {}

export class IN202000_AISCostOverheadAllocation_converted {}

export interface IN202000_ItemSettings_AISCostOverheadAllocation_converted extends ItemSettings {}
export class IN202000_ItemSettings_AISCostOverheadAllocation_converted {
  UsrAISMaterialCost: PXFieldState;
  UsrAISOverheadID: PXFieldState;
}

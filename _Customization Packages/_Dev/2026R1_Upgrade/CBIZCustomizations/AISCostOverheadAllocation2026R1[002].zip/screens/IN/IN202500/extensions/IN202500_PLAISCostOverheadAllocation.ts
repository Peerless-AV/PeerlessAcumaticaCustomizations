﻿import {
  PXFieldState,
  
} from "client-controls";
import { IN202500, ItemSettings } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_AISCostOverheadAllocation_converted extends IN202500 {}

export class IN202500_AISCostOverheadAllocation_converted {}

export interface IN202500_ItemSettings_AISCostOverheadAllocation_converted extends ItemSettings {}
export class IN202500_ItemSettings_AISCostOverheadAllocation_converted {
  
  UsrAISMaterialCost: PXFieldState;
  UsrAISOverheadID: PXFieldState;

}

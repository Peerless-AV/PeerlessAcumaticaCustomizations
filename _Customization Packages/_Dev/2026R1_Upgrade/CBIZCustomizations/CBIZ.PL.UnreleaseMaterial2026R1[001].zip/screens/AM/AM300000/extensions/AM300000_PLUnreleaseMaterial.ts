﻿import {
    PXFieldState,
    PXActionState,
    PXFieldOptions,
    
} from "client-controls";
import { AM300000, AMBatch, AMMTran } from "src/screens/AM/AM300000/AM300000";

export interface AM300000_PLUnreleaseMaterial extends AM300000 {}
export class AM300000_PLUnreleaseMaterial {}

export interface AM300000_AMBatch_PLUnreleaseMaterial extends AMBatch {}
export class AM300000_AMBatch_PLUnreleaseMaterial {
    UsrUnreleaseBatNbr: PXFieldState;
    UsrUnreleaseDocType: PXFieldState;
}


export interface AM300000_AMMTran_PLUnreleaseMaterial extends AMMTran {}
export class AM300000_AMMTran_PLUnreleaseMaterial {
    // Toolbar actions added by the customization
    SelectAll:   PXActionState;
    UnselectAll: PXActionState;

    // New grid columns
    UsrUnreleaseSelected: PXFieldState<PXFieldOptions.CommitChanges>;
    UsrUnreleaseQty: PXFieldState<PXFieldOptions.CommitChanges>;
}
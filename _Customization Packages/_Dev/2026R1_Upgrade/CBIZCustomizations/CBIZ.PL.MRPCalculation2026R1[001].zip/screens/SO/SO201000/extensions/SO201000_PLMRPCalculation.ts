import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
 
} from "client-controls";
import { SO201000, SOOrderTypeHeaderSettings } from "src/screens/SO/SO201000/SO201000";

export interface SO201000_PLMRPCalculation extends SO201000 {}

export class SO201000_PLMRPCalculation {}

export interface SO201000_SOOrderTypeHeaderSettings_PLMRPCalculation extends SOOrderTypeHeaderSettings {}
export class SO201000_SOOrderTypeHeaderSettings_PLMRPCalculation {
  @placeAfterProperty("EncryptAndPseudonymizePII")
  UsrExcludeFromMRP: PXFieldState;

}

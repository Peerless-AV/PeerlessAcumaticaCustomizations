import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  placeAfterProperty,
  columnConfig,
  GridPreset,
  PXFieldStateGeneric,
} from "client-controls";

import { SO301000, SOLine } from "src/screens/SO/SO301000/SO301000";

export interface SO301000_PLQtyOnLine extends SO301000 {}

export class SO301000_PLQtyOnLine {}

export interface SO301000_SOLine_PLQtyOnLine extends SOLine {}
export class SO301000_SOLine_PLQtyOnLine {
  @placeAfterProperty("InventoryID")
  @columnConfig({
    width: 100,
  })
  UsrQtyAvailable: PXFieldState;

  @placeAfterProperty("UsrQtyAvailable")
  RelatedItems: PXFieldState;

  @placeAfterProperty("BlanketOpenQty")
  UnshippedQty: PXFieldState;

  @placeAfterProperty("UnshippedQty")
  ShippedQty: PXFieldState;

  @placeAfterProperty("ShippedQty")
  OpenQty: PXFieldState;
}
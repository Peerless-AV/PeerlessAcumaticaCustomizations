import {
  PXFieldState,
  placeAfterProperty,
  columnConfig,
  
} from "client-controls";
import { SO302000, Transactions } from "src/screens/SO/SO302000/SO302000";

export interface SO302000_PLQtyOnLine extends SO302000 {}

export class SO302000_PLQtyOnLine {}

export interface SO302000_Transactions_PLQtyOnLine extends Transactions {}
export class SO302000_Transactions_PLQtyOnLine {
  @placeAfterProperty("InventoryID")
  @columnConfig({
    width: 100,
  })
  UsrQtyAvailable: PXFieldState;

  
}
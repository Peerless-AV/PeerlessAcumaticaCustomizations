﻿import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
 
} from "client-controls";
import { AM100000, Setup } from "src/screens/AM/AM100000/AM100000";

export interface AM100000_PLManufacturingFAB extends AM100000 {}

export class AM100000_PLManufacturingFAB {}

export interface AM100000_Setup_PLManufacturingFAB extends Setup {}
export class AM100000_Setup_PLManufacturingFAB {
  @placeAfterProperty("DefaultMPSTypeID")
  UsrDefaultFABOrderType: PXFieldState;

}

import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  placeAfterProperty,
  columnConfig,
  GridPreset,
  PXFieldStateGeneric,
} from "client-controls";

import { SO301000, SOLine, SOOrder } from "src/screens/SO/SO301000/SO301000";

export interface SO301000_PLEDISOLineustomFields extends SO301000 {}

export class SO301000_PLEDISOLineustomFields {}

export interface SO301000_SOLine_PLEDISOLineustomFields extends SOLine {}
export class SO301000_SOLine_PLEDISOLineustomFields {
  @placeAfterProperty("BlanketOpenQty")
  UnshippedQty: PXFieldState;

  @placeAfterProperty("OrchestrationPlanID")
  @columnConfig({
    width: 90,
  })
  UsrEDIPODate: PXFieldState;

  @columnConfig({
    width: 70,
  })
  UsrEDIPOLineNumber: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrEDIPrice: PXFieldState;

  @columnConfig({
    width: 180,
  })
  UsrWarrantyID: PXFieldState;

  @columnConfig({
    width: 220,
  })
  UsrUPCNo: PXFieldState;
}
export interface SO301000_SOOrder_PLEDISOLineustomFields extends SOOrder {}
export class SO301000_SOOrder_PLEDISOLineustomFields {
  @placeAfterProperty("DefaultSiteID")
  UsrEDIConfirmation: PXFieldState<PXFieldOptions.Disabled>;

}

import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
  
} from "client-controls";
import { GL401000, GLHistoryEnqFilter, GLHistoryEnquiryResult } from "src/screens/GL/GL401000/GL401000";

export interface GL401000_PLAccountCompareBudget extends GL401000 {}

export class GL401000_PLAccountCompareBudget {}

export interface GL401000_GLHistoryEnqFilter_PLAccountCompareBudget extends GLHistoryEnqFilter {}
export class GL401000_GLHistoryEnqFilter_PLAccountCompareBudget {
  
  UsrLedget2: PXFieldState<PXFieldOptions.CommitChanges>;
}
export interface GL401000_GLHistoryEnquiryResult_PLAccountCompareBudget extends GLHistoryEnquiryResult {}
export class GL401000_GLHistoryEnquiryResult_PLAccountCompareBudget {
  @placeAfterProperty("AccountClassID")
  @columnConfig({
    width: 100,
  })
  UsrSignEndBalance2: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrSignCuryEndBalance2: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrDifference: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrCuryDifference: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrPercentage: PXFieldState;
}

import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
  
} from "client-controls";
import { GL402000, Filter, EnqResult } from "src/screens/GL/GL402000/GL402000";

export interface GL402000_PLAccountCompareBudget extends GL402000 {}

export class GL402000_PLAccountCompareBudget {}

export interface GL402000_Filter_PLAccountCompareBudget extends Filter {}
export class GL402000_Filter_PLAccountCompareBudget {
 
  UsrLedget2: PXFieldState<PXFieldOptions.CommitChanges>;
}
export interface GL402000_EnqResult_PLAccountCompareBudget extends EnqResult {}
export class GL402000_EnqResult_PLAccountCompareBudget {
  @placeAfterProperty("CuryPtdSaldo")
  @columnConfig({
    width: 100,
  })
  UsrSignEndBalance2: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrSignCuryEndBalance2: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrDifference: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrCuryDifference: PXFieldState;

  @columnConfig({
    width: 100,
  })
  UsrPercentage: PXFieldState;
}

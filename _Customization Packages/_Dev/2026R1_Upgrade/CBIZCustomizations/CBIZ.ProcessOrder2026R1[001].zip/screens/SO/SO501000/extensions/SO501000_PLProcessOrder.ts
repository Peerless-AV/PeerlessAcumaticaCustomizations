import {
  PXFieldState,
  
  
} from "client-controls";
import { SO501000, Orders } from "src/screens/SO/SO501000/SO501000";

export interface SO501000_PLProcessOrder extends SO501000 {}

export class SO501000_PLProcessOrder {}

export interface SO501000_Orders_PLProcessOrder extends Orders {}
export class SO501000_Orders_PLProcessOrder {
  
  UsrCreditLimit: PXFieldState;
  UsrAvailableCredit: PXFieldState;

}

﻿
import { PXFieldState,
	placeAfterProperty,
	 columnConfig,
	 GridColumnShowHideMode,

} from "client-controls";

import { AR508000, ARInvoice } from "src/screens/AR/AR508000/AR508000";

export interface AR508000_PLPrintInvoice extends AR508000 {}

export class AR508000_PLPrintInvoice {}


export interface ARInvoice_PLPrintInvoice extends ARInvoice { }

export class ARInvoice_PLPrintInvoice {
	
  @placeAfterProperty("CustomerID_BAccountR_acctName")
  @columnConfig({
    width: 100,
    allowShowHide: GridColumnShowHideMode.True,
    hideViewLink: true,
  })
  UsrSiteID: PXFieldState;

  @placeAfterProperty("UsrSiteID")
  @columnConfig({
    width: 100,
    allowShowHide: GridColumnShowHideMode.True,
    hideViewLink: true,
  })
  TaxZoneID: PXFieldState;

}


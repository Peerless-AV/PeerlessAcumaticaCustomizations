import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
} from "client-controls";
import { SO501010, SalesAllocationsFilter, SalesAllocation } from "src/screens/SO/SO501010/SO501010";

export interface SO501010_PLManageSalesAllocation extends SO501010 {}

export class SO501010_PLManageSalesAllocation {}

export interface SO501010_SalesAllocationsFilter_PLManageSalesAllocation extends SalesAllocationsFilter {}
export class SO501010_SalesAllocationsFilter_PLManageSalesAllocation {
  @placeAfterProperty("CustomerID")
  UsrPartialAllocation: PXFieldState<PXFieldOptions.CommitChanges>;
}
export interface SO501010_SalesAllocation_PLManageSalesAllocation extends SalesAllocation {}
export class SO501010_SalesAllocation_PLManageSalesAllocation {
  @placeAfterProperty("RequestDate")
  @columnConfig({
    width: 60,
  })
  UsrPutAway: PXFieldState;

}

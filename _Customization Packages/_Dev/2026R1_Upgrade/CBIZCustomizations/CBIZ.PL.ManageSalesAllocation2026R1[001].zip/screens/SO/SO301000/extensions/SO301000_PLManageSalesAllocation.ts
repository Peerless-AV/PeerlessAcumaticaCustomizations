import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
  
} from "client-controls";

import { SO301000, SOLine } from "src/screens/SO/SO301000/SO301000";

export interface SO301000_PLManageSalesAllocation extends SO301000 {}

export class SO301000_PLManageSalesAllocation {}

export interface SO301000_SOLine_PLManageSalesAllocation extends SOLine {}
export class SO301000_SOLine_PLManageSalesAllocation {
  @placeAfterProperty("IsFree")
  @columnConfig({
    width: 60,
  })
  UsrPutAway: PXFieldState;

}

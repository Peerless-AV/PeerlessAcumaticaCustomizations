import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
  
  
} from "client-controls";
import { SO301000, SOLine, SOOrder } from "src/screens/SO/SO301000/SO301000";
import { Address } from "src/screens/common/form-address/form-address";

export interface SO301000_PLShippingInst extends SO301000 {}

export class SO301000_PLShippingInst {}

export interface SO301000_SOLine_PLShippingInst extends SOLine {}
export class SO301000_SOLine_PLShippingInst {
  @placeAfterProperty("BlanketOpenQty")
  UnshippedQty: PXFieldState;

  @placeAfterProperty("CuryUnitPrice")
  @columnConfig({
    width: 100,
  })
  UsrCIUnitCost: PXFieldState;

  RequestDate: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("ShipDate")
  @columnConfig({
    width: 90,
  })
  UsrLatestShipDate: PXFieldState;

}
export interface SO301000_SOOrder_PLShippingInst extends SOOrder {}
export class SO301000_SOOrder_PLShippingInst {
  UsrExported: PXFieldState;

  UsrInsideDelReq: PXFieldState;
  UsrLiftgateReq: PXFieldState;
  UsrSignatureReq: PXFieldState;
  UsrAppointmentRequired: PXFieldState;
  UsrPalletJack: PXFieldState;
  UsrLimitedAccess: PXFieldState;
  UsrGuaranteedRate: PXFieldState;

}



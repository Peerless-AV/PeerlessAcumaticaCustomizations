import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
} from "client-controls";
import { SO302000, SOShipmentHeader, Transactions, SOShipment } from "src/screens/SO/SO302000/SO302000";
import { Address } from "src/screens/common/form-address/form-address";

export interface SO302000_PLShippingInsts extends SO302000 {}

export class SO302000_PLShippingInsts {}

export interface SO302000_SOShipmentHeader_PLShippingInsts extends SOShipmentHeader {}
export class SO302000_SOShipmentHeader_PLShippingInsts {
  @placeAfterProperty("ShipDate")
  CreatedDateTime: PXFieldState;

  ConfirmationPrinted: PXFieldState;

  PickListPrinted: PXFieldState;

  LabelsPrinted: PXFieldState;

  UsrExportDPD: PXFieldState;

  UsrBillOfLading: PXFieldState;

  UsrTotalWeight: PXFieldState;

  UsrMstrTrckNbr: PXFieldState;
}
export interface SO302000_Transactions_PLShippingInsts extends Transactions {}
export class SO302000_Transactions_PLShippingInsts {
  
  UsrPicklistPrinted: PXFieldState;

  @columnConfig({
    width: 70,
  })
  UsrPicklistPrintedCnt: PXFieldState;
}
export interface SO302000_SOShipment_PLShippingInsts extends SOShipment {}
export class SO302000_SOShipment_PLShippingInsts {
  
  UsrInsideDelReq: PXFieldState;

  UsrLiftgateReq: PXFieldState;

  UsrSignatureReq: PXFieldState;

  UsrAppointmentRequired: PXFieldState;

  UsrPalletJack: PXFieldState;

  UsrLimitedAccess: PXFieldState;

  UsrGuaranteedRate: PXFieldState;

}

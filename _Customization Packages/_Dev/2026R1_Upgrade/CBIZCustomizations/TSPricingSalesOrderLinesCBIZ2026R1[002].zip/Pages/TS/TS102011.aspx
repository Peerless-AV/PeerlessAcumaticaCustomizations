<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="TS102011.aspx.cs" Inherits="Page_TS102011" Title="List Customer PriceGroup" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" TypeName="PricingSalesOrderLines.TSCustomerPriceGroupMaint" AttributesFound="False" EnableAttributes="False" SuspendUnloading="False" UDFTypeField="" PrimaryView="CustomerPriceGroup" >
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="Primary" TabIndex="3600">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataMember="CustomerPriceGroup">
			    <RowTemplate>
                    <px:PXSelector ID="edCustomerID" runat="server" DataField="CustomerID"  CommitChanges="True">
                    </px:PXSelector>
                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" IsClientControl="True">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edPriceClassID" runat="server" DataField="PriceClassID">
                    </px:PXSelector>
                    <px:PXSelector ID="edPriceGroupID" runat="server" DataField="PriceGroupID">
                    </px:PXSelector>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="CustomerID" CommitChanges="True" TextAlign="Right">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="PriceClassID" TextAlign="Right">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="PriceGroupID" TextAlign="Right">
                    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	    <Mode AllowUpload="True" />
	</px:PXGrid>
</asp:Content>

using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_TS102010 : PX.Web.UI.PXPage
{
	protected void Page_Init(object sender, EventArgs e)
	{
	}
}

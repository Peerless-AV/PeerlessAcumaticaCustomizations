<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="TS102010.aspx.cs" Inherits="Page_TS102010" Title="List PriceGroup" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" TypeName="PricingSalesOrderLines.TSPriceGroupMaint" AttributesFound="False" EnableAttributes="False" PrimaryView="PriceGroup" SuspendUnloading="False" UDFTypeField="" >
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="Primary" TabIndex="2300">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="RecID" DataMember="PriceGroup">
			    <RowTemplate>
                    <px:PXTextEdit ID="edPriceGroupCode" runat="server" AlreadyLocalized="False" DataField="PriceGroupCode" IsClientControl="True">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edPriceGroupDescription" runat="server" AlreadyLocalized="False" DataField="PriceGroupDescription" IsClientControl="True">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="PriceGroupCode" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="PriceGroupDescription" Width="280px">
                    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	    <Mode AllowUpload="True" />
	</px:PXGrid>
</asp:Content>

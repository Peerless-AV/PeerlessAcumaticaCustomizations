

import {
  createCollection,
  
  PXScreen,
  graphInfo,
 
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "PricingSalesOrderLines.TSPriceGroupMaint", primaryView: "PriceGroup" })
export class TS102010 extends PXScreen {
  PriceGroup = createCollection(TSPriceGroup);
}
// Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class TSPriceGroup extends PXView {
  @columnConfig({
    width: 180,
  })
  PriceGroupCode: PXFieldState;
  @columnConfig({
    width: 280,
  })
  PriceGroupDescription: PXFieldState;
}

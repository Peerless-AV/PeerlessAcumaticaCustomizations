﻿import {
  PXFieldState,
  placeAfterProperty,
  
} from "client-controls";
import { IN202500, ItemSettings } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_TSPricingSalesOrderLinesCBIZ2023R1_converted extends IN202500 {}

export class IN202500_TSPricingSalesOrderLinesCBIZ2023R1_converted {}

export interface IN202500_ItemSettings_TSPricingSalesOrderLinesCBIZ2023R1_converted extends ItemSettings {}
export class IN202500_ItemSettings_TSPricingSalesOrderLinesCBIZ2023R1_converted {
  @placeAfterProperty("ItemClassID")
  UsrPriceGroupID: PXFieldState;

    @placeAfterProperty("CountryOfOrigin")
  UsrAuthorization: PXFieldState;

  
}

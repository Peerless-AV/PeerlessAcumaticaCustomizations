﻿import {
  PXFieldState,
  placeAfterProperty,
  
} from "client-controls";
import { IN202000, ItemSettings } from "src/screens/IN/IN202000/IN202000";

export interface IN202000_TSPricingSalesOrderLinesCBIZ2023R1_converted extends IN202000 {}

export class IN202000_TSPricingSalesOrderLinesCBIZ2023R1_converted {}

export interface IN202000_ItemSettings_TSPricingSalesOrderLinesCBIZ2023R1_converted extends ItemSettings {}
export class IN202000_ItemSettings_TSPricingSalesOrderLinesCBIZ2023R1_converted {
  @placeAfterProperty("ItemClassID")
  UsrPriceGroupID: PXFieldState;

  @placeAfterProperty("NonStockShip")
  UsrAuthorization: PXFieldState;

  
}

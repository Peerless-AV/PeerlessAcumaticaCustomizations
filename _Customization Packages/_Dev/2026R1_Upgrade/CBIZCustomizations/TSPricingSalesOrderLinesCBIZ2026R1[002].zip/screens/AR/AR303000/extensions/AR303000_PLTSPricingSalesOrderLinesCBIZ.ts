import {
  PXFieldState,
  
} from "client-controls";
import { AR303000, Customer2 } from "src/screens/AR/AR303000/AR303000";

export interface AR303000_TSPricingSalesOrderLinesCBIZ2023R1_converted extends AR303000 {}

export class AR303000_TSPricingSalesOrderLinesCBIZ2023R1_converted {}

export interface AR303000_Customer2_TSPricingSalesOrderLinesCBIZ2023R1_converted extends Customer2 {}
export class AR303000_Customer2_TSPricingSalesOrderLinesCBIZ2023R1_converted {
  
  UsrAuthorization: PXFieldState;

}

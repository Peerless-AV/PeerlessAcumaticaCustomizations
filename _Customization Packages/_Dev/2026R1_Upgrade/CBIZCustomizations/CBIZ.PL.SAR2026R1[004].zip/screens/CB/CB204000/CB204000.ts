
import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "CBIZ.PL.SAR.SalesAttainmentMaint", primaryView: "MasterView" })
export class CB204000 extends PXScreen {
  MasterView = createCollection(SalesAttainmentReport);
}
// Views

@gridConfig({
  initNewRow: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class SalesAttainmentReport extends PXView {
  @columnConfig({
    width: 140,
  })
  SalesPersonID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 220,
  })
  SalesPersonID_description: PXFieldState;
  @columnConfig({
    width: 140,
  })
  SalesType: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 70,
  })
  RoleType: PXFieldState;
  @columnConfig({
    width: 90,
  })
  SalesDate: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 72,
  })
  FinPeriodID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  ItemSalesCategory: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 100,
  })
  Amount: PXFieldState;
  @columnConfig({
    width: 280,
  })
  CreatedByID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  CreatedDateTime: PXFieldState;
  @columnConfig({
    width: 280,
  })
  LastModifiedByID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  LastModifiedDateTime: PXFieldState;
}

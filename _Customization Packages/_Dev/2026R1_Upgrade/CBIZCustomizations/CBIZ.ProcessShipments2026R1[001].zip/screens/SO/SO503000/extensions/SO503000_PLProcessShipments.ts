import {
  PXFieldState,
  placeAfterProperty,
  columnConfig,
} from "client-controls";
import { SO503000, Orders } from "src/screens/SO/SO503000/SO503000";

export interface SO503000_PLProcessShipments extends SO503000 {}

export class SO503000_PLProcessShipments {}

export interface SO503000_Orders_PLProcessShipments extends Orders {}
export class SO503000_Orders_PLProcessShipments {
  @placeAfterProperty("SiteID_INSite_descr")
  @columnConfig({
    width: 70,
  })
  Operation: PXFieldState;

  @placeAfterProperty("Operation")
  WorkgroupID: PXFieldState;
}

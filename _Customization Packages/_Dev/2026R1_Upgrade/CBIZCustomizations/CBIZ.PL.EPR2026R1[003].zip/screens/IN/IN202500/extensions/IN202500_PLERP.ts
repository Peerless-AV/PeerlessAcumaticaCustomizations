﻿import {
  PXFieldState,
  
} from "client-controls";
import { IN202500, ItemSettings } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_PLERP extends IN202500 {}

export class IN202500_PLERP {}

export interface IN202500_ItemSettings_PLERP extends ItemSettings {}
export class IN202500_ItemSettings_PLERP {
  
  UsrLDPEWRAP: PXFieldState;

  UsrLDPEBAG: PXFieldState;

  UsrPPRIGID: PXFieldState;

  UsrEPSFOAM: PXFieldState;

  UsrLDPEFOAM: PXFieldState;

  UsrSteel: PXFieldState;

  UsrPAPCORR: PXFieldState;

  UsrPAPBRD: PXFieldState;

  UsrPAPWHT: PXFieldState;

  UsrPAPKRAFT: PXFieldState;

  UsrPAPFORMS: PXFieldState;

  UsrWOOD: PXFieldState;

  UsrLDPEWRAPCnt: PXFieldState;

  UsrLDPEBAGCnt: PXFieldState;

  UsrPPRIGIDCnt: PXFieldState;

  UsrEPSFOAMCnt: PXFieldState;

  UsrLDPEFOAMCnt: PXFieldState;
}

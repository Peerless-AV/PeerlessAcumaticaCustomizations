﻿import {
  PXFieldState,
  
} from "client-controls";
import { IN202000, ItemSettings } from "src/screens/IN/IN202000/IN202000";

export interface IN202000_PLERP extends IN202000 {}

export class IN202000_PLERP {}

export interface IN202000_ItemSettings_PLERP extends ItemSettings {}
export class IN202000_ItemSettings_PLERP {
  
  UsrLDPEWRAP: PXFieldState;

  UsrLDPEBAG: PXFieldState;

  UsrPPRIGID: PXFieldState;

  UsrEPSFOAM: PXFieldState;

  UsrLDPEFOAM: PXFieldState;

  UsrSteel: PXFieldState;

  UsrPAPCORR: PXFieldState;

  UsrPAPBRD: PXFieldState;

  UsrPAPWHT: PXFieldState;

  UsrPAPKRAFT: PXFieldState;

  UsrPAPFORMS: PXFieldState;

  UsrWOOD: PXFieldState;

  UsrLDPEWRAPCnt: PXFieldState;

  UsrLDPEBAGCnt: PXFieldState;

  UsrPPRIGIDCnt: PXFieldState;

  UsrEPSFOAMCnt: PXFieldState;

  UsrLDPEFOAMCnt: PXFieldState;
}

﻿import { PXFieldState,placeAfterProperty, columnConfig} from "client-controls";

import { IN402000, InventoryAllocDetEnqResult } from "src/screens/IN/IN402000/IN402000";

export interface IN402000_PLInvAllocationDetail extends IN402000 {}

export class IN402000_PLInvAllocationDetail {}

export interface IN402000_InventoryAllocDetEnqResult_PLInvAllocationDetail extends InventoryAllocDetEnqResult {}
export class IN402000_InventoryAllocDetEnqResult_PLInvAllocationDetail {
  @placeAfterProperty("RefNbr")
  @columnConfig({
    width: 180,
  })
  UsrStatus: PXFieldState;

  
}

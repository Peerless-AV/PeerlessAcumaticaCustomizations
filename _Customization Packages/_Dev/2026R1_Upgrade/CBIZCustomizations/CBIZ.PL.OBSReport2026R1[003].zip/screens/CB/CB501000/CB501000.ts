import {
  createCollection,
  PXScreen,
  graphInfo,
  viewInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "CBIZ.PL.OBSReport.CBOBSReportProcess", primaryView: "DispositionItems" })
export class CB501000 extends PXScreen {
  @viewInfo({ containerName: "Disposition Items" })
  DispositionItems = createCollection(CBDispositionItems);
  @viewInfo({ containerName: "Warehouses" })
  Warehouses = createCollection(INSite);
  @viewInfo({ containerName: "Break Down" })
  BreakdownItems = createCollection(CBDispositionBreakDown);
  @viewInfo({ containerName: "Where Used" })
  WhereUsedItems = createCollection(CBDispositionWhereUsed);
  @viewInfo({ containerName: "Obsoleted" })
  ObsoletedItems = createCollection(CBDispositionObsoleted);
  @viewInfo({ containerName: "Not Obsoleted" })
  NotObsoletedItems = createCollection(CBDispositionObsoleted2);
}
// Views

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class CBDispositionItems extends PXView {
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 280,
  })
  InventoryID_description: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Inquiry,
})
export class INSite extends PXView {
  @columnConfig({
    width: 60,
  })
  UsrSelected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    editorConfig: {
      parameters: null,
    },
    width: 140,
    hideViewLink: true,
  })
  SiteCD: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Descr: PXFieldState;
  @columnConfig({
    width: 60,
  })
  Active: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class CBDispositionBreakDown extends PXView {
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  InventoryID_description: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class CBDispositionWhereUsed extends PXView {
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  InventoryID_description: PXFieldState;
  @columnConfig({
    width: 70,
  })
  ParentInventoryID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  ParentInventoryID_description: PXFieldState;
  @columnConfig({
    width: 140,
  })
  BOMID: PXFieldState;
  @columnConfig({
    width: 120,
  })
  RevisionID: PXFieldState;
  @columnConfig({
    width: 140,
  })
  SiteID: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class CBDispositionObsoleted extends PXView {
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  InventoryID_description: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Bomid: PXFieldState;
  @columnConfig({
    width: 70,
  })
  Type: PXFieldState;
  @columnConfig({
    width: 70,
  })
  ItemStatus: PXFieldState;
  @columnConfig({
    width: 140,
  })
  SiteID: PXFieldState;
  @columnConfig({
    width: 100,
  })
  StdCost: PXFieldState;
  @columnConfig({
    width: 100,
  })
  VendorCost: PXFieldState;
  @columnConfig({
    width: 100,
  })
  QtyOnHand: PXFieldState;
  @columnConfig({
    width: 100,
  })
  ShopOrderQty: PXFieldState;
  @columnConfig({
    width: 100,
  })
  OpenPOQty: PXFieldState;
  @columnConfig({
    width: 100,
  })
  QtyOnHandVendor: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class CBDispositionObsoleted2 extends PXView {
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  InventoryID_description: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Bomid: PXFieldState;
  @columnConfig({
    width: 70,
  })
  Type: PXFieldState;
  @columnConfig({
    width: 70,
  })
  ItemStatus: PXFieldState;
  @columnConfig({
    width: 140,
  })
  SiteID: PXFieldState;
  @columnConfig({
    width: 100,
  })
  StdCost: PXFieldState;
  @columnConfig({
    width: 100,
  })
  VendorCost: PXFieldState;
  @columnConfig({
    width: 100,
  })
  QtyOnHand: PXFieldState;
  @columnConfig({
    width: 100,
  })
  ShopOrderQty: PXFieldState;
  @columnConfig({
    width: 100,
  })
  OpenPOQty: PXFieldState;
  @columnConfig({
    width: 100,
  })
  QtyOnHandVendor: PXFieldState;
}


<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CB501000.aspx.cs" Inherits="Page_CB501000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CBIZ.PL.OBSReport.CBOBSReportProcess"
        PrimaryView="DispositionItems"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server"></asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="Disposition Items">
				<Template>
					<px:PXLayoutRule ControlSize="XM" LabelsWidth="S" runat="server" ID="CstPXLayoutRule4" StartColumn="True" ></px:PXLayoutRule>
					<px:PXGrid BatchUpdate="True" Height="400px" SkinID="Details" Width="600" FilesIndicator="False" SyncPosition="True" NoteIndicator="False" AllowFilter="False" AllowSearch="False" DataSourceID="ds" runat="server" ID="CstPXGridCB8" Caption="Disposition Items" CaptionVisible="True">
						<Levels>
							<px:PXGridLevel DataMember="DispositionItems" >
								<Columns>
									<px:PXGridColumn CommitChanges="True" DataField="InventoryID" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
						<Mode InitNewRow="False" AllowDragRows="True" AllowAddNew="True" AllowDelete="True" AllowUpload="True" AllowUpdate="True" ></Mode>
						<Mode InitNewRow="True" ></Mode>
						<Mode AllowAddNew="True" ></Mode>
						<ActionBar>
							<Actions>
								<Upload MenuVisible="True" Enabled="True" ></Upload></Actions></ActionBar>
						<ActionBar>
							<Actions>
								<Upload MenuVisible="True" ></Upload></Actions></ActionBar></px:PXGrid>
					<px:PXLayoutRule LabelsWidth="S" ControlSize="XM" runat="server" ID="CstPXLayoutRule5" StartColumn="True" ></px:PXLayoutRule>
					<px:PXGrid CaptionVisible="True" Height="400px" SkinID="PrimaryInquire" RepaintColumns="True" SyncPosition="True" Caption="Warehouses" Width="480" FilesIndicator="False" NoteIndicator="False" runat="server" ID="CstPXGrid7">
						<Levels>
							<px:PXGridLevel DataMember="Warehouses" >
								<Columns>
									<px:PXGridColumn CommitChanges="True" DataField="UsrSelected" Width="60" Type="CheckBox" AllowCheckAll="True" ></px:PXGridColumn>
									<px:PXGridColumn DataField="SiteCD" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Descr" Width="220" ></px:PXGridColumn>
									<px:PXGridColumn Type="CheckBox" DataField="Active" Width="60" ></px:PXGridColumn></Columns>
								<RowTemplate>
									<px:PXSegmentMask runat="server" ID="CstPXSegmentMask12" DataField="SiteCD" Enabled="False" ></px:PXSegmentMask>
									<px:PXCheckBox Enabled="False" runat="server" ID="CstPXCheckBox13" DataField="Active" ></px:PXCheckBox>
									<px:PXTextEdit runat="server" ID="CstPXTextEdit14" DataField="Descr" Enabled="False" /></RowTemplate></px:PXGridLevel></Levels></px:PXGrid></Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Break Down">
				<Template>
					<px:PXGrid Height="500px" SkinID="Inquire" Width="100%" DataSourceID="ds" FilesIndicator="False" NoteIndicator="False" SyncPosition="True" runat="server" ID="CstPXGridCB8">
						<Levels>
							<px:PXGridLevel DataMember="BreakdownItems" >
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Where Used" >
				<Template>
					<px:PXGrid Height="500px" SkinID="Inquire" Width="100%" runat="server" ID="CstPXGrid9" DataSourceID="ds" SyncPosition="True">
						<Levels>
							<px:PXGridLevel DataMember="WhereUsedItems" >
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ParentInventoryID" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ParentInventoryID_description" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DataField="BOMID" Width="140" />
									<px:PXGridColumn DataField="RevisionID" Width="120" />
									<px:PXGridColumn DataField="SiteID" Width="140" /></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem>
			<px:PXTabItem Text="Obsoleted" >
				<Template>
					<px:PXGrid DataSourceID="ds" Height="500px" runat="server" ID="CstPXGrid10" SkinID="Inquire" Width="100%" SyncPosition="True">
						<Levels>
							<px:PXGridLevel DataMember="ObsoletedItems" >
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Bomid" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Type" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ItemStatus" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="SiteID" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="StdCost" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="VendorCost" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="QtyOnHand" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ShopOrderQty" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="OpenPOQty" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="QtyOnHandVendor" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem>
			<px:PXTabItem Text="Not Obsoleted" >
				<Template>
					<px:PXGrid DataSourceID="ds" Height="500px" SyncPosition="True" SkinID="Inquire" Width="100%" runat="server" ID="CstPXGrid11">
						<Levels>
							<px:PXGridLevel DataMember="NotObsoletedItems" >
								<Columns>
									<px:PXGridColumn DataField="InventoryID" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="InventoryID_description" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Bomid" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Type" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ItemStatus" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="SiteID" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="StdCost" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="VendorCost" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="QtyOnHand" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="ShopOrderQty" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="OpenPOQty" Width="100" ></px:PXGridColumn>
									<px:PXGridColumn DataField="QtyOnHandVendor" Width="100" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem></Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
	</px:PXTab>
</asp:Content>
﻿import {
  PXFieldState,
  placeAfterProperty,
 
} from "client-controls";
import { IN202500, ItemSettings } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_PLStockLevel extends IN202500 {}

export class IN202500_PLStockLevel {}

export interface IN202500_ItemSettings_PLStockLevel extends ItemSettings {}
export class IN202500_ItemSettings_PLStockLevel {
  @placeAfterProperty("CountryOfOrigin")
  UsrStockLevel: PXFieldState;

  
}

﻿import { PXFieldState,placeAfterProperty, columnConfig} from "client-controls";

import { AP402000, APDocumentResult } from "src/screens/AP/AP402000/AP402000";

export interface AP402000_PLVendorDetail extends AP402000 {}

export class AP402000_PLVendorDetail {}

export interface AP402000_APDocumentResult_PLVendorDetail extends APDocumentResult {}
export class AP402000_APDocumentResult_PLVendorDetail {
  @placeAfterProperty("DocDate")
  @columnConfig({
    width: 90,
  })
  UsrDueDate: PXFieldState;

  
}
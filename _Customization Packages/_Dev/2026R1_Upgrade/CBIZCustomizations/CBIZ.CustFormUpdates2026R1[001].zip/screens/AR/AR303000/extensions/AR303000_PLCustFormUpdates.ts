﻿import { AR303000, Customer2 } from "src/screens/AR/AR303000/AR303000";
import { PXFieldState,PXFieldOptions } from "client-controls";

export interface AR303000_PLCustFormUpdates extends AR303000 { }
export class AR303000_PLCustFormUpdates {}

export interface Customer2_PLCustFormUpdates extends Customer2 { }

export class Customer2_PLCustFormUpdates {
	UsrSFAcctID : PXFieldState;
	UsrDBNo : PXFieldState;
	UsrDBComment : PXFieldState;
	UsrCredAnalyst : PXFieldState;
}


﻿import { AR503500, DetailsResult } from "src/screens/AR/AR503500/AR503500";
import { PXFieldState,PXFieldOptions } from "client-controls";

export interface AR503500_PLCustFormUpdates extends AR503500 { }

export interface DetailsResult_PLCustFormUpdates extends DetailsResult { }

export class DetailsResult_PLCustFormUpdates {
	UsrCredAnalyst : PXFieldState;
}


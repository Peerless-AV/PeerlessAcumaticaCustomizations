<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="RL301000.aspx.cs" Inherits="Page_RL301000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="CBIZRadley.ISRadleyEntry"  PrimaryView="DocumentSOShipment">
		<CallbackCommands>
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" DataMember="DocumentSOShipment" Width="100%" TabIndex="100">
		<Template>
			<px:PXLayoutRule runat="server" LabelsWidth="S" ColumnSpan="2" StartRow="True" StartColumn="True"/>
            <px:PXSelector ID="edShipmentNbr"  Size="SM" runat="server" AlreadyLocalized="False" DataField="ShipmentNbr" >
            </px:PXSelector>
            <px:PXDropDown ID="edRadleyStatus" runat="server" CommitChanges="True" DataField="UsrRadleyStatus" Enabled="false">
            </px:PXDropDown>
            <px:PXLayoutRule runat="server"/>
            <px:PXNumberEdit ID="edUsrRadleyBoxes" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="UsrRadleyBoxes" IsClientControl="True">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edUsrRadleyPallets" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="UsrRadleyPallets" IsClientControl="True">
            </px:PXNumberEdit>
            <px:PXLayoutRule runat="server" StartColumn="True"/>
             <px:PXLabel runat="server" ID="CstLabel1" />
            <px:PXNumberEdit ID="edUsrRadleyBoxesVal" CommitChanges="True" Enabled="False" runat="server" AlreadyLocalized="False" DataField="UsrRadleyBoxesVal" IsClientControl="True">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edUsrRadleyPalletsVal" CommitChanges="True" Enabled="False" runat="server" AlreadyLocalized="False" DataField="UsrRadleyPalletsVal" IsClientControl="True">
            </px:PXNumberEdit>
            <px:PXLayoutRule runat="server"  LabelsWidth="S" StartRow="True"/>
            <px:PXGrid ID="PXGrid1" runat="server" KeepPosition ="true"
                Width="480px" Height="498px" SkinID="DetailsInTab" DataSourceID="ds"
                AutoAdjustColumns="True" TabIndex="500" 
                Caption="Radley Input" CaptionVisible="true" SyncPosition="false">
                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." FilteredMessage="No records found.
Try to change filter to see records here." NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here." NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." ></EmptyMsg>
                <Levels>
                    <px:PXGridLevel DataMember="RadleyView">
                        <RowTemplate>
                            <px:PXSelector ID="edInputInventoryID" CommitChanges="True" Size="S" runat="server" AlreadyLocalized="False" DataField="InventoryID" AutoRefresh="true">
                            </px:PXSelector>
                            <px:PXNumberEdit ID="edInputQty" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="Qty">
                            </px:PXNumberEdit>
                            <px:PXTextEdit ID="edInputSerialNbr"  CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="SerialNbr">
                            </px:PXTextEdit>
                            <px:PXTextEdit ID="edInputBoxNbr" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="BoxNbr">
                            </px:PXTextEdit>
                            <px:PXTextEdit ID="edInputPalletNbr" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="PalletNbr" >
                            </px:PXTextEdit>
                            <px:PXNumberEdit ID="edLineNbr" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                            </px:PXNumberEdit>
                            <px:PXNumberEdit ID="edShipmentSplitLineNbr" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="ShipmentSplitLineNbr">
                            </px:PXNumberEdit>
                        </RowTemplate>
                        <Columns>
                            <px:PXGridColumn DataField="InventoryID" Width="198px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="Qty" Width="150px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="SerialNbr" Width="300px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="PalletNbr" Width="200px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="BoxNbr" Width="200px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="LineNbr" Width="205px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="ShipmentSplitLineNbr" Width="205px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                        </Columns>
                    </px:PXGridLevel>
                </Levels>
            
	<Mode AllowUpload="True" /></px:PXGrid>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXGrid ID="PXPallets" runat="server" KeepPosition="true" SyncPosition="true" AutoCallBack-Target="PXBox" AutoCallBack-Command="Refresh"
                Width="220px" Height="500px" SkinID="Inquire" DataSourceID="ds"
                AutoAdjustColumns="True" TabIndex="500" FilesIndicator="false" NoteIndicator="false"
                Caption="All Pallets" CaptionVisible="true">
                <AutoCallBack Command="Refresh" Target="PXBox" ActiveBehavior="true" />
                <OnChangeCommand Command="Refresh" Target="PXBox" />
                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." FilteredMessage="No records found.
Try to change filter to see records here." NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here." NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                <Levels>
                    <px:PXGridLevel DataMember="PalletsView">
                        <RowTemplate>
                            <px:PXTextEdit ID="edPalletsNbr" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="PalletNbr" DefaultLocale="">
                            </px:PXTextEdit>
                        </RowTemplate>
                        <Columns>
                            <px:PXGridColumn DataField="PalletNbr"  Width="100px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                        </Columns>
                        <Mode AllowAddNew="False" AllowDelete="False" AllowUpdate="False" />
                    </px:PXGridLevel>
                </Levels>
            </px:PXGrid>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXGrid ID="PXBox" runat="server" KeepPosition="true" SyncPosition="true" AutoCallBack-Target="PXItems" AutoCallBack-Command="Refresh"
                Width="220px" Height="500px" SkinID="Inquire" DataSourceID="ds"
                AutoAdjustColumns="True" TabIndex="500" FilesIndicator="false" NoteIndicator="false"
                Caption="Boxes" CaptionVisible="true" >
                  <AutoCallBack Command="Refresh" Target="PXItems" ActiveBehavior="true" />
                  <OnChangeCommand Command="Refresh" Target="PXItems" />
                  <CallbackCommands>
                      <Refresh SelectControlsIDs="PXPallets" />
                  </CallbackCommands>
                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." FilteredMessage="No records found.
Try to change filter to see records here." NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here." NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                <Levels>
                    <px:PXGridLevel DataMember="BoxesView">
                        <RowTemplate>
                            <px:PXTextEdit ID="edBoxesNbr" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="BoxNbr" DefaultLocale="">
                            </px:PXTextEdit>
                        </RowTemplate>
                        <Columns>
                            <px:PXGridColumn DataField="BoxNbr" Width="100px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                        </Columns>
                        <Mode AllowAddNew="False" AllowDelete="False" AllowUpdate="False" />
                    </px:PXGridLevel>
                </Levels>
            </px:PXGrid>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXGrid ID="PXItems" runat="server" KeepPosition="true" SyncPosition="true"
                Width="310px" Height="500px" SkinID="Inquire" DataSourceID="ds"
                AutoAdjustColumns="True" TabIndex="500" FilesIndicator="false" NoteIndicator="false"
                Caption="Items" CaptionVisible="true">
                <CallbackCommands>
                    <Refresh SelectControlsIDs="PXBox" />
                </CallbackCommands>
                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." FilteredMessage="No records found.
Try to change filter to see records here." NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here." NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here." NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                <Levels>
                    <px:PXGridLevel DataMember="ItemsView">
                        <RowTemplate>
                            <px:PXSelector ID="edInventoryIDItem" Size="S" CommitChanges="True" runat="server" AlreadyLocalized="False" DataField="InventoryID">
                            </px:PXSelector>
                            <px:PXNumberEdit ID="edQtyItem" runat="server" CommitChanges="True" AlreadyLocalized="False" DataField="Qty">
                            </px:PXNumberEdit>
                            <px:PXTextEdit ID="edSerialNbrItem" runat="server" CommitChanges="True" AlreadyLocalized="False" DataField="SerialNbr">
                            </px:PXTextEdit>
                        </RowTemplate>
                        <Columns>
                            <px:PXGridColumn DataField="InventoryID" CommitChanges="True" Width="198px" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="Qty" CommitChanges="True" Width="150px" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="SerialNbr" CommitChanges="True" Width="200px" TextAlign="Left">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="ShipmentSplitLineNbr" Width="205px" CommitChanges="True" TextAlign="Left">
                            </px:PXGridColumn>
                        </Columns>
                        <Mode AllowAddNew="False" AllowDelete="False" AllowUpdate="False" />
                    </px:PXGridLevel>
                </Levels>
            </px:PXGrid>
		</Template>
        <AutoSize Enabled="True" Container="Window" />
	</px:PXFormView>
</asp:Content>


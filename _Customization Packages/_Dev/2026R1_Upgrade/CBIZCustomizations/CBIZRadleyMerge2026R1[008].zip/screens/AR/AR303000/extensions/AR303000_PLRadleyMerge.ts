﻿import { AR303000, Customer2 } from "src/screens/AR/AR303000/AR303000";
import { PXFieldState,PXFieldOptions } from "client-controls";

export interface AR303000_PLRadleyMerge extends AR303000 { }

export interface Customer2_PLRadleyMerge extends Customer2 { }

export class Customer2_PLRadleyMerge {
	UsrCartonSerialLabel : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrGs1Sequence : PXFieldState<PXFieldOptions.CommitChanges>;
}


import {
  SO302000,
  Transactions,
  Packages,
 
} from "src/screens/SO/SO302000/SO302000";



import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  createCollection,
  gridConfig,
  GridPreset,
  PXFieldStateGeneric,
} from "client-controls";

export interface SO302000_PLRadleyMerge extends SO302000 { }

export interface Transactions_PLRadleyMerge extends Transactions { }
export class Transactions_PLRadleyMerge {
    
  UsrRadleyPicked : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrRadleyPickDate : PXFieldState;
	UsrRadleyPacked : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrRadleyQty : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrRadleyVal : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrRadleyCal : PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface Packages_PLRadleyMerge extends Packages { }
export class Packages_PLRadleyMerge {
    
  UsrGS1Barcode : PXFieldState;
  UsrCartonsPerPallet : PXFieldState;
	UsrPalletSSCC : PXFieldState;
}



import {
  SO101000,
  sosetup
} from "src/screens/SO/SO101000/SO101000";



import {
  PXFieldState,
  
} from "client-controls";

export interface SO101000_PLRadleyMerge extends SO101000 { }

export interface sosetup_PLRadleyMerge extends sosetup { }
export class sosetup_PLRadleyMerge {
    
  UsrRadleyMessage : PXFieldState;
	UsrAttributeID : PXFieldState;
	UsrPalletSSCCSequence : PXFieldState;
}

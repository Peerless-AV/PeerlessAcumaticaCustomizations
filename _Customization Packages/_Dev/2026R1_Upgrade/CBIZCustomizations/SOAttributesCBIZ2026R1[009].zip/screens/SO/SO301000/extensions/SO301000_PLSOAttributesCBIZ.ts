import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  PXActionState,
  placeAfterProperty,
  viewInfo,
  gridConfig,
  columnConfig,
  TextAlign,
  GridPreset,
  GridColumnShowHideMode,
  GridFastFilterVisibility,
  createCollection,
  createSingle,
} from "client-controls";
import { SO301000, SOOrderHeader, SOLine, SOOrder } from "src/screens/SO/SO301000/SO301000";

export interface SO301000_SOAttributesCBIZ2026R1_converted extends SO301000 {}

export class SO301000_SOAttributesCBIZ2026R1_converted {
  //AddAttribute: PXActionState;

  @viewInfo({ containerName: "Attributes" })
  Answers = createCollection(CSAnswers);
  @viewInfo({ containerName: "Add Attributes" })
  NewAttributeSelectedPanel = createSingle(EnterAttributePanel);
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class CSAnswers extends PXView {
  AddAttribute: PXActionState;
  
  @columnConfig({
    width: 120,
    allowShowHide: GridColumnShowHideMode.True,
    textAlign: TextAlign.Left,
  })
  AttributeID: PXFieldState;

  @columnConfig({
    width: 280,
  })
  Value: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({
    width: 220,
  })
  UsrDescription: PXFieldState;

  @columnConfig({
    width: 60,
  })
  IsRequired: PXFieldState;
}
export class EnterAttributePanel extends PXView {
  AttributeBySelected: PXFieldState;
}
export interface SO301000_SOOrderHeader_SOAttributesCBIZ2026R1_converted extends SOOrderHeader {}
export class SO301000_SOOrderHeader_SOAttributesCBIZ2026R1_converted {
  @placeAfterProperty("CustomerRefNbr")
  UsrSFQuoteNbr: PXFieldState;

  @placeAfterProperty("OrderDesc")
  UsrTier: PXFieldState;

  @placeAfterProperty("UsrTier")
  UsrSalespersonGroup: PXFieldState<PXFieldOptions.CommitChanges>;
}
export interface SO301000_SOLine_SOAttributesCBIZ2026R1_converted extends SOLine {}
export class SO301000_SOLine_SOAttributesCBIZ2026R1_converted {
  @placeAfterProperty("InventoryID")
  @columnConfig({
    width: 120,
  })
  UsrPMPLCM: PXFieldState;

  @columnConfig({
    width: 280,
  })
  UsrPCLLT: PXFieldState;

  UnshippedQty: PXFieldState;

  @placeAfterProperty("UnshippedQty")
  ShippedQty: PXFieldState;

  @placeAfterProperty("ShippedQty")
  OpenQty: PXFieldState;
}
export interface SO301000_SOOrder_SOAttributesCBIZ2026R1_converted extends SOOrder {}
export class SO301000_SOOrder_SOAttributesCBIZ2026R1_converted {
  
  UsrThirdPName: PXFieldState;

  UsrThirdPAdressLine1: PXFieldState;

  UsrThirdPAdressLine2: PXFieldState;

  UsrThirPCity: PXFieldState;

  UsrThirdPState: PXFieldState;

  UsrThirdPPostalCode: PXFieldState;

  UsrThirdPCountry: PXFieldState;

  UsrThirdPTpbNbr: PXFieldState;

  UsrThirPCollectNbr: PXFieldState;

  UsrConfAttention: PXFieldState;

  UsrConfEmail: PXFieldState;

  
}

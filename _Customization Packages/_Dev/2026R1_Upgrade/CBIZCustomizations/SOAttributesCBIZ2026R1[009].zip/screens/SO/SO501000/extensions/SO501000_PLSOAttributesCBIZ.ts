import {
  PXFieldState,
  
  
} from "client-controls";
import { SO501000, Orders } from "src/screens/SO/SO501000/SO501000";

export interface SO501000_SOAttributesCBIZ2026R1_converted extends SO501000 {}

export class SO501000_SOAttributesCBIZ2026R1_converted {}

export interface SO501000_Orders_SOAttributesCBIZ2026R1_converted extends Orders {}
export class SO501000_Orders_SOAttributesCBIZ2026R1_converted {
  
  UsrSalespersonGroup: PXFieldState;

  UsrTier: PXFieldState;

  
}

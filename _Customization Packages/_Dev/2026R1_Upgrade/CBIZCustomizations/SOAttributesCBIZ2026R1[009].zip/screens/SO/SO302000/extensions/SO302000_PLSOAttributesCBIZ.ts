import {
  PXFieldState,
  
} from "client-controls";
import { SO302000, SOShipment } from "src/screens/SO/SO302000/SO302000";

export interface SO302000_SOAttributesCBIZ2026R1_converted extends SO302000 {}

export class SO302000_SOAttributesCBIZ2026R1_converted {}

export interface SO302000_SOShipment_SOAttributesCBIZ2026R1_converted extends SOShipment {}
export class SO302000_SOShipment_SOAttributesCBIZ2026R1_converted {

  UsrThirdPName: PXFieldState;

  UsrThirdPAdressLine1: PXFieldState;

  UsrThirdPAdressLine2: PXFieldState;

  UsrThirPCity: PXFieldState;

  UsrThirdPState: PXFieldState;

  UsrThirdPPostalCode: PXFieldState;

  UsrThirdPCountry: PXFieldState;

  UsrThirdPTpbNbr: PXFieldState;

  UsrThirPCollectNbr: PXFieldState;

}

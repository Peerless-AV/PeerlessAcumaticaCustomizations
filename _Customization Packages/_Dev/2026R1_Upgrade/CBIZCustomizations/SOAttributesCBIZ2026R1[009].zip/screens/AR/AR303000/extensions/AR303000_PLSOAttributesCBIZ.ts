﻿import {
  PXFieldState,
  PXFieldOptions,
  updateDecorator,
  placeAfterProperty,
  columnConfig,
  fieldOptions,
  GridColumnShowHideMode,
  
} from "client-controls";
import { AR303000, Customer, Customer2, SalesPersons, Answers } from "src/screens/AR/AR303000/AR303000";

export interface AR303000_PLSOAttributesCBIZ extends AR303000 {}

export class AR303000_PLSOAttributesCBIZ {}

export interface AR303000_Customer_PLSOAttributesCBIZ extends Customer {}
export class AR303000_Customer_PLSOAttributesCBIZ {
  usrTier: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface AR303000_Customer2_PLSOAttributesCBIZ extends Customer2 {}
export class AR303000_Customer2_PLSOAttributesCBIZ {
  UsrConfAttention: PXFieldState;
  UsrConfEmail: PXFieldState;

}
export interface AR303000_SalesPersons_PLSOAttributesCBIZ extends SalesPersons {}
export class AR303000_SalesPersons_PLSOAttributesCBIZ {
  
  usrSalespersonGroup: PXFieldState<PXFieldOptions.CommitChanges>;
}
export interface AR303000_Answers_PLSOAttributesCBIZ extends Answers {}
export class AR303000_Answers_PLSOAttributesCBIZ {
  UsrDescription: PXFieldState;
  UsrExportToSO: PXFieldState;
 
}

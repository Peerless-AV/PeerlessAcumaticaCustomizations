﻿import {
  PXFieldState,
  PXFieldOptions,
  updateDecorator,
  placeAfterProperty,
  columnConfig,
  fieldOptions,
  GridColumnShowHideMode,
  
} from "client-controls";
import { AR303020, Location2 } from "src/screens/AR/AR303020/AR303020";

export interface AR303020_SOAttributesCBIZ2026R1_converted extends AR303020 {}

export class AR303020_SOAttributesCBIZ2026R1_converted {}

export interface AR303020_Location2_SOAttributesCBIZ2026R1_converted extends Location2 {}
export class AR303020_Location2_SOAttributesCBIZ2026R1_converted {
  UsrThirdPName: PXFieldState;

  UsrThirdPAdressLine1: PXFieldState;

  UsrThirdPAdressLine2: PXFieldState;

  UsrThirPCity: PXFieldState;

  UsrThirdPState: PXFieldState;

  UsrThirdPPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrThirdPCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrThirdPTpbNbr: PXFieldState;

  UsrThirPCollectNbr: PXFieldState;

  
}

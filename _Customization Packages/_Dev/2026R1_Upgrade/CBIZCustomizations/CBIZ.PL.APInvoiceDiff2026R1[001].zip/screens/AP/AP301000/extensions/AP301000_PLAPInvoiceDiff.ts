﻿import { AP301000, APInvoice  } from "src/screens/AP/AP301000/AP301000";
import { PXFieldState,PXFieldOptions } from "client-controls";

export interface AP301000_PLAPInvoiceDiff extends AP301000 { }

export interface APInvoice_PLAPInvoiceDiff extends APInvoice { }

export class APInvoice_PLAPInvoiceDiff {
	UsrCuryDiff: PXFieldState<PXFieldOptions.Disabled>;
}


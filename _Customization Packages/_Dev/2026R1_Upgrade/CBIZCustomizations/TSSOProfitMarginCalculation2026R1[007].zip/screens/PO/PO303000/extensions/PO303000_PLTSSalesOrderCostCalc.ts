import {
  PO303000,
  POLandedCostDetail
} from "src/screens/PO/PO303000/PO303000";



import {
  GridPreset,
  GridFastFilterVisibility,
  gridConfig,
  PXScreen,
  
} from "client-controls";

export interface PO303000_PLTSSalesOrderCostCalc extends PO303000 { }
export class PO303000_PLTSSalesOrderCostCalc {}

export interface POLandedCostDetail_PLTSSalesOrderCostCalc extends POLandedCostDetail { }

@gridConfig({
	initNewRow: true,
	allowImport: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class POLandedCostDetail_PLTSSalesOrderCostCalc {
    
}

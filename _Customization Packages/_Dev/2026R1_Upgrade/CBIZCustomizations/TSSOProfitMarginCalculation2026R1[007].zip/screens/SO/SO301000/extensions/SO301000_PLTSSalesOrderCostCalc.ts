import {
  SO301000,
  SOOrderHeader,
  SOOrder,
  SOLine
} from "src/screens/SO/SO301000/SO301000";



import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  createCollection,
  gridConfig,
  GridPreset,
  PXFieldStateGeneric,
} from "client-controls";

export interface SO301000_PLTSSalesOrderCostCalc extends SO301000 { }

export interface SOOrderHeader_PLTSSalesOrderCostCalc extends SOOrderHeader { }
export class SOOrderHeader_PLTSSalesOrderCostCalc {
    
  UsrTotalCost : PXFieldState<PXFieldOptions.Disabled>;
	UsrTotalProfit : PXFieldState<PXFieldOptions.Disabled>;
	UsrTotalMargin : PXFieldState<PXFieldOptions.Disabled>;
	UsrGrossProfit : PXFieldState<PXFieldOptions.Disabled>;
}

export interface SOOrder_PLTSSalesOrderCostCalc extends SOOrder { }
export class SOOrder_PLTSSalesOrderCostCalc {
    
  Usr15Pay : PXFieldState;
	
}

export interface SOLine_PLTSSalesOrderCostCalc extends SOLine { }
export class SOLine_PLTSSalesOrderCostCalc {
  UsrSOUcost : PXFieldState<PXFieldOptions.CommitChanges>;
  UsrProfit : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrMargin : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrExtUcost : PXFieldState<PXFieldOptions.CommitChanges>;
	
}

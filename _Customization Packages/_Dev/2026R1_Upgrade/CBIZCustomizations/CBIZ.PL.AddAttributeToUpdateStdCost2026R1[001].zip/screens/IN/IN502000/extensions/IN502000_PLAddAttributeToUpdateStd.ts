﻿import { PXFieldState,placeAfterProperty, columnConfig} from "client-controls";

import { IN502000, INItemList } from "src/screens/IN/IN502000/IN502000";

export interface IN502000_PLAddAttriuteToUpdateStd extends IN502000 {}

export class IN502000_PLAddAttriuteToUpdateStd {}

export interface IN502000_INItemList_PLAddAttriuteToUpdateStd extends INItemList {}
export class IN502000_INItemList_PLAddAttriuteToUpdateStd {
  @placeAfterProperty("InvtSubID")
  @columnConfig({
    width: 220,
  })
  UsrAcctGroup: PXFieldState;

  @placeAfterProperty("UsrAcctGroup")
  @columnConfig({
    width: 220,
  })
  UsrPartCstGrp: PXFieldState;

}

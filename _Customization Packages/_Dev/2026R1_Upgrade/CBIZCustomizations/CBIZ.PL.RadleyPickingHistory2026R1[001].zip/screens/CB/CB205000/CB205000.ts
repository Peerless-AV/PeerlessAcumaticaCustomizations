import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "CBIZ.PL.RadleyPickingHistory.CBRadleyPickingHistMaint", primaryView: "MasterView" })
export class CB205000 extends PXScreen {
  MasterView = createCollection(CBRadleyPickingHistory);
}
// Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class CBRadleyPickingHistory extends PXView {
  @columnConfig({
    width: 140,
  })
  TaskID: PXFieldState;
  @columnConfig({
    width: 180,
  })
  TaskType: PXFieldState;
  @columnConfig({
    width: 280,
  })
  LoginID: PXFieldState;
  @columnConfig({
    width: 150,
    format: "G",
  })
  StartTime: PXFieldState;
  @columnConfig({
    width: 150,
    format: "G",
  })
  EndTime: PXFieldState;
  @columnConfig({
    width: 70,
  })
  TotalTime: PXFieldState;
  @columnConfig({
    width: 140,
  })
  ShipmentNbr: PXFieldState;
  @columnConfig({
    width: 70,
  })
  ShipmentLineNbr: PXFieldState;
  @columnConfig({
    width: 100,
  })
  Quantity: PXFieldState;
  @columnConfig({
    width: 70,
  })
  InventoryID: PXFieldState;
  @columnConfig({
    width: 70,
  })
  OrderType: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 140,
  })
  OrderNbr: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Warehouse: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 140,
  })
  LocationID: PXFieldState;
  @columnConfig({
    width: 60,
  })
  DNSE: PXFieldState;
  @columnConfig({
    width: 140,
  })
  CustomerID: PXFieldState;
  @columnConfig({
    width: 280,
  })
  CreatedByID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  CreatedDateTime: PXFieldState;
}

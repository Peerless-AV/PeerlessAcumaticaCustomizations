﻿import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig,
  
} from "client-controls";
import { AP301000, APTran } from "src/screens/AP/AP301000/AP301000";
import { POReceiptLineAdd } from "src/screens/AP/AP301000/extensions/AP301000_PO_FillingInvoiceWithPOEntities";

export interface AP301000_PLAddSubDescription extends AP301000 {}

export class AP301000_PLAddSubDescription {}

export interface AP301000_APTran_PLAddSubDescription extends APTran {}
export class AP301000_APTran_PLAddSubDescription {
  @placeAfterProperty("SubID")
  @columnConfig({
    width: 280,
  })
  SubID_description: PXFieldState;

  
}
export interface AP301000_POReceiptLineAdd_PLAddSubDescription extends POReceiptLineAdd {}
export class AP301000_POReceiptLineAdd_PLAddSubDescription {
  @placeAfterProperty("ReceiptNbr")
  @columnConfig({
    width: 90,
  })
  ReceiptDate: PXFieldState;
}

﻿import { AR301000, ARTran } from "src/screens/AR/AR301000/AR301000";
import { PXFieldState,placeAfterProperty,columnConfig } from "client-controls";

export interface AR301000_PLAddSubDescription extends AR301000 { }
export class AR301000_PLAddSubDescription {}

export interface ARTran_PLAddSubDescription extends ARTran { }

export class ARTran_PLAddSubDescription {
  @placeAfterProperty("SubID")
  @columnConfig({
    width: 280,
  })
  SubID_description: PXFieldState;
}


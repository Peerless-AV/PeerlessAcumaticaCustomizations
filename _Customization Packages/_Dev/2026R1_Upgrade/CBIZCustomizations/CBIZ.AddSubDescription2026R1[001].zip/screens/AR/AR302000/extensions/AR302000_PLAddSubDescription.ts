﻿import {
  PXFieldState,
  placeAfterProperty,
  
 
} from "client-controls";
import { AR302000, ARTranPostBal } from "src/screens/AR/AR302000/AR302000";

export interface AR302000_PLAddSubDescription extends AR302000 {}

export class AR302000_PLAddSubDescription {}

export interface AR302000_ARTranPostBal_PLAddSubDescription extends ARTranPostBal {}
export class AR302000_ARTranPostBal_PLAddSubDescription {
  @placeAfterProperty("LineNbr")
  AdjdCuryRate: PXFieldState;

  @placeAfterProperty("CuryRGOLAmt")
  ApplicationDate: PXFieldState;
}

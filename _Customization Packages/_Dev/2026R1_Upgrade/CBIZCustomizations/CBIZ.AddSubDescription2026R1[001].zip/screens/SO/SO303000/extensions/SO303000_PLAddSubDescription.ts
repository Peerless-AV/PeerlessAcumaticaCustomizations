import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  
  columnConfig
} from "client-controls";

import { SO303000, ARTran } from "src/screens/SO/SO303000/SO303000";

export interface SO303000_PLAddSubDescription extends SO303000 {}

export class SO303000_PLAddSubDescription {}

export interface SO303000_ARTran_PLAddSubDescription extends ARTran {}
export class SO303000_ARTran_PLAddSubDescription {
 
  @placeAfterProperty("SubID")
  @columnConfig({
    width: 280,
  })
  SubID_description: PXFieldState;

  @placeAfterProperty("SubID_description")
  ExpenseAccrualAccountID: PXFieldState<PXFieldOptions.CommitChanges>;

  
}

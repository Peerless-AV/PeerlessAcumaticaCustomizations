﻿import {
  PXFieldState,
  placeAfterProperty,
  placeBeforeProperty,
  columnConfig
} from "client-controls";
import { IN101000, insetup } from "src/screens/IN/IN101000/IN101000";

export interface IN101000_PLAutoUPC extends IN101000 {}

export class IN101000_PLAutoUPC {}

export interface IN101000_insetup_PLAutoUPC extends insetup {}
export class IN101000_insetup_PLAutoUPC {
  @placeAfterProperty("ManufacturingNumberingID")
  UsrUPCNumberingID: PXFieldState;

  
}

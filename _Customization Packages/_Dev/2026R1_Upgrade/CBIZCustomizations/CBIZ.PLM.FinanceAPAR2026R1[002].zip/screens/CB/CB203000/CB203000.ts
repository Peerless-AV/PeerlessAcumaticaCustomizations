import {
  createSingle,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
 
} from "client-controls";

@graphInfo({ graphType: "CBIZ.PL.SalesRegion.SalesRegionMaint", primaryView: "MasterView" })
export class CB203000 extends PXScreen {
  MasterView = createSingle(CBSalesRegion);
}
// Views

export class CBSalesRegion extends PXView {
  RegionID: PXFieldState;
  RegionCD: PXFieldState;
  Descr: PXFieldState;
  State: PXFieldState;
  CountryID: PXFieldState;
  PostalCode: PXFieldState;
  PostalCodeTo: PXFieldState;
}

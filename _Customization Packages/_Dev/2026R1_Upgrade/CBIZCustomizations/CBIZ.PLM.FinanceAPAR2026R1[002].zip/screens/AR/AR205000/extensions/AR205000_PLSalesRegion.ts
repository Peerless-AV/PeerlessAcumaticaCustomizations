﻿import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  viewInfo,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
  createCollection,
} from "client-controls";
import { AR205000 } from "src/screens/AR/AR205000/AR205000";

export interface AR205000_PLSalesRegion extends AR205000 {}

export class AR205000_PLSalesRegion {
  @viewInfo({ containerName: "Region" })
  SPRegions = createCollection(CBSalesPeopleRegion);
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class CBSalesPeopleRegion extends PXView {
  @columnConfig({
    width: 70,
  })
  RegionID: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({
    width: 140,
  })
  CBSalesRegion__RegionCD: PXFieldState;

  @columnConfig({
    width: 60,
  })
  IsDefault: PXFieldState<PXFieldOptions.CommitChanges>;
}

﻿import {
  PXFieldState,
  placeAfterProperty,
  columnConfig,
  IGridColumn,                
} from "client-controls";
import { GL302010, GLBudgetLine2 } from "src/screens/GL/GL302010/GL302010";

export interface GL302010_PLBudget extends GL302010 {}
export class GL302010_PLBudget {
  // override the base whitelist so UsrType is allowed through
  onFilterBudgetArticlesColumns(col: IGridColumn) {
    const validColumns = [
      "Files", "Notes", "IsGroup", "GroupID", "Released", "AccountID",
      "SubID", "Description", "Amount", "BranchID",
      "AllocatedAmount", "CreatedByID", "LastModifiedByID", "LedgerID", "FinYear",
      "UsrType",                   // new
    ];
    return validColumns.includes(col.key!)
        || validColumns.includes(col.field!)
        || (col.generated && col.field?.startsWith("Period"));
  }
}

export interface GL302010_GLBudgetLine2_PLBudget extends GLBudgetLine2 {}
export class GL302010_GLBudgetLine2_PLBudget {
  @placeAfterProperty("AccountID")
  @columnConfig({ width: 90 })
  UsrType: PXFieldState;
}
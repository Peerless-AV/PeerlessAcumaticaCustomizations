import { PXFieldState,
	columnConfig,
	placeAfterProperty,
} from "client-controls";

import { CS209000 } from "src/screens/CS/CS209000/CS209000";
import { CSCalendarExceptions } from "src/screens/CS/CS209000/extensions/CS209000_Exceptions";

export interface CS209000_PLAlternateDate extends CS209000 {}

export class CS209000_PLAlternateDate {}

export interface CS209000_CSCalendarExceptions_PLAlternateDate extends CSCalendarExceptions {}
export class CS209000_CSCalendarExceptions_PLAlternateDate {
  

  @placeAfterProperty("EndTime")
  @columnConfig({
    width: 90,
  })
  UsrAlternateDate: PXFieldState;
}

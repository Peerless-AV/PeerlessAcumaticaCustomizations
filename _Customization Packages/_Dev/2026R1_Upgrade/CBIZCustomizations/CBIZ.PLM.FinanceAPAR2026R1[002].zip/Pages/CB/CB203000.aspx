<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CB203000.aspx.cs" Inherits="Page_CB203000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CBIZ.PL.SalesRegion.SalesRegionMaint"
        PrimaryView="MasterView"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="MasterView" Width="100%" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector8" DataField="RegionID" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit7" DataField="RegionCD" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit2" DataField="Descr" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule6" StartGroup="True" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector5" DataField="State" ></px:PXSelector>
			<px:PXSelector runat="server" ID="CstPXSelector1" DataField="CountryID" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit3" DataField="PostalCode" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit9" DataField="PostalCodeTo" /></Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView>
</asp:Content>
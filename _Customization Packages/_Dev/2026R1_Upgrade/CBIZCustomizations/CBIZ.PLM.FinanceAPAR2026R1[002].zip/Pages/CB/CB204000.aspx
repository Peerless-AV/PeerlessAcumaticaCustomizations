<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CB204000.aspx.cs" Inherits="Page_CB204000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="CBIZ.PL.SAR.SalesAttainmentMaint"
        PrimaryView="MasterView"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="Primary" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataMember="MasterView">
			    <Columns>
				<px:PXGridColumn CommitChanges="True" DataField="SalesPersonID" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SalesPersonID_description" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="SalesType" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="RoleType" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="SalesDate" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="FinPeriodID" Width="72" ></px:PXGridColumn>
				<px:PXGridColumn CommitChanges="True" DataField="ItemSalesCategory" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Amount" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CreatedByID" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="CreatedDateTime" Width="90" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LastModifiedByID" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn DataField="LastModifiedDateTime" Width="90" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	
		<Mode InitNewRow="True" AllowUpload="True" ></Mode>
		<Mode InitNewRow="True" ></Mode></px:PXGrid>
</asp:Content>
﻿import {
  PXFieldState,
  placeAfterProperty,
  placeBeforeProperty,
  columnConfig,
  updateDecorator,
  GridColumnShowHideMode,
  fieldOptions
} from "client-controls";
import { IN202500, InventoryItem, Attributes } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_PLUpdateItemAttributes extends IN202500 {}

export class IN202500_PLUpdateItemAttributes {}

export interface IN202500_InventoryItem_PLUpdateItemAttributes extends InventoryItem {}
export class IN202500_InventoryItem_PLUpdateItemAttributes {
  
  UsrSalesForcePartID: PXFieldState;

}
export interface IN202500_Attributes_PLUpdateItemAttributes extends Attributes {}
export class IN202500_Attributes_PLUpdateItemAttributes {
  @placeBeforeProperty("AttributeID")
  @columnConfig({
    width: 120,
  })
  UsrAttributeID: PXFieldState;

  @placeAfterProperty("UsrAttributeID")
  AttributeID: PXFieldState;

  @placeAfterProperty("AttributeID")
  AttributeCategory: PXFieldState;

  @updateDecorator("columnConfig", "allowShowHide", GridColumnShowHideMode.False)
  @fieldOptions({ hidden: true })
  isRequired: PXFieldState;
}

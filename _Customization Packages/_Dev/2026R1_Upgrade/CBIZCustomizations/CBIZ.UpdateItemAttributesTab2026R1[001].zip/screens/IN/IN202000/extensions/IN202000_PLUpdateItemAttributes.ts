﻿import {
  PXFieldState,
  placeAfterProperty,
  placeBeforeProperty,
  columnConfig
} from "client-controls";
import { IN202000, InventoryItem, Attributes } from "src/screens/IN/IN202000/IN202000";

export interface IN202000_PLUpdateItemAttributes extends IN202000 {}

export class IN202000_PLUpdateItemAttributes {}

export class INItemCategory {}
export interface IN202000_InventoryItem_PLUpdateItemAttributes extends InventoryItem {}
export class IN202000_InventoryItem_PLUpdateItemAttributes {
  @placeAfterProperty("Descr")
  UsrSalesForcePartID: PXFieldState;

  
}
export interface IN202000_Attributes_PLUpdateItemAttributes extends Attributes {}
export class IN202000_Attributes_PLUpdateItemAttributes {
  @placeBeforeProperty("AttributeID")
  @columnConfig({
    width: 120,
  })
  UsrAttributeID: PXFieldState;

  @placeAfterProperty("UsrAttributeID")
  AttributeID: PXFieldState;

  @placeAfterProperty("AttributeID")
  AttributeCategory: PXFieldState;

}
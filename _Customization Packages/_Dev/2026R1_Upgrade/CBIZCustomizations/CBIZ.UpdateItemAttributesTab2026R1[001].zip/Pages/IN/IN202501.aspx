<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="IN202501.aspx.cs" Inherits="Page_IN202501" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" PrimaryView="InventoryLotSerial" SuspendUnloading="False" TypeName="PX.LotSerialNbrAttribute.Ext.InventoryLotSerialMaint">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="false" Name="ViewOrgDocument" />
            <px:PXDSCallbackCommand Visible="false" CommitChanges="false" Name="ViewCurrentDocument" />
        </CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" 
		Width="100%" DataMember="InventoryLotSerial" TabIndex="5300" FilesIndicator="true" NoteIndicator="true">
		<Template>
			<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"/>
            <px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID" AutoRefresh="True">
            </px:PXSegmentMask>
            <px:PXSelector ID="edLotSerialNbr" runat="server" DataField="LotSerialNbr" AutoRefresh="True">
            </px:PXSelector>
		    <px:PXSelector ID="edUsrLotSerClassID" runat="server" DataField="UsrLotSerClassID" CommitChanges="True"  AllowEdit="True" edit="1">
            </px:PXSelector>
		    <px:PXTextEdit ID="edUsrMfgLotSerialNbr" runat="server" AlreadyLocalized="False" DataField="UsrMfgLotSerialNbr" >
            </px:PXTextEdit>
		    <px:PXDateTimeEdit ID="edExpireDate" runat="server" AlreadyLocalized="False" DataField="ExpireDate" >
            </px:PXDateTimeEdit>
            <px:PXLayoutRule runat="server" ColumnSpan="2">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edUsrLotSerialDesc" runat="server" AlreadyLocalized="False" DataField="UsrLotSerialDesc" >
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="S" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXSegmentMask ID="edSiteID" runat="server" DataField="SiteID" AllowEdit="True">
            </px:PXSegmentMask>
            <px:PXSegmentMask ID="edLocationID" runat="server" DataField="LocationID" AllowEdit="True">
            </px:PXSegmentMask>
            <px:PXTextEdit ID="edOrgDocument" runat="server" AlreadyLocalized="False" DataField="OriginalDocument">
                <LinkCommand Command="ViewOrgDocument" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edCurrentDocument" runat="server" AlreadyLocalized="False" DataField="CurrentDocument">
                <LinkCommand Command="ViewCurrentDocument" Target="ds"></LinkCommand>
            </px:PXTextEdit>
		    <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="S" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXNumberEdit ID="edUsrSalesPrice" runat="server" AlreadyLocalized="False" DataField="UsrSalesPrice" >
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edUsrRecPrice" runat="server" AlreadyLocalized="False" DataField="UsrRecPrice" >
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edPurchaseCost" runat="server" AlreadyLocalized="False" DataField="PurchaseCost" >
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edPriceSoldFor" runat="server" AlreadyLocalized="False" DataField="PriceSoldFor" >
            </px:PXNumberEdit>
		    <px:PXDropDown ID="edStatus" runat="server" DataField="Status" Width="100">
            </px:PXDropDown>
		</Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
    <px:PXTab ID="tab" runat="server" Width="100%" Height="606px" DataSourceID="ds" DataMember="InventoryLotSerialSettings" FilesIndicator="False" NoteIndicator="False">
        <AutoSize Enabled="True" Container="Window" MinHeight="150" />
        <Items>
            <px:PXTabItem Text="Attributes">
                <Template>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                    <px:PXGrid ID="PXGridAnswers" runat="server" Caption="Attributes" DataSourceID="ds" Height="150px" MatrixMode="True" Width="420px" SkinID="Attributes">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="AttributeID,RefNoteID" DataMember="Answers">
                                <RowTemplate>
                                    <px:PXLayoutRule runat="server" ControlSize="XM" LabelsWidth="M" StartColumn="True" />
                                    <px:PXTextEdit ID="edParameterID" runat="server" DataField="AttributeID" Enabled="False" />
                                    <px:PXTextEdit ID="edAnswerValue" runat="server" DataField="Value" />
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn AllowShowHide="False" DataField="AttributeID" TextField="AttributeID_description" TextAlign="Left" Width="135px" />
                                    <px:PXGridColumn DataField="isRequired" TextAlign="Center" Type="CheckBox" Width="80px" />
                                    <px:PXGridColumn DataField="Value" Width="185px" />
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                    </px:PXGrid>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="XS" ControlSize="XM" />
                    <px:PXImageUploader Height="320px" Width="430px" ID="imgUploader" runat="server" 
                                        DataField="UsrImageUrl" AllowUpload="true" ShowComment="true" DataMember="InventoryLotSerialSettings"/>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Description" LoadOnDemand="true" >
                <Template>
                    <px:PXRichTextEdit ID="edLongDesc" runat="server" DataField="UsrLongDesc" Style="border-width: 0px; border-top-width: 1px; width: 100%;"
                        AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                        <AutoSize Enabled="True" MinHeight="216" />
                        <LoadTemplate TypeName="PX.SM.SMNotificationMaint" DataMember="Notifications" ViewName="NotificationTemplate" ValueField="notificationID" TextField="Name" DataSourceID="ds" Size="M"/>
                    </px:PXRichTextEdit>
                </Template>
            </px:PXTabItem>
			<px:PXTabItem Text="eCommerce">
				<Template>
					<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XL" />
					<px:PXDropDown runat="server" ID="edUsrVisibility" DataField="UsrVisibility" />
					<px:PXDropDown runat="server" ID="edUsrAvailability" DataField="UsrAvailability" CommitChanges="True" />
					<px:PXDropDown runat="server" ID="edUsrNotAvailMode" DataField="UsrNotAvailMode" />
					<px:PXTextEdit runat="server" ID="edUsrCustomURL" DataField="UsrCustomURL" CommitChanges="True" />
					<px:PXTextEdit runat="server" ID="edUsrPageTitle" DataField="UsrPageTitle" />
					<px:PXTextEdit runat="server" ID="edUsrShortDescription" DataField="UsrShortDescription" />
					<px:PXTextEdit runat="server" ID="edUsrSearchKeywords" DataField="UsrSearchKeywords" />
					<px:PXTextEdit runat="server" ID="edUsrMetaKeywords" DataField="UsrMetaKeywords" />
					<px:PXTextEdit runat="server" ID="edUsrMetaDescription" DataField="UsrMetaDescription" TextMode="MultiLine" Height="150" />
					<px:PXLayoutRule runat="server" StartColumn="True" />
					<px:PXGrid runat="server" ID="gridLotSerialFileUrls" Caption="Media URLs" AutoAdjustColumns="True" Width="500px" Height="265px" 
                               SkinID="ShortList" CaptionVisible="True" FilesIndicator="False" NoteIndicator="False" ExportNotes="False">
						<Levels>
							<px:PXGridLevel DataMember="LotSerialFileUrls">
								<Columns>
									<px:PXGridColumn DataField="FileURL" Width="250" CommitChanges="True" />
									<px:PXGridColumn DataField="FileType" Width="120px" />
								</Columns>
							</px:PXGridLevel>
						</Levels>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
            <px:PXTabItem Text="Lot/Serial History">
                <Template>
                    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Height="144px" Style="z-index: 100" Width="100%" AdjustPageSize="Auto"
                        AllowPaging="True" AllowSearch="True"  SkinID="Inquire" 
                        RestrictFields="True" SyncPosition="true">
                        <ActionBar PagerVisible="Bottom" >
                            <PagerSettings Mode="NumericCompact" />
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataMember="LotSerialHistoryRecords">
                                <RowTemplate>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                                    <px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID" AllowEdit="true" />
                                    <px:PXSegmentMask ID="edVendor__AcctCD" runat="server" DataField="Vendor__AcctCD" AllowEdit="true" />
                                    <px:PXSegmentMask ID="edCustomer__AcctCD" runat="server" DataField="Customer__AcctCD" AllowEdit="true" />
                                    <px:PXSelector ID="edRefNbr" runat="server" DataField="RefNbr" AllowEdit="true" />
                                    <px:PXSegmentMask ID="edSiteID" runat="server" DataField="SiteID" AllowEdit="true" />
                                    <px:PXSelector ID="edPOReceiptLine__ReceiptNbr" runat="server" DataField="POReceiptLine__ReceiptNbr" AllowEdit="true" />
                                    <px:PXDropDown ID="edPOReceiptType" runat="server" DataField="POReceiptType" />
                                    <px:PXTextEdit ID="edSOOrderType" runat="server" DataField="SOOrderType" />
                                    <px:PXSelector ID="edSOOrderNbr" runat="server" DataField="SOOrderNbr" AllowEdit="true" />
                                    <px:PXSelector ID="edSOShipmentNbr" runat="server" DataField="SOShipmentNbr" AllowEdit="true" />
                                    <px:PXTextEdit ID="edTotalQty" DataField="TotalQty" runat="server"/>
                                    <px:PXTextEdit ID="edTotalCost" DataField="TotalCost" runat="server"/>
                                    <px:PXTextEdit ID="edAdditionalCost" DataField="AdditionalCost" runat="server" />
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryID" DisplayFormat="&gt;CCCCC-CCCCCCCCCCCCCCC" />
                                    <px:PXGridColumn DataField="TranDate" Width="90px" />
                                    <px:PXGridColumn DataField="TranType" />
                                    <px:PXGridColumn DataField="DocType" Visible="false" />
                                    <px:PXGridColumn DataField="RefNbr">
                                        <NavigateParams>
                                            <px:PXControlParam ControlID="grid" Name="DocType" PropertyName="DataValues[&quot;DocType&quot;]" Type="String" />
                                            <px:PXControlParam ControlID="grid" Name="RefNbr" PropertyName="DataValues[&quot;RefNbr&quot;]" Type="String" />
                                        </NavigateParams>
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SubItemID" DisplayFormat="&gt;AA-A" />
                                    <px:PXGridColumn DataField="SiteID" DisplayFormat="&gt;AAAAAAAAAA" />
                                    <px:PXGridColumn DataField="LocationID" AllowShowHide="Server" DisplayFormat="&gt;AAAAAAAAAA" />
                                    <px:PXGridColumn DataField="LotSerialNbr" Width="120px" />
                                    <px:PXGridColumn DataField="ExpireDate" DisplayFormat="d" Width="90px" />
                                    <px:PXGridColumn AllowUpdate="False" DataField="UOM" DisplayFormat="&gt;aaaaaa" Label="UOM" />
                                    <px:PXGridColumn DataField="InvQty" Label="Quantity" TextAlign="Right" Width="100px" />
                                    <px:PXGridColumn AllowNull="False" DataField="TranUnitCost" Label="Unit Cost" TextAlign="Right" Width="100px" />
                                    <px:PXGridColumn DataField="SOOrderType" DisplayFormat="&gt;aa" />
                                    <px:PXGridColumn DataField="SOOrderNbr" />
                                    <px:PXGridColumn DataField="SOShipmentNbr" />
                                    <px:PXGridColumn DataField="Customer__AcctCD" DisplayFormat="&gt;AAAAAAAAAA" />
                                    <px:PXGridColumn DataField="Customer__AcctName" Width="200px" />
                                    <px:PXGridColumn DataField="POReceiptType" RenderEditorText="True" />
                                    <px:PXGridColumn DataField="POReceiptLine__ReceiptNbr" />
                                    <px:PXGridColumn DataField="Vendor__AcctCD" DisplayFormat="&gt;AAAAAAAAAA" />
                                    <px:PXGridColumn DataField="Vendor__AcctName" Width="200px" />
                                    <px:PXGridColumn DataField="Released" TextAlign="Center" Type="CheckBox" />
                                    <px:PXGridColumn DataField="InventoryID_InventoryItem_Descr" Visible="false" Width="120px" />
                                    <px:PXGridColumn DataField="TotalQty" Visible="false" Width="0px" AllowShowHide="Server" />
                                    <px:PXGridColumn DataField="TotalCost" Visible="false" Width="0px" AllowShowHide="Server" />
                                    <px:PXGridColumn DataField="AdditionalCost" Visible="false" Width="0px" AllowShowHide="Server" />
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
        </Items>
        <AutoSize Enabled="True" MinHeight="150" />
    </px:PXTab>
</asp:Content>
import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.Graph.IGCMCustomClassificationForOriginDestinationCountryMaint", primaryView: "Records" })
export class IGCM1099 extends PXScreen {
  Records = createCollection(IGCMCustomClassificationForOriginDestinationCountry);
} // Views

@gridConfig({
  initNewRow: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMCustomClassificationForOriginDestinationCountry extends PXView {
  @columnConfig({ width: 70, hideViewLink: true }) InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 70, hideViewLink: true }) OriginCountry: PXFieldState;
  @columnConfig({ width: 70, hideViewLink: true }) DestinationCountry: PXFieldState;
  @columnConfig({ width: 120, hideViewLink: true }) CustomClassificationNbr: PXFieldState;
  @columnConfig({ width: 180, hideViewLink: true }) Descr: PXFieldState;
  @columnConfig({ width: 100, hideViewLink: true }) PercentageOfCost: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100, hideViewLink: true }) FlatAmountPerUnit: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100, hideViewLink: true }) FlatAmountPerWeight: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100, hideViewLink: true }) Tariff: PXFieldState<PXFieldOptions.CommitChanges>;
}

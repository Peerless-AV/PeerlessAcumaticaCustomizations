import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMContainerDestinationMaint", primaryView: "ContainerDestination" })
export class IGCM2094 extends PXScreen {
  ContainerDestination = createCollection(IGCMContainerDestination);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMContainerDestination extends PXView {
  @columnConfig({ width: 120 }) DestinationCodeID: PXFieldState;
  @columnConfig({ width: 200 }) Descr: PXFieldState;
}

import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMPOLCTallyEntry", primaryView: "LandedCosts" })
export class IGCM3097 extends PXScreen {
  LandedCosts = createSingle(IGCMPOLandedCost);
  LandedCostLines = createCollection(IGCMPOLandedCostLine);
} // Views

export class IGCMPOLandedCost extends PXView {
  LandedCostNbr: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMPOLandedCostLine extends PXView {
  ClearTallyQuantities: PXActionState;
  CompleteShipped: PXActionState;
  @columnConfig({ allowUpdate: false, width: 70 }) PONbr: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 90, hideViewLink: true }) InventoryID: PXFieldState;
  @columnConfig({ width: 120 }) UPCCode: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 200 }) Descr: PXFieldState;
  @columnConfig({ width: 100 }) OrderQty: PXFieldState;
  @columnConfig({ width: 100 }) ContainerQty: PXFieldState;
  @columnConfig({ width: 100 }) TallyQty: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ allowUpdate: false, width: 70, hideViewLink: true }) UOM: PXFieldState<PXFieldOptions.CommitChanges>;
}

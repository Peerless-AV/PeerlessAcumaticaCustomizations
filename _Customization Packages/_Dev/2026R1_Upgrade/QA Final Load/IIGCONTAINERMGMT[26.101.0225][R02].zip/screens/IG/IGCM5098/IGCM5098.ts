import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({
  graphType: "IGCM.IGCMPOLandedCostEntry",
  primaryView: "IIGDocument",
  showActivitiesIndicator: true,
  showUDFIndicator: true,
})
export class IGCM5098 extends PXScreen {
  addPOOrder2: PXActionState;
  addPOOrderLine2: PXActionState;
 

  @viewInfo({ containerName: "Document Summary" })
  IIGDocument = createSingle(IGCMPOLandedCost);
  CurrentDocument = createSingle(IGCMPOLandedCost2);
  @viewInfo({ containerName: "Details" })
  LandedCostLines = createCollection(IGCMPOLandedCostLine);
  @viewInfo({ containerName: "Vendor / Customer Info" })
  Remit_Contact = createSingle(POContact);
  @viewInfo({ containerName: "Vendor / Customer Info" })
  Remit_Address = createSingle(POAddress);
  @viewInfo({ containerName: "Landed Costs" })
  LandedCosts = createCollection(IGCMPOLCDetail);
  @viewInfo({ containerName: "Vessel Info" })
  VesselInfo = createCollection(IGCMVesselInfo);
  @viewInfo({ containerName: "Searates Info" })
  IGSFCMSearateInfo = createCollection(IGCMSearateInfo);
  @viewInfo({ containerName: "Expeditors Info" })
  IGCMExpeditorInfoView = createCollection(IGCMExpeditorInfo);
  @viewInfo({ containerName: "PO Selection" })
  filter = createSingle(POOrderFilter);
  @viewInfo({ containerName: "Add Purchase Order Line" })
  poLinesSelection = createCollection(POLine);
  @viewInfo({ containerName: "Add Purchase Order" })
  openOrders = createCollection(POOrder);
  @viewInfo({ containerName: "sOTransferFilter" })
  sOTransferFilter = createSingle(IGCMSOTransferFilter);
  @viewInfo({ containerName: "Add SO Transfer" })
  SOTransfers = createCollection(SOOrderShipment);
  @viewInfo({ containerName: "IGCMLandedCostLineSplittingExtension_LotSerOptions" })
  IGCMLandedCostLineSplittingExtension_LotSerOptions = createSingle(LotSerOptions);
  @viewInfo({
    containerName: "splits",
    parameters: [
      new ControlParameter("IGCMPOLandedCostLineSplit.siteID", "", ""),
      new ControlParameter("IGCMPOLandedCostLineSplit.inventoryID", "", ""),
      new ControlParameter("IGCMPOLandedCostLineSplit.subItemID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.inventoryID", "", ""),
      new ControlParameter("IGCMPOLandedCostLineSplit.inventoryID", "", ""),
      new ControlParameter("IGCMPOLandedCostLineSplit.subItemID", "", ""),
      new ControlParameter("IGCMPOLandedCostLineSplit.locationID", "", ""),
    ],
  })
  splits = createCollection(IGCMPOLandedCostLineSplit);
  @viewInfo({ containerName: "LineINDocuments" })
  LineINDocuments = createCollection(INTran);
  @viewInfo({ containerName: "Show SO Allocations Filter" })
  SOAllocationfilter = createSingle(IGCMSOOrderLineFilter);
  @viewInfo({ containerName: "SOAllocationLines" })
  SOAllocationLines = createCollection(SOLine);
  @viewInfo({ containerName: "Allocate To SO" })
  Allocations = createCollection(IGCMContainerSOAllocation);
  @viewInfo({ containerName: "Events Information" })
  IGSFCMSearateLineInfo = createSingle(IGCMSearateInfo2);
  @viewInfo({ containerName: "Events Information" })
  IGSFCMSearateEventsInfo = createCollection(IGCMSearateEventsInfo);
  @viewInfo({ containerName: "Container Information" })
  IGCMExpeditorContainerInfoView = createSingle(IGCMExpeditorContainerInfo);
  @viewInfo({ containerName: "Container Events" })
  IGCMExpeditorContainerEventsView = createCollection(IGCMExpeditorContainerEvents);
  @viewInfo({ containerName: "Container Lines" })
  IGCMExpeditorContainerLinesView = createCollection(IGCMExpeditorContainerLines);
  @viewInfo({ containerName: "Shipment Information" })
  IGCMExpeditorShipmentInfoView = createSingle(IGCMExpeditorShipmentInfo);
  @viewInfo({ containerName: "Shipment Documents" })
  IGCMExpeditorShipmentDocView = createCollection(IGCMExpeditorShipmentDoc);
  @viewInfo({ containerName: "Shipment Events" })
  IGCMExpeditorShipmentEventsView = createCollection(IGCMExpeditorShipmentEvents);
  @viewInfo({ containerName: "Shipment References" })
  IGCMExpeditorShipmentReferencesView = createCollection(IGCMExpeditorShipmentReferences);
  @viewInfo({ containerName: "Schedule Information" })
  VesselScheduleInfo = createSingle(IGCMVesselInfoSchedule);
  @viewInfo({ containerName: "Events Information" })
  VesselInfoScheduleEvents = createCollection(IGCMVesselInfoScheduleEvents);
} // Views

export class IGCMPOLandedCost extends PXView {
  LandedCostNbr: PXFieldState;
  LandedCostDate: PXFieldState;
  Status: PXFieldState;
  ContainerStatusID: PXFieldState<PXFieldOptions.CommitChanges>;
  SearateStatusID: PXFieldState;
  CountryCode: PXFieldState<PXFieldOptions.CommitChanges>;
  Hold: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMAutoAllocateLandedCost: PXFieldState;
  MMSI: PXFieldState<PXFieldOptions.CommitChanges>;
  Descr: PXFieldState;
  VendorID: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
  ContainerNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMFreightForwarderID: PXFieldState;
  ContainerTypeID: PXFieldState<PXFieldOptions.CommitChanges>;
  LogisticsServiceID: PXFieldState;
  DestinationCodeID: PXFieldState;
  InTransitLocation: PXFieldState<PXFieldOptions.CommitChanges>;
  OrderQty: PXFieldState<PXFieldOptions.Disabled>;
  TotalAmount: PXFieldState<PXFieldOptions.Disabled>;
  TotalWeight: PXFieldState<PXFieldOptions.Disabled>;
  TotalVolume: PXFieldState<PXFieldOptions.Disabled>;
  TotalLCAmount: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
  TotalDutyAmount: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
  TotalTariffAmount: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
  ContainerVolume: PXFieldState;
}

export class IGCMPOLandedCost2 extends PXView {
  AddPOOrder2: PXFieldState;


  CustomerID: PXFieldState;
  CustomerOrderNbr: PXFieldState;
  CustomerPaymentStatusID: PXFieldState;
  ExpectedDepartureDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ExpectedArrivalDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ExpectedArrivalSearateDate: PXFieldState<PXFieldOptions.CommitChanges>;
  FactoryReadyDate: PXFieldState;
  UsrIGCMFactoryPickupDate: PXFieldState;
  UsrIGCMOnBoardDate: PXFieldState;
  UsrIGCMContainerLoadingDate: PXFieldState;
  UsrIGCMCargoReadyDate: PXFieldState;
  PaymentDueDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ShipmentWindowStartDate: PXFieldState;
  ShipmentWindowEndDate: PXFieldState;
  GCCDate: PXFieldState;
  ActualDepartureDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ActualArrivalDate: PXFieldState<PXFieldOptions.CommitChanges>;
  CustomsEntryNbr: PXFieldState;
  CustomsEntryDate: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMExpCustomsClearanceDate: PXFieldState;
  DrayageAppointmentDate_Date: PXFieldState;
  DrayageAppointmentDate_Time: PXFieldState;
  DeliveryOrderNbr: PXFieldState;
  DeliveryOrderDate_Date: PXFieldState<PXFieldOptions.CommitChanges>;
  DeliveryOrderDate_Time: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMFinalDeliveryDate: PXFieldState;
  LastFreeDate: PXFieldState<PXFieldOptions.CommitChanges>;
  BrokerInvoiceNbr: PXFieldState;
  MainReferenceInvoice: PXFieldState;
  SecondaryInvoice: PXFieldState;
  UsrIGCMBillOfLadingNumber: PXFieldState;
  SCACNumber: PXFieldState;
  EstimatedFreight: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  allowUpdate: true,
  preset: GridPreset.Details,
  allowInsert: false,
})
export class IGCMPOLandedCostLine extends PXView {
  IGCMLandedCostLineSplittingExtension_ShowSplits: PXActionState;
  AddPOOrder: PXActionState;
  AddPOOrderLine: PXActionState;
  AddSOTransfer: PXActionState;
  ViewOrder: PXActionState;
  OverrideTallyQty: PXActionState;
  INDocuments: PXActionState;
  AllocateSOLines: PXActionState;
  ImportPoContainer: PXActionState;
  
  @linkCommand("viewOrder")
  @columnConfig({ hideViewLink: false, width: 120 })
  PONbr: PXFieldState<PXFieldOptions.CommitChanges>;
  
  @columnConfig({ hideViewLink: true, width: 220 }) POOrderDesc: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70, type: GridColumnType.CheckBox })
  Cancelled: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 140 }) VendorID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 180 }) VendorRefNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) BranchID: PXFieldState;
  @linkCommand("viewInventory")
  @columnConfig({ width: 170 })
  InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 140 }) UPCCode: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 140 }) InTransitSiteLocation: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 120 }) SiteID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 140 }) DestSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 140 }) LocationID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) OriginCountry: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) DestinationCountry: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) LotSerialNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) Descr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 85 }) OrderQty: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 100 }) ContainerQty: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 100 }) QtyOnContainers: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) InTransitQty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 85 }) ReceiptQty: PXFieldState;
  @linkCommand("viewReceipt")
  @columnConfig({ hideViewLink: true, width: 140 })
  ReceiptNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) ReturnQty: PXFieldState;
  @linkCommand("viewReturn")
  @columnConfig({ hideViewLink: true, width: 140 })
  ReturnNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 85 }) UnitCost: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 70 }) CuryID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox })
  GSPEligible: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 120 }) CustomClassificationNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 100 }) DutyAmt: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 100 }) Tariff: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 100 }) DiscPct: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) CuryDiscAmt: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) CuryDiscAmtVisible: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) CuryExtCost: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) ContainerNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 50 }) UOM: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 100 }) UnitWeight: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) UnitVolume: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 150 }) DollarsAllocated: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 120 }) ExpireDate: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 90 }) FactoryReadyDate: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 280 }) UsrIGCMInvoiceNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) POLineNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 180 }) APBillRefNbr: PXFieldState;
  @linkCommand("viewAPBill")
  @columnConfig({ width: 140 })
  APBillNbr: PXFieldState;
}

export class POContact extends PXView {
  FullName: PXFieldState;
  Salutation: PXFieldState;
  Phone1: PXFieldState;
  Email: PXFieldState;
}

export class POAddress extends PXView {
  AddressLine1: PXFieldState;
  AddressLine2: PXFieldState;
  City: PXFieldState;
  CountryID: PXFieldState;
  State: PXFieldState;
  PostalCode: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class IGCMPOLCDetail extends PXView {
  @linkCommand("viewLandedCostCode")
  @columnConfig({ width: 120 })
  LandedCostCodeID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) LandedCostCode__Descr: PXFieldState;
  @columnConfig({ width: 100 }) DollarsPayable: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 70, hideViewLink: true }) CuryID: PXFieldState;
  @columnConfig({ width: 160 }) InvoiceNbr: PXFieldState;
  @linkCommand("viewVendor")
  @columnConfig({ width: 120 })
  VendorID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 70, hideViewLink: true }) VendorLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 120, hideViewLink: true }) PrepaymentMethodID: PXFieldState;
  @columnConfig({ width: 180 }) ExtRefNbr: PXFieldState;
  @columnConfig({ width: 120, hideViewLink: true }) CashAccountID: PXFieldState;
  @linkCommand("ViewPrepayment")
  @columnConfig({ width: 140 })
  PrepaymentNbr: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  topBarItems: {
    UpdateVesselInfo: { index: 0, config: { commandName: "UpdateVesselInfo", text: "Update Vessel Info" } },
    ClearVesselInfo: { index: 1, config: { commandName: "ClearVesselInfo", text: "Clear" } },
    ShowVesselLocation: { index: 2, config: { commandName: "ShowVesselLocation", text: "Show Vessel Location" } },
    ShowVesselEventsInfo: { index: 3, config: { commandName: "ShowVesselEventsInfo", text: "Show Schedules" } },
  },
})
export class IGCMVesselInfo extends PXView {
  UpdateVesselInfo: PXActionState;
  ClearVesselInfo: PXActionState;
  ShowVesselLocation: PXActionState;
  ShowVesselEventsInfo: PXActionState;
  @columnConfig({ width: 100 }) ContainerNumber: PXFieldState;
  @columnConfig({ width: 100 }) Carrier: PXFieldState;
  @columnConfig({ width: 100 }) UpdatedAt: PXFieldState;
  @columnConfig({ width: 100 }) CacheExpires: PXFieldState;
  @columnConfig({ width: 100 }) Progress: PXFieldState;
  @columnConfig({ width: 100 }) OriginDate: PXFieldState;
  @columnConfig({ width: 100 }) OriginCountry: PXFieldState;
  @columnConfig({ width: 100 }) OriginLOCODE: PXFieldState;
  @columnConfig({ width: 100 }) OriginName: PXFieldState;
  @columnConfig({ width: 100 }) OriginLatitude: PXFieldState;
  @columnConfig({ width: 100 }) OriginLongitude: PXFieldState;
  @columnConfig({ width: 100 }) DestinationDate: PXFieldState;
  @columnConfig({ width: 100 }) DestinationCountry: PXFieldState;
  @columnConfig({ width: 100 }) DestinationLOCODE: PXFieldState;
  @columnConfig({ width: 100 }) DestinationName: PXFieldState;
  @columnConfig({ width: 100 }) DestinationLatitude: PXFieldState;
  @columnConfig({ width: 100 }) DestinationLongitude: PXFieldState;
  @columnConfig({ width: 100 }) Imo: PXFieldState;
  @columnConfig({ width: 100 }) Mmsi: PXFieldState;
  @columnConfig({ width: 100 }) VesselName: PXFieldState;
  @columnConfig({ width: 100 }) VesselLatitude: PXFieldState;
  @columnConfig({ width: 100 }) VesselLongitude: PXFieldState;
  @columnConfig({ width: 100 }) Course: PXFieldState;
  @columnConfig({ width: 100 }) Speed: PXFieldState;
  @columnConfig({ width: 100 }) PortCountry: PXFieldState;
  @columnConfig({ width: 100 }) PortLOCODE: PXFieldState;
  @columnConfig({ width: 100 }) PortName: PXFieldState;
  @columnConfig({ width: 100 }) PortLatitude: PXFieldState;
  @columnConfig({ width: 100 }) PortLongitude: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  topBarItems: {
    UpdateSearateInfo: { index: 0, config: { commandName: "UpdateSearateInfo", text: "Update Searates Info" } },
    ClearSearateInfo: { index: 1, config: { commandName: "ClearSearateInfo", text: "Clear" } },
    ShowSearateEventsInfo: { index: 2, config: { commandName: "ShowSearateEventsInfo", text: "Show Events" } },
  },
})
export class IGCMSearateInfo extends PXView {
  UpdateSearateInfo: PXActionState;
  ClearSearateInfo: PXActionState;
  ShowSearateEventsInfo: PXActionState;
  @columnConfig({ width: 280 }) VesselName: PXFieldState;
  @columnConfig({ width: 108 }) VesselMMSI: PXFieldState;
  @columnConfig({ width: 120 }) VesselImo: PXFieldState;
  @columnConfig({ width: 70 }) VesselFlag: PXFieldState;
  @columnConfig({ width: 120 }) VesselCallSign: PXFieldState;
  @columnConfig({ width: 140 }) ContainerNumber: PXFieldState;
  @columnConfig({ width: 140 }) ContainerIsoCode: PXFieldState;
  @columnConfig({ width: 220 }) PrepolLocationName: PXFieldState;
  @columnConfig({ width: 90 }) PrepolDate: PXFieldState;
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) PrepolActual: PXFieldState;
  @columnConfig({ width: 220 }) PolLocationName: PXFieldState;
  @columnConfig({ width: 90 }) PolDate: PXFieldState;
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) PolActual: PXFieldState;
  @columnConfig({ width: 220 }) PodLocationName: PXFieldState;
  @columnConfig({ width: 90 }) PodDate: PXFieldState;
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) PodActual: PXFieldState;
  @columnConfig({ width: 220 }) PostpodLocationName: PXFieldState;
  @columnConfig({ width: 90 }) PostpodDate: PXFieldState;
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) PostpodActual: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
  topBarItems: {
    UpdateExpeditorInfo: { index: 0, config: { commandName: "UpdateExpeditorInfo", text: "Update Expeditors Info" } },
    ClearExpeditorInfo: { index: 1, config: { commandName: "ClearExpeditorInfo", text: "Clear" } },
    ShowContainerInfo: { index: 2, config: { commandName: "ShowContainerInfo", text: "Show Container Info" } },
    ShowShipmentInfo: { index: 3, config: { commandName: "ShowShipmentInfo", text: "Show Shipment Info" } },
  },
})
export class IGCMExpeditorInfo extends PXView {
  UpdateExpeditorInfo: PXActionState;
  ClearExpeditorInfo: PXActionState;
  ShowContainerInfo: PXActionState;
  ShowShipmentInfo: PXActionState;
  @columnConfig({ width: 140 }) InstanceNo: PXFieldState;
  @columnConfig({ width: 140 }) ContainerNumber: PXFieldState;
  @columnConfig({ width: 140 }) ShipmentNumber: PXFieldState;
  @columnConfig({ width: 130 }) LastUpdateTime: PXFieldState;
}

export class POOrderFilter extends PXView {
  OrderType: PXFieldState<PXFieldOptions.CommitChanges>;
  OrderNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMVendorRef: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorID: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class POLine extends PXView {
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox, allowCheckAll: true })
  Selected: PXFieldState;
  @columnConfig({ width: 140, format: ">CCCCCCCCCCCCCCC" }) OrderNbr: PXFieldState;
  @columnConfig({ visible: false, textAlign: TextAlign.Right }) LineNbr: PXFieldState<PXFieldOptions.Hidden>;
  @columnConfig({ width: 100, format: ">AAAAAAAAAA" }) VendorID: PXFieldState;
  @columnConfig({ width: 180 }) UsrIGCMVendorRef: PXFieldState;
  @columnConfig({ width: 100, format: ">AAAAAAAAAA" }) InventoryID: PXFieldState;
  @columnConfig({ width: 200 }) TranDesc: PXFieldState;
  @columnConfig({ width: 60, type: GridColumnType.CheckBox })
  UsrIGCMShippedFull: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100, textAlign: TextAlign.Right }) OrderQty: PXFieldState;
  @columnConfig({ width: 108, textAlign: TextAlign.Right }) ReceivedQty: PXFieldState;
  @columnConfig({ width: 100 }) UsrIGCMQtyOnContainers: PXFieldState;
  @columnConfig({ width: 108, textAlign: TextAlign.Right }) LeftToReceiveQty: PXFieldState;
  @columnConfig({ width: 63, format: ">aaaaaa" }) UOM: PXFieldState;
  @columnConfig({ allowNull: false, width: 90 }) LineType: PXFieldState;
  @columnConfig({ width: 80, textAlign: TextAlign.Left }) PromisedDate: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class POOrder extends PXView {
  @columnConfig({
    //allowNull: false,
    width: 60,
    textAlign: TextAlign.Center,
    type: GridColumnType.CheckBox,
    allowCheckAll: true,
  })
  Selected: PXFieldState;
  OrderType: PXFieldState;
  @columnConfig({  hideViewLink: true, width: 200 }) OrderNbr: PXFieldState;
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox })
  UsrIGCMShippedFull: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 90 }) OrderDate: PXFieldState;
  @columnConfig({ allowUpdate: false, allowNull: false }) Status: PXFieldState;
  @columnConfig({ allowUpdate: false, allowNull: false, width: 100, textAlign: TextAlign.Right })
  CuryOrderTotal: PXFieldState;
  VendorRefNbr: PXFieldState;
  @columnConfig({ width: 200 }) OrderDesc: PXFieldState;
}

export class IGCMSOTransferFilter extends PXView {
  StartDate: PXFieldState<PXFieldOptions.CommitChanges>;
  EndDate: PXFieldState<PXFieldOptions.CommitChanges>;
  DestinationSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
  Priority: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class SOOrderShipment extends PXView {
  @columnConfig({ width: 60, type: GridColumnType.CheckBox, allowCheckAll: true })
  Selected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 70 }) OrderType: PXFieldState;
  @linkCommand("viewSOOrder")
  @columnConfig({ hideViewLink: true, width: 140 })
  OrderNbr: PXFieldState;
  @linkCommand("viewSOShipment")
  @columnConfig({ hideViewLink: true, width: 140 })
  ShipmentNbr: PXFieldState;
  @columnConfig({ width: 90 }) ShipDate: PXFieldState;
  @columnConfig({ width: 100 }) ShipmentQty: PXFieldState;
  @columnConfig({ width: 140 }) SOOrder__DestinationSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
  @linkCommand("viewINTransfer")
  @columnConfig({ hideViewLink: true, width: 140 })
  InvtRefNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 140 }) SOOrder__Priority: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class LotSerOptions extends PXView {
  IGCMLandedCostLineSplittingExtension_GenerateNumbers: PXActionState;

  UnassignedQty: PXFieldState<PXFieldOptions.Disabled>;
  Qty: PXFieldState;
  StartNumVal: PXFieldState;
}

@gridConfig({
  initNewRow: true,
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class IGCMPOLandedCostLineSplit extends PXView {
  @columnConfig({ width: 108 }) InventoryID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 140 }) SiteID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108 }) SubItemID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108, allowShowHide: GridColumnShowHideMode.Server })
  LocationID: PXFieldState;
  @columnConfig({ width: 140 }) InTransitLocation: PXFieldState;
  @columnConfig({ width: 108 }) LotSerialNbr: PXFieldState;
  @columnConfig({ width: 108, textAlign: TextAlign.Right }) Qty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108 }) UOM: PXFieldState;
  @columnConfig({ width: 90 }) ExpireDate: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class INTran extends PXView {
  @columnConfig({ width: 120 }) TranType: PXFieldState;
  @linkCommand("ViewInDocument")
  @columnConfig({ width: 120 })
  RefNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 150 }) InventoryID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) TranDesc: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) SiteID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) LocationID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) LotSerialNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) UOM: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) Qty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) UnitCost: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) TranCost: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) ExpireDate: PXFieldState;
}

export class IGCMSOOrderLineFilter extends PXView {
  ApplyAllocations: PXActionState;
  UnAllocateLine: PXActionState;

  OrderType: PXFieldState<PXFieldOptions.CommitChanges>;
  OrderNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  AvailableQtyForAllocation: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  allowInsert: false,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})


export class SOLine extends PXView {
  @columnConfig({ width: 60, type: GridColumnType.CheckBox, allowCheckAll: true })
  UsrIGCMIsSelected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 70 }) OrderType: PXFieldState;
  @columnConfig({ width: 70 }) OrderNbr: PXFieldState;
  @columnConfig({ width: 70, textAlign: TextAlign.Center }) LineNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100, textAlign: TextAlign.Center }) InventoryID: PXFieldState;
  @columnConfig({ width: 100 }) OpenQty: PXFieldState;
  @columnConfig({ width: 70, textAlign: TextAlign.Center }) UOM: PXFieldState;
  @columnConfig({ width: 70 }) SOOrder__Status: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) SOOrder__CustomerID: PXFieldState;
  @columnConfig({ width: 70 }) SOOrder__CustomerID_BAccountR_acctName: PXFieldState;
  @columnConfig({ width: 90 }) OrderDate: PXFieldState;
  @columnConfig({ width: 90 }) RequestDate: PXFieldState;
  @columnConfig({ width: 100 }) UnitPrice: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  allowInsert: false,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMContainerSOAllocation extends PXView {
  @columnConfig({ width: 70, type: GridColumnType.CheckBox, allowCheckAll: true })
  Selected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) LandedCostNbr: PXFieldState;
  @columnConfig({ width: 70 }) LCLineNbr: PXFieldState;
  @columnConfig({ width: 70 }) OrderType: PXFieldState;
  @columnConfig({ width: 100 }) OrderNbr: PXFieldState;
  @columnConfig({ width: 70 }) SOLineNbr: PXFieldState;
  @columnConfig({ width: 70 }) SOLineOrderQty: PXFieldState;
  @columnConfig({ width: 70 }) AllocatedQty: PXFieldState;
}

export class IGCMSearateInfo2 extends PXView {}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMSearateEventsInfo extends PXView {
  @columnConfig({ width: 130 }) Description: PXFieldState;
  @columnConfig({ width: 70 }) Status: PXFieldState;
  @columnConfig({ width: 90 }) EventDate: PXFieldState;
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) EventActual: PXFieldState;
  @columnConfig({ width: 80 }) Type: PXFieldState;
  @columnConfig({ width: 80 }) Voyage: PXFieldState;
  @columnConfig({ width: 120 }) LocationName: PXFieldState;
  @columnConfig({ width: 150 }) LocationState: PXFieldState;
  @columnConfig({ width: 70 }) LocationCountryCode: PXFieldState;
  @columnConfig({ width: 150 }) LocationCountry: PXFieldState;
  @columnConfig({ width: 80 }) LocationLocode: PXFieldState;
  @columnConfig({ width: 100 }) LocationLat: PXFieldState;
  @columnConfig({ width: 100 }) LocationLng: PXFieldState;
}

export class IGCMExpeditorContainerInfo extends PXView {
  InstanceNo: PXFieldState;
  ContainerNumber: PXFieldState;
  OriginName: PXFieldState;
  OriginCode: PXFieldState;
  DestinationName: PXFieldState;
  DestinationCode: PXFieldState;
  Mode: PXFieldState;
  Carrier: PXFieldState;
  Size: PXFieldState;
  MoveType: PXFieldState;
  ActualDepartureDate: PXFieldState;
  EstimatedDepartureDate: PXFieldState;
  ActualArrivalDate: PXFieldState;
  EstimatedArrivalDate: PXFieldState;
  Vessel: PXFieldState;
  VoyageNumber: PXFieldState;
  SealNumber: PXFieldState;
  PackagesValue: PXFieldState;
  PackagesUnits: PXFieldState;
  WeightValue: PXFieldState;
  WeightUnits: PXFieldState;
  VolumeValue: PXFieldState;
  VolumeUnits: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMExpeditorContainerEvents extends PXView {
  @columnConfig({ width: 140 }) InstanceNo: PXFieldState;
  @columnConfig({ width: 70 }) Code: PXFieldState;
  @columnConfig({ width: 280 }) Description: PXFieldState;
  @columnConfig({ width: 90 }) Time: PXFieldState;
  @columnConfig({ width: 180 }) OriginName: PXFieldState;
  @columnConfig({ width: 70 }) OriginCode: PXFieldState;
  @columnConfig({ width: 180 }) DestinationName: PXFieldState;
  @columnConfig({ width: 70 }) DestinationCode: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMExpeditorContainerLines extends PXView {
  @columnConfig({ width: 100 }) WeightValue: PXFieldState;
  @columnConfig({ width: 140 }) WeightUnits: PXFieldState;
  @columnConfig({ width: 100 }) VolumeValue: PXFieldState;
  @columnConfig({ width: 140 }) VolumeUnits: PXFieldState;
  @columnConfig({ width: 140 }) ShipmentNumber: PXFieldState;
  @columnConfig({ width: 100 }) QuantityValue: PXFieldState;
  @columnConfig({ width: 140 }) QuantityUnits: PXFieldState;
  @columnConfig({ width: 100 }) PackagesValue: PXFieldState;
  @columnConfig({ width: 140 }) PackagesUnits: PXFieldState;
  @columnConfig({ width: 70 }) LoadSequence: PXFieldState;
  @columnConfig({ width: 140 }) InstanceNo: PXFieldState;
  @columnConfig({ width: 140 }) BillOfLadingNumber: PXFieldState;
}

export class IGCMExpeditorShipmentInfo extends PXView {
  ShipmentNumber: PXFieldState;
  Status: PXFieldState;
  LastUpdateTime: PXFieldState;
  OriginName: PXFieldState;
  OriginCode: PXFieldState;
  DestinationName: PXFieldState;
  DestinationCode: PXFieldState;
  DeliveryName: PXFieldState;
  DeliveryCode: PXFieldState;
  LoadingName: PXFieldState;
  LoadingCode: PXFieldState;
  UnladingName: PXFieldState;
  UnladingCode: PXFieldState;
  ClearanceName: PXFieldState;
  ClearanceCode: PXFieldState;
  Mode: PXFieldState;
  Vessel: PXFieldState;
  QuantityValue: PXFieldState;
  QuantityUnits: PXFieldState;
  WeightValue: PXFieldState;
  WeightUnits: PXFieldState;
  VolumeValue: PXFieldState;
  VolumeUnits: PXFieldState;
  CarrierName: PXFieldState;
  CarrierCode: PXFieldState;
  Consignee: PXFieldState;
  ActualReceiptTimesInvoiceNumber: PXFieldState;
  ActualReceiptTimesTime: PXFieldState;
  GoodsDesc: PXFieldState;
  SecurityFilingParty: PXFieldState;
  Hazardous: PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMExpeditorShipmentDoc extends PXView {
  @columnConfig({ width: 180 }) DocumentType: PXFieldState;
  @columnConfig({ width: 180 }) Group: PXFieldState;
  @columnConfig({ width: 180 }) Label: PXFieldState;
  @columnConfig({ width: 140 }) FileSize: PXFieldState;
  @columnConfig({ width: 70 }) NumberOfPages: PXFieldState;
  @columnConfig({ width: 280 }) DownloadCallbackUrl: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMExpeditorShipmentEvents extends PXView {
  @columnConfig({ width: 280 }) Description: PXFieldState;
  @columnConfig({ width: 90 }) Time: PXFieldState;
  @columnConfig({ width: 180 }) OriginName: PXFieldState;
  @columnConfig({ width: 70 }) OriginCode: PXFieldState;
  @columnConfig({ width: 180 }) DestinationName: PXFieldState;
  @columnConfig({ width: 70 }) DestinationCode: PXFieldState;
  @columnConfig({ width: 280 }) Remarks: PXFieldState;
  @columnConfig({ width: 70 }) Invoice: PXFieldState;
  @columnConfig({ width: 70 }) Code: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMExpeditorShipmentReferences extends PXView {
  @columnConfig({ width: 180 }) RefType: PXFieldState;
  @columnConfig({ width: 180 }) RefNumber: PXFieldState;
}

export class IGCMVesselInfoSchedule extends PXView {
  @columnConfig({ width: 90 }) Date: PXFieldState;
  @columnConfig({ width: 70 }) Country: PXFieldState;
  @columnConfig({ width: 120 }) LOCODE: PXFieldState;
  @columnConfig({ width: 120 }) Name: PXFieldState;
  @columnConfig({ width: 100 }) Latitude: PXFieldState;
  @columnConfig({ width: 100 }) Longitude: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMVesselInfoScheduleEvents extends PXView {
  @columnConfig({ width: 70 }) Code: PXFieldState;
  @columnConfig({ width: 120, type: GridColumnType.CheckBox }) Actual: PXFieldState;
  @columnConfig({ width: 120 }) Name: PXFieldState;
  @columnConfig({ width: 90 }) Date: PXFieldState;
}
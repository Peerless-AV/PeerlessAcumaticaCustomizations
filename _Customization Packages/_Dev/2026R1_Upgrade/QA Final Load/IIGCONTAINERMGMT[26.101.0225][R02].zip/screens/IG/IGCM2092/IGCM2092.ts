import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMContainerTypeMaint", primaryView: "ContainerType" })
export class IGCM2092 extends PXScreen {
  ContainerType = createCollection(IGCMContainerType);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMContainerType extends PXView {
  @columnConfig({ width: 120 }) ContainerTypeID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 200 }) Descr: PXFieldState;
  @columnConfig({ width: 100 }) Volume: PXFieldState;
  @columnConfig({ width: 72, hideViewLink: true }) UOM: PXFieldState;
}

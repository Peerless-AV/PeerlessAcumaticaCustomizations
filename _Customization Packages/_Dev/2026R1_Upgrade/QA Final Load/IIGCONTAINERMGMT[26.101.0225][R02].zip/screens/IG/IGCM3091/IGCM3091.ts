import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMFreightForwarderMaint", primaryView: "FreightForwarder" })
export class IGCM3091 extends PXScreen {
  FreightForwarder = createCollection(IGCMFreightForwarder);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMFreightForwarder extends PXView {
  @columnConfig({ width: 120 }) FreightForwarderID: PXFieldState;
  @columnConfig({ width: 200 }) URL: PXFieldState;
  @columnConfig({ width: 200 }) ShippingVessel: PXFieldState;
}

import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMPOContainerStatusMaint", primaryView: "ContainerStatuses" })
export class IGCM2096 extends PXScreen {
  ContainerStatuses = createCollection(IGCMPOContainerStatus);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMPOContainerStatus extends PXView {
  @columnConfig({ width: 120 }) ContainerStatusID: PXFieldState;
  @columnConfig({ width: 200 }) Descr: PXFieldState;
}

import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMPOLCDistributionEntry", primaryView: "Documents" })
export class IGCM3096 extends PXScreen {
  Documents = createSingle(IGCMPOLCDistribution);
  CurrentDocument = createSingle(IGCMPOLCDistribution2);
  @viewInfo({ containerName: "Document Details" })
  DistributionsDetails = createCollection(IGCMPOLCDistributionLine);
  @viewInfo({ containerName: "Vendor Info" })
  Remit_Contact = createSingle(POContact);
  @viewInfo({ containerName: "Vendor Info" })
  Remit_Address = createSingle(POAddress);
  @viewInfo({ containerName: "Landed Costs" })
  LandedCosts = createCollection(IGCMPOLCDetailDist);
  @viewInfo({ containerName: "Add Containers" })
  OpenLandedCosts = createCollection(IGCMPOLandedCost);
} // Views

export class IGCMPOLCDistribution extends PXView {
  addLandedCosts2: PXActionState;
  
  FileNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  FileDate: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorID: PXFieldState<PXFieldOptions.CommitChanges>;
  TotalQuantity: PXFieldState;
  TotalCost: PXFieldState;
  TotalWeight: PXFieldState;
  TotalVolume: PXFieldState;
}

export class IGCMPOLCDistribution2 extends PXView {
  ExpectedDepartureDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ExpectedArrivalDate: PXFieldState<PXFieldOptions.CommitChanges>;
  FactoryReadyDate: PXFieldState;
  UsrIGCMFactoryPickupDate: PXFieldState;
  UsrIGCMOnBoardDate: PXFieldState;
  UsrIGCMContainerLoadingDate: PXFieldState;
  UsrIGCMCargoReadyDate: PXFieldState;
  PaymentDueDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ShipmentWindowStartDate: PXFieldState;
  ShipmentWindowEndDate: PXFieldState;
  GCCDate: PXFieldState;
  ActualDepartureDate: PXFieldState<PXFieldOptions.CommitChanges>;
  ActualArrivalDate: PXFieldState<PXFieldOptions.CommitChanges>;
  CustomsEntryNbr: PXFieldState;
  CustomsEntryDate: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMExpCustomsClearanceDate: PXFieldState;
  DrayageAppointmentDate_Date: PXFieldState;
  DrayageAppointmentDate_Time: PXFieldState;
  DeliveryOrderNbr: PXFieldState;
  DeliveryOrderDate: PXFieldState;
  UsrIGCMFinalDeliveryDate: PXFieldState;
  LastFreeDate: PXFieldState<PXFieldOptions.CommitChanges>;
  BrokerInvoiceNbr: PXFieldState;
  MainReferenceInvoice: PXFieldState;
  SecondaryInvoice: PXFieldState;
  UsrIGCMBillOfLadingNumber: PXFieldState;
  EstimatedFreight: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  topBarItems: {
    AddLandedCosts: {
      index: 0,
      config: { commandName: "AddLandedCosts", toolTip: "Add Multiple Containers", text: "Add Containers" },
    },
  },
})
export class IGCMPOLCDistributionLine extends PXView {
  AddLandedCosts: PXActionState;
  @linkCommand("viewLandedCost")
  @columnConfig({ width: 120 })
  LandedCostNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class POContact extends PXView {
  FullName: PXFieldState;
  Salutation: PXFieldState;
  Phone1: PXFieldState;
  Email: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class POAddress extends PXView {
  AddressLine1: PXFieldState;
  AddressLine2: PXFieldState;
  City: PXFieldState;
  CountryID: PXFieldState;
  State: PXFieldState;
  PostalCode: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class IGCMPOLCDetailDist extends PXView {
  @linkCommand("viewLandedCostCode")
  @columnConfig({ width: 120 })
  LandedCostCodeID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) LandedCostCode__Descr: PXFieldState;
  @columnConfig({ width: 100 }) DollarsPayable: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 180 }) InvoiceNbr: PXFieldState;
  @columnConfig({ width: 140, hideViewLink: true }) VendorID: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 70, hideViewLink: true }) VendorLocationID: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMPOLandedCost extends PXView {
  addLandedCosts2: PXActionState;
  
  @columnConfig({ hideViewLink: true, width: 30, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) Selected: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) LandedCostNbr: PXFieldState;
  @columnConfig({ width: 120 }) LandedCostDate: PXFieldState;
  @columnConfig({ width: 100 }) OrderQty: PXFieldState;
  @columnConfig({ width: 100 }) TotalAmount: PXFieldState;
  @columnConfig({ width: 100 }) TotalVolume: PXFieldState;
  @columnConfig({ width: 100 }) TotalWeight: PXFieldState;
  @columnConfig({ width: 80 }) Status: PXFieldState;
}

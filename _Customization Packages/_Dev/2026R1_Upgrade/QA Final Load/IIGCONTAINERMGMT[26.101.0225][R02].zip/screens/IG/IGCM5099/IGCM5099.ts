import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMUpdateSearateInformationProc", primaryView: "Records" })
export class IGCM5099 extends PXScreen {
  Records = createCollection(IGCMPOLandedCost);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Inquiry,
})
export class IGCMPOLandedCost extends PXView {
  @columnConfig({ width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox }) Selected: PXFieldState;
  @columnConfig({ width: 150, hideViewLink: true }) LandedCostNbr: PXFieldState;
  @columnConfig({ width: 100 }) LandedCostDate: PXFieldState;
  @columnConfig({ width: 150 }) ContainerNbr: PXFieldState;
}

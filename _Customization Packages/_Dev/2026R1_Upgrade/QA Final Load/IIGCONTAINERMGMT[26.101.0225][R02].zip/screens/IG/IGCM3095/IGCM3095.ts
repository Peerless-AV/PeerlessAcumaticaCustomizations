import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMShippingContStatusMaint", primaryView: "ContainerStatuses" })
export class IGCM3095 extends PXScreen {
  ContainerStatuses = createCollection(IGCMShippingContStatus);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMShippingContStatus extends PXView {
  @columnConfig({ width: 70 }) ContainerStatusID: PXFieldState;
  @columnConfig({ width: 220 }) Descr: PXFieldState;
}

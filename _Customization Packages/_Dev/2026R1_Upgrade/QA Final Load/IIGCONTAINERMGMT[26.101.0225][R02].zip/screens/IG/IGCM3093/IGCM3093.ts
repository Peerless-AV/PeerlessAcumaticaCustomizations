import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMCustomClassificationMaint", primaryView: "CustomClassification" })
export class IGCM3093 extends PXScreen {
  CustomClassification = createCollection(IGCMCustomClassification);
  Tariff = createCollection(IGCMTariff);
} // Views

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Primary,
  mergeToolbarWith: "ScreenToolbar",
  autoRepaint: ["Tariff"],
  initNewRow: true,
})
export class IGCMCustomClassification extends PXView {
  @columnConfig({ width: 120 }) CustomClassificationNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 180 }) Descr: PXFieldState;
  @columnConfig({ width: 100 }) PercentageOfCost: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) FlatAmountPerUnit: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) FlatAmountPerWeight: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  initNewRow: true,
  preset: GridPreset.Details,
})
export class IGCMTariff extends PXView {
  @columnConfig({ width: 70, hideViewLink: true }) CountryCode: PXFieldState;
  @columnConfig({ width: 100 }) Tariff: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 280 }) Description: PXFieldState;
}

import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  PXView,
  PXFieldState,
  gridConfig,
  controlConfig,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMShippingContainerEntry", primaryView: "Container" })
export class IGCM3094 extends PXScreen {
  addShipment2: PXActionState;
  addSOShipLine2: PXActionState;
  attachLinesToPackage: PXActionState;

  Container = createSingle(IGCMShippingContainer);
  CurrentDocument = createSingle(IGCMShippingContainer2);
  @viewInfo({ containerName: "Details" })
  ShippingContainerLines = createCollection(IGCMShippingContainerLine);
  @viewInfo({ containerName: "Packages" })
  packages = createCollection(IGCMPackages);
  @viewInfo({ containerName: "Customer Info" })
  ContactInfo = createSingle(SOContact);
  @viewInfo({ containerName: "Customer Info" })
  AddressInfo = createSingle(SOAddress);
  @viewInfo({ containerName: "Add Shipment" })
  shipments = createCollection(SOShipment);
  @viewInfo({ containerName: "shipLine" })
  shipLine = createCollection(SOShipLine);
  @viewInfo({ containerName: "Add Package" })
  packDetails = createCollection(SOPackageDetail);
  @viewInfo({ containerName: "Ship. Lines" })
  contShipLineUnbound = createCollection(IGCMShipLinePack);
  @viewInfo({ containerName: "Ship. Lines" })
  shipLineS = createCollection(SOShipLine2);
} // Views

export class IGCMShippingContainer extends PXView {
  attachLinesToPackage: PXActionState;


  ShippingContNbr: PXFieldState;
  Status: PXFieldState<PXFieldOptions.CommitChanges>;
  Hold: PXFieldState<PXFieldOptions.CommitChanges>;
  @controlConfig({ allowEdit: true })
  POReceiptNbr: PXFieldState;
  CustomerID: PXFieldState<PXFieldOptions.CommitChanges>;
  DestinationSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
  ShipmentType: PXFieldState<PXFieldOptions.CommitChanges>;
  ShippingContainerDate: PXFieldState;
  ContainerNbr: PXFieldState;
  ContainerStatusID: PXFieldState;
  OrderQty: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
  TotalWeight: PXFieldState;
  TotalVolume: PXFieldState;
}

export class IGCMShippingContainer2 extends PXView {
  ExpectedDepartureDate: PXFieldState;
  ActualDepartureDate: PXFieldState;
  PaymentDueDate: PXFieldState;
  ExpectedArrivalDate: PXFieldState;
  ActualArrivalDate: PXFieldState<PXFieldOptions.CommitChanges>;
  CustomsEntryNbr: PXFieldState;
  CustomsEntryDate: PXFieldState<PXFieldOptions.CommitChanges>;
  DeliveryOrderNbr: PXFieldState;
  DeliveryOrderDate: PXFieldState;
  CompletionDate: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  allowInsert: false,
})
export class IGCMShippingContainerLine extends PXView {
  AddShipment: PXActionState;
  AddSOShipLine: PXActionState;

  @linkCommand("viewSOShipment")
  @columnConfig({ width: 140 })
  ShipmentNbr: PXFieldState;
  @columnConfig({ width: 80 }) ShipLineNbr: PXFieldState;
  @columnConfig({ width: 90 }) ShipmentDate: PXFieldState;
  @linkCommand("viewInventory")
  @columnConfig({ width: 80 })
  InventoryID: PXFieldState;

  @columnConfig({ hideViewLink: true, width: 100 }) SiteID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 140 }) LocationID: PXFieldState;
  @columnConfig({ width: 140 }) LotSerialNbr: PXFieldState;
  @columnConfig({ width: 140 }) TranDesc: PXFieldState;
  @columnConfig({ width: 80 }) OrderedQty: PXFieldState;
  @columnConfig({ width: 100 }) ContainerQty: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) QtyOnContainers: PXFieldState;
  @columnConfig({ width: 80 }) OpenQty: PXFieldState;
  @columnConfig({ width: 100 }) UnitWeight: PXFieldState;
  @columnConfig({ width: 100 }) UnitVolume: PXFieldState;
  @columnConfig({ width: 100 }) ExtWeight: PXFieldState;
  @columnConfig({ width: 100 }) ExtVolume: PXFieldState;
  @columnConfig({ width: 90 }) ExpireDate: PXFieldState;
  @columnConfig({ width: 120, type: GridColumnType.CheckBox }) Confirmed: PXFieldState;
  @columnConfig({ width: 80, type: GridColumnType.CheckBox }) Released: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  allowInsert: false,
})
export class IGCMPackages extends PXView {
  AddPackage: PXActionState;
  @columnConfig({ width: 90, type: GridColumnType.CheckBox }) Confirmed: PXFieldState;
  @columnConfig({ width: 140 }) BoxID: PXFieldState;
  @columnConfig({ width: 70 }) PackageType: PXFieldState;
  @columnConfig({ width: 140 }) ShipmentNbr: PXFieldState;
  @columnConfig({ width: 70 }) PackLineNbr: PXFieldState;
  @columnConfig({ width: 140 }) Description: PXFieldState;
  @columnConfig({ width: 100 }) Weight: PXFieldState;
  @columnConfig({ width: 70 }) WeightUOM: PXFieldState;
  @columnConfig({ width: 100 }) DeclaredValue: PXFieldState;
  @columnConfig({ width: 100 }) COD: PXFieldState;
  @columnConfig({ width: 212 }) TrackNumber: PXFieldState;
}

export class SOContact extends PXView {
  OverrideContact: PXFieldState<PXFieldOptions.CommitChanges>;
  FullName: PXFieldState;
  Attention: PXFieldState;
  Phone1: PXFieldState;
  Email: PXFieldState;
}

export class SOAddress extends PXView {
  OverrideAddress: PXFieldState<PXFieldOptions.CommitChanges>;
  AddressLine1: PXFieldState;
  AddressLine2: PXFieldState;
  City: PXFieldState;
  CountryID: PXFieldState;
  State: PXFieldState;
  PostalCode: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class SOShipment extends PXView {

  @columnConfig({
    allowNull: false,
    width: 60,
    textAlign: TextAlign.Center,
    type: GridColumnType.CheckBox,
    allowCheckAll: true,
  })
  Selected: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) ShipmentNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) ShipmentType: PXFieldState;
  @columnConfig({ width: 60, type: GridColumnType.CheckBox, allowCheckAll: true }) UsrIGCMShippedFull: PXFieldState;
  @columnConfig({ hideViewLink: true, allowCheckAll: false, width: 90, type: GridColumnType.NotSet }) ShipDate: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) CustomerID: PXFieldState;
  @columnConfig({ allowUpdate: false, allowNull: false }) Status: PXFieldState;
  @columnConfig({ allowUpdate: false, allowNull: false, width: 100, textAlign: TextAlign.Right })
  LineTotal: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class SOShipLine extends PXView {
  @columnConfig({ width: 60, allowCheckAll: true })
  UsrIGCMSelected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 60, allowCheckAll: true })
  UsrIGCMShippedFull: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) SOShipment__ShipmentNbr: PXFieldState;
  @columnConfig({ width: 70 }) SOShipment__ShipmentType: PXFieldState;
  @columnConfig({ width: 70 }) UsrIGCMCustomerID: PXFieldState;
  @columnConfig({ width: 70 }) LineNbr: PXFieldState;
  @columnConfig({ width: 100, format: ">AAAAAAAAAA", hideViewLink: true }) InventoryID: PXFieldState;
  @columnConfig({ width: 200 }) TranDesc: PXFieldState;
  @columnConfig({ width: 100, textAlign: TextAlign.Right }) OrigOrderQty: PXFieldState;
  @columnConfig({ width: 108, textAlign: TextAlign.Right }) ShippedQty: PXFieldState;
  @columnConfig({ width: 100 }) UsrIGCMQtyOnContainers: PXFieldState;
  @columnConfig({ width: 108, textAlign: TextAlign.Right }) UnassignedQty: PXFieldState;
  @columnConfig({ width: 63, format: ">aaaaaa", hideViewLink: true }) UOM: PXFieldState;
  @columnConfig({ width: 80, textAlign: TextAlign.Left }) ExpireDate: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class SOPackageDetail extends PXView {

  @columnConfig({ width: 60, type: GridColumnType.CheckBox, allowCheckAll: true, textAlign: TextAlign.Center })
  UsrIGCMSelected: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 140 }) ShipmentNbr: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 70 }) SOShipment__ShipmentType: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 70 }) LineNbr: PXFieldState;
  @columnConfig({ hideViewLink: true,allowUpdate: false, width: 140 }) BoxID: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 90, type: GridColumnType.CheckBox }) Confirmed: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 140 }) Description: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 220 }) TrackNumber: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 100 }) Weight: PXFieldState;
  @columnConfig({ allowUpdate: false, width: 70 }) WeightUOM: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMShipLinePack extends PXView {
  @columnConfig({ width: 140 }) ShipmentNbr: PXFieldState;
  @columnConfig({ width: 70 }) ShipContLineNbr: PXFieldState;
  @columnConfig({ width: 70 }) InventoryID: PXFieldState;
  @columnConfig({ width: 140 }) UOM: PXFieldState;
  @columnConfig({ width: 100 }) Qty: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class SOShipLine2 extends PXView {
  @columnConfig({ width: 60, type: GridColumnType.CheckBox, allowCheckAll: true, textAlign: TextAlign.Center })
  UsrIGCMSelected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ hideViewLink: true, width: 70 }) SOShipment__ShipmentNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) SOShipment__ShipmentType: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) SOShipment__CustomerID: PXFieldState; 
  @columnConfig({ hideViewLink: true, width: 70 }) LineNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) InventoryID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 280 }) TranDesc: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) OrigOrderQty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) ShippedQty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) UnassignedQty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 72 }) UOM: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 90 }) ExpireDate: PXFieldState;
}
/*import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, PXView, PXFieldState, gridConfig, controlConfig, PXFieldOptions, linkCommand, columnConfig, GridColumnType, TextAlign, GridPreset, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "IGCM.IGCMShippingContainerEntry", primaryView: "Container", })
export class IGCM3094 extends PXScreen {

	Container = createSingle(IGCMShippingContainer);
	CurrentDocument = createSingle(IGCMShippingContainer2);
   	@viewInfo({containerName: "Details"})
	ShippingContainerLines = createCollection(IGCMShippingContainerLine);
   	@viewInfo({containerName: "Packages"})
	packages = createCollection(IGCMPackages);
   	@viewInfo({containerName: "Customer Info"})
	ContactInfo = createSingle(SOContact);
   	@viewInfo({containerName: "Customer Info"})
	AddressInfo = createSingle(SOAddress);
   	@viewInfo({containerName: "Add Shipment"})
	shipments = createCollection(SOShipment);
   	@viewInfo({containerName: "shipLine"})
	shipLine = createCollection(SOShipLine);
   	@viewInfo({containerName: "Add Package"})
	packDetails = createCollection(SOPackageDetail);
   	@viewInfo({containerName: "Ship. Lines"})
	contShipLineUnbound = createCollection(IGCMShipLinePack);
   	@viewInfo({containerName: "Ship. Lines"})
	shipLineS = createCollection(SOShipLine2);
}// Views

export class IGCMShippingContainer extends PXView  {

	ShippingContNbr : PXFieldState;
	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	Hold : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	POReceiptNbr : PXFieldState;
	CustomerID : PXFieldState<PXFieldOptions.CommitChanges>;
	DestinationSiteID : PXFieldState<PXFieldOptions.CommitChanges>;
	ShipmentType : PXFieldState<PXFieldOptions.CommitChanges>;
	ShippingContainerDate : PXFieldState;
	ContainerNbr : PXFieldState;
	ContainerStatusID : PXFieldState;
	OrderQty : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	TotalWeight : PXFieldState;
	TotalVolume : PXFieldState;
}

export class IGCMShippingContainer2 extends PXView  {

	ExpectedDepartureDate : PXFieldState;
	ActualDepartureDate : PXFieldState;
	PaymentDueDate : PXFieldState;
	ExpectedArrivalDate : PXFieldState;
	ActualArrivalDate : PXFieldState<PXFieldOptions.CommitChanges>;
	CustomsEntryNbr : PXFieldState;
	CustomsEntryDate : PXFieldState<PXFieldOptions.CommitChanges>;
	DeliveryOrderNbr : PXFieldState;
	DeliveryOrderDate : PXFieldState;
	CompletionDate : PXFieldState;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	AddShipment: {index: 0, config: {commandName: "AddShipment", text: "Add Shipment"}},
	AddSOShipLine: {index: 1, config: {commandName: "AddSOShipLine", text: "Add Ship. Line"}},
}
})
export class IGCMShippingContainerLine extends PXView  {

	AddShipment : PXActionState;
	AddSOShipLine : PXActionState;
	@linkCommand("viewSOShipment")
	@columnConfig({width: 140})	ShipmentNbr : PXFieldState;
	@columnConfig({width: 80})	ShipLineNbr : PXFieldState;
	@columnConfig({width: 90})	ShipmentDate : PXFieldState;
	@linkCommand("viewInventory")
	@columnConfig({width: 80})	InventoryID : PXFieldState;
	@columnConfig({width: 100})	SiteID : PXFieldState;
	@columnConfig({width: 140})	LocationID : PXFieldState;
	@columnConfig({width: 140})	LotSerialNbr : PXFieldState;
	@columnConfig({width: 140})	TranDesc : PXFieldState;
	@columnConfig({width: 80})	OrderedQty : PXFieldState;
	@columnConfig({width: 100})	ContainerQty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	QtyOnContainers : PXFieldState;
	@columnConfig({width: 80})	OpenQty : PXFieldState;
	@columnConfig({width: 100})	UnitWeight : PXFieldState;
	@columnConfig({width: 100})	UnitVolume : PXFieldState;
	@columnConfig({width: 100})	ExtWeight : PXFieldState;
	@columnConfig({width: 100})	ExtVolume : PXFieldState;
	@columnConfig({width: 90})	ExpireDate : PXFieldState;
	@columnConfig({width: 120, type: GridColumnType.CheckBox})	Confirmed : PXFieldState;
	@columnConfig({width: 80, type: GridColumnType.CheckBox})	Released : PXFieldState;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	AddPackage: {index: 0, config: {commandName: "AddPackage", text: "Add Package"}},
}
})
export class IGCMPackages extends PXView  {

	AddPackage : PXActionState;
	@columnConfig({width: 90, type: GridColumnType.CheckBox})	Confirmed : PXFieldState;
	@columnConfig({width: 140})	BoxID : PXFieldState;
	@columnConfig({width: 70})	PackageType : PXFieldState;
	@columnConfig({width: 140})	ShipmentNbr : PXFieldState;
	@columnConfig({width: 70})	PackLineNbr : PXFieldState;
	@columnConfig({width: 140})	Description : PXFieldState;
	@columnConfig({width: 100})	Weight : PXFieldState;
	@columnConfig({width: 70})	WeightUOM : PXFieldState;
	@columnConfig({width: 100})	DeclaredValue : PXFieldState;
	@columnConfig({width: 100})	COD : PXFieldState;
	@columnConfig({width: 212})	TrackNumber : PXFieldState;
}

export class SOContact extends PXView  {

	OverrideContact : PXFieldState<PXFieldOptions.CommitChanges>;
	FullName : PXFieldState;
	Attention : PXFieldState;
	Phone1 : PXFieldState;
	Email : PXFieldState;
}

export class SOAddress extends PXView  {

	OverrideAddress : PXFieldState<PXFieldOptions.CommitChanges>;
	AddressLine1 : PXFieldState;
	AddressLine2 : PXFieldState;
	City : PXFieldState;
	CountryID : PXFieldState;
	State : PXFieldState;
	PostalCode : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class SOShipment extends PXView  {

	@columnConfig({allowNull: false, width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox})	Selected : PXFieldState;
	@columnConfig({width: 200})	ShipmentNbr : PXFieldState;
	@columnConfig({width: 70})	ShipmentType : PXFieldState;
	@columnConfig({width: 60, type: GridColumnType.CheckBox})	UsrIGCMShippedFull : PXFieldState;
	@columnConfig({allowCheckAll: false, width: 90, type: GridColumnType.NotSet})	ShipDate : PXFieldState;
	CustomerID : PXFieldState;
	@columnConfig({allowUpdate: false, allowNull: false})	Status : PXFieldState;
	@columnConfig({allowUpdate: false, allowNull: false, width: 100, textAlign: TextAlign.Right})	LineTotal : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class SOShipLine extends PXView  {

	@columnConfig({width: 60, type: GridColumnType.CheckBox})	UsrIGCMSelected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60, type: GridColumnType.CheckBox})	UsrIGCMShippedFull : PXFieldState;
	@columnConfig({width: 70})	UsrIGCMCustomerID : PXFieldState;
	@columnConfig({width: 70})	LineNbr : PXFieldState;
	@columnConfig({width: 100, format: ">AAAAAAAAAA"})	InventoryID : PXFieldState;
	@columnConfig({width: 200})	TranDesc : PXFieldState;
	@columnConfig({width: 100, textAlign: TextAlign.Right})	OrigOrderQty : PXFieldState;
	@columnConfig({width: 108, textAlign: TextAlign.Right})	ShippedQty : PXFieldState;
	@columnConfig({width: 100})	UsrIGCMQtyOnContainers : PXFieldState;
	@columnConfig({width: 108, textAlign: TextAlign.Right})	UnassignedQty : PXFieldState;
	@columnConfig({width: 63, format: ">aaaaaa"})	UOM : PXFieldState;
	@columnConfig({width: 80, textAlign: TextAlign.Left})	ExpireDate : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class SOPackageDetail extends PXView  {

	@columnConfig({width: 60, type: GridColumnType.CheckBox})	UsrIGCMSelected : PXFieldState;
	@columnConfig({allowUpdate: false, width: 140})	ShipmentNbr : PXFieldState;
	@columnConfig({allowUpdate: false, width: 70})	LineNbr : PXFieldState;
	@columnConfig({allowUpdate: false, width: 140})	BoxID : PXFieldState;
	@columnConfig({allowUpdate: false, width: 90, type: GridColumnType.CheckBox})	Confirmed : PXFieldState;
	@columnConfig({allowUpdate: false, width: 140})	Description : PXFieldState;
	@columnConfig({allowUpdate: false, width: 220})	TrackNumber : PXFieldState;
	@columnConfig({allowUpdate: false, width: 100})	Weight : PXFieldState;
	@columnConfig({allowUpdate: false, width: 70})	WeightUOM : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class IGCMShipLinePack extends PXView  {

	@columnConfig({width: 140})	ShipmentNbr : PXFieldState;
	@columnConfig({width: 70})	ShipContLineNbr : PXFieldState;
	@columnConfig({width: 70})	InventoryID : PXFieldState;
	@columnConfig({width: 140})	UOM : PXFieldState;
	@columnConfig({width: 100})	Qty : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class SOShipLine2 extends PXView  {

	@columnConfig({width: 60, type: GridColumnType.CheckBox})	UsrIGCMSelected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	LineNbr : PXFieldState;
	@columnConfig({width: 70})	InventoryID : PXFieldState;
	@columnConfig({width: 280})	TranDesc : PXFieldState;
	@columnConfig({width: 100})	OrigOrderQty : PXFieldState;
	@columnConfig({width: 100})	ShippedQty : PXFieldState;
	@columnConfig({width: 100})	UnassignedQty : PXFieldState;
	@columnConfig({width: 72})	UOM : PXFieldState;
	@columnConfig({width: 90})	ExpireDate : PXFieldState;
}*/
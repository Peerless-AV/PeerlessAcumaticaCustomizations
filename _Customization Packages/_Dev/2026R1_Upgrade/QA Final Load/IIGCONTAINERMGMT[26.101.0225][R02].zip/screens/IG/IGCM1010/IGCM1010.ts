import {
  createSingle,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  controlConfig,
  PXFieldOptions,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMSetupMaint", primaryView: "setup" })
export class IGCM1010 extends PXScreen {
  setup = createSingle(IGCMSetup);
} // Views

export class IGCMSetup extends PXView {
  @controlConfig({ allowEdit: true })
  LandedCostNumberingID: PXFieldState;
  @controlConfig({ allowEdit: true })
  LCDistributionNumberingID: PXFieldState;
  @controlConfig({ allowEdit: true })
  ShippingContainerNumberingID: PXFieldState;
  UpdatePOPromDate: PXFieldState<PXFieldOptions.CommitChanges>;
  UpdatePOReqDate: PXFieldState<PXFieldOptions.CommitChanges>;
  UPCCodeAttribute: PXFieldState<PXFieldOptions.CommitChanges>;
  ShippedQtyExceed: PXFieldState<PXFieldOptions.CommitChanges>;
  AllowZeroCharge: PXFieldState<PXFieldOptions.CommitChanges>;
  CopyNotesAndAttachments: PXFieldState;
  GroupPOReceiptByBranch: PXFieldState;
  GroupPOReceiptBySiteID: PXFieldState;
  ManualLoadPOLines: PXFieldState;
  AutoAllocateLandedCost: PXFieldState<PXFieldOptions.CommitChanges>;
  GSPEligible: PXFieldState<PXFieldOptions.CommitChanges>;
  AdvancedDutyCalculation: PXFieldState<PXFieldOptions.CommitChanges>;
  DutyLandedCostCodeID: PXFieldState<PXFieldOptions.CommitChanges>;
  TariffLandedCostCodeID: PXFieldState<PXFieldOptions.CommitChanges>;
  AllowInTransitProcessing: PXFieldState<PXFieldOptions.CommitChanges>;
  @controlConfig({ allowEdit: true })
  DefaultInTransitSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
  @controlConfig({ allowEdit: true })
  AdjustmentReasonCode: PXFieldState<PXFieldOptions.CommitChanges>;
  CreateAdjustment: PXFieldState<PXFieldOptions.CommitChanges>;
  AutoCreateAPBill: PXFieldState<PXFieldOptions.CommitChanges>;
  AutoReleaseAPBill: PXFieldState;
  LocationInTransit: PXFieldState;
  GenerateTemporarySerialNumber: PXFieldState<PXFieldOptions.CommitChanges>;
  TemporarySerialNumberPrefix: PXFieldState;
  ContainerManagementEnabled: PXFieldState<PXFieldOptions.CommitChanges>;
  SearateAPIKey: PXFieldState;
  //SearateAPIKey : IsPassword<true>;
  SearateUpdateUsing: PXFieldState;
  VesselFinderAPIKey: PXFieldState;
  ExpeditorsClientID: PXFieldState;
  ExpeditorsPassword: PXFieldState;
}
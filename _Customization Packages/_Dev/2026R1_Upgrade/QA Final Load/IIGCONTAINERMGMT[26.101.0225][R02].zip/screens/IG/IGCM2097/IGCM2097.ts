import {
  createSingle,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  PXFieldOptions,
  columnConfig,
  createCollection,
} from "client-controls";

@graphInfo({ graphType: "IGCM.Graph.IGCMDutyTarrifAdjustmentMaint", primaryView: "adjustment" })
export class IGCM2097 extends PXScreen {
  adjustment = createSingle(IGCMDutyTarrifRateAdjustmentbyCountry);
  details = createCollection(IGCMDutyTarrifRateAdjustmentbyCountryDetail);
} // Views

export class IGCMDutyTarrifRateAdjustmentbyCountry extends PXView {
  Country: PXFieldState<PXFieldOptions.CommitChanges>;
  Descr: PXFieldState;
  Active: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class IGCMDutyTarrifRateAdjustmentbyCountryDetail extends PXView {
  @columnConfig({ width: 120 }) CustomClassificationNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) PercentageOfCost: PXFieldState;
  @columnConfig({ width: 100 }) FlatAmountPerUnit: PXFieldState;
  @columnConfig({ width: 100 }) FlatAmountPerWeight: PXFieldState;
  @columnConfig({ width: 100 }) Tariff: PXFieldState;
}

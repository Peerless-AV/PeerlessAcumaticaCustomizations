import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMLogisticsServiceMaint", primaryView: "LogisticsService" })
export class IGCM2093 extends PXScreen {
  LogisticsService = createCollection(IGCMLogisticsService);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMLogisticsService extends PXView {
  @columnConfig({ width: 120 }) LogisticsServiceID: PXFieldState;
  @columnConfig({ width: 200 }) Descr: PXFieldState;
}

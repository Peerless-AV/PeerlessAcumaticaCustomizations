import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMCustomerPaymentStatusMaint", primaryView: "CustomerPaymentStatus" })
export class IGCM2095 extends PXScreen {
  CustomerPaymentStatus = createCollection(IGCMCustomerPaymentStatus);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMCustomerPaymentStatus extends PXView {
  @columnConfig({ width: 120 }) CustomerPaymentStatusID: PXFieldState;
  @columnConfig({ width: 200 }) Descr: PXFieldState;
}

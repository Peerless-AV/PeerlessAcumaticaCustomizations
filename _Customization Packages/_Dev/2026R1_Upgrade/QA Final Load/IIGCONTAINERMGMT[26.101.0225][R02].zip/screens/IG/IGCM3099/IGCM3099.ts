import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFastFilterVisibility,
  GridNoteFilesShowMode
} from "client-controls";

@graphInfo({
  graphType: "IGCM.IGCMINTransitRegisterEntry",
  primaryView: "filter",
  hideFilesIndicator: true,
  hideNotesIndicator: true,
})
export class IGCM3099 extends PXScreen {
  IGCMINTransitLineSplittingExtension_generateNumbers: PXActionState;

  filter = createSingle(IGCMLandedCostFilter);
  @viewInfo({ containerName: "Transactions" })
  Transactions = createCollection(IGCMPOLandedCostLine);
  @viewInfo({ containerName: "LineINDocuments" })
  LineINDocuments = createCollection(INTran);
  @viewInfo({ containerName: "IGCMINTransitLineSplittingExtension_LotSerOptions" })
  IGCMINTransitLineSplittingExtension_LotSerOptions = createSingle(LotSerOptions);
  @viewInfo({
    containerName: "splits",
    parameters: [
      new ControlParameter("IGCMPOLandedCostLine.siteID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.inventoryID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.subItemID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.inventoryID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.inventoryID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.subItemID", "", ""),
      new ControlParameter("IGCMPOLandedCostLine.locationID", "", ""),
    ],
  })
  splits = createCollection(IGCMPOLandedCostLineSplit);
  @viewInfo({ containerName: "Lot/Serial Items requiring selection" })
  LinesRequiringDistribution = createCollection(IGCMPOLandedCostLine2);
  @viewInfo({ containerName: "Lot/Serial Item Allocation" })
  currentLineSplits = createCollection(IGCMPOLandedCostLineSplit2);
} // Views

export class IGCMLandedCostFilter extends PXView {
  LandedCostNbrStarting: PXFieldState<PXFieldOptions.CommitChanges>;
  LandedCostNbrEnding: PXFieldState<PXFieldOptions.CommitChanges>;
  LandedCostAll: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorIDStarting: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorIDEnding: PXFieldState<PXFieldOptions.CommitChanges>;
  VendorAll: PXFieldState<PXFieldOptions.CommitChanges>;
  PurchaseOrderNbrStarting: PXFieldState<PXFieldOptions.CommitChanges>;
  PurchaseOrderNbrEnding: PXFieldState<PXFieldOptions.CommitChanges>;
  PurchaseOrdersAll: PXFieldState<PXFieldOptions.CommitChanges>;
  CreateAPBill: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  //preset: GridPreset.Empty
  preset: GridPreset.ReadOnly,
  showNoteFiles: GridNoteFilesShowMode.Suppress
})
export class IGCMPOLandedCostLine extends PXView {
  IGCMINTransitLineSplittingExtension_ShowSplits: PXActionState;
  INDocuments: PXActionState;
  @columnConfig({ allowCheckAll: false, width: 60, textAlign: TextAlign.Center, type: GridColumnType.CheckBox })
  Selected: PXFieldState<PXFieldOptions.CommitChanges>;
  @linkCommand("ViewContainer")
  @columnConfig({ width: 140 })
  LandedCostNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 70, hideViewLink: true }) VendorID: PXFieldState;
  @linkCommand("ViewPO")
  @columnConfig({ width: 140 })
  PONbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 70, hideViewLink: true }) InventoryID: PXFieldState;
  @columnConfig({ width: 100, hideViewLink: true }) ContainerQty: PXFieldState;
  @columnConfig({ width: 100, hideViewLink: true }) InTransitQty: PXFieldState;
  @columnConfig({ width: 140, hideViewLink: true }) InTransitSiteID: PXFieldState;
  @columnConfig({ width: 140, hideViewLink: true }) InTransitSiteLocation: PXFieldState;
  @columnConfig({ width: 100, hideViewLink: true }) QtyToInTransit: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
  syncPosition: true,
  showNoteFiles: GridNoteFilesShowMode.Suppress
})
export class INTran extends PXView {
  @columnConfig({ width: 120 }) TranType: PXFieldState;
  @linkCommand("ViewInDocument")
  @columnConfig({ width: 120 })
  RefNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) InventoryID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) TranDesc: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) SiteID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) LocationID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) LotSerialNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) UOM: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) Qty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) UnitCost: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) TranCost: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) ExpireDate: PXFieldState;
}

export class LotSerOptions extends PXView {
  UnassignedQty: PXFieldState<PXFieldOptions.Disabled>;
  Qty: PXFieldState;
  StartNumVal: PXFieldState;
}

@gridConfig({
  initNewRow: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  syncPosition: true,
})
export class IGCMPOLandedCostLineSplit extends PXView {
  @columnConfig({ hideViewLink: true, width: 108 }) InventoryID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108 }) SubItemID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 140 }) TransferSiteID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 140 }) TransferLocationID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108, allowShowHide: GridColumnShowHideMode.Server })
  LotSerialNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108, textAlign: TextAlign.Right }) Qty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 108 }) UOM: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 90 }) ExpireDate: PXFieldState;
  //LocationID : PXFieldState;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Empty,
})
export class IGCMPOLandedCostLine2 extends PXView {
  @columnConfig({ width: 120 }) LandedCostNbr: PXFieldState;
  @columnConfig({ width: 120 }) PONbr: PXFieldState;
  @columnConfig({ width: 120 }) InventoryID: PXFieldState;
  @columnConfig({ width: 120 }) SiteID: PXFieldState;
  @columnConfig({ width: 100 }) QtyToInTransit: PXFieldState;
  @columnConfig({ width: 100 }) SplitsSelected: PXFieldState;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Empty,
})
export class IGCMPOLandedCostLineSplit2 extends PXView {
  @columnConfig({ width: 60, type: GridColumnType.CheckBox }) Selected: PXFieldState<PXFieldOptions.CommitChanges>;
  // @columnConfig({hideViewLink: true, width: 120})	LocationID : PXFieldState;
  @columnConfig({ hideViewLink: true, width: 200 }) LotSerialNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) Qty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 70 }) UOM: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) ExpireDate: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) ReceiptedQty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 100 }) SelectedQty: PXFieldState<PXFieldOptions.CommitChanges>;
}

import { PXFieldState, PXFieldOptions } from "client-controls";

import { POReceiptHeader } from "src/screens/PO/PO302000/PO302000";

export interface POReceiptHeader_IGCMPOReceiptHeaderExt extends POReceiptHeader {}
export class POReceiptHeader_IGCMPOReceiptHeaderExt {
  UsrIGCMLCEntryNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMShipContNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}
import { PXFieldState, PXFieldOptions } from "client-controls";

import { POLandedCostDocHeader } from "src/screens/PO/PO303000/PO303000";

export interface IGCMPOLandedCostDocHeaderExt extends POLandedCostDocHeader {}
export class IGCMPOLandedCostDocHeaderExt {
  UsrIGCMLCEntryNbr: PXFieldState;
}

import {
  GridFastFilterVisibility,
  GridPreset,
  PXActionState,
  PXFieldOptions,
  PXFieldState,
  PXView,
  columnConfig,
  createCollection,
  gridConfig,
  linkCommand,
  placeAfterProperty,
  viewInfo,
  GridNoteFilesShowMode
} from "client-controls";

import { 
  PO301000,
  POLine
} from "src/screens/PO/PO301000/PO301000";

export interface PO301000_CreateContainer extends PO301000 {}
export class PO301000_CreateContainer {
  @viewInfo({ containerName: "Containers" })
  IGCMRelatedContainers = createCollection(IGCMPOLandedCostLine);
}

@gridConfig({
  	preset: GridPreset.ReadOnly,
        syncPosition: true,
       adjustPageSize: true,
       autoAdjustColumns: true,
      //syncPosition: true,
})
export class IGCMPOLandedCostLine extends PXView {
  @linkCommand("iGCMViewLandedCost")
  @columnConfig({ hideViewLink: true,  width: 120 }) LandedCostNbr: PXFieldState;
  @columnConfig({ hideViewLink: true,  width: 90 }) IGCMPOLandedCost__Status: PXFieldState;
  @columnConfig({ hideViewLink: true,  width: 120 }) ContainerNbr: PXFieldState;
  @columnConfig({ hideViewLink: true,  width: 90 }) ContainerQty: PXFieldState;
}

export interface IGCMPOLineExt extends POLine {}
export class IGCMPOLineExt {
  IGCMContainers: PXActionState;

  @placeAfterProperty("OrderQty")
  IGCMQtyOnContainers: PXFieldState;
}
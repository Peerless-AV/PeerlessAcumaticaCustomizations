import { PXFieldState, PXFieldOptions } from "client-controls";

import { APInvoice } from "src/screens/AP/AP301000/AP301000";

export interface APInvoice_IGCMAPInvoiceExt extends APInvoice {}
export class APInvoice_IGCMAPInvoiceExt {
  UsrIGCMLCEntryNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}

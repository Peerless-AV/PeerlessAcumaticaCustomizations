import { PXFieldState, PXFieldOptions } from "client-controls";

import { Vendor } from "src/screens/AP/AP303000/views";

export interface Vendor_IGCMVendorExt extends Vendor {}
export class Vendor_IGCMVendorExt {
  UsrIGCMDefaultInTransitSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
}

import { PXFieldState, PXFieldOptions, createCollection, viewInfo, PXActionState, gridConfig, columnConfig, PXView, GridFastFilterVisibility, GridPreset } from "client-controls";
import { ItemSettings, IN202500 } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_IGCMStockItemsExt extends IN202500 {}
export class IN202500_IGCMStockItemsExt {
  addClassification2: PXActionState;
  @viewInfo ({containerName: "Custom Classifications"})
	IGCMINCustomClassificationView = createCollection(IGCMINCustomClassification);
  @viewInfo ({containerName: "Custom Classifications"})
	IGCMINTariffView = createCollection(IGCMINTariff);
  @viewInfo ({containerName: "Load Custom Classification"})
	IGCMINCustomClassificationBase = createCollection(IGCMCustomClassification);
}

export interface ItemSettings_IGCMItemSettingsExt extends ItemSettings {}
export class ItemSettings_IGCMItemSettingsExt {
  UsrIGCMCustomClassificationNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
  autoRepaint: ["IGCMINTariffView"],
})
export class IGCMINCustomClassification extends PXView  {
	addCustomClassification: PXActionState;
  @columnConfig({ width: 120 }) CustomClassificationNbr : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 180 }) Descr : PXFieldState;
  @columnConfig({ width: 100 }) PercentageOfCost : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) FlatAmountPerUnit : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 100 }) FlatAmountPerWeight : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class IGCMINTariff extends PXView  {
  @columnConfig({ width: 70 }) CountryCode : PXFieldState;
  @columnConfig({ width: 100 }) Tariff : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({ width: 280 }) Description : PXFieldState;
  @columnConfig({ width: 90 }) TariffEffDate : PXFieldState;
  @columnConfig({ width: 90 }) TariffExpDate : PXFieldState;
  @columnConfig({ width: 70 }) RecordID : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class IGCMCustomClassification extends PXView  {
  @columnConfig({ width: 30, allowCheckAll: true }) IsSelected : PXFieldState;
  @columnConfig({ width: 120 }) CustomClassificationNbr : PXFieldState;
  @columnConfig({ width: 180 }) Descr : PXFieldState;
  @columnConfig({ width: 100 }) PercentageOfCost : PXFieldState;
  @columnConfig({ width: 100 }) FlatAmountPerUnit : PXFieldState;
  @columnConfig({ width: 100 }) FlatAmountPerWeight : PXFieldState;
}
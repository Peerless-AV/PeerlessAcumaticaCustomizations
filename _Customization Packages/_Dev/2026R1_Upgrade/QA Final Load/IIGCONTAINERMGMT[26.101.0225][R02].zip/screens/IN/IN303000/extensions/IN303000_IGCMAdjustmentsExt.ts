import { PXFieldState, PXFieldOptions } from "client-controls";

import { INRegister } from "src/screens/IN/IN303000/IN303000";

export interface IGCMINRegisterExt extends INRegister {}
export class IGCMINRegisterExt {
  UsrIGCMLandedCostNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}

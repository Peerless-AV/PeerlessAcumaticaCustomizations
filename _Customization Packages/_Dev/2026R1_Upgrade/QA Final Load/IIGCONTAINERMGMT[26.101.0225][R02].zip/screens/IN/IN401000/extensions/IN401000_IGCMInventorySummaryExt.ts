import {
  PXFieldState,
  PXView,
  createCollection,
  columnConfig,
  gridConfig,
  GridFastFilterVisibility,
  GridPreset,
  viewInfo,
  placeBeforeProperty,
} from "client-controls";
import { IN401000, ISERecords } from "src/screens/IN/IN401000/IN401000";

export interface IN401000_IGCMContainers extends IN401000 {}
export class IN401000_IGCMContainers {
  IGCMPurchasesInTransit = createCollection(IGCMInventorySummaryInTransitFilter);
}

@gridConfig({
  // showFastFilter: GridFastFilterVisibility.False,
  syncPosition: true,
  //allowUpdate: true,
  preset: GridPreset.ReadOnly,
})
export class IGCMInventorySummaryInTransitFilter extends PXView {
  @columnConfig({ width: 140 }) LandedCostNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120, editorConfig: {} }) InventoryID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) SiteID: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120 }) LocationID: PXFieldState;
  @columnConfig({ width: 100 }) InTransitQty: PXFieldState;
}

export interface ISERecords_IGCMContainers extends ISERecords {}
@gridConfig({
  autoRepaint: ["IGCMPurchasesInTransit"]
})
export class ISERecords_IGCMContainers {
  @placeBeforeProperty("ExpireDate")
  UsrIGCMPurchaseOrdersOnWater: PXFieldState;
}

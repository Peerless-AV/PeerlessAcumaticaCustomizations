import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  createCollection,
  GridFastFilterVisibility,
  gridConfig,
  GridPreset,
  columnConfig
} from "client-controls";

import { IN402000, InventoryAllocDetEnqFilter } from "src/screens/IN/IN402000/IN402000";

export interface IGCMInventoryAllocDetEnqFilterExt extends InventoryAllocDetEnqFilter {}
export class IGCMInventoryAllocDetEnqFilterExt {
  UsrIGCMQtyOnPOContainers: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMQtyOnSOContainers: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface IN402000_IGCMContainers extends IN402000 {}
export class IN402000_IGCMContainers {
  IGCMLandedCosts = createCollection(IGCMPOLandedCostLine);
  IGCMLinkedSOLines = createCollection(IGCMContainerSOAllocation);
  IGCMSOContainers = createCollection(IGCMSOContainers);
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
  autoRepaint: ["IGCMLinkedSOLines"],
})

export class IGCMPOLandedCostLine extends PXView {
  IGCMPOLandedCost__LandedCostNbr: PXFieldState;
  IGCMPOLandedCost__LandedCostDate: PXFieldState;
  IGCMPOLandedCost__ContainerNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120, editorConfig: {} }) VendorID: PXFieldState;
  ContainerQty: PXFieldState;
  InTransitQty: PXFieldState;
  IGCMPOLandedCost__Status: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120, editorConfig: {} }) IGCMPOLandedCost__ContainerStatusID: PXFieldState;
  IGCMPOLandedCost__ExpectedDepartureDate: PXFieldState;
  IGCMPOLandedCost__ExpectedArrivalDate: PXFieldState;
  IGCMPOLandedCost__ActualDepartureDate: PXFieldState;
  IGCMPOLandedCost__ActualArrivalDate: PXFieldState;
  OpenQty: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120, editorConfig: {} }) SiteID: PXFieldState;
  IGCMPOLandedCost__ExpectedArrivalSearateDate: PXFieldState;
}
@gridConfig({
  //showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
})
export class IGCMContainerSOAllocation extends PXView {
  OrderType: PXFieldState;
  OrderNbr: PXFieldState;
  SOOrder__Status: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120, editorConfig: {} }) SOLine__SiteID: PXFieldState;
  SOLine__RequestDate: PXFieldState;
  SOLine__ShipDate: PXFieldState;
}
@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class IGCMSOContainers extends PXView {
  ShippingContNbr: PXFieldState;
  ShippingContainerDate: PXFieldState;
  ContainerNbr: PXFieldState;
  @columnConfig({ hideViewLink: true, width: 120, editorConfig: {} }) CustomerID: PXFieldState;
  IGCMShippingContainerLine__ContainerQty: PXFieldState;
  ActualDepartureDate: PXFieldState;
  ExpectedArrivalDate: PXFieldState;
  ExpectedDepartureDate: PXFieldState;
  ActualArrivalDate: PXFieldState;
}

import { PXFieldState, PXFieldOptions, PXView, createCollection } from "client-controls";

import { INSite, IN204000 } from "src/screens/IN/IN204000/IN204000";

export interface INSite_IGCMINSiteExt extends INSite {}
export class INSite_IGCMINSiteExt {
  UsrIGCMInTransitWarehouse: PXFieldState<PXFieldOptions.CommitChanges>;
  UsrIGCMIsInTransit: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface IN204000_IGCMINTransitWarehouse extends IN204000 {}
export class IN204000_IGCMINTransitWarehouse {
  IGCMVendorINSite = createCollection(IGCMVendorINSite);
}

export class IGCMVendorINSite extends PXView {
  UsrIGCMVendorID: PXFieldState;
  UsrIGCMVendorWarehouseID: PXFieldState;
}

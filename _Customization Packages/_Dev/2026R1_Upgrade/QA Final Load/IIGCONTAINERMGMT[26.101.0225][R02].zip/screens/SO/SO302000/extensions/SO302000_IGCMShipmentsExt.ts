import {
  linkCommand,
  PXView,
  PXFieldState,
  createCollection,
  viewInfo,
  PXActionState,
  PXFieldOptions,
} from "client-controls";
import { SO302000, Transactions, Packages, SOShipment } from "src/screens/SO/SO302000/SO302000";

export interface SO302000_IGCMContainers extends SO302000 {}
export class SO302000_IGCMContainers {
  @viewInfo({ containerName: "Containers" })
  IGCMrelatedContainers = createCollection(IGCMShippingContainerLine);
  IGCMrelatedPackages = createCollection(IGCMPackages);
}

export class IGCMShippingContainerLine extends PXView {
  @linkCommand("IGCMContainers")
  ShippingContNbr: PXFieldState;
  ShipmentNbr: PXFieldState;
  ShipmentDate: PXFieldState;
  ExtWeight: PXFieldState;
  ExtVolume: PXFieldState;
}

export interface IGCMSOShipLineExt extends Transactions {}
export class IGCMSOShipLineExt {
  IGCMContainers: PXActionState;
}

export interface SOShipment_IGCMSOShipmentExt extends SOShipment {}
export class SOShipment_IGCMSOShipmentExt {
  UsrIGCMIncludeInContainer: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface IGCMPackagesExt extends Packages {}
export class IGCMPackagesExt {
  IGCMPackContainers: PXActionState;
}

export class IGCMPackages extends PXView {
  Confirmed: PXFieldState;
  @linkCommand("IGCMPackContainers")
  ShippingContNbr: PXFieldState;
  ShipmentNbr: PXFieldState;
  BoxID: PXFieldState;
  Weight: PXFieldState;
}

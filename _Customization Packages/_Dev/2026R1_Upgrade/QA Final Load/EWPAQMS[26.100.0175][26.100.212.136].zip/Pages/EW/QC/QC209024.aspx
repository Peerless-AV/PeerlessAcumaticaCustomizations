﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209024.aspx.cs" Inherits="Page_QC209024" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" attributesfound="False" enableattributes="False" primaryview="EWQCInventoryLotStatusImportExport" suspendunloading="False" typename="EW.QC.EWQCLotSerialIMEX">
	</px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="True" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" tabindex="3200" syncposition="true" bpeventsindicator="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="InventoryID,LotSerNumVal,WarehouseID,LocationID" DataMember="EWQCInventoryLotStatusImportExport">
			    <RowTemplate>
                   <px:PXSelector ID="PXSelector1" runat="server" DataField="InventoryID"  CommitChanges="true" >
                    </px:PXSelector>
                    <px:PXTextEdit ID="PXTextEdit1" runat="server" DataField="LotSerNumVal" CommitChanges="true" >
                    </px:PXTextEdit>                    
                   <px:PXSelector ID="PXSelector2" runat="server" DataField="WarehouseID" CommitChanges="true">
                    </px:PXSelector>
                   <px:PXSelector ID="PXSelector3" runat="server" DataField="LocationID"  CommitChanges="true">
                    </px:PXSelector>
                    <px:PXSelector ID="PXSelector4" runat="server" DataField="StatusID" CommitChanges="true">
                    </px:PXSelector>                   
                    <px:PXTextEdit ID="PXTextEdit3" runat="server" DataField="Reason" CommitChanges="true">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                   <px:PXGridColumn DataField="InventoryID" Width="150"  CommitChanges="true" />                    
                    <px:PXGridColumn DataField="LotSerNumVal" Width="100"  CommitChanges="true" />                  
                    <px:PXGridColumn DataField="WarehouseID" Width="100"  CommitChanges="true" />
                    <px:PXGridColumn DataField="LocationID" Width="100"   CommitChanges="true"/>
                     <px:PXGridColumn DataField="StatusID" Width="100"   CommitChanges="true"/>                  
                 <px:PXGridColumn DataField="Reason" Width="200" CommitChanges="true" /> 
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	</px:pxgrid>

    
</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC502013.aspx.cs" Inherits="Page_QC502013" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="phDS" runat="Server">

    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" typename="EW.QC.EWQCOrderNSDataProcess" primaryview="OrderNSProcess">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewOrder" Visible="false" CommitChanges="true" DependOnGrid="grid" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" syncposition="true">
        <Levels>
            <px:PXGridLevel DataMember="OrderNSProcess" DataKeyNames="RowNum">
                <Columns>
                    <px:PXGridColumn DataField="Selected" TextAlign="Center" Type="CheckBox" Width="30" AllowCheckAll="True" AllowSort="False"  CommitChanges="true"/>
                    <px:PXGridColumn DataField="ItemType" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ArticleID" LinkCommand="ViewArticleID" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Name">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="PlanID" LinkCommand="ViewPlanID" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="IntervalBy">
                    </px:PXGridColumn>  
                     <px:PXGridColumn DataField="Interval">
                    </px:PXGridColumn> 
                     <px:PXGridColumn DataField="LastQCOrderID" LinkCommand="ViewDQCOrder" CommitChanges="true">
                    </px:PXGridColumn> 
                      <px:PXGridColumn DataField="QCStatus">
                    </px:PXGridColumn> 
                     <px:PXGridColumn DataField="DueDate">
                    </px:PXGridColumn> 
                     <px:PXGridColumn DataField="Status">
                    </px:PXGridColumn> 
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>


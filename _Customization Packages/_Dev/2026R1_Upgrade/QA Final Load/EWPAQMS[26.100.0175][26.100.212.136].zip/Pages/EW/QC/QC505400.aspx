<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505400.aspx.cs" Inherits="Page_QC505400" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>


<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="False" runat="server" visible="True" width="100%" primaryview="Filter"
        typename="EW.QC.EWQCStockItemsRetestProcess">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewOrder" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" tabindex="3700" bpeventsindicator="True">
        <Template>
            <%--<px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" CommitChanges="True"/>--%>
            <%--<px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edLotSerNumVal" runat="server" DataField="LotSerNumVal" CommitChanges="True"/>--%>
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" syncposition="true" adjustpagesize="Auto" datasourceid="ds" skinid="PrimaryInquire" onrowdatabound="grid_RowDataBound">
        <Levels>
            <px:PXGridLevel DataMember="EWQCInventory">
                <RowTemplate>
<%--                    <px:PXSelector ID="edWarehouseID" runat="server" DataField="WarehouseID" CommitChanges="True" AutoRefresh ="true"/>
                    <px:PXSelector ID="edLocationID" runat="server" DataField="LocationID" CommitChanges="True" AutoRefresh ="true"/>--%>
                    <%--<px:PXTextEdit ID="edQty" runat="server" DataField="Qty" CommitChanges="True" AutoRefresh ="true"/>--%>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="InventoryID" Width="100" LinkCommand="ViewStockItem" />
                    <px:PXGridColumn DataField="Description" />
                    <px:PXGridColumn DataField="LotSerNumVal" />
                    <px:PXGridColumn DataField="WarehouseID" CommitChanges="True"/>
                    <px:PXGridColumn DataField="LocationID" CommitChanges="True"/>
                    <px:PXGridColumn DataField="Qty" TextAlign="Left"/>
                    <px:PXGridColumn DataField="SampleDate" />
                    <px:PXGridColumn DataField="OnGoingQCOrderCD" LinkCommand="ViewOrder" />
                    <px:PXGridColumn DataField="OnGoingQCOrderDate" />
                    <px:PXGridColumn DataField="LastQCType" />
                    <px:PXGridColumn DataField="LastQCOrderCD" LinkCommand="ViewLastOrder" />
                    <px:PXGridColumn DataField="LastQCDate" />
                    <px:PXGridColumn DataField="Quantity" />
                    <px:PXGridColumn DataField="LastQCStatus" />
                    <px:PXGridColumn DataField="TestingDate" />
                    <px:PXGridColumn DataField="RetestStatus"/>
                    <px:PXGridColumn DataField="RetestFrequency" />
                    <px:PXGridColumn DataField="Interval" TextAlign="Left" />
                    <px:PXGridColumn DataField="LotExpiryDate" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>

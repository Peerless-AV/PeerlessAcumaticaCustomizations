using System;
using System.Collections;
using System.Configuration;
using System.Drawing;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Page_QC301008 : PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}

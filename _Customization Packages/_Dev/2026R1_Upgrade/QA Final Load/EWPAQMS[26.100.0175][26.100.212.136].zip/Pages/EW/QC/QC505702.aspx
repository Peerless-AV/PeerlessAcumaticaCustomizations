<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505702.aspx.cs" Inherits="Page_QC505702" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="False" runat="server" Visible="True" Width="100%" PrimaryView="LotStatusList"
        TypeName="EW.QC.EWQCInvLotInsertProcess">
        <CallbackCommands>
              <px:PXDSCallbackCommand Name="ViewData" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" BPEventsIndicator="True"
        Width="100%" DataMember="Filter" TabIndex="3700">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" />
             <px:PXSelector ID="edItemClassID" runat="server" DataField="ItemClassID" CommitChanges="True" AutoRefresh="true" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" CommitChanges="True" AutoRefresh="true" />
            <px:PXTextEdit ID="edLotSerNumVal" runat="server" DataField="LotSerNumVal" CommitChanges="True" AutoRefresh="true"></px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edWarehouseID" runat="server" DataField="WarehouseID" CommitChanges="True" AutoRefresh="true" />
            <px:PXSelector ID="edLocationID" runat="server" DataField="LocationID" CommitChanges="True" AutoRefresh="true" />
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
     <px:pxtab id="tab" runat="server"  style="z-index: 100;" width="100%">
     <Items>
         <px:PXTabItem Text="Process Data">
             <Template>
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
       AutoAdjustColumns="True" SyncPosition="true" DataSourceID="ds" SkinID="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataKeyNames="InventoryID,LotSerialNbr,SiteID,LocationID" DataMember="LotStatusList">
                <RowTemplate>
                    <px:PXSelector ID="edInventoryID1" runat="server" DataField="InventoryID" AllowEdit="true" CommitChanges="true" Enabled="false">
                    </px:PXSelector>
                    <px:PXTextEdit ID="edLotSerialNbr" runat="server" DataField="LotSerialNbr" CommitChanges="true" Enabled="false">
                    </px:PXTextEdit>                  
                   <px:PXSelector ID="edSiteID" runat="server" DataField="SiteID" AllowEdit="true" Enabled="false" CommitChanges="true">
                    </px:PXSelector>
                    <px:PXSelector ID="edLocationID1" runat="server" DataField="LocationID" AllowEdit="true" Enabled="false" CommitChanges="true">
                    </px:PXSelector>
                  
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="InventoryID" Width="150" />              
                    <px:PXGridColumn DataField="InventoryItem__descr" Width="150" />              
                    <px:PXGridColumn DataField="LotSerialNbr" Width="150" />              
                    <px:PXGridColumn DataField="SiteID" Width="100" />                  
                    <px:PXGridColumn DataField="LocationID" Width="100" />
                    <px:PXGridColumn DataField="AcumaticaQty" Width="100" />                     
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" />
    </px:PXGrid>

                    </Template>
            </px:PXTabItem>

          <px:PXTabItem Text="Event History">

     <Template>
         <px:PXGrid ID="PXGrid2" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
              <ActionBar ActionsText="False">
     <CustomItems>
         <px:PXToolBarButton Text="EventDescription" PopupPanel="EventDescriptionPanel" Visible="false" Enabled="True">
             <AutoCallBack Command="ViewData" Target="ds">
                 <Behavior CommitChanges="True" PostData="Page"></Behavior>
             </AutoCallBack>
         </px:PXToolBarButton>
     </CustomItems>
 </ActionBar>
             <Levels>
                 <px:PXGridLevel DataKeyNames="ProcessEventid" DataMember="ProcessEventSummary">
                      <RowTemplate>
   
     <px:PXTextEdit ID="edShow" runat="server" AlreadyLocalized="False" DataField="Show">
     </px:PXTextEdit>
                          </RowTemplate>
                     <Columns>
                         <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g" Width="40px">
                         </px:PXGridColumn>
                         <px:PXGridColumn DataField="CreatedByID" Width="40px">
                         </px:PXGridColumn>
                         <px:PXGridColumn DataField="Show" LinkCommand="ViewData" CommitChanges="true" Width="40px">
                        </px:PXGridColumn>
                     </Columns>
                 </px:PXGridLevel>
                         </Levels>
            <AutoSize Container="Window" Enabled="True"  />
            <AutoCallBack />
        </px:PXGrid>
    </Template>
    <AutoCallBack Target="PXGrid2" Command="Refresh">
        <Behavior RepaintControlsIDs="PXGrid2" />
    </AutoCallBack>
</px:PXTabItem>

        </Items>    
         </px:pxtab>
    <px:PXSmartPanel ID="EventDescriptionPanel" runat="server" Width="720px" Height="360px" 
                 Key="EWQCProcessEventPanel" Caption="Event Descriptions" CaptionVisible="True"
                 AutoCallBack-Command="Refresh" AutoCallBack-Target="EventDescriptionGrid" DesignView="Content">

    <px:PXGrid ID="EventDescriptionGrid" runat="server" DataSourceID="ds" SkinID="Details" 
               AutoAdjustColumns="True" SyncPosition="true" AllowSearch="True"
               Width="685px" Height="200px">
        <Levels>
            <px:PXGridLevel DataMember="EWQCProcessEventPanel">
                                 <RowTemplate>
   
<px:PXSelector ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryID" AllowEdit=" true">
</px:PXSelector>
                     </RowTemplate>
               <Columns>
     <px:PXGridColumn DataField="InventoryID" TextAlign="Left" CommitChanges="true"></px:PXGridColumn>
      <px:PXGridColumn DataField="InventoryItem__descr" Width="150" />     
          <px:PXGridColumn DataField="SiteID" TextAlign="Left" CommitChanges="true"></px:PXGridColumn>
               <px:PXGridColumn DataField="LocationID" TextAlign="Left" CommitChanges="true"></px:PXGridColumn>
                    <px:PXGridColumn DataField="LotSerialNbr" TextAlign="Left" CommitChanges="true"></px:PXGridColumn>
                          <px:PXGridColumn DataField="Qty" TextAlign="Left" CommitChanges="true"></px:PXGridColumn>                    
 </Columns>
            </px:PXGridLevel>
        </Levels>
        <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" AllowUpload="false" />
    </px:PXGrid>

    <px:PXPanel ID="EventDescriptionButtonPanel" runat="server" SkinID="Buttons">
        <px:PXButton ID="EventDescriptionCloseButton" runat="server" DialogResult="Cancel" Text="Close">
        </px:PXButton>
    </px:PXPanel>

</px:PXSmartPanel>
      
</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC401055.aspx.cs" Inherits="Page_QC401055" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="Tests"
        TypeName="EW.QC.EWQCWhereUsed">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="viewInventory" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" DataMember="Tests" TabIndex="3700" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXDropDown ID="edDocType" runat="server" Width="150px" DataField="DocType" CommitChanges="true">
            </px:PXDropDown>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edVariableID" runat="server" DataField="VariableID" Width="170" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edPlan" runat="server" DataField="Plan" Width="170" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edSamplingPlanID" runat="server" DataField="SamplingPlanID" Width="170" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edInspectionPlanID" runat="server" DataField="InspectionPlanID" Width="170" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edChecklistGroupID" runat="server" DataField="ChecklistGroupID" Width="170" CommitChanges="true">
            </px:PXSelector>

        </Template>
    </px:PXFormView>
</asp:Content>


<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tab" runat="server" Width="100%" Height="120px" DataSourceID="ds">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
            <px:PXTabItem Text="QC Plan ID" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="PlanByTest" DataKeyNames="PlanID">
                                <Columns>

                                    <px:PXGridColumn DataField="PlanCD" LinkCommand="ViewTestQCPlan">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="PlanID" LinkCommand="ViewTestQCPlan">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="EWQCPlan__Name">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__Status">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__RevisionNo">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__EffectiveFromDate">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__EffectiveToDate">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>

                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Inspection Plan ID" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridInspectionTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="false" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="InspectionPlanByTest" DataKeyNames="InspectionPlanCD,RevisionNo,VariableID">
                                <Columns>
                                    <px:PXGridColumn DataField="InspectionPlanCD" LinkCommand="ViewTestinspectionPlan">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__Name">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__Status">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__RevisionNo">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__EffectiveFromDate">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__EffectiveToDate">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>

                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Stock Items" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridStockTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="StockItemsByTest" DataKeyNames="InventoryID">
                                <Columns>
                                    <%--<px:PXGridColumn DataField="InventoryID"/>--%>
                                    <px:PXGridColumn DataField="InventoryCD" LinkCommand="ViewStockitems" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Item Class" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridItemClassTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="form,PXGrid1"></Behavior>
                        </AutoCallBack>
                        <Levels>
                            <px:PXGridLevel DataMember="ItemClassByTest" DataKeyNames="ItemClassPlanDetailID">
                                <Columns>

                                    <px:PXGridColumn DataField="ItemClassCD" Width="150px" LinkCommand="ViewItemClass" />
                                    <px:PXGridColumn DataField="Descr" Width="150px" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ReceivingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ShippingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ProductionQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__AdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__KitAssemblyQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__RMAQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__WTQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__AdjustQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__DefaultAdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />

                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Tools" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridToolsTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="ToolsByTest" DataKeyNames="ToolID">
                                <Columns>
                                    <px:PXGridColumn DataField="ToolID" LinkCommand="ViewTools" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Machines" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridmachineTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="MachineByTest" DataKeyNames="MachID">
                                <Columns>
                                    <px:PXGridColumn DataField="MachID" LinkCommand="ViewMachine" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Fixed Assets" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridFixedAssetsTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="FixedAssetByTest" DataKeyNames="AssetID">
                                <Columns>
                                    <px:PXGridColumn DataField="AssetCD" LinkCommand="ViewFixedAsset" />
                                    <px:PXGridColumn DataField="Description" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Non-Stock Items" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridNonStockTest" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="NonStockByTest" DataKeyNames="InventoryID">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryCD" LinkCommand="ViewNonStock" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>

             <px:PXTabItem Text="Stability" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridStability" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="StabilityByTest" DataKeyNames="InventoryID">
                                <RowTemplate>
                                    <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" AutoRefresh="true" AllowEdit="true" Enabled="false" CommitChanges="true" Width="100%">
                                    </px:PXSelector>                                    
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />
                                    <px:PXSelector ID="edRetentionWarehouseID" runat="server" CommitChanges="true" AllowEdit="true" Enabled="false" DataField="RetentionWarehouseID" Width="100%">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edRetentionLocationID" runat="server" AutoRefresh="true" AllowEdit="true" Enabled="false" DataField="RetentionLocationID" Width="100%">
                                    </px:PXSelector>
                                    <px:PXDropDown ID="edQCOrderCreation" runat="server" DataField="QCOrderCreation" Enabled="false" Width="100%">
                                    </px:PXDropDown>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="Stability" LinkCommand="ViewStabilityPlanning" /> 
                                    <px:PXGridColumn DataField="InventoryID" />                                    
                                    <px:PXGridColumn DataField="RetentionWarehouseID" />
                                    <px:PXGridColumn DataField="RetentionLocationID" />
                                    <px:PXGridColumn DataField="QCOrderCreation" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>

            <px:PXTabItem Text="Service" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == T">
                <Template>
                    <px:PXGrid ID="PXGridServiceQC" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="ServiceByTest" DataKeyNames="servQCID">
                                <Columns>
                                    <px:PXGridColumn DataField="ServItemType" LinkCommand="viewServPlaningTest" />
                                    <px:PXGridColumn DataField="EquipmentId" LinkCommand="viewServTest" />
                                    <px:PXGridColumn DataField="EWQCServQCUnionSelector__ServItemDescr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>

            <%-----QCPlan-----%>
            <px:PXTabItem Text="Stock item" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridStockitemPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="StokItem" DataKeyNames="QCInventoryDetailID">
                                <Columns>

                                    <px:PXGridColumn DataField="InventoryCD" Width="150px" LinkCommand="ViewStockQCPlan " />
                                    <px:PXGridColumn DataField="Descr" Width="150px" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__VendorID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__CustomerID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__ReceivingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__ShippingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__ProductionQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__AdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__KitAssemblyQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__RMAQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__WTQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__AdjustQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__DefaultAdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Item Class" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridItemClassPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                            <%-- <Behavior RepaintControlsIDs="form,PXGrid1"></Behavior>--%>
                        </AutoCallBack>
                        <Levels>
                            <px:PXGridLevel DataMember="ItemClassPlanInfo" DataKeyNames="ItemClassPlanDetailID">
                                <Columns>

                                    <px:PXGridColumn DataField="ItemClassCD" Width="150px" LinkCommand="ViewItemClassPlan" />
                                    <px:PXGridColumn DataField="Descr" Width="150px" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ReceivingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ShippingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ProductionQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__AdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__KitAssemblyQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__RMAQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__WTQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__AdjustQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__DefaultAdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />

                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Bill of Material" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridBomPlan1" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="BOMItem">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryID" LinkCommand="ViewBomItem">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__Descr">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__ItemType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BOMID" LinkCommand="ViewBomPlan">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RevisionID">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Tools" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridToolsPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="Tools" DataKeyNames="ToolID">
                                <Columns>
                                    <px:PXGridColumn DataField="ToolID" LinkCommand="ViewTools" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Machines" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridMachinePlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="Machine" DataKeyNames="MachID">
                                <Columns>
                                    <px:PXGridColumn DataField="MachID" LinkCommand="ViewMachine" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Fixed Assets" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridFixedAssetsPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="FixedAsset" DataKeyNames="AssetID">
                                <Columns>
                                    <px:PXGridColumn DataField="AssetCD" LinkCommand="ViewFixedAsset" />
                                    <px:PXGridColumn DataField="Description" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Non-Stock Items" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridNonStockPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="NonStock" DataKeyNames="InventoryID">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryCD" LinkCommand="ViewNonStock" />
                                    <px:PXGridColumn DataField="Descr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Stability" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridStability" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="StabilityByPlan" DataKeyNames="InventoryID">
                                <RowTemplate>
                                    <px:PXSelector ID="edPlanInventoryID" runat="server" DataField="InventoryID" AutoRefresh="true" AllowEdit="true" Enabled="false" CommitChanges="true" Width="100%">
                                    </px:PXSelector>                                    
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />
                                    <px:PXSelector ID="edPlanRetentionWarehouseID" runat="server" CommitChanges="true" AllowEdit="true" Enabled="false" DataField="RetentionWarehouseID" Width="100%">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edPlanRetentionLocationID" runat="server" AutoRefresh="true" AllowEdit="true" Enabled="false" DataField="RetentionLocationID" Width="100%">
                                    </px:PXSelector>
                                    <px:PXDropDown ID="edPlanQCOrderCreation" runat="server" DataField="QCOrderCreation" Enabled="false" Width="100%">
                                    </px:PXDropDown>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="Stability" LinkCommand="ViewStability" /> 
                                    <px:PXGridColumn DataField="InventoryID" />                                    
                                    <px:PXGridColumn DataField="RetentionWarehouseID" />
                                    <px:PXGridColumn DataField="RetentionLocationID" />
                                    <px:PXGridColumn DataField="QCOrderCreation" />
                                </Columns>

                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>

            <px:PXTabItem Text="Service" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == P">
                <Template>
                    <px:PXGrid ID="PXGridServicePlanQC" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="ServiceQCByPlan" DataKeyNames="servQCID">
                                <Columns>
                                    <px:PXGridColumn DataField="ServItemType" LinkCommand="viewServPlaningPlan" />
                                    <px:PXGridColumn DataField="EquipmentId" LinkCommand="viewServEquipment" />
                                    <px:PXGridColumn DataField="EWQCServQCUnionSelector__ServItemDescr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <%-----SamplingPlan-----%>
            <px:PXTabItem Text="Stock Item" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == S">
                <Template>
                    <px:PXGrid ID="PXGridStockItemSamplingPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="StokItemSamplingPlan" DataKeyNames="QCInventoryDetailID">
                                <Columns>

                                    <px:PXGridColumn DataField="InventoryCD" Width="150px" LinkCommand="ViewStockitemSamplingPlan" />
                                    <px:PXGridColumn DataField="Descr" Width="150px" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__VendorID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__CustomerID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__ReceivingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__ShippingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__ProductionQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__AdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__KitAssemblyQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__RMAQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__WTQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__AdjustQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCInventoryDetail__DefaultAdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Item Class" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == S">
                <Template>
                    <px:PXGrid ID="PXGriditemCalssSamplingPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="ItemClassSamplingPlan" DataKeyNames="ItemClassPlanDetailID">
                                <Columns>

                                    <px:PXGridColumn DataField="ItemClassCD" Width="150px" LinkCommand="ViewItemClassSamplingPlan" />
                                    <px:PXGridColumn DataField="Descr" Width="150px" />

                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ReceivingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ShippingQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__ProductionQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__AdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__KitAssemblyQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__RMAQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__WTQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__AdjustQC" TextAlign="Center" Type="CheckBox" Width="60" />
                                    <px:PXGridColumn DataField="EWQCItemClassPlanDetail__DefaultAdhocQC" TextAlign="Center" Type="CheckBox" Width="60" />

                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Bill of Material" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == S">
                <Template>
                    <px:PXGrid ID="PXGridBOMSamplingPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="BOMItemSamplingPlan">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryID" LinkCommand="ViewInventorySamplingPlan">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__Descr">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__ItemType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BOMID" LinkCommand="ViewBomSamplingPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RevisionID">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>

            <%-----InspectionPlan-----%>
            <px:PXTabItem Text="Stock item" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == I">
                <Template>
                    <px:PXGrid ID="PXGridStockItemInspectionPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="StockItemInspectionplan">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryCD" LinkCommand="ViewInventoryItemInspectionplan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Descr">
                                    </px:PXGridColumn>
                                    <%--  <px:PXGridColumn DataField="Vendor">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Customer">
                                    </px:PXGridColumn>--%>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Item Class" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == I">
                <Template>
                    <px:PXGrid ID="PXGridItemClassInspectionPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.

Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="ItemClassInspectionplan">
                                <Columns>
                                    <px:PXGridColumn DataField="ItemClassCD" LinkCommand="ViewItemClassInspectionplan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Descr">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Bill of Material" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == I">
                <Template>
                    <px:PXGrid ID="PXGridBOMInspectionPlan1" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="Bominspection">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryID" LinkCommand="ViewInventoryInspection" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__Descr">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__ItemType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BOMID" LinkCommand="ViewBomInspection" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RevisionID">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <%-----ChecklistGroup-----%>
            <px:PXTabItem Text="Stock item" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridStockItemChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="StockItemsByChecklist">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryCD" LinkCommand="ViewInventoryItemInspectionplan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Descr">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Item Class" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridItemClassChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.

Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="ItemclassByChecklist">
                                <Columns>
                                    <px:PXGridColumn DataField="ItemClassCD" LinkCommand="ViewItemClassInspectionplan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Descr">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Bill of Material" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridBOMChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="BOMByChecklist">
                                <Columns>
                                    <px:PXGridColumn DataField="InventoryID" LinkCommand="ViewInventoryInspection" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__Descr">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__ItemType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BOMID" LinkCommand="ViewBomInspection" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RevisionID">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Tools" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridToolsChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="ToolsByChecklist" DataKeyNames="ToolID">
                                <Columns>
                                    <px:PXGridColumn DataField="ToolID" LinkCommand="ViewtncToolPlaning" />
                                    <px:PXGridColumn DataField="Description" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Machines" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridmachineChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="MachineByChecklist" DataKeyNames="ToolID">
                                <Columns>
                                    <px:PXGridColumn DataField="ToolID" LinkCommand="ViewtncMachinePlaning" />
                                    <px:PXGridColumn DataField="Description" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Qc Tool" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridQcToolChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="QcToolsByChecklist" DataKeyNames="ToolID">
                                <Columns>
                                    <px:PXGridColumn DataField="ToolID" LinkCommand="ViewtncQctoolPlaning" />
                                    <px:PXGridColumn DataField="Description" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Service" BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == C">
                <Template>
                    <px:PXGrid ID="PXGridChecklistServiceQC" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true">
                        <Levels>
                            <px:PXGridLevel DataMember="ServiceByChecklist" DataKeyNames="servQCID">
                                <Columns>
                                    <px:PXGridColumn DataField="ServItemType" LinkCommand="ViewServPlaningChecklist" />
                                    <px:PXGridColumn DataField="EquipmentId" LinkCommand="ViewServChecklist" />
                                    <px:PXGridColumn DataField="EWQCServQCUnionSelector__ServItemDescr" />
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
        </Items>
    </px:PXTab>

</asp:Content>



<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301017.aspx.cs" Inherits="Page_QC301017" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" TypeName="EW.QC.EWQCOrderPostMobile" PrimaryView="QCOrders" PageLoadBehavior="GoLastRecord" AttributesFound="False" EnableAttributes="False" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="AcceptedQtyTab" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="RejectedQtyTab" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ScrappedQtyTab" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="NCQtyTab" DependOnGrid="" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="DestructiveQtyTab" CommitChanges="true" />

        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="QCOrders" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXFormView ID="PXFormView12" runat="server" DataSourceID="ds" Width="100%" DataMember="InventoryDetails" SkinID="Transparent" LoadOnDemand="true">
                <Template>
                    <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
                    <px:PXTextEdit ID="edInventoryID" runat="server" Enabled="False" AlreadyLocalized="False" DataField="InventoryCD" AutoRefresh="true">
                    </px:PXTextEdit>
                </Template>
            </px:PXFormView>
            <%--<px:PXTextEdit ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryItem__InventoryCD">
            </px:PXTextEdit>--%>
            <px:PXFormView ID="PXFormView1" runat="server" DataSourceID="ds" Width="100%" DataMember="QCOrders" SkinID="Transparent" LoadOnDemand="true">
                <Template>
                    <px:PXLayoutRule runat="server" startrow="True" startcolumn="True" />
                    <px:PXTextEdit id="edQCOrderCD" runat="server" alreadylocalized="False" datafield="QCOrderCD" enabled="false"></px:PXTextEdit>
                    <px:PXDropDown ID="edQCType" runat="server" DataField="QCType" Enabled="false" LabelWidth="140px"></px:PXDropDown>
                    <px:PXDropDown ID="edStatus" runat="server" DataField="Status" Enabled="false"></px:PXDropDown>
                    <px:PXDateTimeEdit id="edPostDateTime" runat="server" alreadylocalized="False" datafield="ClosingDateTime" width="100%" enabled="false"></px:PXDateTimeEdit>
                    <px:PXLayoutRule runat="server" startcolumn="True"></px:PXLayoutRule>
                    <px:PXSelector ID="edPlanID" runat="server" DataField="PlanID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" LabelWidth="140px" />
                    <px:PXSelector ID="edSamplingPlanID" runat="server" DataField="SamplingPlanID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" LabelWidth="140px" />
                    <px:PXTextEdit id="edPostDescription" runat="server" alreadylocalized="False" datafield="TranDescription"></px:PXTextEdit>
                    <px:PXDropDown id="edTransferType" runat="server" datafield="TranType" width="300px"></px:PXDropDown>
                </Template>
            </px:PXFormView>
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXSplitContainer ID="PXSplitContainer2" runat="server" SkinID="Horizontal" SplitterPosition="250" Height="600px" Panel1MinSize="315" Panel2MinSize="315">
        <AutoSize Enabled="true" MinHeight="500" />
        <Template1>
            <px:PXGrid Caption="Disposition Details" CaptionVisible="true" ID="PXGridInventoryPlan" OnRowDataBound="grid_RowDataBound" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="Inquire" SyncPosition="true" AutoAdjustColumns="true">
                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                    <Behavior RepaintControlsIDs="gridAcceptedTransfers,gridRejectedTransfers,gridScrappedTransfers,gridNCTransfers,gridDestructive"></Behavior>
                </AutoCallBack>
                <Levels>
                    <px:PXGridLevel DataKeyNames="QCOrderLotDetailID" DataMember="QCOrderDetails">
                        <Columns>
                            <px:PXGridColumn DataField="LotSerNumVal" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="Status" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="WarehouseID" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="LocationID" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="TestQTY" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="BaseUOM" Width="120px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="AcceptedQTY" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="RejectedQTY" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="RejectionCode" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="ScappedQTY" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="ScrapCode" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="DestructiveQTY" Width="180px">
                            </px:PXGridColumn>
                            <%-- <px:PXGridColumn DataField="NCQTY" Width="180px">
                            </px:PXGridColumn>--%>
                            <px:PXGridColumn DataField="ActualResult" Width="180px">
                            </px:PXGridColumn>
                            <%-- <px:PXGridColumn DataField="FinalResult" Width="180px">
                            </px:PXGridColumn>--%>
                            <px:PXGridColumn DataField="Remarks" Width="180px">
                            </px:PXGridColumn>
                        </Columns>
                        <Mode AllowAddNew="false" AllowDelete="false" />
                    </px:PXGridLevel>
                </Levels>
                <AutoSize Enabled="True" />

            </px:PXGrid>

        </Template1>

        <Template2>
            <px:PXTab ID="distributionTab" runat="server" Height="100%" Width="100%">

                <Items>
                    <px:PXTabItem Text="Accepted Item">
                        <Template>
                            <px:PXGrid ID="gridAcceptedTransfers" SkinID="Details" runat="server" Width="100%" Height="100%" AutoAdjustColumns="True" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <Levels>
                                    <px:PXGridLevel DataMember="AcceptedQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edToWarehouseIDw" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationIDw" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty2w" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCodew" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescriptionw" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="AcceptedQtyTab"></AutoCallBack>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Rejected Item">
                        <Template>

                            <px:PXGrid ID="gridRejectedTransfers" SkinID="Details" runat="server" AutoAdjustColumns="True" Width="100%" Height="100%" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <Levels>
                                    <px:PXGridLevel DataMember="RejectedQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edToWarehouseID1" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID1" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty21" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode1" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription1" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="RejectedQtyTab"></AutoCallBack>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Scrapped Item">
                        <Template>
                            <px:PXGrid ID="gridScrappedTransfers" SkinID="Details" runat="server" Width="100%" Height="100%" AutoAdjustColumns="True" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <Levels>
                                    <px:PXGridLevel DataMember="ScrappedQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edToWarehouseID3" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID3" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty23" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode3" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription3" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="ScrappedQtyTab"></AutoCallBack>
                    </px:PXTabItem>

                    <px:PXTabItem Text="Destructive Item">
                        <Template>

                            <px:PXGrid ID="gridDestructive" SkinID="Details" runat="server" AutoAdjustColumns="True" Width="100%" Height="100%" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <Levels>
                                    <px:PXGridLevel DataMember="DestructiveQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edToWarehouseID4" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID4" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty4" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode4" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription4" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="DestructiveQtyTab"></AutoCallBack>
                    </px:PXTabItem>
                    <%--  <px:PXTabItem Text="NC Item">
                        <Template>
                            <px:PXGrid ID="gridNCTransfers" SkinID="Details" runat="server" Width="100%" AutoAdjustColumns="True" DataSourceID="ds" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Levels>
                                    <px:PXGridLevel DataMember="NCQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" />
                                            <px:PXGridColumn DataField="Description" Width="108px" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edToWarehouseID4" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID4" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty42" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode4" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription4" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>
                                        <Layout ColumnsMenu="False" />
                                    </px:PXGridLevel>
                                </Levels>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="NCQtyTab"></AutoCallBack>
                    </px:PXTabItem>--%>
                </Items>
            </px:PXTab>

        </Template2>
    </px:PXSplitContainer>
    <px:PXSmartPanel ID="PanelAddNCLine" runat="server" Height="500px" Width="1000px" Caption="Add Line Details" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="QCOrderLotDetailsSmartPanel" Style="position: static"
        AutoCallBack-Target="AddLine Grid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXLabel ID="edAccepted" Style="position: absolute; margin-left: 35%; margin-top: 2%; z-index: 9999;" runat="server" Text="Accepted"></px:PXLabel>
        <px:PXLabel ID="edRejected" Style="position: absolute; margin-left: 53%; margin-top: 2%; z-index: 9999;" runat="server" Text="Rejected"></px:PXLabel>
        <px:PXLabel ID="edScrapped" Style="position: absolute; margin-left: 70%; margin-top: 2%; z-index: 9999;" runat="server" Text="Scrapped"></px:PXLabel>
        <px:PXLabel ID="edDestructive" Style="position: absolute; margin-left: 87%; margin-top: 2%; z-index: 9999;" runat="server" Text="Destructive"></px:PXLabel>
        <px:PXGrid ID="gridOL" runat="server" DataSourceID="ds" SkinID="Inquire" AutoAdjustColumns="true" AllowPaging="false" PageSize="10"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="QCOrderLotDetailsSmartPanel">
                    <Columns>
                        <px:PXGridColumn DataField="SerialNumber">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheckrejected" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheckscrapped" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheckdestructive" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel13" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton4" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitSerialNo" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="PXButton5" runat="server" DialogResult="No" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>

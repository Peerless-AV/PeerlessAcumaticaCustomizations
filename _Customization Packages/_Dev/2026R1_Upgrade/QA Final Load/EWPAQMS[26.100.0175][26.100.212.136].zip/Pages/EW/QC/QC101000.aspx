﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC101000.aspx.cs" Inherits="Page_QC101000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCSetupMaint" PageLoadBehavior="InsertRecord" AttributesFound="False" PrimaryView="Setup" SuspendUnloading="False">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <!--For View-->
    <px:PXTab ID="PXTab1" runat="server" Width="100%" Height="120px" DataSourceID="ds" DataMember="Setup" BPEventsIndicator="True">
        <AutoSize Enabled="True" Container="Window" MinHeight="200"></AutoSize>
        <Activity Width="" Height=""></Activity>
        <Items>
            <px:PXTabItem Text="General">
                <Template>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                    <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Numbering Settings" />
                    <px:PXSelector ID="edQCTESTNumberSequenceID" runat="server" DataField="QCTESTNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCPNumberSequenceID" runat="server" DataField="QCPNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCSPNumberSequenceID" runat="server" DataField="QCSPNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCORecNumberSequenceID" runat="server" DataField="QCORecNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCOShippingNumberSequenceID" runat="server" DataField="QCOShippingNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCOAdhocNumberSequenceID" runat="server" DataField="QCOAdhocNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCOProductionNumberSequenceID" runat="server" DataField="QCOProductionNumberSequenceID" Width="220" Size="XL" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCOperationNumberSequenceID" runat="server" DataField="QCOperationQCOrderNumberSequenceID" Width="220" Size="XL" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCKitAssemblyQCOrderNumberSequenceID" runat="server" DataField="QCKitAssemblyQCOrderNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edRMASequenceID" runat="server" DataField="QCRMANumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCInventoryAdjustmentNumberingSequence" runat="server" DataField="QCInventoryAdjustmentNumberingSequence" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCWarehouseTransferNumberingSequence" runat="server" DataField="QCWarehouseTransferNumberingSequence" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCONonStockSequenceID" runat="server" DataField="QCONonStockSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCSNumberSequenceID" runat="server" DataField="QCSNumberSequenceID" Size="XL" Width="220" LabelWidth="300" AllowEdit="True">
                    </px:PXSelector>
                    <%--<px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />--%>
                    <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Allow By-Pass QC" />
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="350" />
                    <px:PXCheckBox ID="PXCheckBox1" runat="server" AlreadyLocalized="False" DataField="EnableReceivingQCRequired" Text="Receiving QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="PXCheckBox5" runat="server" AlreadyLocalized="False" DataField="EnableRMAQCRequired" Text="RMA QC">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="350" />
                    <px:PXCheckBox ID="PXCheckBox2" runat="server" AlreadyLocalized="False" DataField="EnableShippingQCRequired" Text="Shipping QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="PXCheckBox6" runat="server" AlreadyLocalized="False" DataField="EnableWTQCRequired" Text="WTQC">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="350" />
                    <px:PXCheckBox ID="PXCheckBox3" runat="server" AlreadyLocalized="False" DataField="EnableProductionQCRequired" Text="Production QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="PXCheckBox7" runat="server" AlreadyLocalized="False" DataField="EnableAdjustQCRequired" Text="Adjustment QC">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="350" />
                    <px:PXCheckBox ID="PXCheckBox4" runat="server" AlreadyLocalized="False" DataField="EnableKitAssemblyQCRequired" Text="Kit Assembly QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="PXCheckBox8" runat="server" AlreadyLocalized="False" DataField="EnableInProcessQCRequired" Text="In Process QC">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                    <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Data Entry Settings" />
                    <px:PXTextEdit ID="edQCPlanRevisionNo" runat="server" AlreadyLocalized="False" DataField="QCPlanRevisionNo" Width="220" LabelWidth="300px">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edQSamplingPlanRevisionNo" runat="server" AlreadyLocalized="False" DataField="SamplingPlanRevisionNo" Width="220" LabelWidth="300px">
                    </px:PXTextEdit>
                    <px:PXNumberEdit ID="edDecimalPrecision" runat="server" AlreadyLocalized="False" DataField="DecimalPrecision" Width="220" LabelWidth="300px">
                    </px:PXNumberEdit>
                    <px:PXDropDown ID="edBooleanTypeLabel" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="BooleanTypeLabel" Text="Boolean Type Label" Width="220" LabelWidth="300px">
                    </px:PXDropDown>
                    <px:PXDropDown ID="edOrderLevel" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="OrderLevel" Text="Default Order Level By" Width="220" LabelWidth="300px" CommitChanges="true">
                    </px:PXDropDown>
                    <px:PXDropDown ID="edDestructiveInventoryTransfer" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="DestructiveInventoryTransfer" Text="Desctructive Inventory Transfer" Width="220" LabelWidth="300px">
                    </px:PXDropDown>
                    <px:PXDropDown ID="edSoLinkPurchasePO" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="SoLinkPurchasePO" Text="SO Linked Purchase/PO" LabelWidth="300px" Width="220" CommitChanges="true">
                    </px:PXDropDown>
                    <px:PXLayoutRule runat="server" StartGroup="True" Merge="True" />
                    <px:PXDropDown ID="edTransactionType" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="TransactionType" LabelWidth="300px" Width="220" CommitChanges="true">
                    </px:PXDropDown>
                    <px:PXLabel ID="lblInfo" runat="server" Text="&#128712;" ToolTip="Allow transactions based on status or physical location." Style="cursor: help; border: solid 1px; background-color: #007acc; color: white;" />
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                    <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Restrict use of QC, Sampling plan that are Inactive, On Hold, or Obsolete" />
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edErrorRequiredOnPR" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnPR" Text="Error Required On PR">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edErrorRequiredOnProduction" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnProduction" Text="Error Required On Production">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edErrorRequiredOnRMA" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnRMA" Text="Error Required On RMA">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edErrorRequiredOnAdjustment" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnAdjustment" Text="Error Required On Adjustment">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edErrorRequiredOnKitAssembly" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnKitAssembly" Text="Error Required On KitAssembly">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edErrorRequiredOnInprocess" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnInprocess" Text="Error Required On Inprocess ">
                    </px:PXCheckBox>
                    <%--<px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="XM" ControlSize="XM" />--%>
                    <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="QC Operations Settings" />
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edOverrideTestResult" runat="server" AlreadyLocalized="False" DataField="OverrideTestResult" Text="Override Test Result">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edAllowRemarkForOptionalTest" runat="server" AlreadyLocalized="False" DataField="AllowRemarkForOptionalTest" Text="Make Remark mandatory for Optional Test">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edAllowInventoryTransfer" runat="server" AlreadyLocalized="False" DataField="AllowInventoryTransfer" Text="Allow Inventory Transfer">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="ewAllowPartialQCOrderPosting" runat="server" AlreadyLocalized="False" DataField="AllowPartialQCOrderPosting" Text="Allow Copy Test on QC Order">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edAutoGenerateQCOrderForProcess" runat="server" AlreadyLocalized="False" DataField="AutoGenerateQCOrderForProcess">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edApprovalRequired" runat="server" AlreadyLocalized="False" DataField="ApprovalRequired" Text="Approval Required">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edAllowFailedQCToShip" runat="server" AlreadyLocalized="False" DataField="AllowFailedQCToShip" Text="Allow Failed QC To Shipment">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edAllowbypassshipmentQC" runat="server" AlreadyLocalized="False" DataField="AllowbypassshipmentQC" Text="Allow bypass shipment QC">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="ewqcAllowCopyTest" runat="server" AlreadyLocalized="False" DataField="AllowCopyTest" Text="Allow Copy Test on QC Order">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edFailedQCQtyOnScraped" runat="server" AlreadyLocalized="False" DataField="FailedQCQtyOnScraped" Text="Failed QC qty to be scraped">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edErrorRequiredOnQCPost" runat="server" AlreadyLocalized="False" DataField="ErrorRequiredOnQCPost" Text="Make remark mandatory if QC order posted without evaluation">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edNCCancel" runat="server" AlreadyLocalized="False" DataField="NCCancel" Text="Summary Mandatory for NC Cancel">
                    </px:PXCheckBox>
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edSettinglotStatusDefaultSite" runat="server" AlreadyLocalized="False" DataField="SettinglotStatusDefaultSite" Text="Auto Transfer Rejected / Scrapped / Destructive Quantity in Inventory Status" />
                     <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
 <px:PXCheckBox ID="edPartialStatusChange" runat="server" AlreadyLocalized="False" DataField="PartialStatusChange" Text="Allow Explicit Status Change of QC Order Quantity" />
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox ID="edEnablePartialPostForLotStatus" runat="server" AlreadyLocalized="False" DataField="EnablePartialPostForLotStatus" Text="Enable Partial QC Order Posting with Inventory Status Update" />
                    <%--<px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />--%>
                    <%-- <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Allow By-passing QC" />
                    <px:PXCheckBox ID="edEnableReceivingQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableReceivingQCRequired" Text="Receiving QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableShippingQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableShippingQCRequired" Text="Shipping QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableProductionQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableProductionQCRequired" Text="Production QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableKitAssemblyQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableKitAssemblyQCRequired" Text="Kit Assembly QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableRMAQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableRMAQCRequired" Text="RMA QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableWTQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableWTQCRequired" Text="WTQC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableAdjustQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableAdjustQCRequired" Text="Adjustment QC">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edEnableInProcessQCRequired" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="EnableInProcessQCRequired" Text="In Process QC">
                    </px:PXCheckBox>
                    <px:PXLayoutRule ID="PXLayoutRule3" runat="server" GroupCaption="Lc CnFg" StartColumn="false" LabelsWidth="200" ControlSize="XXL" />--%>
                    <px:PXTextEdit ID="edDescription" runat="server" DataField="Description" CommitChanges="True" Size="XXS" Width="320" />
                    <px:PXTextEdit ID="edKeyVal" runat="server" DataField="KeyVal" CommitChanges="True" Size="XXS" Width="320" />
                    <px:PXLayoutRule runat="server" Merge="true" ColumnWidth="446" />
                    <px:PXCheckBox runat="server" Text="Allow Adding Test Results On Lot Attribute" DataField="AllowCopyLotAttribute" AlreadyLocalized="False" ID="edAllowCopyLotAttribute" />
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="QC Warehouse and Location Settings">
                <Template>
                    <px:PXTab ID="tab" runat="server" Width="100%" Height="606px" DataSourceID="ds" FilesIndicator="False" NoteIndicator="False">
                        <AutoSize Enabled="True" Container="Window" MinHeight="150" />
                        <Items>
                            <px:PXTabItem Text="QC Location" BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="grid1" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="SetupDetailID" DataMember="SetupDetailQC">
                                                <RowTemplate>

                                                    <px:PXSelector ID="edWarehouseID" runat="server" AlreadyLocalized="False" DataField="WarehouseID" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>
                                                    <px:PXSelector ID="edLocationID" runat="server" AlreadyLocalized="False" DataField="LocationID" AutoRefresh="true" CommitChanges="true" SyncStateWithCommand="true">
                                                        <GridProperties FastFilterFields="Descr"></GridProperties>
                                                    </px:PXSelector>
                                                    <px:PXCheckBox ID="edDefaultWarehouseQC" runat="server" AlreadyLocalized="False" DataField="DefaultWarehouse" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXCheckBox>
                                                    <px:PXTextEdit ID="edSetupDetailID" runat="server" DataField="SetupDetailID" CommitChanges="true">
                                                    </px:PXTextEdit>
                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="WarehouseID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="LocationID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="DefaultWarehouse" CommitChanges="true" TextAlign="Center" Type="CheckBox">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="SetupDetailID" CommitChanges="true" Width="0px">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="GlobalPlanTab" />
                            </px:PXTabItem>

                            <px:PXTabItem Text="Scrap Location" BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="grid2" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="SetupDetailID" DataMember="SetupDetailScrapped">
                                                <RowTemplate>

                                                    <px:PXSelector ID="edWarehouseIDScrapped" runat="server" AlreadyLocalized="False" DataField="WarehouseID" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>
                                                    <px:PXSelector ID="edLocationIDScrapped" runat="server" AlreadyLocalized="False" DataField="LocationID" AutoRefresh="true" CommitChanges="true" SyncStateWithCommand="true">
                                                        <GridProperties FastFilterFields="Descr"></GridProperties>
                                                    </px:PXSelector>
                                                    <px:PXCheckBox ID="edDefaultWarehouseScrapped" runat="server" AlreadyLocalized="False" DataField="DefaultWarehouse" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXCheckBox>
                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="WarehouseID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="LocationID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="DefaultWarehouse" CommitChanges="true" TextAlign="Center" Type="CheckBox">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="CustomerPlanTab" />
                            </px:PXTabItem>

                            <px:PXTabItem Text="Rejection Location" BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="grid3" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="SetupDetailID" DataMember="SetupDetailRejected">
                                                <RowTemplate>

                                                    <px:PXSelector ID="edWarehouseIDRejected" runat="server" AlreadyLocalized="False" DataField="WarehouseID" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>
                                                    <px:PXSelector ID="edLocationIDRejected" runat="server" AlreadyLocalized="False" DataField="LocationID" AutoRefresh="true" CommitChanges="true" SyncStateWithCommand="true">
                                                    </px:PXSelector>
                                                    <px:PXCheckBox ID="edDefaultWarehouseRejected" runat="server" AlreadyLocalized="False" DataField="DefaultWarehouse" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXCheckBox>
                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="WarehouseID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="LocationID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="DefaultWarehouse" CommitChanges="true" TextAlign="Center" Type="CheckBox">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="RejectedLocationTab" />
                            </px:PXTabItem>

                            <px:PXTabItem Text="Destructive Location" BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="grid3" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="SetupDetailID" DataMember="SetupDetailDestructive">
                                                <RowTemplate>

                                                    <px:PXSelector ID="edWarehouseIDDestructive" runat="server" AlreadyLocalized="False" DataField="WarehouseID" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>
                                                    <px:PXSelector ID="edLocationIDDestructive" runat="server" AlreadyLocalized="False" DataField="LocationID" AutoRefresh="true" CommitChanges="true" SyncStateWithCommand="true">
                                                    </px:PXSelector>
                                                    <px:PXCheckBox ID="edDefaultWarehouseDestructive" runat="server" AlreadyLocalized="False" DataField="DefaultWarehouse" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXCheckBox>
                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="WarehouseID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="LocationID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="DefaultWarehouse" CommitChanges="true" TextAlign="Center" Type="CheckBox">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="DestructiveLocationTab" />
                            </px:PXTabItem>
                            <px:PXTabItem Text="Stability Location" BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="SetupDetailID" DataMember="SetupDetailStability">
                                                <RowTemplate>

                                                    <px:PXSelector ID="edWarehouseIDStability" runat="server" AlreadyLocalized="False" DataField="WarehouseID" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>
                                                    <px:PXSelector ID="edLocationIDStability" runat="server" AlreadyLocalized="False" DataField="LocationID" AutoRefresh="true" CommitChanges="true" SyncStateWithCommand="true">
                                                    </px:PXSelector>
                                                    <px:PXCheckBox ID="edDefaultWarehouseStability" runat="server" AlreadyLocalized="False" DataField="DefaultWarehouse" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXCheckBox>
                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="WarehouseID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="LocationID" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="DefaultWarehouse" CommitChanges="true" TextAlign="Center" Type="CheckBox">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="StabilityLocationTab" />
                            </px:PXTabItem>
                            <px:PXTabItem>
                            </px:PXTabItem>
                        </Items>
                        <AutoSize Enabled="True" MinHeight="150" />
                    </px:PXTab>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Inventory Status Setting">
                <Template>
                    <px:PXTab ID="transactiontab" runat="server" Width="100%" Height="606px" DataSourceID="ds" FilesIndicator="False" NoteIndicator="False">
                        <AutoSize Enabled="True" Container="Window" MinHeight="150" />
                        <Items>
                            <px:PXTabItem Text="Transaction Configuration " BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="transactionsgrid" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="Status" DataMember="LotLocStatusPref">
                                                <RowTemplate>

                                                    <px:PXSelector ID="edStatus" runat="server" AlreadyLocalized="False" DataField="Status" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>

                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="Status" CommitChanges="true" Width="65">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="EWQCLotLocStatus__Description" Width="250" />
                                                    <px:PXGridColumn DataField="AllowProduction" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="65">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="AllowSales" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="65">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="AllowTransfer" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="65">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="AllowAdhoc" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="65">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="AllowAssembly" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="65">
                                                    </px:PXGridColumn>
                                                     <px:PXGridColumn DataField="AllowMoveReversal" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="65">
 </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="GlobalPlanTab" />
                            </px:PXTabItem>

                            <px:PXTabItem Text="Transaction Mapping " BindingContext="form">
                                <Template>
                                    <px:PXGrid ID="transactionsMappinggrid" runat="server" DataSourceID="ds" Style="z-index: 100"
                                        Width="45%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="Status" DataMember="LotLocDocType">
                                                <RowTemplate>
                                                    <px:PXDropDown ID="edDocType" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="DocType" Width="220" LabelWidth="300px" CommitChanges="true">
                                                    </px:PXDropDown>
                                                    <px:PXSelector ID="edStatusL" runat="server" AlreadyLocalized="False" DataField="LotStatus" CommitChanges="true" AutoRefresh="true">
                                                    </px:PXSelector>
                                                </RowTemplate>
                                                <Columns>

                                                    <px:PXGridColumn DataField="DocType" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="LotStatus" Width="50" />
                                                    <px:PXGridColumn DataField="EWQCLotLocStatus__Description"/>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <Mode AllowUpload="True" />
                                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Enabled="True" Target="ds" Command="GlobalPlanTab" />
                            </px:PXTabItem>
                            <px:PXTabItem Text="Event History">
                                <Template>
                                    <px:PXGrid ID="LotStatusHistory" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                                        <Levels>
                                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                                <Columns>
                                                    <px:PXGridColumn DataField="CreatedDateTime" Width="130" DisplayFormat="g">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="Description" Width="370">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="EventType" Width="200">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="CreatedByID" Width="200">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="AbsoluteRefNbr" Width="200">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <AutoSize Enabled="True" />
                                        <AutoCallBack />
                                    </px:PXGrid>
                                </Template>
                                <AutoCallBack Target="LotStatusHistory" Command="Refresh">
                                    <Behavior RepaintControlsIDs="LotStatusHistory" />
                                </AutoCallBack>
                            </px:PXTabItem>
                            <px:PXTabItem>
                            </px:PXTabItem>
                        </Items>
                        <AutoSize Enabled="True" MinHeight="150" />
                    </px:PXTab>
                </Template>
            </px:PXTabItem>

        </Items>
    </px:PXTab>
</asp:Content>







﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209020.aspx.cs" Inherits="Page_QC209020" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="ServQC" TypeName="EW.QC.EWQCServiceQCMaint">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" DataMember="ServQC" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True"></px:PXLayoutRule>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM" />
            <px:PXPanel ID="PXPanel3" runat="server" RenderStyle="Simple">
                <px:PXDropDown ID="edServItemType" runat="server" CommitChanges="true" Width="300px" DataField="ServItemType" Size="S"></px:PXDropDown>
            </px:PXPanel>
            <px:PXPanel ID="PXPanel4" runat="server" RenderStyle="Simple">
                <px:PXSelector CommitChanges="True" ID="edEquipmentId" AutoRefresh="true" runat="server" Width="300px" DataField="EquipmentId"></px:PXSelector>
            </px:PXPanel>
            <px:PXPanel ID="PXPanel1" runat="server" DataMember="FsEquipment" RenderStyle="Simple">
                <px:PXTextEdit ID="edEquipmentDescr" runat="server" DataField="Descr" Width="300px" Enabled="false"></px:PXTextEdit>
            </px:PXPanel>
            <px:PXPanel ID="PXPanel2" runat="server" DataMember="FsEquipment" RenderStyle="Simple">
                <%--<px:PXDropDown ID="edEquipmentStatus" runat="server" DataField="Status" Enabled="false" Width="300px" Size="S"></px:PXDropDown>--%>
                <px:PXSelector runat="server" ID="edEquipmentInventoryID" DataField="InventoryID" Width="300px" Enabled="false">
                </px:PXSelector>
                <px:PXTextEdit ID="edEquipmentInvDescr" runat="server" DataField="InventoryItem__Descr" Width="300px" Enabled="false"></px:PXTextEdit>
            </px:PXPanel>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM" />
            <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" Width="300px" DataField="CreatedOn" TimeMode="false">
            </px:PXDateTimeEdit>
            <px:PXTextEdit ID="edRemarks" runat="server" DataField="Remarks" TextMode="MultiLine" Height="100" Width="300" CommitChanges="true">
            </px:PXTextEdit>
        </Template>
    </px:PXFormView>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds">
        <Items>
            <px:PXTabItem Text="Plan">
                <Template>
                    <px:PXSplitContainer runat="server" Orientation="Horizontal" Panel1MinSize="250" Panel2MinSize="250" SplitterPosition="60" PositionInPercent="True" ID="splitConditions">
                        <AutoSize Container="Window" Enabled="true" />
                        <Template1>
                            <px:PXGrid runat="server" ID="grdServPlan" SyncPosition="True" KeepPosition="True" Height="100%" SkinID="Details" Width="100%" CaptionVisible="True" AutoAdjustColumns="True" DataSourceID="ds">
                                <Levels>
                                    <px:PXGridLevel DataMember="ServPlan" DataKeyNames="ServQCID,ServPlanID">
                                        <Mode AllowAddNew="True" InitNewRow="True" />
                                        <RowTemplate>
                                            <px:PXSelector runat="server" ID="edPlanID" DataField="PlanID" CommitChanges="true">
                                                <GridProperties FastFilterFields="RevisionNo,Name" />
                                            </px:PXSelector>
                                            <px:PXDropDown runat="server" ID="edResultCriteria" DataField="ResultCriteria" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="PlanID" Width="180" DisplayMode="Text" CommitChanges="True" LinkCommand="EWQCViewPlanMaster" />
                                            <px:PXGridColumn DataField="EWQCPlan__Status" Width="70" />
                                            <px:PXGridColumn DataField="ResultCriteria" Width="70" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" Container="Parent" />
                                <AutoCallBack Command="Refresh" Target="grdServPlanVar" />
                                <OnChangeCommand Command="Refresh" Target="grdServPlanVar" />
                                <Mode AllowUpload="true" />
                            </px:PXGrid>
                        </Template1>
                        <Template2>
                            <px:PXGrid runat="server" ID="grdServPlanVar" Height="80" SkinID="Details" Width="100%" Caption="Tests" CaptionVisible="True" AutoAdjustColumns="True" DataSourceID="ds" SyncPosition="True">
                                <Levels>
                                    <px:PXGridLevel DataMember="ServPlanVar">
                                        <Columns>
                                            <px:PXGridColumn DataField="AddInReports" Type="CheckBox" Width="120px" />
                                            <px:PXGridColumn DataField="VariableID" Width="180" CommitChanges="True" LinkCommand="EWQCViewTestMaster" />
                                            <px:PXGridColumn DataField="EWQCVariable__Name" Width="180" />
                                            <px:PXGridColumn DataField="ToolSteps" Width="180" CommitChanges="True" LinkCommand="EWQCGotoToolSteps" />
                                            <px:PXGridColumn DataField="TestGroupID" Width="180" />
                                            <px:PXGridColumn DataField="SeverityLevel" Width="140px" />
                                            <px:PXGridColumn DataField="EWQCVariable__Description" Width="280" />
                                            <px:PXGridColumn DataField="EWQCTestCategory__Name" Width="180" />
                                            <px:PXGridColumn DataField="EWQCTestMethod__Name" Width="180" />
                                            <px:PXGridColumn DataField="EWQCVariable__DataType" Width="70" />
                                            <px:PXGridColumn DataField="CalculationType" Width="70" />
                                            <px:PXGridColumn DataField="UOM" Width="220" />
                                            <px:PXGridColumn DataField="QCOperator" Width="100" CommitChanges="True" />
                                            <px:PXGridColumn DataField="NumMinValue" Width="100" />
                                            <px:PXGridColumn DataField="NumMaxValue" Width="100" />
                                            <px:PXGridColumn DataField="TestResultUOM" Width="100" CommitChanges="True" />
                                            <px:PXGridColumn DataField="BitGoNoGo" Type="CheckBox" Width="120" />
                                            <px:PXGridColumn DataField="AlphaValue" Width="100px" />
                                            <px:PXGridColumn DataField="EWQCVariable__Equation" Width="70" />
                                            <px:PXGridColumn DataField="OptionalTest" Width="100" Type="CheckBox" />
                                            <px:PXGridColumn DataField="LeadTimeDurationType" Width="150" />
                                            <px:PXGridColumn DataField="LeadTimeDuration" Width="150" />
                                            <px:PXGridColumn DataField="SampleSize" Width="150" />
                                            <px:PXGridColumn DataField="ComboValue" Width="150" CommitChanges="True" LinkCommand="EWQCAddCombo" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector runat="server" ID="edUOMUnit" DataField="UOM" AllowEdit="True" CommitChanges="True" />
                                            <px:PXDropDown runat="server" ID="edQCOperator" DataField="QCOperator" />
                                            <px:PXSelector runat="server" DataField="VariableID" ID="edEWQCVariableID">
                                                <GridProperties FastFilterFields="VariableCD,Name" />
                                            </px:PXSelector>
                                            <px:PXSelector runat="server" DataField="SeverityLevel" ID="edEWQCSeverityLevel">
                                                <GridProperties FastFilterFields="Name,Description" />
                                            </px:PXSelector>
                                            <px:PXSelector runat="server" DataField="TestGroupID" ID="edEWQCTestGroupID">
                                                <GridProperties FastFilterFields="Name,Description" />
                                            </px:PXSelector>
                                            <px:PXTextEdit runat="server" DataField="ComboValue" AlreadyLocalized="False" ID="edComboValue" />
                                        </RowTemplate>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" Container="Window" />
                                <CallbackCommands>
                                    <Refresh SelectControlsIDs="grdServPlan" />
                                </CallbackCommands>
                                <Mode AllowUpload="true" />
                            </px:PXGrid>
                        </Template2>
                    </px:PXSplitContainer>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Checklist Group">
                <Template>
                    <px:PXSplitContainer runat="server" Orientation="Horizontal" Panel1MinSize="200" Panel2MinSize="100" SplitterPosition="40" PositionInPercent="True" ID="splitConditions">
                        <AutoSize Container="Window" Enabled="true" />
                        <Template1>
                            <px:PXGrid runat="server" ID="chkgrp" SyncPosition="True" KeepPosition="True" Height="100%" SkinID="DetailsInTab" Width="100%" CaptionVisible="True" AutoAdjustColumns="True" DataSourceID="ds">
                                <Levels>
                                    <px:PXGridLevel DataMember="ServChkGrp" DataKeyNames="ServQCID,ServPlanID">
                                        <RowTemplate>
                                            <px:PXSelector runat="server" ID="edChkGrpID" DataField="ChkGrpID" AllowEdit="True" CommitChanges="True" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="ChkGrpID" Width="70" LinkCommand="EWQCViewChecklistGroup" CommitChanges="True" />
                                            <px:PXGridColumn DataField="EWQCChecklistGroup__Description" Width="180" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" Container="Parent" />
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="Checklist" />
                                </AutoCallBack>
                                <Mode AllowUpload="true" />
                            </px:PXGrid>
                        </Template1>
                        <Template2>
                            <px:PXGrid runat="server" ID="Checklist" AutoAdjustColumns="True" Width="100%" SkinID="DetailsInTab" KeepPosition="True" SyncPosition="True" DataSourceID="ds" Caption="Checklists">
                                <Levels>
                                    <px:PXGridLevel DataMember="ServChkList">
                                        <Columns>
                                            <px:PXGridColumn DataField="ChecklistID" Width="180" LinkCommand="EWQCViewCheckListItem" />
                                            <px:PXGridColumn DataField="EWQCChecklist__Name" Width="180" />
                                            <px:PXGridColumn DataField="EWQCChecklist__Description" Width="180" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" Container="Window" />
                                <Mode AllowUpload="true" />
                            </px:PXGrid>
                        </Template2>
                    </px:PXSplitContainer>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" Width="240px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                        <Mode AllowUpload="false" AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>
    <px:PXSmartPanel runat="server" DesignView="Content" Height="500px" Width="1100px" ID="pnlTestSteps" LoadOnDemand="true" AutoReload="true" CaptionVisible="true" Caption="QC Tool" Key="ToolSteps" AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" Style='position: static;'>
        <px:PXGrid runat="server" ID="StepsGrid" SkinID="Inquire" Width="100%" DataSourceID="ds">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID" />
                        <px:PXGridColumn DataField="Description" />
                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" AllowUpload="false" AutoInsert="false" />
        </px:PXGrid>
        <px:PXPanel runat="server" ID="PXPanel1" SkinID="Buttons">
            <px:PXButton runat="server" ID="PXButton1" Text="OK" DialogResult="OK" />
        </px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel runat="server" ID="pnlcombo" DesignView="Content" Height="360px" Width="720px" CaptionVisible="True" Caption="Combo Values" Key="TestComboValues" AutoCallBack-Target="grdcombo" AutoCallBack-Command="Refresh">
        <px:PXGrid runat="server" ID="grdcombo" SyncPosition="true" Height="200px" SkinID="Details" Width="685px" AutoAdjustColumns="True" DataSourceID="ds" AllowPaging="True" AdjustPageSize="Auto" AllowSearch="true">
            <Mode AllowAddNew="false" AllowUpdate="true" AllowDelete="false" AllowUpload="false" AutoInsert="false" />
            <Levels>
                <px:PXGridLevel DataMember="TestComboValues">
                    <Columns>
                        <px:PXGridColumn DataField="TestComboCD" />
                        <px:PXGridColumn DataField="Description" />
                        <px:PXGridColumn DataField="ComboCheck" Type="CheckBox" TextAlign="Center" Width="120px" />
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel runat="server" ID="ComboButtonPanel" SkinID="Buttons">
            <px:PXButton runat="server" ID="EWQCComboSaveButton" Text="OK" DialogResult="OK">
                <AutoCallBack Target="ds" Command="EWQCComboSaveButton" />
            </px:PXButton>
            <px:PXButton runat="server" ID="ComboCancelButton" Text="Cancel" DialogResult="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>


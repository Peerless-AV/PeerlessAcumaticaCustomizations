﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_QC301020:PX.Web.UI.PXPage {
  protected void Page_Load(object sender, EventArgs e) {
    AddStyle("rowDsiabled", "#D3D3D3", null, false);
  }

  private void AddStyle(string name, string backColor, string foreColor, bool bold) {
    Style style = new Style();
    if(!string.IsNullOrEmpty(backColor))
      style.BackColor = Color.FromName(backColor + " !important");

    if(!string.IsNullOrEmpty(foreColor))
      style.ForeColor = Color.FromName(foreColor);
    style.Font.Bold = bold;

    this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
  }

  protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e) {

    Object statusVal = e.Row.Cells["Status"].Value;

    if(statusVal != null && Convert.ToString(statusVal) == EW.QC.QCToolOrderStatus.Posted)
      e.Row.Style.CssClass = "rowDsiabled";
  }
}
﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC102100.aspx.cs" Inherits="Page_QC102100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCToolsManagementSetupMaint" PageLoadBehavior="InsertRecord" AttributesFound="False" PrimaryView="Setup" SuspendUnloading="False">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds"  Width="100%" DataMember="Setup"  Height ="100%" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
          <AutoSize Enabled="True" Container="Window" MinHeight="200"></AutoSize>
        <Activity Width="" Height=""></Activity>
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />
             <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="NUMBERING SETTINGS" />
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True"></px:PXLayoutRule>
            <px:PXSelector ID="edQCTnCNumberSequenceID" runat="server" DataField="QCTnCNumberSequenceID" LabelWidth="300" CommitChanges="true" AllowEdit="true">
            </px:PXSelector>
            <px:PXSelector ID="edQCTnCMaintNumberSequenceID" runat="server" DataField="QCTnCMaintNumberSequenceID" LabelWidth="300" CommitChanges="true" AllowEdit="true">
            </px:PXSelector>

            <px:PXLayoutRule runat="server"   StartColumn="True"  LabelsWidth="M" ControlSize="XM" />               
               <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Data Entry Settings" />
             <px:PXDropDown ID="edTnCValidationType" runat="server" CommitChanges="true" DataField="TnCValidationType" LabelWidth="300"></px:PXDropDown>
            <px:PXDropDown ID="edTnCMaintValidationType" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="TnCMaintValidationType" LabelWidth="300"></px:PXDropDown>
        </Template>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXFormView>
</asp:Content>

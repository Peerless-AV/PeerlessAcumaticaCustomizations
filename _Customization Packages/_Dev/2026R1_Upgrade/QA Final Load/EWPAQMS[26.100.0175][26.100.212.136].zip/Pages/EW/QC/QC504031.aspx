﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC504031.aspx.cs" Inherits="Page_QC504031" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="False" runat="server" visible="True" width="100%" primaryview="ToolsProcess"
        typename="EW.QC.EWQCToolsManagementProcess">
        <CallbackCommands>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="PrimaryDAC" tabindex="3700">
        <Template>

        </Template>
    </px:pxformview>
</asp:Content>


<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100" bpeventsindicator="True"
        allowpaging="false" allowsearch="true" adjustpagesize="None" syncposition="true" datasourceid="ds" skinid="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataMember="ToolsProcess" DataKeyNames="ToolsManagementID">
                <RowTemplate>
                    
                    <px:PXDropDown ID="edToolSource" runat="server" TimeMode="false" DataField="ToolSource" Width="100%">
                    </px:PXDropDown>
                    <px:PXDropDown ID="edToolID" runat="server" TimeMode="false" DataField="ToolID" Width="100%">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edDescription" runat="server" DataField="Description" Width="100%">
                    </px:PXTextEdit>
                    <px:PXDropDown ID="edToolStatus" runat="server" DataField="ToolStatus" Width="100%">
                    </px:PXDropDown>
                    <px:PXSelector ID="edCalibrationChecklistID" runat="server" CommitChanges="true" Width="100%" DataField="CalibrationChecklistID">
                    </px:PXSelector>
                     <px:PXDateTimeEdit ID="edLastCalibrationDate" runat="server" TimeMode="false" DataField="LastCalibrationDate" Width="100%">
                    </px:PXDateTimeEdit>
                    <px:PXDropDown ID="edOrderType" runat="server" DataField="OrderType" Width="100%">
            </px:PXDropDown>
                     
                    
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ToolSource" Width="150px" />
                    <px:PXGridColumn DataField="ToolID" Width="150px"  LinkCommand="ViewToolID" CommitChanges="true" />
                    <px:PXGridColumn DataField="Description" Width="150px" />
                    <px:PXGridColumn DataField="ToolStatus" Width="150px" />
                    <px:PXGridColumn DataField="CalibrationChecklistID" Width="150px" LinkCommand="EWQCViewChecklistGroup" CommitChanges="true" />
                    <px:PXGridColumn DataField="LastCalibrationDate" Width="150px" />
                    <px:PXGridColumn DataField="OrderType" Width="150px" />
                
                   
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>
<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505300.aspx.cs" Inherits="Page_QC505200" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="False" runat="server" visible="True" width="100%" primaryview="Filter"
        typename="EW.QC.EWQCOrderCancelProcess">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewOrder" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
            <%--<px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewPlan" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
               <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewStockItem" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
               <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewSampling" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
                <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewRefNumber" DependOnGrid="grid">
            </px:PXDSCallbackCommand>--%>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100" bpeventsindicator="True"
        width="100%" datamember="Filter" tabindex="3700">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="True"/>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" CommitChanges="True"/>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edLotSerNumVal" runat="server" DataField="LotSerNumVal" CommitChanges="True"/>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edProdOrderID" runat="server" DataField="ProdOrderID" CommitChanges="True"/>
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" syncposition="true" adjustpagesize="Auto" datasourceid="ds" skinid="PrimaryInquire">
         <Levels>
            <px:PXGridLevel DataMember="EWQCOrders">
                <RowTemplate>
                    <%--<px:PXPanel runat="server" ID="PXPanel1" DataMember="EWQCLotdetails" RenderStyle="Simple">
    <px:PXTextEdit runat="server" Enabled="false" DataField="EWQCOrderLotDetail__LotSerNumVal" ID="PXGridColumn1" /></px:PXPanel>--%>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QCOrderCD" Width="150" LinkCommand="ViewOrder" />
                    <px:PXGridColumn DataField="PlanCD" Width="150" LinkCommand="ViewPlan"/>
                    <px:PXGridColumn DataField="InventoryCD" Width="150" LinkCommand="ViewStockItem"/>
                    <px:PXGridColumn DataField="SamplingPlanCD" Width="180" LinkCommand="ViewSampling"/>
                    <px:PXGridColumn DataField="QCType" />
                    <px:PXGridColumn DataField="RefDocumentNbr" Width="180" LinkCommand="ViewRefNumber"/>
                    <px:PXGridColumn DataField="RefDocumentType" />
                    <px:PXGridColumn DataField="Status" />
                    <px:PXGridColumn DataField="EWQCOrderLotDetail__LotSerNumVal"/>

                    <%--<px:PXGridColumn TextField ="LotSrNbr" ValueField ="Lot"/>--%>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>

</asp:Content>

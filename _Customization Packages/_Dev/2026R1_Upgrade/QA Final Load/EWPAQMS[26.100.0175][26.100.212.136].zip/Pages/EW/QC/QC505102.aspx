﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505102.aspx.cs" Inherits="Page_QC505102" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="ProcessPlan"
        typename="EW.QC.EWQCSamplingPlanActivateMaint">
        <CallbackCommands>  
           <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewPlan" DependOnGrid="grid">
            </px:PXDSCallbackCommand>          
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" bpeventsindicator="True"> 
<Levels>
<px:PXGridLevel DataMember="ProcessPlan">
<RowTemplate>
<px:PXSelector ID="edSamplingPlanCD" runat="server" DataField="SamplingPlanCD" AllowEdit="True" />
</RowTemplate>
<Columns>
<px:PXGridColumn DataField="Selected" TextAlign="Center" Type="CheckBox" Width="30" AllowCheckAll="True" AllowSort="False" />
<px:PXGridColumn DataField="SamplingPlanCD" Width="90" LinkCommand="ViewPlan" />
<px:PXGridColumn DataField="RevisionNo" Width="90" LinkCommand="ViewPlan" />
<px:PXGridColumn DataField="Name" />
<px:PXGridColumn DataField="Description" Width="90" />
<px:PXGridColumn DataField="EffectiveFromDate" />                    
<px:PXGridColumn DataField="EffectiveToDate" />
<px:PXGridColumn DataField="Status" Width="80" />
</Columns>
</px:PXGridLevel>
</Levels>
<AutoSize Container="Window" Enabled="True" MinHeight="200" />
</px:pxgrid>
</asp:Content>

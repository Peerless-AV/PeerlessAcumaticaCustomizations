﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="true" CodeFile="QC507400.aspx.cs" Inherits="Page_QC507400" Title="Vendor Performance" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="Wizard" TypeName="EW.QC.EWQCVendorPerformanceProcess">
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Wizard" Width="100%" BPEventsIndicator="True">
         <Template>
      <px:PXLayoutRule runat="server" StartRow="True" />
      <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
      </px:PXLayoutRule>
      <px:PXSelector ID="edItemClassID" runat="server" DataField="ItemClassID" CommitChanges="True">
      </px:PXSelector>
        
      <px:PXDropDown ID="edTimePeriod" style="margin-bottom: 40px;" runat="server" DataField="TimePeriod" CommitChanges="True">
      </px:PXDropDown>
      <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
      </px:PXLayoutRule>
      <px:PXSelector ID="edInventoryID" runat="server" AutoRefresh="true" DataField="InventoryID" CommitChanges="True">
      </px:PXSelector>             
      <px:PXSelector ID="edYear" runat="server" AutoRefresh="true" DataField="Year" CommitChanges="True">
      </px:PXSelector>
      <px:PXSelector ID="edMonth" runat="server" AutoRefresh="true" DataField="Month" CommitChanges="True">
      </px:PXSelector>
      <px:PXDropDown ID="edQuarter" runat="server" AutoRefresh="true" DataField="Quarter" CommitChanges="True">
      </px:PXDropDown>
      <px:PXDateTimeEdit ID="edDateFrom" runat="server" AlreadyLocalized="False" DataField="DateFrom">
      </px:PXDateTimeEdit>
      <px:PXDateTimeEdit ID="edDateTo" runat="server" AlreadyLocalized="False" DataField="DateTo">
      </px:PXDateTimeEdit>
       <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
      </px:PXLayoutRule>
      <px:PXCheckBox ID="edInventoryFilter" runat="server" AlreadyLocalized="False" DataField="InventoryFilter" Text="Check" CommitChanges ="true">
       </px:PXCheckBox>
      <px:PXLayoutRule runat="server" StartRow="True" />
      <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
      <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Inventory" />
      <px:PXGrid ID="grdInventory" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="Details" SyncPosition="True" AutoAdjustColumns="true">
          <Levels>
              <px:PXGridLevel DataKeyNames="InventoryCD" DataMember="InventoryItems">
                  <RowTemplate>
                      <px:PXCheckBox ID="edSelected" runat="server" AlreadyLocalized="False" DataField="Selected" Text="Check">
                      </px:PXCheckBox>
                      <px:PXSelector ID="edInventoryCD" runat="server" AlreadyLocalized="False" DataField="InventoryCD" Enabled="false">
                      </px:PXSelector>
                      <px:PXTextEdit runat="server" ID="edDescr" DataField="Descr" TextMode="MultiLine" Enabled="false"></px:PXTextEdit>
                      <px:PXSelector ID="edItemClassID1" runat="server" AlreadyLocalized="False" DataField="ItemClassID" Enabled="false">
                      </px:PXSelector>
                       <px:PXDropDown ID="edUsrTimePeriod" style="margin-bottom: 40px;" runat="server" DataField="UsrTimePeriod" CommitChanges="True">
                  </px:PXDropDown>
                      <px:PXSelector ID="edUsrYear" runat="server" AutoRefresh="true" DataField="UsrYear" CommitChanges="True">
                  </px:PXSelector>
                  <px:PXSelector ID="edUsrMonth" runat="server" AutoRefresh="true" DataField="UsrMonth" CommitChanges="True">
                  </px:PXSelector>
                  <px:PXDropDown ID="edUsrQuarter" runat="server" AutoRefresh="true" DataField="UsrQuarter" CommitChanges="True">
                  </px:PXDropDown>
                  <px:PXDateTimeEdit ID="edUsrDateFrom" runat="server" AlreadyLocalized="False" DataField="UsrDateFrom"  CommitChanges="True">
                  </px:PXDateTimeEdit>
                  <px:PXDateTimeEdit ID="edUsrDateTo" runat="server" AlreadyLocalized="False" DataField="UsrDateTo"   CommitChanges="True">
                  </px:PXDateTimeEdit>
                  </RowTemplate>
                  <Columns>
                      <px:PXGridColumn DataField="Selected" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="40px" CommitChanges="true">
                      </px:PXGridColumn>
                      <px:PXGridColumn DataField="InventoryCD" Width="150px"  CommitChanges="true">
                      </px:PXGridColumn>
                       <px:PXGridColumn DataField="Descr" Width="300px"  CommitChanges="true">
                      </px:PXGridColumn>
                       <px:PXGridColumn DataField="ItemClassID" Width="300px"  CommitChanges="true">
                      </px:PXGridColumn>
                       <px:PXGridColumn DataField="UsrTimePeriod" Width="300px"  CommitChanges="true">
                      </px:PXGridColumn>
                      <px:PXGridColumn DataField="UsrYear" Width="300px"  CommitChanges="true" />
                      <px:PXGridColumn DataField="UsrMonth" Width="300px"  CommitChanges="true"/>
                      <px:PXGridColumn DataField="UsrQuarter" Width="300px"  CommitChanges="true"/>
                      <px:PXGridColumn DataField="UsrDateFrom" Width="300px"  CommitChanges="true"/>
                      <px:PXGridColumn DataField="UsrDateTo" Width="300px"  CommitChanges="true"/>

                  </Columns>
              </px:PXGridLevel>
          </Levels>
          <AutoSize Enabled="True" Container="Window" />
          <AutoCallBack />
          <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
      </px:PXGrid>
  </Template>
    </px:PXFormView>
</asp:Content>
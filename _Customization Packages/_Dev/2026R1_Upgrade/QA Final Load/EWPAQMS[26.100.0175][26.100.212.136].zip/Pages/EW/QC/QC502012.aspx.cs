﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_QC502012 : PX.Web.UI.PXPage {
    protected void Page_Init(object sender, EventArgs e)
    {
    }
}

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301002.aspx.cs" Inherits="Page_QC301002" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" TypeName="EW.QC.EWQCOrderPostLotStatus" PrimaryView="QCOrders" PageLoadBehavior="GoLastRecord" AttributesFound="False" EnableAttributes="False" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="AcceptedQtyTab" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="RejectedQtyTab" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ScrappedQtyTab" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="NCQtyTab" Visible="false" DependOnGrid="" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="DestructiveQtyTab" Visible="false" CommitChanges="true" />

        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="QCOrders" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXFormView ID="PXFormView12" runat="server" DataSourceID="ds" Width="100%" DataMember="InventoryDetails" SkinID="Transparent" LoadOnDemand="true">
                <Template>
                    <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
                    <px:PXTextEdit ID="edInventoryID" runat="server" Enabled="False" AlreadyLocalized="False" DataField="InventoryCD" AutoRefresh="true">
                    </px:PXTextEdit>
                </Template>
            </px:PXFormView>
            <%--<px:PXTextEdit ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryItem__InventoryCD">
            </px:PXTextEdit>--%>
            <px:PXFormView ID="PXFormView1" runat="server" DataSourceID="ds" Width="100%" DataMember="QCOrders" SkinID="Transparent" LoadOnDemand="true">
                <Template>
                    <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
                    <px:PXDateTimeEdit ID="edPostDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Width="100%" Enabled="false">
                    </px:PXDateTimeEdit>
                    <px:PXTextEdit ID="edPostDescription" runat="server" AlreadyLocalized="False" DataField="TranDescription">
                    </px:PXTextEdit>
                    <px:PXLayoutRule runat="server" StartColumn="True">
                    </px:PXLayoutRule>
                    <px:PXDropDown ID="edTransferType" runat="server" DataField="TranType" Width="300px">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edRefDocumentNbr" runat="server" AlreadyLocalized="False" DataField="QCOrderCD" Enabled="false">
                    </px:PXTextEdit>
                </Template>
            </px:PXFormView>
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXSplitContainer ID="PXSplitContainer2" runat="server" SkinID="Horizontal" SplitterPosition="250" Height="600px" Panel1MinSize="315" Panel2MinSize="315">
        <AutoSize Enabled="true" MinHeight="500" />
        <Template1>
            <px:PXSplitContainer ID="PXSplitContainer3" runat="server" SkinID="vertical" SplitterPosition="1000" FixedPanel="None" Height="600px" Panel1MinSize="100" Panel2MinSize="100">
                <AutoSize Enabled="true" MinHeight="300" />
                <Template1>
                    <px:PXGrid Caption="Disposition Details" CaptionVisible="true" ID="PXGridInventoryPlan" OnRowDataBound="grid_RowDataBound" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="Inquire" SyncPosition="true" AutoAdjustColumns="true">
                        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="gridAcceptedTransfers,gridRejectedTransfers,gridScrappedTransfers,gridNCTransfers,gridDestructive,PXGridLotStatus"></Behavior>
                        </AutoCallBack>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="QCOrderLotDetailID" DataMember="QCOrderDetails">
                                <Columns>
                                    <px:PXGridColumn DataField="LotSerNumVal" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Status" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="INSite__SiteCD" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="INLocation__LocationCD" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestQTY" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BaseUOM" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AcceptedQTY" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RejectedQTY" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RejectionCode" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ScappedQTY" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ScrapCode" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DestructiveQTY" Width="180px">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="NCQTY" Width="180px">
                         </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="ActualResult" Width="180px">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="FinalResult" Width="180px">
                         </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="Remarks" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                          <ActionBar>
    <CustomItems>
      <px:PXToolBarButton Key="cmdQCOrderLotAttributeSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributes" /></CustomItems></ActionBar>
                    </px:PXGrid>
                </Template1>
                <Template2>
                    <px:PXGrid Caption="Lot Details" CaptionVisible="true" ID="PXGridLotStatus" runat="server" DataSourceID="ds" Width="99%" Height="100%" SkinID="Inquire" SyncPosition="true" AutoAdjustColumns="true">

                        <Levels>
                            <px:PXGridLevel DataKeyNames="InventoryID,LotSerialNbr,SiteID,LocationID" DataMember="QCOrderLotStatus">
                                <RowTemplate>
                                    <%--<px:PXSelector ID="edInventoryIDLot" runat="server" DataField="InventoryID" Enabled="false"></px:PXSelector>--%>
                                    <%-- <px:PXCheckBox ID="edSelectedLot" runat="server" AlreadyLocalized="False" DataField="Selected" Text="Check">
                                    </px:PXCheckBox>--%>
                                    <px:PXSelector ID="edLotSerialNbrLot" runat="server" DataField="LotSerialNbr" Enabled="false"></px:PXSelector>
                                    <px:PXSelector ID="edSiteIDLot" runat="server" DataField="SiteID" Enabled="false"></px:PXSelector>
                                    <px:PXSelector ID="edLocationIDLot" runat="server" DataField="LocationID" Enabled="false"></px:PXSelector>
                                    <px:PXSelector ID="edQtyAvailLot" runat="server" DataField="QtyAvail" Enabled="false"></px:PXSelector>
                                    <px:PXNumberEdit ID="edAcceptedQtyLot" runat="server" DataField="AcceptedQty"></px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edRejectedQtyLot" runat="server" DataField="RejectedQty"></px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edScrappedQty" runat="server" DataField="ScappedQTY"></px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edDestructiveQty" runat="server" DataField="DestructiveQty"></px:PXNumberEdit>
                                    <%--<px:PXDateTimeEdit ID="edExpireDateLot" runat="server" AlreadyLocalized="False" DataField="ExpireDate" Width="100%" Enabled="false"></px:PXDateTimeEdit>--%>
                                </RowTemplate>
                                <Columns>
                                    <%--<px:PXGridColumn DataField="InventoryID" Width="180px">
                                 </px:PXGridColumn>--%>
                                    <%--<px:PXGridColumn DataField="Selected" Type="CheckBox" CommitChanges="True" AllowCheckAll="True" AllowSort="False" AllowMove="False" TextAlign="Center" AllowResize="False" />--%>
                                    <px:PXGridColumn DataField="LotSerialNbr" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SiteID" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LocationID" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="QtyAvail" Width="80px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AcceptedQty" Width="80px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RejectedQty" Width="80px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ScappedQTY" Width="80px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DestructiveQty" Width="80px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <%--<px:PXGridColumn DataField="ExpireDate" Width="80px">
                                 </px:PXGridColumn>--%>
                                </Columns>
                                <Mode AllowAddNew="false" AllowDelete="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />

                    </px:PXGrid>
                </Template2>
            </px:PXSplitContainer>
        </Template1>

        <Template2>
            <px:PXTab ID="distributionTab" runat="server" Height="100%" Width="100%">

                <Items>
                    <px:PXTabItem Text="Accepted Item">
                        <Template>
                            <px:PXGrid ID="gridAcceptedTransfers" SkinID="Details" runat="server" Width="100%" Height="100%" AutoAdjustColumns="True" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="PXGridLotStatus"></Behavior>
                                </AutoCallBack>
                                <Levels>
                                    <px:PXGridLevel DataMember="AcceptedQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="FromWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="FromLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edFromWarehouseIDw" runat="server" DataField="FromWarehouseID" Enabled="false" />
                                            <px:PXSelector ID="edFromLocationIDw" runat="server" DataField="FromLocationID" Enabled="false" />
                                            <px:PXSelector ID="edToWarehouseIDw" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationIDw" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty2w" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCodew" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescriptionw" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                          <px:PXToolBarButton Key="cmdQCOrderLotAttributeTestSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributestest" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="AcceptedQtyTab"></AutoCallBack>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Rejected Item">
                        <Template>

                            <px:PXGrid ID="gridRejectedTransfers" SkinID="Details" runat="server" AutoAdjustColumns="True" Width="100%" Height="100%" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="PXGridLotStatus"></Behavior>
                                </AutoCallBack>
                                <Levels>
                                    <px:PXGridLevel DataMember="RejectedQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="FromWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="FromLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edFromWarehouseID1" runat="server" DataField="FromWarehouseID" Enabled="false" />
                                            <px:PXSelector ID="edFromLocationID1" runat="server" DataField="FromLocationID" Enabled="false" />
                                            <px:PXSelector ID="edToWarehouseID1" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID1" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty21" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode1" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription1" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                          <px:PXToolBarButton Key="cmdQCOrderLotAttributeTestSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributestest" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="RejectedQtyTab"></AutoCallBack>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Scrapped Item">
                        <Template>
                            <px:PXGrid ID="gridScrappedTransfers" SkinID="Details" runat="server" Width="100%" Height="100%" AutoAdjustColumns="True" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="PXGridLotStatus"></Behavior>
                                </AutoCallBack>
                                <Levels>
                                    <px:PXGridLevel DataMember="ScrappedQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="FromWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="FromLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edFromWarehouseID3" runat="server" DataField="FromWarehouseID" Enabled="false" />
                                            <px:PXSelector ID="edFromLocationID3" runat="server" DataField="FromLocationID" Enabled="false" />
                                            <px:PXSelector ID="edToWarehouseID3" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID3" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty23" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode3" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription3" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                          <px:PXToolBarButton Key="cmdQCOrderLotAttributeTestSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributestest" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="ScrappedQtyTab"></AutoCallBack>
                    </px:PXTabItem>

                    <px:PXTabItem Text="Destructive Item">
                        <Template>

                            <px:PXGrid ID="gridDestructive" SkinID="Details" runat="server" AutoAdjustColumns="True" Width="100%" Height="100%" DataSourceID="ds" AllowPaging="true" PageSize="5" SyncPosition="True">
                                <AutoSize Enabled="true" />
                                <Mode InitNewRow="True"></Mode>
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="PXGridLotStatus"></Behavior>
                                </AutoCallBack>
                                <Levels>
                                    <px:PXGridLevel DataMember="DestructiveQTYInventoryDistribution">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                            <px:PXGridColumn DataField="FromWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="FromLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="ToLocationID" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__BaseUOM" Width="108px" />
                                            <px:PXGridColumn DataField="ReasonCode" Width="108px" CommitChanges="true" />
                                            <px:PXGridColumn DataField="Description" Width="108px" CommitChanges="true" />
                                        </Columns>
                                        <RowTemplate>
                                            <px:PXSelector ID="edFromWarehouseID4" runat="server" DataField="FromWarehouseID" Enabled="false" />
                                            <px:PXSelector ID="edFromLocationID4" runat="server" DataField="FromLocationID" Enabled="false" />
                                            <px:PXSelector ID="edToWarehouseID4" runat="server" DataField="ToWarehouseID" />
                                            <px:PXSelector ID="edToLocationID4" runat="server" DataField="ToLocationID" />
                                            <px:PXNumberEdit ID="edQty4" runat="server" DataField="Qty" />
                                            <px:PXSelector ID="edReasonCode4" runat="server" DataField="ReasonCode" />
                                            <px:PXTextEdit ID="eddescription4" runat="server" AlreadyLocalized="False" DataField="Description" />
                                        </RowTemplate>

                                    </px:PXGridLevel>
                                </Levels>
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                          <px:PXToolBarButton Key="cmdQCOrderLotAttributeTestSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributestest" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="ds" Command="DestructiveQtyTab"></AutoCallBack>
                    </px:PXTabItem>
                    <%--  <px:PXTabItem Text="NC Item">
                     <Template>
                         <px:PXGrid ID="gridNCTransfers" SkinID="Details" runat="server" Width="100%" AutoAdjustColumns="True" DataSourceID="ds" SyncPosition="True">
                             <AutoSize Enabled="true" />
                             <Levels>
                                 <px:PXGridLevel DataMember="NCQTYInventoryDistribution">
                                     <Columns>
                                         <px:PXGridColumn DataField="SamplingSerailNum" Width="108px" />
                                         <px:PXGridColumn DataField="ToWarehouseID" Width="108px" CommitChanges="true" />
                                         <px:PXGridColumn DataField="ToLocationID" Width="108px" />
                                         <px:PXGridColumn DataField="Qty" Width="108px" CommitChanges="true" />
                                         <px:PXGridColumn DataField="ReasonCode" Width="108px" />
                                         <px:PXGridColumn DataField="Description" Width="108px" />
                                     </Columns>
                                     <RowTemplate>
                                         <px:PXSelector ID="edToWarehouseID4" runat="server" DataField="ToWarehouseID" />
                                         <px:PXSelector ID="edToLocationID4" runat="server" DataField="ToLocationID" />
                                         <px:PXNumberEdit ID="edQty42" runat="server" DataField="Qty" />
                                         <px:PXSelector ID="edReasonCode4" runat="server" DataField="ReasonCode" />
                                         <px:PXTextEdit ID="eddescription4" runat="server" AlreadyLocalized="False" DataField="Description" />
                                     </RowTemplate>
                                     <Layout ColumnsMenu="False" />
                                 </px:PXGridLevel>
                             </Levels>
                         </px:PXGrid>
                     </Template>
                     <AutoCallBack Target="ds" Command="NCQtyTab"></AutoCallBack>
                 </px:PXTabItem>--%>
                </Items>
            </px:PXTab>

        </Template2>
    </px:PXSplitContainer>
    <px:PXSmartPanel ID="PanelAddNCLine" runat="server" Height="500px" Width="1000px" Caption="Add Line Details" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="QCOrderLotDetailsSmartPanel" Style="position: static"
        AutoCallBack-Target="AddLine Grid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXLabel ID="edAccepted" Style="position: absolute; margin-left: 35%; margin-top: 2%; z-index: 9999;" runat="server" Text="Accepted"></px:PXLabel>
        <px:PXLabel ID="edRejected" Style="position: absolute; margin-left: 53%; margin-top: 2%; z-index: 9999;" runat="server" Text="Rejected"></px:PXLabel>
        <px:PXLabel ID="edScrapped" Style="position: absolute; margin-left: 70%; margin-top: 2%; z-index: 9999;" runat="server" Text="Scrapped"></px:PXLabel>
        <px:PXLabel ID="edDestructive" Style="position: absolute; margin-left: 87%; margin-top: 2%; z-index: 9999;" runat="server" Text="Destructive"></px:PXLabel>
        <px:PXGrid ID="gridOL" runat="server" DataSourceID="ds" SkinID="Inquire" AutoAdjustColumns="true" AllowPaging="false" PageSize="10"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="QCOrderLotDetailsSmartPanel">
                    <Columns>
                        <px:PXGridColumn DataField="SerialNumber">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheckrejected" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheckscrapped" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheckdestructive" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel13" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton4" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitSerialNo" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="PXButton5" runat="server" DialogResult="No" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel runat="server" ID="PanelAttributes" DesignView="Content" Height="500px" Width="1100px" LoadOnDemand="true" AutoReload="true" CaptionVisible="true" Caption="Attributes" Key="LotSerialAttributes" AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" Style='Position:static;'>
    <px:PXGrid runat="server" ID="PXGridAttributeValues" Height="150px" SkinID="Attributes" Width="100%" Caption="Attributes" CaptionVisible="false" DataSourceID="ds">
      <Levels>
        <px:PXGridLevel DataMember="LotSerialAttributes">
          <RowTemplate>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
            <px:PXTextEdit runat="server" DataField="Value" ID="edAttributeValue" /></RowTemplate>
          <Columns>
            <px:PXGridColumn DataField="AttributeID" TextAlign="Left" Width="135px" AllowShowHide="False" />
            <px:PXGridColumn DataField="Required" Type="CheckBox" TextAlign="Center" Width="80px" />
            <px:PXGridColumn DataField="Value" Width="185px" /></Columns></px:PXGridLevel></Levels>
      <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" AllowUpload="false" /></px:PXGrid></px:PXSmartPanel>
</asp:Content>

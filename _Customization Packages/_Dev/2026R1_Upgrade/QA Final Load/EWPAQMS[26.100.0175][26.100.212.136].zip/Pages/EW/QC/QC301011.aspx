<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC301011.aspx.cs" Inherits="Page_QC301011" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCServiceQCEntry" PrimaryView="ServOrders" AttributesFound="False" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="GotoSteps" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="GotoEquation" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="SubmitFormula" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="First" PostData="Self" StartNewGroup="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Last" PostData="Self"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewTestMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewGroupMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewSeverityMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewAssignedToID" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewServOrder" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewServAppointment" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewServEquipment" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewInventory" Visible="False" CommitChanges="true" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="ServOrders" TabIndex="4900" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />           
            <px:PXSelector ID="edQCOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="true">
            </px:PXSelector>
             <px:PXDropDown ID="edQCType" runat="server" DataField="QCType" Enabled="false">
            </px:PXDropDown>
             <px:PXDropDown ID="edStatus" runat="server" DataField="Status" Enabled="false">
            </px:PXDropDown>
             <px:PXCheckBox ID="edOhHold" runat="server" DataField="OnHold" CommitChanges="true">
            </px:PXCheckBox> 
             <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" DataField="OrderDate" TimeMode="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edClosingDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Enabled="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXSelector ID="edPlanID" runat="server" DataField="PlanID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" />
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" Enabled="false">
            </px:PXTextEdit>
            <px:PXDropDown ID="edResultingCriteria" runat="server" AlreadyLocalized="False" DataField="ResultingCriteria">
            </px:PXDropDown>
            <px:PXDropDown ID="edQCResult" runat="server" AlreadyLocalized="False" DataField="QCResult">
            </px:PXDropDown>
            <px:PXNumberEdit ID="edPassTest" runat="server" AlreadyLocalized="False" DataField="PassTest" Enabled="false">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edFailedTest" runat="server" AlreadyLocalized="False" DataField="FailedTest" Enabled="false">
            </px:PXNumberEdit>
             <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M">
            </px:PXLayoutRule>  
            <px:PXTextEdit ID="edBRefDocType" runat="server" AlreadyLocalized="False" DataField="BRefDocType" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edBRefDocID" Enabled="false" runat="server" CommitChanges="true" DataField="BRefDocID">
                <LinkCommand Command="ViewServOrder" Target="ds"></LinkCommand>
            </px:PXTextEdit>
             <px:PXTextEdit ID="edBRefDocLineNbr" runat="server" AlreadyLocalized="False" DataField="BRefDocLineNbr" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edRefDocType" runat="server" AlreadyLocalized="False" DataField="RefDocType" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edRefDocNbr" runat="server" AlreadyLocalized="False" DataField="RefDocNbr" Enabled="false">
                <LinkCommand Command="ViewServAppointment" Target="ds"></LinkCommand>
            </px:PXTextEdit>
             <px:PXTextEdit ID="edLineItemType" runat="server" AlreadyLocalized="False" DataField="LineItemType" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edRefDocLineNbr" runat="server" AlreadyLocalized="False" DataField="RefDocLineNbr" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRefDocSource" runat="server" AlreadyLocalized="False" DataField="RefDocSource" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edRefDocSourceID" runat="server" AlreadyLocalized="False" DataField="RefDocSourceID" Enabled="false">
                <LinkCommand Command="ViewServEquipment" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryID" Enabled="false">
                <LinkCommand Command="ViewInventory" Target="ds"></LinkCommand>
            </px:PXTextEdit>
             <px:PXTextEdit ID="edInventoryDescr" runat="server" AlreadyLocalized="False" DataField="InventoryDescr" Enabled="false">
            </px:PXTextEdit>
            <px:PXDropDown ID="edTrackingMethod" runat="server" AlreadyLocalized="False" DataField="TrackingMethod" Enabled="false">
                </px:PXDropDown>
            <px:PXTextEdit ID="edLotSerialNbr" runat="server" AlreadyLocalized="False" DataField="LotSerialNbr" Enabled="false">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edCustomerCD" runat="server" AlreadyLocalized="False" DataField="CustomerCD" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edCustomerName" runat="server" AlreadyLocalized="False" DataField="CustomerName" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edProject" runat="server" AlreadyLocalized="False" DataField="Project" Enabled="false">
            </px:PXTextEdit>
             <px:PXTextEdit ID="edRemarks" runat="server" DataField="Remarks" TextMode="MultiLine" Height="140" Width="300" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDisposition" runat="server" AlreadyLocalized="False" DataField="Disposition" Height="140" Width="300" TextMode="MultiLine">
            </px:PXTextEdit>           
        </Template>
        <CallbackCommands>
            <Refresh CommitChanges="True" PostData="Page" />
            <Search CommitChanges="True" PostData="Page" />
        </CallbackCommands>
    </px:PXFormView>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tab" runat="server" Height="150px" Style="z-index: 100;" Width="100%">
        <Items>
            <px:PXTabItem Text="Test Results">
                <Template>
                    <px:PXGrid ID="PXGrid2" runat="server" OnRowDataBound="grid2_RowDataBound" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="QCOrderID,ServQCVariableID" DataMember="ServVariables">
                                <RowTemplate>
                                    <px:PXTextEdit ID="edSamplingSerailNum" runat="server" AlreadyLocalized="False" DataField="SamplingSerailNum">
                                    </px:PXTextEdit>
                                    <px:PXSelector ID="edAssignedToID" runat="server" DataField="AssignedToID">
                                        <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
                                    </px:PXSelector>
                                    <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="edTestValue" />
                                    <px:PXTextEdit runat="server" DataField="TestResultUOM" CommitChanges="True" ID="edTestResultUOM" />
                                    <px:PXCheckBox ID="edTested" runat="server" AlreadyLocalized="False" DataField="Tested" Text="Tested">
                                    </px:PXCheckBox>
                                    <px:PXDropDown ID="edActualResult" runat="server" DataField="ActualResult">
                                    </px:PXDropDown>
                                    <px:PXDropDown ID="edFinalResult" runat="server" DataField="FinalResult">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="PXTextEdit1" runat="server" AlreadyLocalized="False" DataField="Remarks">
                                    </px:PXTextEdit>
                                    <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports" Enabled="false">
                                    </px:PXCheckBox>
                                    <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest" Enabled="false">
                                    </px:PXCheckBox>
                                    <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="ServQCVariableID" Width="1px">
                                    </px:PXGridColumn>                                    
                                    <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__VariableCD" LinkCommand="ViewTestMaster" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestGroup__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestCategory__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestMethod__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true" LinkCommand="viewAssignedToID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ExpectedValue" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="UOM" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Equation" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Formula" Width="180px" LinkCommand="GotoEquation" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestValue" CommitChanges="true" MatrixMode="true" />
                                    <px:PXGridColumn DataField="TestResultUOM" CommitChanges="true" />
                                    <px:PXGridColumn DataField="ActualResult" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FinalResult" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Remarks" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <Mode AllowUpload="True" />
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid2" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid2" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                         <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Enabled="True"></AutoSize>
    </px:PXTab>


    <px:PXSmartPanel ID="pnlTestSteps1" runat="server" Height="500px" Width="1100px" Caption="QC Tool" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ToolSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel11" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel ID="pnlTestSteps" runat="server" Height="400px" Width="1100px" Caption="Test Steps" CaptionVisible="true" AutoReload="true" Key="TestSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="StepsGrid" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataMember="TestSteps">
                    <Columns>
                        <px:PXGridColumn DataField="Name">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="pnlEquation" runat="server" Height="500px" Width="800px" Caption="Equation" CaptionVisible="true" AutoReload="true" Key="ServOrderTestFormula" Style="position: static"
        AutoCallBack-Target="PXGridEquation" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="PXGridEquation" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataKeyNames="TestFormulaID" DataMember="ServOrderTestFormula">
                    <RowTemplate>
                        <px:PXTextEdit ID="edParameter" runat="server" AlreadyLocalized="False" DataField="ParameterName" Enabled="false" Width="600px">
                        </px:PXTextEdit>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ParameterName">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="FormulaValue">
                        </px:PXGridColumn>

                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel10" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton2" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitFormula" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnInvCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>

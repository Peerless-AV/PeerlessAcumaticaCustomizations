<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC201001.aspx.cs" Inherits="Page_QC201001" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="AssociateInspection" suspendunloading="False" attributesfound="False" enableattributes="true" typename="EW.QC.EWQCAssociateInspectionPlanMaint">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewInspectionPlan" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewTestMaster" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewSeverityMaster" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewEquipmentMaster" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewCheckListItem" Visible="false" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="AddQCTool" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>            
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">

    <px:pxformview id="form" runat="server" datamember="AssociateInspection" datasourceid="ds" style="z-index: 100" width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>


            <px:PXLayoutRule runat="server" StartColumn="true" />

            <px:PXDropDown ID="edSource" Enabled="true" runat="server" DataField="DocType" Width="180px">
            </px:PXDropDown>

        </Template>
    </px:pxformview>

    <px:pxtab id="tabParent" runat="server" width="100%" height="100%" datasourceid="ds">
         <AutoSize Enabled="True" Container="Window" MinHeight="150" />
        <Items>
            <px:PXTabItem Text="Plans">
                <Template>
                    <px:PXGrid ID="gridInspectionPlan" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" NoteIndicator="true" FilesIndicator="true" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="PlanID,DocType" DataMember="AssociateInspectionPlan">
                                <RowTemplate>
                                    <px:PXSelector ID="edPlanID" runat="server" DataField="PlanID">
                                         <GridProperties FastFilterFields="InspectionPlanCD,Name,RevisionNo" ></GridProperties>
                                    </px:PXSelector>
                                   
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="PlanID" Width="180px" LinkCommand="ViewInspectionPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                   
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                    <Behavior RepaintControlsIDs="gridInspectionPlanVariables"></Behavior>
                </AutoCallBack>
                        <AutoSize Enabled="True" />
                        
                    </px:PXGrid>
                    <px:PXGrid ID="gridInspectionPlanVariables" Caption="Tests" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="AssociateInspectionPlanID" DataMember="AssociateInspectionPlanVariables">
                                <RowTemplate>
                                    <px:PXSelector ID="edVariableID" runat="server" DataField="VariableID" CommitChanges="true"  AllowEdit=" true">
                                         <GridProperties FastFilterFields="VariableCD,Name" ></GridProperties>
                                    </px:PXSelector>
                                     <px:PXSelector ID="edToolgauge" runat="server" DataField="ToolGaugeID" CommitChanges="true">
                                          <GridProperties FastFilterFields="ToolGaugeCD,Description" ></GridProperties>
                                    </px:PXSelector>
                                    <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                                    </px:PXTextEdit>
                                     <px:PXTextEdit ID="edEquation" runat="server" DataField="Equation" Width="180px" AlreadyLocalized="False" CommitChanges="true"/>
                                    <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="Go/NoGo">
                                    </px:PXCheckBox>
                                     <px:PXDropDown ID="edQCOperator" runat="server" AlreadyLocalized="False" DataField="QCOperator">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edComboValue" runat="server" AlreadyLocalized="False" DataField="ComboValue">
                                    </px:PXTextEdit>
                                  <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                                    </px:PXDropDown>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="VariableID"  Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>
                                   
                                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="100px">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__TestCategoryID" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__TestMethodID" Width="100px">
                                    </px:PXGridColumn>
                                    <%--<px:PXGridColumn DataField="ToolGaugeID" LinkCommand="ViewEquipmentMaster" Width="100px">
                                    </px:PXGridColumn>--%>
                                     <%--<px:PXGridColumn DataField="ToolSteps" Width="180px" CommitChanges="true" LinkCommand="GotoToolInspectionSteps" />--%>
                                     <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolInspectionSteps" CommitChanges="true">
                                      </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestGroupID" Width="180" />
                                                    <px:PXGridColumn DataField="QCOperator" CommitChanges="true">
                                    </px:PXGridColumn>              
                                    <px:PXGridColumn DataField="NumMinValue" Width="100" />                                    
                                    <px:PXGridColumn DataField="NumMaxValue" Width="100" />
                                     <px:PXGridColumn DataField="EWQCVariable__Equation" Width="180px">
                                    </px:PXGridColumn>
                                   <px:PXGridColumn DataField="TestResultUOM" Width="220px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="70px">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="OrderLevel" CommitChanges ="true" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AlphaValue" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Unit" Width="70px">
                                    </px:PXGridColumn>
                                    
                                    <px:PXGridColumn DataField="LineNbr" Width="50px" />
                                      <px:PXGridColumn DataField="ComboValue" Width="280px" LinkCommand="addInspectionCombo" CommitChanges ="true">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                        <ActionBar ActionsText="False">
                             <CustomItems>
                                <px:PXToolBarButton Text="QCTool" PopupPanel="AttributePanel" Visible="false" Enabled="True">
                                      <AutoCallBack Command="AddQCTool" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="gridInspectionPlanVariables" Command="Refresh">
                    <Behavior RepaintControlsIDs="gridInspectionPlanVariables" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Checklist Group">
                <Template>
                    <px:PXGrid ID="gridChecklistGroup" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" NoteIndicator="true" FilesIndicator="true" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="ChecklistGroupID,DocType" DataMember="AssociateChecklistGroup">
                                <RowTemplate>
                                    <px:PXSelector ID="edChecklistGroupID" runat="server" DataField="ChecklistGroupID">
                                        
 <GridProperties FastFilterFields="Description" ></GridProperties>
                                    </px:PXSelector>
                                   
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="ChecklistGroupID" Width="180px" LinkCommand="ViewChecklistGroup" CommitChanges="true">
                                    </px:PXGridColumn>
                                   
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                         <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                    <Behavior RepaintControlsIDs="gridChecklist"></Behavior>
                </AutoCallBack>
                    </px:PXGrid>
                    <px:PXGrid ID="gridChecklist" Caption="CheckList" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" NoteIndicator="true" FilesIndicator="true" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="AssociateChecklistGroupID" DataMember="AssociateChecklistGroupVariable">
                                <RowTemplate>
                                    <px:PXSelector ID="edChecklistID" runat="server" DataField="ChecklistID" CommitChanges="True">
                                         <GridProperties FastFilterFields="Name,Description" ></GridProperties>
                                    </px:PXSelector>

                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="ChecklistID" LinkCommand="ViewCheckListItem" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCChecklist__Name">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCChecklist__Description">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="gridChecklist" Command="Refresh">
                    <Behavior RepaintControlsIDs="gridChecklist" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>

    </px:pxtab>



    <px:pxsmartpanel id="AttributePanel" runat="server" width="720px" height="360px" key="ToolInspectionSteps" caption="Tools" captionvisible="True"
        autocallback-command="Refresh" autocallback-target="AttributesGrid" designview="Content">
        <px:PXGrid ID="AttributesGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="ToolInspectionSteps">
                    <Columns>
                        
                                    <px:PXGridColumn DataField="ToolGaugeID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn> 
                    </Columns>                   
                </px:PXGridLevel>                
            </Levels>  
             <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
        </px:PXGrid>         
        <px:PXPanel ID="AttributeButtonPanel" runat="server" SkinID="Buttons">
             <px:PXButton ID="AttributeSaveButton" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
            <px:PXButton ID="AttributeCancelButton" runat="server" DialogResult="Cancel" Text="Cancel"></px:PXButton> 
        </px:PXPanel>
    </px:pxsmartpanel>




    <px:pxsmartpanel id="ComboBoxPanel" runat="server" width="720px" height="360px" key="TestInspectionComboValues" caption="Combo Values" captionvisible="True"
        autocallback-command="Refresh" autocallback-target="ComboBoxGrid" designview="Content">
        <px:PXGrid ID="ComboBoxGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="TestInspectionComboValues">
                    <Columns>
                        <px:PXGridColumn DataField="TestComboCD">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ComboCheck" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn> 
                    </Columns>                   
                </px:PXGridLevel>                
            </Levels>  
             <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
        </px:PXGrid>         
        <px:PXPanel ID="ComboButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="ComboInspectionSaveButton" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="ComboInspectionSaveButton" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="ComboCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">              
            </px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>

     
</asp:Content>


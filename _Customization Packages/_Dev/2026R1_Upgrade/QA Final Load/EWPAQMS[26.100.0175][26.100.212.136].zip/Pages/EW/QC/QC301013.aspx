<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301013.aspx.cs" Inherits="Page_QC301013" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="true" TypeName="EW.QC.EWQCChkListOrderEntry" PrimaryView="ChkListOrderEntry" AttributesFound="false" EnableAttributes="true" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewServAppointment" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewServEquipment" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewInventory" Visible="False" CommitChanges="true" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="ChkListOrderEntry" TabIndex="4900" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="true" LabelsWidth="M" ControlSize="M" />
            <px:PXSelector ID="edQCChkListOrderCD" runat="server" DataField="QCChkListOrderCD" CommitChanges="true">
            </px:PXSelector>
            <px:PXDropDown ID="edCheckListType" runat="server" AlreadyLocalized="False" DataField="CheckListType" Enabled="false">
            </px:PXDropDown>
            <px:PXDropDown ID="edStatus" Enabled="false" ReadOnly="true" runat="server" DataField="Status">
            </px:PXDropDown>
            <px:PXCheckBox ID="edOhHold" runat="server" DataField="OnHold" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" DataField="OrderDate" Width="100%" Enabled="false" TimeMode="false">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edClosingDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Enabled="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edRefDocument" runat="server" AlreadyLocalized="False" DataField="RefDocument" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRefDocumentNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentNbr" Enabled="false">
                <LinkCommand Command="ViewServAppointment" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRefDocumentLineNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentLineNbr" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRefDocumentSrc" runat="server" AlreadyLocalized="False" DataField="RefDocumentSrc" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRefDocumentID" runat="server" AlreadyLocalized="False" DataField="RefDocumentID" Enabled="false">
                <LinkCommand Command="ViewServEquipment" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryID" Enabled="false">
                <LinkCommand Command="ViewInventory" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edCustomerCD" runat="server" AlreadyLocalized="False" DataField="CustomerCD" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edCustomerName" runat="server" AlreadyLocalized="False" DataField="CustomerName" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edProject" runat="server" AlreadyLocalized="False" DataField="Project" Enabled="false">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRemarks" runat="server" AlreadyLocalized="False" DataField="Remarks" TextMode="MultiLine" Height="110" Width="300">
            </px:PXTextEdit>
        </Template>
    </px:PXFormView>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tabParent" runat="server" Width="100%" Height="100%" DataSourceID="ds">
        <Items>
            <px:PXTabItem Text="CheckList Group">
                <Template>
                    <px:PXSplitContainer runat="server" Orientation="Horizontal" Panel1MinSize="200" Panel2MinSize="100" SplitterPosition="40" PositionInPercent="True" ID="splitConditions">
                        <AutoSize Container="Window" Enabled="true" />
                        <Template1>
                            <px:PXGrid runat="server" DataSourceID="ds" ID="PXGridCheckList" Caption="Checklist" SkinID="DetailsInTab" TabIndex="27364" Width="100%" Height="100%" NoteIndicator="true" FilesIndicator="true" SyncPosition="true">
                                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                                    AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                    ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                    FilteredAddMessage="No records found.
Try to change filter to see records here."
                                    FilteredMessage="No records found.
Try to change filter to see records here."
                                    NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                    NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                    NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                                    NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                                <Levels>
                                    <px:PXGridLevel DataMember="ChkListOrderChkList" DataKeyNames="QCChkListOrderChkListID">
                                        <Columns>
                                            <px:PXGridColumn DataField="EWQCChecklistGroup__ChecklistGroupCD" LinkCommand="ViewChecklistGroup" Width="150px"></px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCChecklistGroup__Description" Width="200px"></px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCChecklist__ChecklistCD" LinkCommand="ViewCheckListItem" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCChecklist__Name" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCChecklist__Description" Width="250px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Completed" TextAlign="Center" Type="CheckBox" Width="90px" CommitChanges="true">
                                            </px:PXGridColumn>
                                             <px:PXGridColumn DataField="Executedby" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedDate" Width="150px">
                                            </px:PXGridColumn>                                           
                                            <px:PXGridColumn DataField="Remarks" Width="250px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" Container="Window" />
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="TaskGrid"></Behavior>
                                </AutoCallBack>
                            </px:PXGrid>
                        </Template1>
                        <Template2>
                            <px:PXGrid ID="TaskGrid" runat="server" Caption="Tasks" DataSourceID="ds" SkinID="DetailsInTab"
                                Width="100%" Height="100%">
                                <Levels>
                                    <px:PXGridLevel DataMember="ChkListOrderChkListTask">
                                        <Columns>
                                            <px:PXGridColumn DataField="Name" Width="300px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Description" Width="400px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Completed" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="90px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedDate" Width="200px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Executedby" Width="200px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Remark" Width="350px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                                <AutoSize Enabled="True" Container="Window" />
                            </px:PXGrid>
                        </Template2>
                    </px:PXSplitContainer>
                </Template>
                <AutoCallBack Target="PXGridCheckList" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGridCheckList, TaskGrid" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" Width="240px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>
</asp:Content>





<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC504900.aspx.cs" Inherits="Page_QC504900" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="SamplingPlan"
        typename="EW.QC.EWQCSamplingPlanDetailProcess">
        <CallbackCommands>           
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="SamplingPlan" tabindex="3700" bpeventsindicator="True">
        <Template>           
        </Template>
    </px:pxformview>

    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" adjustpagesize="Auto" syncposition="true" datasourceid="ds" skinid="Primary">
        <Levels>
            <px:PXGridLevel DataMember="SamplingPlan" DataKeyNames="SamplingPlanID">
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SamplingPlanCD" Width="150px" />
                    <px:PXGridColumn DataField="RevisionNo" Width="150px" />
                    <px:PXGridColumn DataField="Name" Width="150px" />
                    <px:PXGridColumn DataField="Description" Width="150px" />
                    <px:PXGridColumn DataField="Status" Width="150px" />
                    <px:PXGridColumn DataField="DisplayPlanCD" Width="150px" />
                    <px:PXGridColumn DataField="SamplingMethodType" Width="150px" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>

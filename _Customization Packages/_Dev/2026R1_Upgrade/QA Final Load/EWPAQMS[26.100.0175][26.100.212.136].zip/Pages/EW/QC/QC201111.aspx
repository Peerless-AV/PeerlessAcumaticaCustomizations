﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC201111.aspx.cs" Inherits="Page_QC201111" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="EWQCBubblesDocuments" typename="EW.QC.EWQCBubbleAttributesMaint">
        <CallbackCommands>

<%--            <px:PXDSCallbackCommand Name="CreateLotLabels" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="PrintLot" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>--%>
            <px:PXDSCallbackCommand Name="EWQCAddUpdateQCTest" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="EWQCAddBubbleTest" Visible="False" CommitChanges="True" RepaintControls="All" DependOnGrid="QCAttributesDetailsGrid" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">

        <style>
        
body {
  font-family: "Segoe UI", Roboto, sans-serif;
  background: #f4f6f9;
}

#canvasContainer {
  display: flex;
  gap: 20px;
  padding: 20px;
}

/* LEFT PANEL */
.CanvasWithFileInput {
  flex: 1;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  padding: 16px;
}

/* TOOLBAR */
.toolbar {
  display: flex;
 justify-content: flex-end;
  /*justify-content: flex-start;*/ /* LEFT */
  margin-bottom: 12px;
}

.upload-btn {
  background: linear-gradient(135deg, #4f46e5, #6366f1);
  color: #fff;
  padding: 10px 16px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: transform 0.2s, box-shadow 0.2s;
}

.upload-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 6px 14px rgba(79, 70, 229, 0.3);
}

.upload-btn input {
  display: none;
}

/* CANVAS */
#canvas_cont {
  border: 2px dashed #c7c9d3;
  border-radius: 10px;
  background: #fafafa;
  padding: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* RIGHT TOOLBOX */
.img_cont {
  width: 160px;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
  padding: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.tool-title {
  margin-bottom: 10px;
  font-size: 14px;
  font-weight: 600;
  color: #374151;
}

/* ICONS */
.img,
.imgRectangle {
  width: 50px;
  height: auto;
  margin: 10px 0;
  cursor: grab;
  padding: 6px;
  border-radius: 8px;
  transition: background 0.2s, transform 0.2s;
}

.img:hover,
.imgRectangle:hover {
  background: #eef2ff;
  transform: scale(1.05);
}

.img:active,
.imgRectangle:active {
  cursor: grabbing;
}

.upload-btn {
  position: relative; /* REQUIRED for tooltip positioning */
  background: linear-gradient(135deg, #4f46e5, #6366f1);
  color: #fff;
  padding: 10px 16px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: transform 0.2s, box-shadow 0.2s;
}

.upload-btn .tooltip {
  position: absolute;
  bottom: 120%;
  left: 50%;
  transform: translateX(-50%);
  background: #111827;
  color: #fff;
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 12px;
  white-space: nowrap;
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition: opacity 0.2s ease;
  z-index: 10;
}

/* Tooltip arrow */
.upload-btn .tooltip::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  transform: translateX(-50%);
  border-width: 5px;
  border-style: solid;
  border-color: #111827 transparent transparent transparent;
}

/* SHOW tooltip on hover */
.upload-btn:hover .tooltip {
  opacity: 1;
  visibility: visible;
}



     </style>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <%-- <script src="https://cdn.jsdelivr.net/npm/fabric@latest/dist/index.min.js"></script>--%>
    <%--<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>--%>
<%-- <script src="~/JS/fabric551.min.js"></script>--%>
   <%-- <script src="https://cdn.jsdelivr.net/npm/fabric@5.5.2/dist/fabric.min.js"></script>--%>

     <script src="https://cdn.jsdelivr.net/npm/fabric@latest/dist/index.min.js"></script>
  

    <script type="text/javascript">


        // allowDrop function called on ondragover event.
        function allowDrop(e) {
            e.preventDefault();
        }

        //dragElement function called on ondrag event.
        function dragElement(e) {
            e.dataTransfer.setData("id", e.target.id); //transfer the "data" i.e. id of the target dragged.
            
        }

     
        //Initializing fabric canvas on window load event.
       // var canvas;
        var canvas = new fabric.Canvas('canvas');
        var canvasWrapper;
        var canvasContainer;
        var descText;
        var iText;
        var arrows = [];
        var fileInput;

        window.onload = setTimeout(LoadCanvas, 3000); 
        
        function LoadCanvas() {
            showLoader();
            setTimeout(() => {
                LoadCanvasImage();
                //HIDE LOADER AFTER FUNCTION EXECUTES
                hideLoader();

            }, 4000);

        }

        //setTimeout(LoadCanvasImage, 3000);

        //Initialize file input control
        function setCanvasImage() {
            //canvasWrapper = document.getElementById('canvas_cont');
            fileInput = document.getElementById('fileInput');
            fileInput.addEventListener('change', (event) => {
               // debugger;
                //canvas.dispose();
                //const canvasobj = document.getElementById('canvas');
                var c = document.getElementById('canvas');
                var ctx = c.getContext('2d');
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    //on file chnage draw canvas background image
                    reader.onload = (e) => {
                        var img = new Image();
                        img.onload = () => {
                            // Clear the canvas
                            //ctx.clearRect(0, 0, canvas.width, canvas.height);
                            // Draw the image on the canvas
                            //ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                            showLoader();
                            setTimeout(() => {
                                setCanvasBackGroundImage();

                                //HIDE LOADER AFTER FUNCTION EXECUTES
                                hideLoader();

                            }, 8000);
                            //setTimeout(setCanvasBackGroundImage, 8000)
                        };
                        img.src = e.target.result;
                       // debugger;
                        //setTimeout(convertToImage, 300)
                        //Save Image on database
                        var ds = px_alls['ds'];
                        ds.executeCallback('SaveFinalImage', e.target.result);
                        //debugger;
                        //Load Image in canvas from database
                       /* setTimeout(setCanvasBackGroundImage, 1500)*/
                    };

                    //Render canvas
                    reader.readAsDataURL(file);
                    canvas.renderAll();
                    //convertToImage();

                }
            });

        }

     
        function LoadCanvasImage() {
            canvasWrapper = document.getElementById('canvas_cont');
            canvasContainer = document.getElementById('canvas');
            // const fileInput = document.getElementById('fileInput');

            debugger;
            var ImageExits;
            var imageUrl;
            ImageExits = document.getElementById("ctl00_phF_form_edAllAttributesvalue").value;
            //Load image from datbase if already have image in database
            if (ImageExits != null && ImageExits != "") {
                canvas = new fabric.Canvas('canvas');
                var canvasJsonObj = JSON.parse(ImageExits)
                canvas.loadFromJSON(canvasJsonObj, function () {
                    // Callback function executes after loading is complete
                    // canvas.renderAll();

                    showLoader();
                    setTimeout(() => {
                        // Callback function executes after loading is complete
                        canvas.renderAll();
                      

                        if (typeof canvas !== 'undefined' && typeof canvas._objects !== 'undefined' && canvas._objects.length > 0 && arrows.length < 1) {
                            var canvasObjLength = canvas._objects.length;

                            for (var i = 0; i < canvasObjLength; i++) {
                               
                                var AtributeID = canvas._objects[i]._objects[1].text;
                                let AtributeIDNum = parseInt(AtributeID, 10);

                                //push Existing  object in javascript array
                                arrows.push({ AttributesID: AtributeIDNum, AttributesName: "", url: "", AttributesValue: "" });

                            }
                        }
                        //HIDE LOADER AFTER FUNCTION EXECUTES
                        hideLoader();

                    }, 8000);
                });

            }

            //if image is not in database then create canvas without image
            else {

                var c = document.getElementById('canvas');
                canvas = new fabric.Canvas(c, {
                    originX: 'left',
                    originY: 'top',
                    width: 750,
                    height: 400,
                });
                canvas.renderAll();

            }

            //To initialize file control
            setCanvasImage();


            document.addEventListener('mousedown', function (e) {
                const canvasWrapper = canvas.wrapperEl; // .canvas-container

                if (!canvasWrapper.contains(e.target)) {
                    canvas.discardActiveObject();
                    canvas.requestRenderAll();
                }
            });

            //delete selected object on window delete key
            document.addEventListener('keydown', function (event) {

               // var canvas = new fabric.Canvas('canvas');
                //var canvasEl = canvas.getElement(); // <canvas>
                //var wrapper = canvasEl.parentElement; // .canvas-container
                //debugger;
                //if (wrapper.contains(event.target)) {
               // if (event.key === 'Delete' || event.key === 'Backspace') {
                    if (event.key === 'Delete') {
                        // Execute your JavaScript method here
                        DeleteActiveObj();
                    }
                //}
            });

        }

      
        //Canvas background image from database, habdle image scaling and centering
        function setCanvasBackGroundImage() {

            if (canvas != null) {
                canvas.dispose();
            }

            canvas = new fabric.Canvas('canvas');

            var canvasbgImage = document.getElementById("ctl00_phF_form_edAllAttributesvalue").value;

            //fabric.Image.fromURL(canvasbgImage)
            //    .then(function (img) {
            fabric.Image.fromURL(canvasbgImage, { crossOrigin: 'anonymous' })
                .then((img) => {
                    const canvasWidth = canvas.getWidth();
                    const canvasHeight = canvas.getHeight();

                    // Scale image proportionally to fit canvas
                    const scale = Math.min(
                        canvasWidth / img.width,
                        canvasHeight / img.height
                    );
                    img.scale(scale);

                    // Center the image
                    img.set({
                        originX: 'center',
                        originY: 'center',
                        left: canvasWidth / 2,
                        top: canvasHeight / 2
                    });

                    // Set as canvas background (v6+ way)
                    //canvas.setBackgroundImage(img, canvas.requestRenderAll.bind(canvas));

                    canvas.backgroundImage = img;
                    canvas.renderAll();
                })
                .catch((err) => {
                    console.error('Error loading image:', err);
                });

        }


        function dropElement(e) {
            e.preventDefault();
           
            let arrowId = 0;
          
            arrows.forEach(arrow => {
                if (arrow.AttributesID > arrowId) {
                    arrowId = arrow.AttributesID;
                }
            });

            if (typeof canvas !== 'undefined' && typeof canvas._objects !== 'undefined' && canvas._objects.length > 0 && arrows.length < 1) {
                var canvasObjLength = canvas._objects.length;
                var lastAtributeID = canvas._objects[canvasObjLength - 1]._objects[1].text;

                let lastAtributeIDNum = parseInt(lastAtributeID, 10);
                arrows.forEach(arrow => {
                    if (arrow.AttributesID > arrowId) {
                        arrowId = arrow.AttributesID;
                    }
                });

                if (lastAtributeIDNum > arrowId) {
                    arrowId = lastAtributeIDNum;
                }
            }

            console.log(arrows);
            //Attribute ID for drop object
            arrowId = arrowId + 1;
            let strText = String(arrowId);
            debugger;
            var pointer = canvas.getScenePoint(e); //canvas.getPointer(e);
            var data = e.dataTransfer.getData("id"); //receiving the id of the target dropped.
            var imag = document.getElementById(data); //getting the target image info by its id. 
            var img = new fabric.Image(imag, { //initializing the fabric image.
               // left: e.layerX - 80,  //positioning the target on exact position of mouse event drop through event.layerX,Y.
                //top: e.layerY - 40,
                left: pointer.x,
                top: pointer.y,
                originX: 'center',
                originY: 'center'
            });
            img.scaleToWidth(imag.width); //scaling the image height and width with target height and width, scaleToWidth, scaleToHeight fabric inbuilt function.  
            img.scaleToHeight(imag.height);

            console.log(img);
            //draw text in midile of image object
            //var TextImg = new fabric.IText(strText, {
            //    fontFamily: 'Arial',
            //    fontSize: 15,
            //    fill: 'red',
            //    editable: true,
            //    underline: true,
            //});
            //console.log(TextImg);
            //TextImg.set({
            //   /* left: img.left + (img.getBoundingRect().width / 2) - (TextImg.width / 2),*/
            //    left: img.left + (img.getBoundingRect().width / 4) - (TextImg.width / 2),
            //    top: img.top + (img.getBoundingRect().height / 4) - (TextImg.height / 2) - (10),
            //    height: 10,
            //    width:20,
            //    lockMovementX: true,
            //    lockMovementY: true,
            //});
            //console.log(TextImg);
            ////group image and text
            //var group = new fabric.Group([img, TextImg], {
            //    left: 10,
            //    top: 50
            //});

            var TextImg = new fabric.IText(strText, {
                fontFamily: 'Arial',
                fontSize: 15,
                fill: 'red',
                editable: true,
                underline: true,
                originX: 'center',
                originY: 'center',
                lockMovementX: true,
                lockMovementY: true
            });

            // center text inside image
            TextImg.set({
                left: img.left + (img.getBoundingRect().width / 4) - (TextImg.width / 2),
                    top: img.top + (img.getBoundingRect().height / 4) - (TextImg.height / 2) - (10),
                    height: 10,
                    width:20,
                    lockMovementX: true,
                    lockMovementY: true,
            });

            var group = new fabric.Group([img, TextImg], {
                left: pointer.x,
                top: pointer.y,
                originX: 'center',
                originY: 'center'
            });
            canvas.add(group);
            //canvas.add(img); 
            canvas.renderAll();
            
            //push drop object in javascript array
            arrows.push({ AttributesID: arrowId, AttributesName: img.cacheKey, url: imag.src, AttributesValue: arrowId + img.cacheKey });
            //openSmartPanel();
            console.log(TextImg);
            //Insert and Update drop object's value in database view
            ExecuteAction();
            console.log(arrows);
        }

        //To delete selected Object from canvas
        function DeleteActiveObj() {
            var activeObject = canvas.getActiveObject(); // Get the selected object
            if (activeObject) {
                const strArrowId = activeObject._objects[1].text;
                const numArrowId = parseInt(strArrowId, 10);
                console.log(numArrowId);
                canvas.remove(activeObject); // Remove the object from the canvas
               // debugger;

                for (let i = 0; i < arrows.length; i++) {
                    //var deleteObj = arrows[i];
                    console.log(JSON.stringify(arrows[i]));
                    var jsonStringObj = JSON.stringify(arrows[i]);
                    if (arrows[i].AttributesID == numArrowId) {

                        arrows.splice(i, 1);
                        console.log(jsonStringObj);
                        //delete selected object from database
                        var ds = px_alls['ds'];
                        ds.executeCallback('DeleteCanvasActiveobj', jsonStringObj);
                        break; // Exit loop after deletion
                    }
                }
                console.log(arrows);
                convertToImage();
            }
        }

        //To save final image of canvas with editable objects
        function convertToImage() {
           // debugger;
            //var canvasAllElements = [];
            var canvasImg = canvas.toDataURL("image/png");
            //var canvasAllObj = document.getElementById('canvas');
            var canvasAllObj = document.getElementById('canvas').getContext("2d");

            //canvasAllElements.push({ CanvasImage: canvasImg, CanvasElements: canvasAllObj});

            //var jsonCanvasElements = JSON.stringify(canvasImg);
           // debugger;
            //Seriallized and convert it on json
            var canvasCloneObj = JSON.stringify({ canvasObj: canvas.toJSON(), canvasImg: canvasImg });
           //var canvasCloneObj = JSON.stringify(canvas.toJSON());
            console.log(canvasCloneObj);
            //Save final ediatble image in database as json, deseriallze on window load
            var ds = px_alls['ds'];
            ds.executeCallback('saveAndUploadFinalImage', canvasCloneObj);
        }


        function convertToFinalImage() {
            // debugger;
            //var canvasAllElements = [];
            var canvasImg = canvas.toDataURL("image/png");
            //var canvasAllObj = document.getElementById('canvas');
            var canvasAllObj = document.getElementById('canvas').getContext("2d");

            //canvasAllElements.push({ CanvasImage: canvasImg, CanvasElements: canvasAllObj});

            //var jsonCanvasElements = JSON.stringify(canvasImg);
            // debugger;
            //Seriallized and convert it on json
            var canvasCloneObj = JSON.stringify({ canvasObj: canvas.toJSON(), canvasImg: canvasImg });
            //var canvasCloneObj = JSON.stringify(canvas.toJSON());
            console.log(canvasCloneObj);
            //Save final ediatble image in database as json, deseriallze on window load
            var ds = px_alls['ds'];
            ds.executeCallback('uploadFinalImage', canvasCloneObj);
        }

        //To save final image of canvas with editable objects In Acumatica Image controller
        //function uploadCanvasImage() {
        //    //var canvasAllElements = [];
        //    var canvasImg = canvas.toDataURL("image/png");
        //    //var canvasAllObj = document.getElementById('canvas');
        //    //var canvasAllObj = document.getElementById('canvas').getContext("2d");

        //    ////Seriallized and convert it on json
        //    //var canvasCloneObj = JSON.stringify(canvas.toJSON());
        //    //console.log(canvasCloneObj);
        //    //Save final ediatble image in database as json, deseriallze on window load
        //    var ds = px_alls['ds'];
        //    ds.executeCallback('saveAndUploadFinalImage', canvasImg);
        //}


        //To Delete final image of canvas along with Annoations

        function confirmDeleteCanvasImage() {
            // Built-in confirm dialog (OK/Cancel)
            if (confirm("Deleting this annotation image will also delete all related annotations. Do you want to continue?")) {
                deleteCanvasImage();
            } else {
                
            }
        }

        function deleteCanvasImage() {
            //var canvasAllElements = [];
            //var canvasImg = canvas.toDataURL("image/png");
            var canvasCloneObj = JSON.stringify(canvas.toJSON());

            var ctx = canvas.getContext('2d');

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            //var canvasAllObj = document.getElementById('canvas');
            //var canvasAllObj = document.getElementById('canvas').getContext("2d");

            ////Seriallized and convert it on json
            //var canvasCloneObj = JSON.stringify(canvas.toJSON());
            //console.log(canvasCloneObj);
            //Save final ediatble image in database as json, deseriallze on window load
            var ds = px_alls['ds'];
            ds.executeCallback('DeleteCanvasImage', canvasCloneObj);

          
        }


        //Insert and Update Drop Object details in database view
        function ExecuteAction() {
            //debugger;
            const jsonString = JSON.stringify(arrows);
            var ds = px_alls['ds'];
            ds.executeCallback('DropAttributes', jsonString);
            convertToImage();
        }

        function showLoader() {
            document.getElementById('annotationLoader').style.display = 'flex';
        }

        function hideLoader() {
            document.getElementById('annotationLoader').style.display = 'none';
        }

    </script>

    <px:pxformview id="form" runat="server" datasourceid="ds" datamember="EWQCBubblesDocuments" style="z-index: 100"
        width="100%" bpeventsindicator="True">
        <Template>
            <px:PXTextEdit ID="edAllAttributesvalue" runat="server" Size="XL" DataField="AllAttributesvalue" />

<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />

        </Template>

    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server" >

    <div id="annotationLoader" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.7); z-index:9999; align-items:center; justify-content:center;">
    <div>Loading...</div>
</div>

      <div id="canvasContainer">

    <div class="CanvasWithFileInput">

        <div class="toolbar">
  <label class="upload-btn">
    Upload Image
    <input type="file" id="fileInput" accept="image/*"  />
      <span class="tooltip">File size must be less than 100 KB.</span>
  </label>
</div>

          <div id="canvas_cont" ondragover="allowDrop(event)" ondrop="dropElement(event)">
        <canvas id="canvas" width="750" height="400"></canvas>
           </div>
        </div>

      <div class="img_cont">
        <img class="img" id="ele1" draggable="true" ondragstart="dragElement(event)" src='../../../Icons/arrow-OneSide.png' alt="One Line Arrow" />
        <img class="img" id="ele2" draggable="true" ondragstart="dragElement(event)" src='../../../Icons/circle.png'" alt="Circle" />
        <img class="img" id="ele3" draggable="true" ondragstart="dragElement(event)" src='../../../Icons/arrowTwoSide.png' alt="Two Line Arrow" />
        <img class="img" id="ele5" draggable="true" ondragstart="dragElement(event)" src='../../../Icons/square.png' alt="Square" />
        <img class="imgRectangle" id="ele4" draggable="true" ondragstart="dragElement(event)" src='../../../Icons/rect.png' alt="Rectangle" />        

    </div>

</div>

    <px:PXFormView 
    ID="PxformviewBtn" 
    runat="server" 
    DataSourceID="ds" 
    DataMember="EWQCBubblesDocuments"
    Width="100%"
    Style="margin-top:20px;"
    BpEventsIndicator="True">

    <Template>
        <px:PXPanel 
            ID="pnlButtons" 
            runat="server" 
            RenderStyle="Simple"
            Style="
                display:flex;
                gap:10px;
                padding:10px;
                background:#f5f7fa;
                border-radius:6px;
                align-items:center;
            ">

            <!-- Convert Image -->
            <px:PXButton 
                ID="PXButton1" 
                runat="server" 
                CommandSourceID="ds"
                Text="Save Annotation"
                Style="background:#0078d4; color:white; font-weight:600;">
                <ClientEvents Click="convertToFinalImage" />
            </px:PXButton>


            <!-- Upload Image -->
<%--            <px:PXButton 
                ID="PXButton2" 
                runat="server" 
                CommandSourceID="ds"
                Text="Upload Image"
                Style="background:#28a745; color:white; font-weight:600;">
                <ClientEvents Click="uploadCanvasImage" />
            </px:PXButton>--%>

            <!-- Delete Image -->
            <px:PXButton 
                ID="PXButton3" 
                runat="server" 
                CommandSourceID="ds"
                Text="Delete Image"
                Style="background:#dc3545; color:white; font-weight:600;">
                <ClientEvents Click="confirmDeleteCanvasImage" />
            </px:PXButton>

        </px:PXPanel>
    </Template>
</px:PXFormView>

    <px:PXTab runat="server" ID="EWQCBubblePXTab35">
	<Items>
   <px:PXTabItem Text="Annotation" RepaintOnDemand="True">
				<Template>
    <px:PXGrid runat="server" ID="QCAttributesDetailsGrid" Caption="Attributes Details" CaptionVisible="true" Style="top:10px" Height="250px" width="100%" MaxHeight="250" DataSourceID="ds" AutoAdjustColumns="true" SyncPosition="true" SkinID="Details" 
          AllowPaging="True" AdjustPageSize="Auto">
      <AutoSize Enabled="True" />
      <Mode InitNewRow="False" />
        <Mode AllowDelete="False" />
      <Levels>
        <px:PXGridLevel DataMember="EWQCInventoryAttributesDetails">
          <RowTemplate>
              <px:PXNumberEdit runat="server" ID="edAttributesID" CommitChanges="True" DataField="AttributesID" />
              <px:PXTextEdit runat="server" ID="edAttributesName" DataField="AttributesName" CommitChanges="True" />           
              <px:PXTextEdit runat="server" DataField="edAttributesValue" AlreadyLocalized="False" ID="edAttributesValue" />
              <px:PXSelector ID="edVariableID" runat="server" DataField="VariableID" CommitChanges="True" AllowEdit=" true">                
        </px:PXSelector>
          <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
 </px:PXTextEdit>
              <px:PXDropDown runat="server" ID="edQCOperator" DataField="QCOperator" />
              <px:PXNumberEdit ID="edNumMinValue" runat="server" AlreadyLocalized="False" DataField="NumMinValue">
              </px:PXNumberEdit>
              <px:PXNumberEdit ID="edNumMaxValue" runat="server" AlreadyLocalized="False" DataField="NumMaxValue">
              </px:PXNumberEdit>
              
               <px:PXTextEdit runat="server" DataField="edInventoryCD" AlreadyLocalized="False" ID="InventoryCD" />
          </RowTemplate>
          <Columns>
            <px:PXGridColumn DataField="AttributesID" TextAlign="Center" Width="80px" CommitChanges="true"/>
            <px:PXGridColumn DataField="AttributesName" Width="120px" CommitChanges="true" />
            <px:PXGridColumn DataField="AttributesValue" Width="120px" />
            <px:PXGridColumn DataField="VariableID" CommitChanges="true" />
            <px:PXGridColumn DataField="Name" CommitChanges="true" />
             <px:PXGridColumn DataField="DataType" CommitChanges="true" />
             <px:PXGridColumn DataField="TestResultUOM" Width="220px"/>
            <px:PXGridColumn DataField="QCOperator" Width="100" CommitChanges="True" />
            <px:PXGridColumn DataField="NumMinValue" Width="100px" CommitChanges="true">
            </px:PXGridColumn>
            <px:PXGridColumn DataField="NumMaxValue" Width="100px" CommitChanges="true">
            </px:PXGridColumn>                       
               <px:PXGridColumn DataField="RefNbr" Width="120px" />

          </Columns></px:PXGridLevel></Levels>

        <ActionBar ActionsText="False">
    <CustomItems>
	<px:PXToolBarButton Text="Attach QC plan">
		<AutoCallBack Target="ds" Command="EWQCAddBubbleTest">
			<Behavior CommitChanges="True" PostData="Page" /></AutoCallBack></px:PXToolBarButton></CustomItems>
</ActionBar>
</px:PXGrid></Template></px:PXTabItem>

        <px:PXTabItem Text="Event History">
				<AutoCallBack Command="EWQCBubbleEventTab" Enabled="True" Target="ds" />
				<Template>
					<px:PXGrid runat="server" ID="PXGrid3" SyncPosition="True" Height="100%" SkinID="DetailsInTab" Width="100%" DataSourceID="ds">
						<AutoSize Enabled="True" />
						<Levels>
							<px:PXGridLevel DataMember="EventHistory" DataKeyNames="EWQCEventID">
								<Columns>
									<px:PXGridColumn DataField="CreatedDateTime" Width="180px" DisplayFormat="g" />
									<px:PXGridColumn DataField="Description" Width="180px" />
									<px:PXGridColumn DataField="EventType" Width="180px" />
									<px:PXGridColumn DataField="CreatedByID" Width="180px" /></Columns></px:PXGridLevel></Levels></px:PXGrid></Template></px:PXTabItem>
        </Items></px:PXTab>

    <px:PXSmartPanel runat="server" ID="PanelAddGlobalPlanTest" DesignView="Content" Height="360px" Width="1200px" LoadOnDemand="true" AutoRepaint="true" CaptionVisible="True" Caption="Attach QC plan" Key="EWQCBubbleGlobalPlanDetail" CommandSourceID="ds" AutoCallBack-Target="QCBubbleGlobalPlanGrid" AutoCallBack-Command="Refresh" CallBackMode-CommitChanges="True" CallBackMode-PostData="Page">
		<px:PXGrid runat="server" ID="QCBubbleGlobalPlanGrid" SyncPosition="true" Height="200px" SkinID="Details" Width="1150px" AutoAdjustColumns="True" DataSourceID="ds" AllowPaging="True" AdjustPageSize="Auto" AllowSearch="true">
			<AutoSize Enabled="true" />
			<Mode InitNewRow="True" />
			<Levels>
				<px:PXGridLevel DataMember="EWQCBubbleGlobalPlanDetail" DataKeyNames="QCInventoryDetailID">
				<Mode AllowAddNew="True" InitNewRow="True" />
				<RowTemplate>
                    <px:PXCheckBox runat="server" Text="Select" DataField="PlanSelected" AlreadyLocalized="False" ID="edPlanSelected" />
								<px:PXDropDown runat="server" ID="EWQCCstPXSelectorPlan" CommitChanges="True" DataField="PlanType" Enabled="True">
									<AutoCallBack Enabled="True" /></px:PXDropDown>
								<px:PXSelector runat="server" ID="EWQCCstPXSelector231" DataField="VendorID">
									<GridProperties FastFilterFields="AcctCD,AcctName" /></px:PXSelector>
								<px:PXSelector runat="server" DataField="CustomerID" ID="EWQCCstPXSelector232">
									<GridProperties FastFilterFields="AcctCD,AcctName" /></px:PXSelector>
								<px:PXSelector runat="server" ID="EWQCCstPXSelector233" DataField="PlanID">
									<GridProperties FastFilterFields="RevisionNo,Name" /></px:PXSelector>
								<px:PXCheckBox runat="server" DataField="AdhocQC" ID="EWQCCstPXCheckBox234" />
								<px:PXDropDown runat="server" ID="EWQCCstPXDropDown238" CommitChanges="True" DataField="InspectionType" />
								<px:PXCheckBox runat="server" DataField="ProductionQC" ID="EWQCCstPXCheckBox235" />
								<px:PXCheckBox runat="server" DataField="ReceivingQC" ID="EWQCCstPXCheckBox236" />
								<px:PXDropDown runat="server" ID="EWQCCstPXDropDown237" DataField="ResultCriteria" />
								<px:PXSelector runat="server" ID="EWQCCstPXSelector239" DataField="SamplingPlanID" AutoRefresh="True">
									<GridProperties FastFilterFields="RevisionNo,Name" /></px:PXSelector>
								<px:PXCheckBox runat="server" DataField="ShippingQC" ID="EWQCCstPXCheckBox240" /></RowTemplate>
				<Columns>
                    <px:PXGridColumn DataField="PlanSelected" Type="CheckBox" TextAlign="Center" Width="80px" CommitChanges="true" />
								<px:PXGridColumn DataField="PlanType" Width="70" Type="DropDownList" DisplayMode="Text" CommitChanges="True" />
								<px:PXGridColumn DataField="VendorID" Width="140" LinkCommand="EWQCViewVendorMaster" />
								<px:PXGridColumn DataField="CustomerID" Width="140" LinkCommand="EWQCViewCustomerMaster" />
								<px:PXGridColumn DataField="PlanID" Width="180" DisplayMode="Text" CommitChanges="True" LinkCommand="EWQCViewPlanMaster" />
								<px:PXGridColumn DataField="EWQCPlan__Status" Width="70" />
								<px:PXGridColumn DataField="ResultCriteria" Width="70" />
								<px:PXGridColumn DataField="InspectionType" Width="70" CommitChanges="True" />
								<px:PXGridColumn DataField="SamplingPlanID" Width="180" CommitChanges="True" DisplayMode="Text" LinkCommand="EWQCViewSamplingMaster" />
								<px:PXGridColumn DataField="AQLInspectionLevel" Width="70" CommitChanges="True" />
								<px:PXGridColumn DataField="EWQCSamplingPlan__Status" Width="70" />
								<px:PXGridColumn DataField="ReceivingQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="ShippingQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="ProductionQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="AdhocQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="KitAssemblyQC" Width="100" Type="CheckBox" />
								<px:PXGridColumn Type="CheckBox" DataField="RMAQC" Width="100" />
								<px:PXGridColumn DataField="WTQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="AdjustQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="DefaultAdhocQC" Type="CheckBox" Width="100" />
								<px:PXGridColumn DataField="LineNbr" Width="100px" CommitChanges="True" /></Columns></px:PXGridLevel></Levels>
			<Parameters>
				<px:PXSyncGridParam ControlID="QCAttributesDetailsGrid" /></Parameters></px:PXGrid>
		<px:PXPanel runat="server" ID="QCBubbleGlobalPlanBtnPanel" SkinID="Buttons">
			<px:PXButton runat="server" DialogResult="OK" Text="OK" SyncVisible="false" ID="QCBubbleGlobalPlanSaveBtn">
				<AutoCallBack Target="ds" Command="EWQCAddUpdateBubbleTest" /></px:PXButton>
			<px:PXButton runat="server" DialogResult="Cancel" Text="Cancel" ID="QCBubbleGlobalPlanCancelBtn" /></px:PXPanel></px:PXSmartPanel>

</asp:Content>



<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC501012.aspx.cs" Inherits="Page_QC501012" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="False" runat="server" visible="True" width="100%" primaryview="Filter"
        typename="EW.QC.EWQCOrderStatusChangeProcess">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewOrder" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewPlan" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
               <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewStockItem" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
               <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewSampling" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
                <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewRefNumber" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" tabindex="3700" bpeventsindicator="True">
      <Template>
         <px:PXLayoutRule runat="server" StartColumn="True" />
          <px:PXDropDown ID="edAction" runat="server" DataField="Action" CommitChanges="True" Width="150px"/>        
          <px:PXLayoutRule runat="server" StartColumn="True" />
         <px:PXSelector ID="edOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="True"/>
       </Template>
    </px:pxformview>   
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" syncposition="true" adjustpagesize="Auto" datasourceid="ds" skinid="PrimaryInquire" AutoAdjustColumns="true">
         <Levels>
            
            <px:PXGridLevel DataMember="OrderSampling">
                <RowTemplate>
                   
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QCOrderCD" Width="100" LinkCommand="ViewOrder" />
                    <px:PXGridColumn DataField="PlanID" Width="100" LinkCommand="ViewPlan"/>
                    <px:PXGridColumn DataField="InventoryID" LinkCommand="ViewStockItem"/>
                    <px:PXGridColumn DataField="SamplingPlanID" Width="100" LinkCommand="ViewSampling"/>
                    <px:PXGridColumn DataField="QCType" />
                    <px:PXGridColumn DataField="RefDocumentNbr" LinkCommand="ViewRefNumber"/>
                    <px:PXGridColumn DataField="RefDocumentType" />
                    <px:PXGridColumn DataField="Status" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>

</asp:Content>


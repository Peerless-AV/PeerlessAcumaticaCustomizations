<%--<%@ Import Namespace="EW.QC" %>--%>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301000.aspx.cs" Inherits="Page_QC301000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCOrderEntry" PrimaryView="QCOrders" AttributesFound="False" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="RefDocNumbers" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="DocNumbers" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="VendorDocNumbers" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="GotoSteps" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="GotoEquation" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="SubmitFormula" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="SubmitFormulaMobile" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="First" PostData="Self" StartNewGroup="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Last" PostData="Self"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewTestMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewGroupMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewSeverityMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewEquipmentMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="AddSample" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="DeleteSample" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="CopyTest" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="CreateNCForLot" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="CreateNCForTest" Visible="False" CommitChanges="true" />
            <%--<px:PXDSCallbackCommand Name="ViewRefDocument" Visible="true" DependOnGrid="PXGrid4" />--%>
            <px:PXDSCallbackCommand Name="ViewAssignedToID" Visible="False" CommitChanges="true" />
            <%--<px:PXDSCallbackCommand Name="ViewOnWeb" Visible="False" CommitChanges="true" />--%>
            <px:PXDSCallbackCommand Name="GoToLotHistory" Visible="False" DependOnGrid="PXGrid1" />
            <px:PXDSCallbackCommand Name="SubmitSerialNo" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddQCTool" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="CalibrationMaintenace" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Width="100%" DataMember="QCOrders" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M" />
            <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" DataField="OrderDate" TimeMode="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXSelector ID="edQCOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="true">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edClosingDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Enabled="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edOhHold" runat="server" DataField="OnHold" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXDropDown ID="edStatus" runat="server" DataField="Status" Enabled="false">
            </px:PXDropDown>
            <px:PXTextEdit ID="edRemarks" runat="server" DataField="Remarks" TextMode="MultiLine" Height="80" CommitChanges="true">
            </px:PXTextEdit>

            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXPanel ID="XX" runat="server" RenderStyle="Simple">
                <px:PXDropDown ID="edQCType" runat="server" DataField="QCType" Enabled="false" LabelWidth="140px">
                </px:PXDropDown>
                <px:PXTextEdit ID="edRefDocumentType" runat="server" AlreadyLocalized="False" DataField="RefDocumentType" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
                <%-- <px:PXTextEdit ID="edRefDocumentNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentNbr" Enabled="false">
                </px:PXTextEdit>
                <px:PXTextEdit ID="edRefDocumentLineNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentLineNbr" Enabled="false">
                </px:PXTextEdit>--%>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel8" runat="server" RenderStyle="Simple">
                <px:PXTextEdit runat="server" DataField="RefDocumentNbr" ID="PXTextEdit5" Enabled="False" LabelWidth="140px">
                    <LinkCommand Command="RefDocNumbers" Target="ds"></LinkCommand>
                    <%-- <Border>
<Bottom Color="#D2D4D7" Width="1px" /></Border>--%>
                </px:PXTextEdit>



                <%--<px:PXSelector ID="edRefDocumentNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentNbr">
                </px:PXSelector>--%>

                <%-- <px:PXLinkEdit ID="edRefDocumentNbr" runat="server" DataField="RefDocumentNbr" CommitChanges="True">
                    <LinkCommand Command="viewOnWeb" ActiveBehavior="true" Enabled="true" Target="edRefDocumentNbr"></LinkCommand>
                </px:PXLinkEdit>--%>

                <%-- <px:PXTextEdit ID="edRefDocumentNbr" runat="server" DataField="RefDocumentNbr" CommitChanges="true">
                    <LinkCommand ActiveBehavior="true" Target="edRefDocumentNbr" Enabled="true" Command="viewOnWeb"></LinkCommand>
                </px:PXTextEdit>--%>

                <%--<px:PXSelector ID="edRefDocumentNbr" runat="server" DataField="RefDocumentNbr" Enabled="False" AllowEdit="True" CommitChanges="true">
                </px:PXSelector>--%>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel9" runat="server" RenderStyle="Simple">
                <px:PXTextEdit ID="edRefDocumentLineNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentLineNbr" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel6" runat="server" RenderStyle="Simple">
                <px:PXSelector ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryID" AllowEdit="true" LabelWidth="140px">
                </px:PXSelector>
                <px:PXTextEdit ID="PXNumberEdit1" runat="server" AlreadyLocalized="False" DataField="Description" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel2" runat="server" RenderStyle="Simple">
                <px:PXTextEdit ID="edTrackingMethod" runat="server" AlreadyLocalized="False" DataField="TrackingMethod" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel14" runat="server" RenderStyle="Simple">
                <px:PXTextEdit ID="edTotalSampleSize" runat="server" AlreadyLocalized="False" DataField="TotalSampleSize" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
            </px:PXPanel>

            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXPanel ID="PXPanel5" runat="server" RenderStyle="Simple">
                <px:PXSelector ID="PXSelector1" runat="server" DataField="PlanID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" LabelWidth="140px" />

            </px:PXPanel>
            <px:PXPanel ID="PXPanel3" runat="server" RenderStyle="Simple" DataMember="Plan">

                <px:PXTextEdit ID="PXNumberEdit2" runat="server" AlreadyLocalized="False" DataField="Description" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel4" runat="server" RenderStyle="Simple">
                <px:PXDropDown ID="edInspectionType" runat="server" DataField="InspectionType" Enabled="false" LabelWidth="140px">
                </px:PXDropDown>
                <px:PXSelector ID="edSamplingPlanID" runat="server" DataField="SamplingPlanID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" LabelWidth="140px" />

                <px:PXDropDown ID="edAQLInspectionLevel" runat="server" AlreadyLocalized="False" DataField="AQLInspectionLevel" LabelWidth="140px">
                </px:PXDropDown>
                <px:PXDropDown ID="edResultingCriteria" runat="server" AlreadyLocalized="False" DataField="ResultingCriteria" LabelWidth="140px">
                </px:PXDropDown>
                <%--<px:PXTextEdit ID="PXTextEdit2" runat="server" AlreadyLocalized="False" DataField="AccountCD" Enabled ="false" >
                </px:PXTextEdit>
                <px:PXTextEdit ID="PXTextEdit3" runat="server" AlreadyLocalized="False"  DataField="AccountName" Enabled ="false" >
                </px:PXTextEdit>--%>
                <px:PXSelector ID="PXTextEdit2" runat="server" AlreadyLocalized="False" DataField="AccountID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True" LabelWidth="140px">
                </px:PXSelector>
                <px:PXSelector ID="PXTextEdit3" runat="server" AlreadyLocalized="False" DataField="AccountName" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True" LabelWidth="140px">
                </px:PXSelector>
                <%--<px:PXTextEdit ID="PXTextEdit4" runat="server" AlreadyLocalized="False" DataField="DocumentNbr" Enabled ="false" >
                </px:PXTextEdit>--%>
                <px:PXTextEdit ID="PXTextEdit4" runat="server" AlreadyLocalized="False" DataField="DocumentNbr" AllowAddNew="True" CommitChanges="True" LabelWidth="140px">
                    <LinkCommand Command="DocNumbers" Target="ds"></LinkCommand>
                </px:PXTextEdit>
            </px:PXPanel>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>

            <px:PXPanel ID="PXPanel12" runat="server" RenderStyle="Simple">
                <px:PXSelector CommitChanges="True" ID="edVendorNID" runat="server" DataField="VendorID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" LabelWidth="140px">
                </px:PXSelector>
                <px:PXSelector CommitChanges="True" ID="edVendorID" runat="server" DataField="VendorName" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" LabelWidth="140px">
                </px:PXSelector>
                <%--<px:PXSelector CommitChanges="True" ID="edVendorNumber" runat="server" DataField="VendorDocumentNbr" AllowAddNew="True" AllowEdit="True" AutoRefresh="True">
</px:PXSelector>--%>

                <px:PXTextEdit CommitChanges="True" ID="edVendorNumber" runat="server" DataField="VendorDocumentNbr" AllowAddNew="True" AutoRefresh="True" LabelWidth="140px">
                    <LinkCommand Command="VendorDocNumbers" Target="ds"></LinkCommand>
                </px:PXTextEdit>
                <px:PXTextEdit ID="edDescr" runat="server" AlreadyLocalized="False" DataField="Descr" Enabled="false" LabelWidth="140px">
                </px:PXTextEdit>
                <px:PXSelector CommitChanges="True" ID="edProjectID" runat="server" DataField="ProjectID" AllowEdit="True" LabelWidth="140px" />
                <px:PXNumberEdit ID="edQCExecuted" runat="server" DataField="QCExecuted" LabelWidth="140px">
                </px:PXNumberEdit>
                <px:PXDropDown ID="edIntervalBy" runat="server" DataField="IntervalBy" CommitChanges="true" LabelWidth="140px">
                </px:PXDropDown>



            </px:PXPanel>

            <%--<px:PXPanel ID="PXPanelACC" runat="server" RenderStyle="Simple">
                <px:PXTextEdit ID="PxtxtAccCD" runat="server" DataField="AccountCD" Enabled ="false" >
                </px:PXTextEdit>
                <px:PXTextEdit ID="PxTxtAccName" runat="server"  DataField="AccountName" Enabled ="false" >
                </px:PXTextEdit>
                 <px:PXTextEdit ID="PxTxtRefNo" runat="server" DataField="DocumentNbr" Enabled ="false" >
                </px:PXTextEdit>
            </px:PXPanel>--%>
        </Template>
        <CallbackCommands>
            <Refresh CommitChanges="True" PostData="Page" />
            <Search CommitChanges="True" PostData="Page" />
        </CallbackCommands>
    </px:PXFormView>
    <px:PXSmartPanel ID="pnlTestSteps" runat="server" Height="400px" Width="1100px" Caption="Test Steps" CaptionVisible="true" AutoReload="true" Key="TestSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="StepsGrid" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataMember="TestSteps">
                    <Columns>
                        <px:PXGridColumn DataField="Name">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="pnlLotHistory" runat="server" Height="500px" Width="1300px" Caption="Lot History" CaptionVisible="true" AutoReload="true" Key="LotHistoryCheck" Style="position: static"
        AutoCallBack-Target="PXGrid5" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="PXGrid5" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataMember="LotHistoryCheck">
                    <RowTemplate>
                        <px:PXSelector ID="edQCOrderID" runat="server" DataField="QCOrderCD" AllowEdit="true">
                        </px:PXSelector>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="QCOrderCD">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="InventoryID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="PlanID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="SamplingPlanID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="QCType">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="RefDocumentType">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="RefDocumentNbr">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Status">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel1" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton1" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="pnlEquation" runat="server" Height="500px" Width="800px" Caption="Equation" CaptionVisible="true" AutoReload="true" Key="QCOrderTestFormula" Style="position: static"
        AutoCallBack-Target="PXGridEquation" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="PXGridEquation" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataKeyNames="QCOrderSamplingDetailID" DataMember="QCOrderTestFormula">
                    <RowTemplate>

                        <px:PXTextEdit ID="edParameter" runat="server" AlreadyLocalized="False" DataField="ParameterName" Enabled="false" Width="600px">
                        </px:PXTextEdit>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ParameterName">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="EWQCTestParameter__Description"></px:PXGridColumn>
                        <px:PXGridColumn DataField="FormulaValue">
                        </px:PXGridColumn>

                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode InitNewRow="False" AllowFormEdit="False" AllowDragRows="True" AutoInsert="False" AllowAddNew="False" AllowDelete="False"></Mode>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel10" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton2" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitFormula" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnInvCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>

</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tabDetails" runat="server" Width="100%" Height="100%">
        <Items>
            <px:PXTabItem Text="Details">
                <Template>
                    <px:PXSplitContainer ID="SptCont1" runat="server" SkinID="Horizontal" SplitterPosition="250" Height="600px" Panel1MinSize="100" Panel2MinSize="100">
                        <AutoSize Container="Window" Enabled="true" MinHeight="600" />
                        <Template1>
                            <px:PXGrid ID="PXGrid1" Caption="Details" CaptionVisible="true" runat="server" OnRowDataBound="grid_RowDataBound" DataSourceID="ds" Width="100%" Height="100%" SkinID="Details" SyncPosition="true" AutoAdjustColumns="true">
                                <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                    NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                    NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                    FilteredMessage="No records found.
Try to change filter to see records here."
                                    FilteredAddMessage="No records found.
Try to change filter to see records here."
                                    NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                    NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                    AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                    AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="form,PXGrid2,PXGrid3,PXGrid4"></Behavior>
                                </AutoCallBack>
                                <%--<AutoCallBack Command="Refresh" Target="PXGrid2 PXGrid3" />
                <OnChangeCommand Command="Refresh" Target="PXGrid2 PXGrid3" />--%>
                                <%-- <AutoCallBack Command="Refresh" Target="PXGrid3" />
                <OnChangeCommand Command="Refresh" Target="PXGrid3" />--%>
                                <Levels>
                                    <px:PXGridLevel DataKeyNames="QCOrderLotDetailID" DataMember="QCOrderLotDetails">
                                        <RowTemplate>
                                            <px:PXTextEdit ID="edLotSerNumVal" runat="server" AlreadyLocalized="False" DataField="LotSerNumVal">
                                            </px:PXTextEdit>
                                            <px:PXTextEdit ID="edLotSerNum" runat="server" AlreadyLocalized="False" DataField="LotSerNum">
                                            </px:PXTextEdit>
                                            <px:PXDropDown ID="edStatus" runat="server" DataField="Status" Enabled="false">
                                            </px:PXDropDown>
                                            <px:PXNumberEdit ID="edTestQTY" runat="server" AlreadyLocalized="False" DataField="TestQTY" Enabled="false">
                                            </px:PXNumberEdit>
                                            <px:PXNumberEdit ID="PXNumberEdit3" runat="server" AlreadyLocalized="False" DataField="PassedSamplesQTY" Enabled="false">
                                            </px:PXNumberEdit>
                                            <px:PXNumberEdit ID="PXNumberEdit4" runat="server" AlreadyLocalized="False" DataField="FailedSamplesQTY" Enabled="false">
                                            </px:PXNumberEdit>
                                             <px:PXNumberEdit ID="PXNumberEdit5" runat="server" AlreadyLocalized="False" DataField="PassedQCtest" Enabled="false">
                                            </px:PXNumberEdit>
                                            <px:PXNumberEdit ID="PXNumberEdit6" runat="server" AlreadyLocalized="False" DataField="FailedQCTest" Enabled="false">
                                            </px:PXNumberEdit>
                                            <px:PXNumberEdit ID="edAcceptedQTY" runat="server" AlreadyLocalized="False" DataField="AcceptedQTY">
                                            </px:PXNumberEdit>
                                            <px:PXNumberEdit ID="edRejectedQTY" runat="server" AlreadyLocalized="False" DataField="RejectedQTY">
                                            </px:PXNumberEdit>
                                            <px:PXSelector ID="edRejectionCode" runat="server" DataField="RejectionCode">
                                            </px:PXSelector>
                                            <px:PXNumberEdit ID="edScappedQTY" runat="server" AlreadyLocalized="False" DataField="ScappedQTY">
                                            </px:PXNumberEdit>
                                            <px:PXSelector ID="edScrapCode" runat="server" DataField="ScrapCode">
                                            </px:PXSelector>
                                            <px:PXNumberEdit ID="edDestructiveQTY" runat="server" AlreadyLocalized="False" DataField="DestructiveQTY">
                                            </px:PXNumberEdit>
                                            <%-- <px:PXNumberEdit ID="edNCQTY" runat="server" AlreadyLocalized="False" DataField="NCQTY">
                                            </px:PXNumberEdit>--%>
                                            <%-- <px:PXDropDown ID="edActualResult" runat="server" AlreadyLocalized="False" DataField="ActualResult">
                            </px:PXDropDown>--%>
                                            <%-- <px:PXDropDown ID="edFinalResult1" runat="server" DataField="FinalResult">
                            </px:PXDropDown>--%>
                                            <px:PXTextEdit ID="edRemarks1" runat="server" AlreadyLocalized="False" DataField="Remarks" CommitChanges="true">
                                            </px:PXTextEdit>
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="LotSerNumVal" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="LotSerNum" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Status" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="LotHistory" Width="230px" LinkCommand="GoToLotHistory" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="BaseWarehouseID" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="BaseLocationID" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="INSite__SiteCD" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="INLocation__LocationCD" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="TestQTY" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="BaseUOM" Width="120px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="PassedSamplesQTY" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="FailedSamplesQTY" Width="180px">
                                            </px:PXGridColumn>  
                                             <px:PXGridColumn DataField="PassedQCtest" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="FailedQCTest" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="AcceptedQTY" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="RejectedQTY" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="RejectionCode" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ScappedQTY" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ScrapCode" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="DestructiveQTY" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ActualResult" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Remarks" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="NCNbr" Width="200px" LinkCommand="ViewLotNC">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" />
                                <ActionBar>
                                    <CustomItems>
                                        <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" CommandName="addLineDetails" />
                                          <px:PXToolBarButton Key="cmdQCOrderLotAttributeSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributes" />
                                    </CustomItems>
                                </ActionBar>
                            </px:PXGrid>
                        </Template1>
                        <Template2>
                            <px:PXTab ID="tab" runat="server" Width="100%" Height="100%">
                                <Items>
                                    <px:PXTabItem Text="Test Results">
                                        <Template>
                                            <px:PXGrid ID="PXGrid2" runat="server" OnRowDataBound="grid2_RowDataBound" DataSourceID="ds" Style="z-index: 100; left: 0px; top: 0px; height: 455px; overflow: hidden" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" TabIndex="2600">
                                                <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                                    NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                                    NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                                    FilteredMessage="No records found.
Try to change filter to see records here."
                                                    FilteredAddMessage="No records found.
Try to change filter to see records here."
                                                    NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                                    NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                                    AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                                    AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                                                <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
                                                <ActionBar ActionsText="False">
                                                    <CustomItems>
                                                        <px:PXToolBarButton Text="QCTool" PopupPanel="AttributePanel" Visible="false" Enabled="True">
                                                            <AutoCallBack Command="AddQCTool" Target="ds">
                                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                                            </AutoCallBack>
                                                        </px:PXToolBarButton>
                                                          <px:PXToolBarButton Key="cmdQCOrderLotAttributeTestSmartPanel" Text="Lot Attribute" CommandSourceID="ds" CommandName="lotAttributestest"></px:PXToolBarButton>
                                                    </CustomItems>
                                                </ActionBar>
                                                <Levels>
                                                    <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderSamplingDetails" SortOrder="LineNbr">
                                                        <RowTemplate>
                                                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                                            <px:PXTextEdit ID="edSamplingSerailNum" runat="server" AlreadyLocalized="False" DataField="SamplingSerailNum">
                                                            </px:PXTextEdit>
                                                            <px:PXSelector ID="edSerialNumber" runat="server" AlreadyLocalized="False" DataField="SerialNumber">
                                                            </px:PXSelector>
                                                            <px:PXSelector ID="edAssignedToID" runat="server" DataField="AssignedToID">
                                                                <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
                                                            </px:PXSelector>
                                                            <%--  <px:PXSelector ID="edToolgauge" runat="server" DataField="ToolGaugeID">
                                                <GridProperties FastFilterFields="ToolGaugeCD,Description"></GridProperties>
                                            </px:PXSelector>--%>
                                                            <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="edTestValue" />
                                                            <px:PXTextEdit runat="server" DataField="TestResultUOM" CommitChanges="True" ID="edTestResultUOM" />
                                                            <%-- <px:PXNumberEdit ID="edNumTargetValue" runat="server" AlreadyLocalized="False" DataField="NumTargetValue">
                                            </px:PXNumberEdit>--%>
                                                            <%-- <px:PXNumberEdit ID="edNumMaxValue" runat="server" AlreadyLocalized="False" DataField="NumMaxValue">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edNumMinValue" runat="server" AlreadyLocalized="False" DataField="NumMinValue">
                                    </px:PXNumberEdit>--%>
                                                            <%--<px:PXDropDown ID="PXDropDown1" runat="server" DataField="BoolAlphaValue">
                                            </px:PXDropDown>--%>
                                                            <%-- <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                                            </px:PXTextEdit>--%>
                                                            <%--<px:PXCheckBox ID="edBitPassFail" runat="server" AlreadyLocalized="False" DataField="BitPassFail" Text="BitPassFail">
                                            </px:PXCheckBox>--%>
                                                            <%--<px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="BitGoNoGo">
                                            </px:PXCheckBox>--%>
                                                            <px:PXCheckBox ID="edTested" runat="server" AlreadyLocalized="False" DataField="Tested" Text="Tested">
                                                            </px:PXCheckBox>
                                                            <%-- <px:PXDropDown ID="edActualResult" runat="server" DataField="ActualResult">
                                            </px:PXDropDown>--%>
                                                            <px:PXDropDown ID="edActualResult" runat="server" DataField="ActualResult">
                                                            </px:PXDropDown>
                                                            <px:PXDropDown ID="edFinalResult" runat="server" DataField="FinalResult">
                                                            </px:PXDropDown>
                                                            <px:PXTextEdit ID="PXTextEdit1" runat="server" AlreadyLocalized="False" DataField="Remarks" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports" Enabled="false">
                                                            </px:PXCheckBox>
                                                            <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest" Enabled="false">
                                                            </px:PXCheckBox>
                                                            <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                                                            </px:PXDropDown>
                                                            <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                                                            </px:PXTextEdit>
                                                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                                            <px:PXTextEdit ID="edName" runat="server" DataField="EWQCVariable__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edVariableCD" runat="server" DataField="EWQCVariable__VariableCD" LinkCommand="ViewTestMaster" Width="180px">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edTGName" runat="server" DataField="EWQCTestGroup__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edSteps" runat="server" DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edDescription" runat="server" DataField="EWQCVariable__Description" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edDataType" runat="server" DataField="EWQCVariable__DataType" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXSelector runat="server" ID="edUsrEWQCLTAttributeID" DataField="AttributeID" AutoRefresh="true" Enabled="false" CommitChanges="true">
                                                            <GridProperties FastFilterFields="AttributeID,Description" /></px:PXSelector>
                                                            <px:PXCheckBox runat="server" CommitChanges="true" DataField="CopyLotAttribute" AlreadyLocalized="False" ID="edUsrEWQCLTCopyLotAttribute" />
                                                            <px:PXTextEdit ID="edTestCategoryName" runat="server" DataField="EWQCTestCategory__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edTestMethodName" runat="server" DataField="EWQCTestMethod__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edTool" runat="server" DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edSeverity" runat="server" DataField="EWQCSeverityLevel__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edAssignto" runat="server" DataField="AssignedToID" LinkCommand="viewAssignedToID" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edExpected" runat="server" DataField="ExpectedValue" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="PXTextEdit6" runat="server" DataField="UOM" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXTextEdit ID="edEquation" runat="server" DataField="Equation" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                                            </px:PXTextEdit>
                                                            <px:PXLayoutRule runat="server" Merge="False" />
                                                            <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                                                            </px:PXDropDown>
                                                            <px:PXCheckBox ID="edDestructiveTesting" runat="server" AlreadyLocalized="False" DataField="DestructiveTesting" Enabled="false">
                                                            </px:PXCheckBox>
                                                            <px:PXSelector ID="edUOM" runat="server" AlreadyLocalized="False" DataField="UOM" Enabled="false">
                                                            </px:PXSelector>
                                                            <px:PXNumberEdit ID="edSampleSize" runat="server" AlreadyLocalized="False" DataField="SampleSize" Enabled="false">
                                                            </px:PXNumberEdit>
                                                        </RowTemplate>
                                                        <Columns>
                                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="SerialNumber" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCVariable__VariableCD" LinkCommand="ViewTestMaster" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="AttributeID"></px:PXGridColumn>
                                                            <px:PXGridColumn DataField="CopyLotAttribute" Type="CheckBox" TextAlign="Center" CommitChanges="true"></px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCTestGroup__Name" CommitChanges="true" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCTestCategory__Name" CommitChanges="true" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCTestMethod__Name" CommitChanges="true" Width="180px">
                                                            </px:PXGridColumn>
                                                            <%--<px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true" Width="180px">
                                            </px:PXGridColumn>--%>
                                                            <%--<px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                                            <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="AddQCTool" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true" LinkCommand="viewAssignedToID">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="ExpectedValue" Width="280px">
                                                            </px:PXGridColumn>
                                                            <%-- <px:PXGridColumn DataField="EWQCVariable__Unit" Width="180px">
                                            </px:PXGridColumn>--%>
                                                            <px:PXGridColumn DataField="DestructiveTesting" TextAlign="Center" Type="CheckBox">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="SampleSize" Width="120px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="UOM" Width="120px">
                                                            </px:PXGridColumn>
                                                            <%-- <px:PXGridColumn DataField="NumMaxValue" Width="100px">
                                    </px:PXGridColumn>--%>
                                                            <px:PXGridColumn DataField="Equation" Width="180px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="Formula" Width="180px" LinkCommand="GotoEquation" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="TestValue" CommitChanges="true" MatrixMode="true" />
                                                            <px:PXGridColumn DataField="TestResultUOM" CommitChanges="true" />
                                                            <%--  <px:PXGridColumn DataField="NumTargetValue" Width="100px" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                                            <%-- <px:PXGridColumn DataField="NumMinValue" Width="100px">
                                    </px:PXGridColumn>--%>
                                                            <%--<px:PXGridColumn DataField="BoolAlphaValue" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                                            <%-- <px:PXGridColumn DataField="AlphaValue" Width="280px" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                                            <%-- <px:PXGridColumn DataField="BitPassFail" TextAlign="Center" Type="CheckBox" Width="60px">
                                            </px:PXGridColumn>--%>
                                                            <%-- <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                                            <%--<px:PXGridColumn DataField="Tested" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                                            <px:PXGridColumn DataField="ActualResult" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="FinalResult" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                                            </px:PXGridColumn>

                                                            <px:PXGridColumn DataField="OrderLevel" CommitChanges="true" Width="120px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="Remarks" Width="280px" CommitChanges="true">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px"></px:PXGridColumn>
                                                            <px:PXGridColumn DataField="NCNbr" Width="200px" LinkCommand="ViewTestNC">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="QCOrderSamplingDetailID" Width="1px">
                                                            </px:PXGridColumn>
                                                        </Columns>
                                                    </px:PXGridLevel>
                                                </Levels>
                                                <Mode AllowUpload="True" />
                                                <AutoSize Enabled="True" />
                                                <AutoCallBack />
                                                <ActionBar>
                                                    <CustomItems>
                                                        <px:PXToolBarButton Text="Add Sample" Key="cmdSample" CommandName="AddSample" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                                            <AutoCallBack>
                                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                                            </AutoCallBack>
                                                        </px:PXToolBarButton>
                                                        <px:PXToolBarButton Text="Delete Sample" Key="cmdDeleteSample" CommandName="DeleteSample" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                                            <AutoCallBack>
                                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                                            </AutoCallBack>
                                                        </px:PXToolBarButton>
                                                        <px:PXToolBarButton Text="Copy Test" Key="cmdCopyTest" CommandName="CopyTest" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                                            <AutoCallBack>
                                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                                            </AutoCallBack>
                                                        </px:PXToolBarButton>
                                                        <px:PXToolBarButton Text="Capture Test Results" Key="cmdCaptureTestResults" CommandName="CaptureTestResults" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                                            <AutoCallBack>
                                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                                            </AutoCallBack>
                                                        </px:PXToolBarButton>
                                                        <px:PXToolBarButton Text="CALIBRATION AND MAINTENANCE ORDERS" Key="cmdCalibrationMaintenace" CommandName="CalibrationMaintenace" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                                            <AutoCallBack>
                                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                                            </AutoCallBack>
                                                        </px:PXToolBarButton>
                                                    </CustomItems>
                                                </ActionBar>
                                                <AutoSize Enabled="True" MinHeight="10"></AutoSize>
                                                <Mode InitNewRow="True" AllowFormEdit="False" AllowDragRows="True" AutoInsert="true"></Mode>
                                            </px:PXGrid>
                                        </Template>
                                        <AutoCallBack Target="PXGrid2" Command="Refresh">
                                            <Behavior RepaintControlsIDs="PXGrid2" />
                                        </AutoCallBack>
                                    </px:PXTabItem>
                                    <%-- <px:PXTabItem Text="Expected Results">
                        <Template>
                            <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="150px" SkinID="DetailsInTab" SyncPosition="True">
                                <Levels>
                                    <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="OrderSampling">
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                            </px:PXGridColumn>

                                            <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCTestCategory__Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCTestMethod__Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCToolGauge__ToolGaugeCD" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__Unit" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpNumMaxValue" Width="100px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpNumTargetValue" Width="100px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpNumMinValue" Width="100px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpAlphaValue" Width="280px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpBitPassFail" TextAlign="Center" Type="CheckBox" Width="60px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpBitGoNoGo" TextAlign="Center" Type="CheckBox" Width="60px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" />
                                <AutoCallBack />
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="PXGrid3" Command="Refresh">
                            <Behavior RepaintControlsIDs="PXGrid3" />
                        </AutoCallBack>
                    </px:PXTabItem>--%>

                                    <px:PXTabItem Text="Event History">
                                        <Template>
                                            <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                                                <Levels>
                                                    <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                                        <Columns>
                                                            <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="Description">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EventType">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="CreatedByID">
                                                            </px:PXGridColumn>
                                                        </Columns>
                                                    </px:PXGridLevel>
                                                </Levels>
                                                <AutoSize Enabled="True" />
                                                <AutoCallBack />
                                            </px:PXGrid>
                                        </Template>
                                        <AutoCallBack Target="PXGrid3" Command="Refresh">
                                            <Behavior RepaintControlsIDs="PXGrid3" />
                                        </AutoCallBack>
                                    </px:PXTabItem>

                                    <px:PXTabItem Text="Lot Transfer Detail">
                                        <Template>
                                            <px:PXGrid ID="PXGrid4" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                                                <Levels>
                                                    <px:PXGridLevel DataKeyNames="LotTransferDetailID" DataMember="QCLotTransferDetails">
                                                        <Columns>
                                                            <px:PXGridColumn DataField="InventoryItem__InventoryCD">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="EWQCOrderLotDetail__LotSerNumVal">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="FromWarehouseID">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="ToWarehouseID">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="RefNbrType">
                                                            </px:PXGridColumn>
                                                            <px:PXGridColumn DataField="RefNbr" LinkCommand="ViewRefDocument">
                                                            </px:PXGridColumn>
                                                        </Columns>
                                                    </px:PXGridLevel>
                                                </Levels>
                                                <AutoSize Enabled="True" />
                                                <AutoCallBack />
                                            </px:PXGrid>
                                        </Template>
                                        <AutoCallBack Target="PXGrid4" Command="Refresh">
                                            <Behavior RepaintControlsIDs="PXGrid4" />
                                        </AutoCallBack>
                                    </px:PXTabItem>
                                </Items>
                                <AutoSize Enabled="True"></AutoSize>
                            </px:PXTab>
                        </Template2>
                    </px:PXSplitContainer>
                </Template>
                <AutoCallBack Target="PXGrid1" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid1" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="CALIBRATION AND MAINTENANCE ORDERS">
                <Template>
                    <px:PXGrid ID="transactionGrid" runat="server" BorderStyle="None" SkinID="DetailsInTab" Width="100%" DataSourceID="ds" SyncPosition="true">
                        <AutoSize Enabled="True" Container="Window" />
                        <ActionBar>
                            <Actions>
                                <AddNew Enabled="false" />
                                <Delete Enabled="false" />
                                <EditRecord Enabled="false" />
                            </Actions>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataMember="ToolManagementView">
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                                <Columns>
                                    <px:PXGridColumn DataField="TnCOrderCD" Width="115px" LinkCommand="RefOrderNbr" />
                                    <px:PXGridColumn DataField="Status" Width="115px" />
                                    <px:PXGridColumn DataField="OrderType" Width="115px" />
                                    <px:PXGridColumn DataField="CalibrationScheduledType" Width="130px" />
                                    <px:PXGridColumn DataField="ToolID" Width="130px" LinkCommand="ViewToolID" CommitChanges="true" />


                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="transactionGrid" Command="Refresh">
                    <Behavior RepaintControlsIDs="transactionGrid" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Enabled="True" Container="Window"></AutoSize>
    </px:PXTab>

    <px:PXSmartPanel ID="pnlCopyTestRecords" runat="server" Height="400px" Width="1100px" Caption="Copy Test Result" CaptionVisible="true" AutoReload="true" Key="QCOrderCopySamplingDetails" Style="position: static"
        AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXFormView ID="frmMyCommand" runat="server" SkinID="Transparent" DataMember="QCOrdersLot" DataSourceID="ds" EmailingGraph="">
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true" />
                <px:PXLayoutRule runat="server" StartColumn="true" ControlSize="M" LabelsWidth="SM" />
                <px:PXDropDown ID="edlevel" runat="server" AlreadyLocalized="False" AutoRefresh="true" CommitChanges="true" DataField="Level">
                </px:PXDropDown>
                <px:PXSelector ID="edLots" runat="server" DataField="Lots" AutoRefresh="true" CommitChanges="true">
                </px:PXSelector>
                <px:PXLayoutRule runat="server" StartColumn="true" ControlSize="M" LabelsWidth="SM" />
                <px:PXSelector ID="edSamples" runat="server" DataField="Samples" AutoRefresh="true" CommitChanges="true">
                </px:PXSelector>
                <px:PXSelector ID="edTests" runat="server" DataField="Tests" AutoRefresh="true" CommitChanges="true">
                </px:PXSelector>
            </Template>
        </px:PXFormView>
        <px:PXTab ID="tab" runat="server">
            <Items>
                <px:PXTabItem Text="Copy To Lot/Serial" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edlevel&quot;].Value == L" BindingContext="frmMyCommand">
                    <Template>
                        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Details" AllowPaging="false"
                            Width="1100px" Height="600px" SyncPosition="true" TabIndex="2600">
                            <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                FilteredMessage="No records found.
Try to change filter to see records here."
                                FilteredAddMessage="No records found.
Try to change filter to see records here."
                                NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                            <Levels>
                                <px:PXGridLevel DataKeyNames="QCOrderLotDetailID" DataMember="QCOrderLot">
                                    <RowTemplate>
                                        <px:PXCheckBox ID="pxcheck" runat="server" AlreadyLocalized="False" DataField="itemcheck" Text="Check">
                                        </px:PXCheckBox>
                                    </RowTemplate>
                                    <Columns>
                                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="DisplayLotSerNumVal" Width="180px">
                                        </px:PXGridColumn>
                                    </Columns>
                                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                                </px:PXGridLevel>
                            </Levels>
                            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                            <AutoSize Enabled="True" />
                            <AutoCallBack />
                            <ActionBar>
                                <CustomItems>
                                    <px:PXToolBarButton Text="Copy" Key="cmdCopy" CommandName="CopyData" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                        <AutoCallBack>
                                            <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                        </AutoCallBack>
                                    </px:PXToolBarButton>
                                </CustomItems>
                            </ActionBar>
                            <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
                        </px:PXGrid>
                        <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    </Template>
                </px:PXTabItem>
                <px:PXTabItem Text="Copy Sample Nbr" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edlevel&quot;].Value == S" BindingContext="frmMyCommand">
                    <Template>
                        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Details" AllowPaging="false"
                            Width="1100px" Height="600px" SyncPosition="true" TabIndex="2600">
                            <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                FilteredMessage="No records found.
Try to change filter to see records here."
                                FilteredAddMessage="No records found.
Try to change filter to see records here."
                                NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                            <Levels>
                                <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderSample">
                                    <RowTemplate>
                                        <px:PXCheckBox ID="pxcheck1" runat="server" AlreadyLocalized="False" DataField="itemcheck" Text="Check">
                                        </px:PXCheckBox>
                                    </RowTemplate>
                                    <Columns>
                                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="EWQCOrderLotDetail__DisplayLotSerNumVal" Width="180px">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                        </px:PXGridColumn>
                                    </Columns>
                                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                                </px:PXGridLevel>
                            </Levels>
                            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                            <AutoSize Enabled="True" />
                            <AutoCallBack />
                            <ActionBar>
                                <CustomItems>
                                    <px:PXToolBarButton Text="Copy" Key="cmdCopy" CommandName="CopyData" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                        <AutoCallBack>
                                            <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                        </AutoCallBack>
                                    </px:PXToolBarButton>
                                </CustomItems>
                            </ActionBar>
                            <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
                        </px:PXGrid>
                        <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    </Template>
                </px:PXTabItem>
                <px:PXTabItem Text="Copy To Test" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edlevel&quot;].Value == T" BindingContext="frmMyCommand">
                    <Template>
                        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Details" AllowPaging="false"
                            Width="1100px" Height="600px" SyncPosition="true" TabIndex="2600">
                            <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                FilteredMessage="No records found.
Try to change filter to see records here."
                                FilteredAddMessage="No records found.
Try to change filter to see records here."
                                NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                            <Levels>
                                <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderTest">
                                    <RowTemplate>
                                        <px:PXCheckBox ID="pxcheck2" runat="server" AlreadyLocalized="False" DataField="itemcheck" Text="Check">
                                        </px:PXCheckBox>
                                    </RowTemplate>
                                    <Columns>
                                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="EWQCOrderLotDetail__DisplayLotSerNumVal" Width="180px">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                        </px:PXGridColumn>
                                    </Columns>
                                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                                </px:PXGridLevel>
                            </Levels>
                            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                            <AutoSize Enabled="True" />
                            <AutoCallBack />
                            <ActionBar>
                                <CustomItems>
                                    <px:PXToolBarButton Text="Copy" Key="cmdCopy" CommandName="CopyData" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                        <AutoCallBack>
                                            <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                        </AutoCallBack>
                                    </px:PXToolBarButton>
                                </CustomItems>
                            </ActionBar>
                            <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
                        </px:PXGrid>
                        <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    </Template>
                </px:PXTabItem>
            </Items>
        </px:PXTab>
    </px:PXSmartPanel>

    <%--<px:PXSmartPanel ID="PanelAddNCLine" runat="server" Height="500px" Width="1100px" Caption="Add Line Details" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="QCOrderLotDetailsSmartPanel" Style="position: static" AutoCallBack-Behavior-CommitChanges="true" AutoCallBack-Behavior-PostData="Page"
        AutoCallBack-Target="AddLine Grid1" AutoCallBack-Command="Refresh" DesignView="Content">
    <px:PXGrid ID="gridOL" runat="server" Height="50px" Width="100%" DataSourceID="ds" AutoAdjustColumns="true" PageSize="200" SkinID="Inquire">
    <AutoSize Enabled="true" />
    <ActionBar>
    <Actions>
    <AddNew Enabled="false" />
    <Delete Enabled="false" />
    <EditRecord Enabled="false" />
    </Actions>
    </ActionBar>
    <Levels>
    <px:PXGridLevel DataMember="QCOrderLotDetailsSmartPanel">
                    <RowTemplate>
                        <px:PXTextEdit ID="edSerialNumbercheck" runat="server" DataField="SerialNumber" CommitChanges="true">
                        </px:PXTextEdit>
                        <px:PXCheckBox ID="editemcheck" runat="server" AlreadyLocalized="False" AllowCheckAll="true" DataField="itemcheck" CommitChanges="true">
                         </px:PXCheckBox>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="SerialNumber">
                        </px:PXGridColumn>
                         <px:PXGridColumn DataField="itemcheck" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                         </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
    </Levels>
            <Mode AllowUpload="false" />
    <AutoSize Enabled="true" />
    <CallbackCommands>
    <Save RepaintControls="None" />
    </CallbackCommands>
    </px:PXGrid>
    <px:PXPanel ID="PXPanel13" runat="server" SkinID="Buttons">
    <px:PXButton ID="PXButton4" runat="server" DialogResult="OK" Text="OK">
    <AutoCallBack Command="SubmitSerialNo" Target="ds"></AutoCallBack>
    </px:PXButton>
    <px:PXButton ID="PXButton5" runat="server" DialogResult="No" Text="Cancel" />
    </px:PXPanel>
    </px:PXSmartPanel>--%>

    <px:PXSmartPanel runat="server" ID="PanelAttributes" DesignView="Content" Height="500px" Width="1100px" LoadOnDemand="true" AutoReload="true" CaptionVisible="true" Caption="Attributes" Key="LotSerialAttributes" AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" Style='Position:static;'>
    <px:PXGrid runat="server" ID="PXGridAttributeValues" Height="150px" SkinID="Attributes" Width="100%" Caption="Attributes" CaptionVisible="false" DataSourceID="ds">
      <Levels>
        <px:PXGridLevel DataMember="LotSerialAttributes">
          <RowTemplate>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
            <px:PXTextEdit runat="server" DataField="Value" ID="edAttributeValue" /></RowTemplate>
          <Columns>
            <px:PXGridColumn DataField="AttributeID" TextAlign="Left" Width="135px" AllowShowHide="False" />
            <px:PXGridColumn DataField="Required" Type="CheckBox" TextAlign="Center" Width="80px" />
            <px:PXGridColumn DataField="Value" Width="185px" /></Columns></px:PXGridLevel></Levels>
      <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" AllowUpload="false" /></px:PXGrid></px:PXSmartPanel>

    <px:PXSmartPanel ID="PanelAddNCLine" runat="server" Height="500px" Width="1100px" Caption="Add Line Details" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="QCOrderLotDetailsSmartPanel" Style="position: static"
        AutoCallBack-Target="AddLine Grid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="gridOL" runat="server" Height="50px" Width="100%" DataSourceID="ds" AutoAdjustColumns="true" PageSize="200" SkinID="Inquire">
            <AutoSize Enabled="true" />
            <Levels>
                <px:PXGridLevel DataMember="QCOrderLotDetailsSmartPanel">
                    <Columns>
                        <px:PXGridColumn DataField="SerialNumber">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="BaseWarehouseID" Width="180px">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="BaseLocationID" Width="180px">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheck" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true" AllowCheckAll="true">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
            <AutoSize Enabled="true" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel13" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton4" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitSerialNo" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="PXButton5" runat="server" DialogResult="No" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>

<asp:Content ID="cont4" ContentPlaceHolderID="phDialogs" runat="server">
    <%--    <px:PXSmartPanel ID="pnlTestSteps1" runat="server" Height="500px" Width="1100px" Caption="QC Tool" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ToolSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel11" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>--%>

    <px:PXSmartPanel ID="AttributePanel" runat="server" Width="720px" Height="360px" Caption="Tools" CaptionVisible="True"
        AutoCallBack-Command="Refresh" AutoCallBack-Target="AttributesGrid" DesignView="Content">
        <px:PXGrid ID="AttributesGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="OrderToolSteps">
                    <RowTemplate>
                        <px:PXSelector ID="edToolGaugeID" runat="server" DataField="ToolGaugeID">
                            <GridProperties FastFilterFields="ToolGaugeID, Description" />
                        </px:PXSelector>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="AttributeButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="AttributeSaveButton" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
            <px:PXButton ID="AttributeCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
                <AutoCallBack Command="CancelQCTools" Target="ds"></AutoCallBack>
            </px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

</asp:Content>

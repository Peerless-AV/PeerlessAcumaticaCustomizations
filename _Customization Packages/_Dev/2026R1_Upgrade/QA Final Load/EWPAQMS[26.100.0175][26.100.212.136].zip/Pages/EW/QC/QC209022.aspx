﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209022.aspx.cs" Inherits="Page_QC209022" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="server">
    <px:PXDataSource ID="ds" runat="server" TypeName="EW.QC.EWQCTnCDisplay" PrimaryView="TnCOrder" visible="True" attributesfound="False" enableattributes="False" suspendunloading="False">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="server">            
    <px:PXGrid ID="gridTnCOrder" runat="server" SyncPosition="True" DataSourceID="ds" Width="100%" AutoAdjustColumns="true" AllowPaging="true" height="400px" style="z-index: 100"
        allowsearch="True" adjustpagesize="Auto" tabindex="3200" bpeventsindicator="True">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="TnCOrderCD" DataMember="TnCOrder">
                <Columns>
                    <px:PXGridColumn DataField="ToolID" LinkCommand="ViewToolID" CommitChanges="true" Width="364px" />
                    <px:PXGridColumn DataField="ToolSource" Width="364px" CommitChanges="true" />
                    <px:PXGridColumn DataField="TnCOrderCD" LinkCommand="RefOrderNbr" Width="365px" CommitChanges="true" />
                    <px:PXGridColumn DataField="Status" Width="364px" CommitChanges="true" />
                    <px:PXGridColumn DataField="CalibrationScheduledType" Width="364px" CommitChanges="true" />
                </Columns>
                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
            </px:PXGridLevel>
        </Levels>
        <AutoCallBack Target="gridTnCOrder" Command="Refresh">
            <Behavior RepaintControlsIDs="gridTnCOrder" />
        </AutoCallBack>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
</asp:Content>

using EW.QC;
using PX.Data;
using System;
using System.Drawing;
using System.Web.UI.WebControls;


public partial class Page_QC505702:PX.Web.UI.PXPage {
	protected void Page_Init(object sender, EventArgs e) {

	}
}

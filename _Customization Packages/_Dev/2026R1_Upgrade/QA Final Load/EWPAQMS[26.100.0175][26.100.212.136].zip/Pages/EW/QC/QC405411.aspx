<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC405411.aspx.cs" Inherits="Page_QC405411" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" typename="EW.QC.EWQCBOMCompareInq" primaryview="Filter">
        <DataTrees>
            <px:PXTreeDataMember TreeView="Tree1" TreeKeys="ParentID, LineNbr, CategoryNbr, DetailLineNbr" />
            <px:PXTreeDataMember TreeView="Tree2" TreeKeys="ParentID, LineNbr, CategoryNbr, DetailLineNbr" />
        </DataTrees>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <style type="text/css">
        .HighlightText {
            background-color: yellow !important;
        }
    </style>
    <px:pxformview id="form" runat="server" width="100%" caption="BOM of Material" datamember="Filter" datasourceid="ds"
        notifyindicator="True" noteindicator="true" filesindicator="True" activityindicator="True" activityfield="NoteActivity" defaultcontrolid="edBOMID1" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule ID="PXLayoutRule15" runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M" ColumnWidth="500px" />
            <px:PXDropDown ID="edIDType1" runat="server" CommitChanges="true" DataField="IDType1" />
            <px:PXSelector ID="edBOMID1" runat="server" AutoRefresh="True" DataField="BOMID1" DataSourceID="ds" CommitChanges="true" FilterByAllFields="True" />
            <px:PXSelector ID="edRevisionID1" runat="server" DataField="RevisionID1" CommitChanges="True" AutoRefresh="True" DataSourceID="ds" AllowEdit="True" />
            <px:PXSelector ID="edECRID1" runat="server" AutoRefresh="True" DataField="ECRID1" DataSourceID="ds" CommitChanges="true" FilterByAllFields="True" />
            <px:PXSelector ID="edECOID1" runat="server" AutoRefresh="True" DataField="ECOID1" DataSourceID="ds" CommitChanges="true" FilterByAllFields="True" />
            <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M" />
            <px:PXDropDown ID="edIDType2" runat="server" CommitChanges="true" DataField="IDType2" />
            <px:PXSelector ID="edBOMID2" runat="server" AutoRefresh="True" DataField="BOMID2" DataSourceID="ds" CommitChanges="true" FilterByAllFields="True" />
            <px:PXSelector ID="edRevisionID2" runat="server" DataField="RevisionID2" CommitChanges="True" AutoRefresh="True" DataSourceID="ds" AllowEdit="True" />
            <px:PXSelector ID="edECRID2" runat="server" AutoRefresh="True" DataField="ECRID2" DataSourceID="ds" CommitChanges="true" FilterByAllFields="True" />
            <px:PXSelector ID="edECOID2" runat="server" AutoRefresh="True" DataField="ECOID2" DataSourceID="ds" CommitChanges="true" FilterByAllFields="True" />
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxsplitcontainer runat="server" id="sp1" splitterposition="400" skinid="Horizontal">
        <AutoSize Enabled="true" Container="Window" />
        <Template1>
            <px:PXSplitContainer runat="server" ID="sp2" SplitterPosition="500">
                <AutoSize Enabled="true" Container="Window" />
                <Template1>
                    <px:PXTreeView ID="edTree1" runat="server" DataSourceID="ds" PopulateOnDemand="True" RootNodeText="BOM" ExpandDepth="4" SelectFirstNode="true"
                        ShowRootNode="false" Caption="Features" CaptionVisible="false" AllowCollapse="true" DataMember="Tree1" AutoRepaint="true">
                        <DataBindings>
                            <px:PXTreeItemBinding DataMember="Tree1" TextField="Label" ValueField="DetailLineNbr" ImageUrlField="Icon" ToolTipField="ToolTip" />
                        </DataBindings>
                        <AutoCallBack Command="Refresh" Target="gridMatl" ActiveBehavior="true">
                            <Behavior RepaintControlsIDs="gridMatl,gridStep,gridTool,gridOvhd,gridQcTest,GrdInspectionPlans,EWQCGridChecklistGroups"/>
                        </AutoCallBack>
                        <AutoSize Enabled="True" />
                    </px:PXTreeView>
                </Template1>
                <Template2>
                    <px:PXTreeView ID="edTree2" runat="server" DataSourceID="ds" PopulateOnDemand="True" RootNodeText="BOM" ExpandDepth="4" SelectFirstNode="true"
                        ShowRootNode="false" Caption="Features" CaptionVisible="false" AllowCollapse="False" DataMember="Tree2" AutoRepaint="true">
                        <DataBindings>
                            <px:PXTreeItemBinding DataMember="Tree2" TextField="Label" ValueField="DetailLineNbr" ImageUrlField="Icon" ToolTipField="ToolTip" />
                        </DataBindings>
                        <AutoCallBack Command="Refresh" Target="gridMatl" ActiveBehavior="true">
                            <Behavior RepaintControlsIDs="gridMatl,gridStep,gridTool,gridOvhd,gridQcTest,GrdInspectionPlans,EWQCGridChecklistGroups" />
                        </AutoCallBack>
                        <AutoSize Enabled="True" />
                    </px:PXTreeView>
                </Template2>
            </px:PXSplitContainer>
        </Template1>
        <Template2>
            <px:PXTab ID="tab" runat="server" Width="100%" Height="100%">
                <Items>
                    <px:PXTabItem Text="Materials" LoadOnDemand="True" RepaintOnDemand="True">
                        <Template>
                            <px:PXGrid ID="gridMatl" runat="server" DataSourceID="ds" Width="100%" SkinID="DetailsInTab" SyncPosition="True" OnRowDataBound="AMBomMatl_RowDataBound">
                                <Levels>
                                    <px:PXGridLevel DataMember="BomMatlRecords" SortOrder="Selected">
                                        <RowTemplate>
                                            <px:PXLayoutRule ID="PXLayoutRule5" runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                                            <px:PXTextEdit ID="edBOMIDmatl" runat="server" DataField="BOMID" />
                                            <px:PXTextEdit ID="edRevisionIDmatl" runat="server" DataField="RevisionID" />
                                            <px:PXTextEdit ID="edOperationIDmatl" runat="server" DataField="OperationID" />
                                            <px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID" />
                                            <px:PXSegmentMask ID="edSubItemID" runat="server" DataField="SubItemID" />
                                            <px:PXTextEdit ID="edDescrMat" runat="server" DataField="Descr" />
                                            <px:PXNumberEdit ID="edQtyReq" runat="server" DataField="QtyReq" />
                                            <px:PXNumberEdit ID="edBatchSize" runat="server" DataField="BatchSize" />
                                            <px:PXSelector ID="edUOM" runat="server" DataField="UOM" AutoRefresh="True" />
                                            <px:PXNumberEdit ID="edUnitCost" runat="server" DataField="UnitCost" />
                                            <px:PXNumberEdit ID="edMatlPlanCost" runat="server" DataField="PlanCost" />
                                            <px:PXDropDown ID="edMaterialType" runat="server" AllowNull="False" DataField="MaterialType" />
                                            <px:PXDropDown ID="edPhtmRtngIorE" runat="server" AllowNull="False" DataField="PhantomRouting" />
                                            <px:PXCheckBox ID="chkBFlush1" runat="server" DataField="BFlush" />
                                            <px:PXSegmentMask ID="edSiteID" runat="server" DataField="SiteID" />
                                            <px:PXTextEdit ID="edCompBOMID" runat="server" DataField="CompBOMID" AutoRefresh="True" />
                                            <px:PXTextEdit ID="edCompBOMRevisionID" runat="server" DataField="CompBOMRevisionID" AutoRefresh="True" />
                                            <px:PXSegmentMask ID="edLocationID" runat="server" DataField="LocationID" />
                                            <px:PXNumberEdit ID="edScrapFactor" runat="server" DataField="ScrapFactor" />
                                            <px:PXTextEdit ID="edBubbleNbr" runat="server" DataField="BubbleNbr" />
                                            <px:PXDateTimeEdit ID="edEffDate" runat="server" DataField="EffDate" />
                                            <px:PXDateTimeEdit ID="edExpDate" runat="server" DataField="ExpDate" />
                                            <px:PXNumberEdit ID="edLineIDmatl" runat="server" DataField="LineID" />
                                            <px:PXDropDown ID="edMatlRowStatus" runat="server" DataField="RowStatus" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="LineID" Width="54px" />
                                            <px:PXGridColumn DataField="SortOrder" Width="54px" />
                                            <px:PXGridColumn DataField="BOMID" Width="130px" />
                                            <px:PXGridColumn DataField="RevisionID" Width="130px" />
                                            <px:PXGridColumn DataField="InventoryID" Width="130px" />
                                            <px:PXGridColumn DataField="OperationID" Width="81px" />
                                            <px:PXGridColumn DataField="SubItemID" Width="81px" />
                                            <px:PXGridColumn DataField="Descr" MaxLength="255" Width="200px" />
                                            <px:PXGridColumn DataField="QtyReq" Width="108px" />
                                            <px:PXGridColumn DataField="BatchSize" Width="108px" />
                                            <px:PXGridColumn DataField="UOM" Width="81px" AutoCallBack="True" />
                                            <px:PXGridColumn DataField="UnitCost" Width="108px" />
                                            <px:PXGridColumn DataField="PlanCost" Width="100px" />
                                            <px:PXGridColumn DataField="MaterialType" Width="100px" />
                                            <px:PXGridColumn DataField="PhantomRouting" Width="110px" />
                                            <px:PXGridColumn DataField="BFlush" TextAlign="Center" Type="CheckBox" Width="85px" />
                                            <px:PXGridColumn DataField="SiteID" Width="130px" />
                                            <px:PXGridColumn DataField="CompBOMID" />
                                            <px:PXGridColumn DataField="CompBOMRevisionID" Width="85px" />
                                            <px:PXGridColumn DataField="LocationID" Width="130px" />
                                            <px:PXGridColumn DataField="ScrapFactor" Width="108px" />
                                            <px:PXGridColumn DataField="BubbleNbr" Width="90px" />
                                            <px:PXGridColumn DataField="EffDate" Width="85px" />
                                            <px:PXGridColumn DataField="ExpDate" Width="85px" />
                                            <px:PXGridColumn DataField="RowStatus" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue" />
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue" />
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
                                <AutoSize Enabled="True" />
                                <ActionBar ActionsText="False"></ActionBar>
                            </px:PXGrid>
                        </Template>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Steps" LoadOnDemand="True" RepaintOnDemand="True">
                        <Template>
                            <px:PXGrid ID="gridStep" runat="server" DataSourceID="ds" Height="150px" Width="100%" SkinID="DetailsInTab" OnRowDataBound="AMBomStep_RowDataBound">
                                <Levels>
                                    <px:PXGridLevel DataMember="BomStepRecords" SortOrder="Selected">
                                        <RowTemplate>
                                            <px:PXLayoutRule ID="PXLayoutRule8" runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" Merge="true" />
                                            <px:PXTextEdit ID="edsBOMID" runat="server" DataField="BOMID" />
                                            <px:PXTextEdit ID="edsRevisionID" runat="server" DataField="RevisionID" />
                                            <px:PXTextEdit ID="edsOperationID" runat="server" DataField="OperationID" />
                                            <px:PXTextEdit Size="xl" ID="edStepDescr" runat="server" AllowNull="False" DataField="Descr" />
                                            <px:PXDropDown ID="edStepRowStatus" runat="server" DataField="RowStatus" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="BOMID" Width="130px" />
                                            <px:PXGridColumn DataField="RevisionID" Width="130px" />
                                            <px:PXGridColumn DataField="OperationID" Width="81px" />
                                            <px:PXGridColumn AllowNull="False" DataField="Descr" Width="351px" />
                                            <px:PXGridColumn DataField="LineID" Visible="False" />
                                            <px:PXGridColumn DataField="RowStatus" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue" />
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue" />
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
                                <AutoSize Enabled="True" />
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                            </px:PXGrid>
                        </Template>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Tools" LoadOnDemand="True" RepaintOnDemand="True">
                        <Template>
                            <px:PXGrid ID="gridTool" runat="server" DataSourceID="ds" Height="150px" Width="100%" SkinID="DetailsInTab" OnRowDataBound="AMBomTool_RowDataBound">
                                <Levels>
                                    <px:PXGridLevel DataMember="BomToolRecords" SortOrder="Selected">
                                        <RowTemplate>
                                            <px:PXLayoutRule ID="PXLayoutRule9" runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                                            <px:PXTextEdit ID="edtBOMID" runat="server" DataField="BOMID" />
                                            <px:PXTextEdit ID="edtRevisionID" runat="server" DataField="RevisionID" />
                                            <px:PXTextEdit ID="edtOperationID" runat="server" DataField="OperationID" />
                                            <px:PXSelector ID="edToolID" runat="server" DataField="ToolID" DataKeyNames="ToolID" DataSourceID="ds" AllowEdit="True" />
                                            <px:PXTextEdit ID="edToolDescr" runat="server" DataField="AMToolMst__Descr" />
                                            <px:PXNumberEdit Size="s" ID="edToolQtyReq" runat="server" DataField="QtyReq" />
                                            <px:PXNumberEdit Size="s" ID="edToolUnitCost" runat="server" DataField="UnitCost" />
                                            <px:PXDropDown ID="edToolRowStatus" runat="server" DataField="RowStatus" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="BOMID" Width="130px" />
                                            <px:PXGridColumn DataField="RevisionID" Width="130px" />
                                            <px:PXGridColumn DataField="OperationID" Width="81px" />
                                            <px:PXGridColumn DataField="LineID" Visible="False" />
                                            <px:PXGridColumn AllowNull="False" DataField="ToolID" Width="180px" />
                                            <px:PXGridColumn AllowNull="False" DataField="Descr" Width="351px" />
                                            <px:PXGridColumn AllowNull="False" DataField="QtyReq" Width="117px" />
                                            <px:PXGridColumn AllowNull="False" DataField="UnitCost" Width="117px" />
                                            <px:PXGridColumn DataField="RowStatus" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue" />
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue" />
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
                                <AutoSize Enabled="True" />
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                            </px:PXGrid>
                        </Template>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Overhead" LoadOnDemand="True" RepaintOnDemand="True">
                        <Template>
                            <px:PXGrid ID="gridOvhd" runat="server" DataSourceID="ds" Height="150px" Width="100%" SkinID="DetailsInTab" OnRowDataBound="AMBomOvhd_RowDataBound">
                                <Levels>
                                    <px:PXGridLevel DataMember="BomOvhdRecords" SortOrder="Selected">
                                        <RowTemplate>
                                            <px:PXLayoutRule ID="PXLayoutRule13" runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                                            <px:PXTextEdit ID="edoBOMID" runat="server" DataField="BOMID" />
                                            <px:PXTextEdit ID="edoRevisionID" runat="server" DataField="RevisionID" />
                                            <px:PXTextEdit ID="edoOperationID" runat="server" DataField="OperationID" />
                                            <px:PXSelector ID="edOvhdID" runat="server" AllowNull="False" DataField="OvhdID" DataKeyNames="OvhdID" AllowEdit="True" />
                                            <px:PXTextEdit ID="edAMOverhead__Descr" runat="server" AllowNull="False" DataField="AMOverhead__Descr" />
                                            <px:PXDropDown ID="edAMOverhead__OvhdType" runat="server" AllowNull="False" DataField="AMOverhead__OvhdType" />
                                            <px:PXNumberEdit ID="edOFactor" runat="server" DataField="OFactor" />
                                            <px:PXDropDown ID="edOvhdRowStatus" runat="server" DataField="RowStatus" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="BOMID" Width="130px" />
                                            <px:PXGridColumn DataField="RevisionID" Width="130px" />
                                            <px:PXGridColumn DataField="OperationID" Width="81px" />
                                            <px:PXGridColumn DataField="LineID" Visible="False" />
                                            <px:PXGridColumn DataField="OvhdID" Width="81px" />
                                            <px:PXGridColumn DataField="AMOverhead__Descr" AllowNull="False" Width="351px" />
                                            <px:PXGridColumn DataField="AMOverhead__OvhdType" Width="198px" RenderEditorText="True" />
                                            <px:PXGridColumn DataField="OFactor" AllowNull="False" Width="117px" />
                                            <px:PXGridColumn DataField="RowStatus" />
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue" />
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue" />
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" />
                                <AutoSize Enabled="True" />
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                            </px:PXGrid>
                        </Template>
                    </px:PXTabItem>

                    <px:PXTabItem Text="QC Test" LoadOnDemand="True" RepaintOnDemand="True">
                        <Template>
                            <px:PXGrid ID="gridQcTest" runat="server" DataSourceID="ds" Height="150px" Width="100%" SkinID="DetailsInTab" OnRowDataBound="EWQCBOMOperVariable_RowDataBound">
                                <Levels>
                                    <px:PXGridLevel DataMember="EWQCBOMVariableRecords" SortOrder="Selected">

                                        <RowTemplate>
                                            <px:PXSelector runat="server" DataField="VariableID" ID="edEWQCVariableID">
                                                <GridProperties FastFilterFields="VariableCD,Name" />
                                            </px:PXSelector>
                                            <px:PXSelector runat="server" DataField="ToolGaugeID" ID="edEWQCToolGaugeID">
                                                <GridProperties FastFilterFields="ToolGaugeCD,Description" />
                                            </px:PXSelector>
                                            <px:PXSelector runat="server" DataField="SeverityLevel" ID="edEWQCSeverityLevel">
                                                <GridProperties FastFilterFields="Name,Description" />
                                            </px:PXSelector>
                                            <px:PXSelector runat="server" DataField="TestGroupID" ID="edEWQCTestGroupID">
                                                <GridProperties FastFilterFields="Name,Description" />
                                            </px:PXSelector>
                                            <px:PXDropDown ID="edOrderLevelPlan" runat="server" CommitChanges="true" DataField="OrderLevel" />
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="LineNbr" Width="70" />
                                            <px:PXGridColumn DataField="AddInReports" Width="60" TextAlign="Center" Type="CheckBox" />
                                            <px:PXGridColumn DataField="VariableID" Width="180" CommitChanges="True" LinkCommand="EWQCViewTestMaster" />
                                            <px:PXGridColumn DataField="ToolGaugeID" Width="180" LinkCommand="EWQCViewEquipmentMaster" />
                                                <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                      </px:PXGridColumn>
                                            <px:PXGridColumn DataField="TestGroupID" Width="180" CommitChanges="True" LinkCommand="EWQCViewTestGroupMaster" />
                                            <px:PXGridColumn DataField="SeverityLevel" Width="180" CommitChanges="True" LinkCommand="EWQCViewSeverityMaster" />
                                            <px:PXGridColumn DataField="NumTargetValue" Width="100" />
                                            <px:PXGridColumn DataField="NumMinValue" Width="100" CommitChanges="True" />
                                            <px:PXGridColumn DataField="NumMaxValue" Width="100" CommitChanges="True" />
                                            <px:PXGridColumn DataField="EWQCVariable__Unit" Width="280" />
                                            <px:PXGridColumn DataField="EWQCTestMethod__Name" Width="180" LinkCommand="EWQCViewTestMethod" />
                                            <px:PXGridColumn DataField="EWQCTestCategory__Name" Width="180" LinkCommand="EWQCViewTestCategoryMaster" />
                                            <px:PXGridColumn DataField="BitGoNoGo" Width="60" TextAlign="Center" Type="CheckBox" />
                                            <px:PXGridColumn DataField="AlphaValue" Width="220" />
                                            <px:PXGridColumn DataField="Equation" Width="70" />
                                            <px:PXGridColumn DataField="OptionalTest" Width="100" TextAlign="Center" Type="CheckBox" />
                                            <px:PXGridColumn DataField="OrderLevel" Width="100" CommitChanges="True" />
                                            <px:PXGridColumn DataField="LeadTimeDurationType" Width="150" />
                                            <px:PXGridColumn DataField="LeadTimeDuration" Width="150" />
                                          
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue"></px:PXControlParam>
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue"></px:PXControlParam>
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false"></Mode>
                                <AutoSize Enabled="True"></AutoSize>
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                            </px:PXGrid>
                        </Template>
                    </px:PXTabItem>
                    <%--     // inspection plan--%>
                    <px:PXTabItem LoadOnDemand="True" RepaintOnDemand="True" Text="Inspection Plans">
                        <Template>
                            <px:PXSplitContainer runat="server" ID="splitConditions" Orientation="Vertical" SplitterPosition="20" Panel1MinSize="100" Panel2MinSize="250" PositionInPercent="True">
                                <AutoSize Container="Window" Enabled="true" />
                                <Template1>
                                    <px:PXGrid runat="server" ID="GrdInspectionPlans" SyncPosition="True" KeepPosition="True" Height="180PX" SkinID="DetailsInTab" Width="100%" DataSourceID="ds" AllowPaging="False">
                                        <ContentLayout Orientation="Horizontal" />
                                        <Levels>
                                            <px:PXGridLevel DataMember="EWQCInspectionPlanDetail">
                                                <Columns>
                                                    <px:PXGridColumn DataField="PlanID" Width="150" CommitChanges="True" />
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                        <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue"></px:PXControlParam>
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue"></px:PXControlParam>
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false"></Mode>
                                <AutoSize Enabled="True"></AutoSize>
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                                        <AutoCallBack ActiveBehavior="True" Command="Refresh">
                                            <Behavior RepaintControlsIDs="GrdInspectionTest" />
                                        </AutoCallBack>
                                    </px:PXGrid>
                                </Template1>
                                <Template2>
                                    <px:PXGrid runat="server" ID="GrdInspectionTest" SyncPosition="True" KeepPosition="True" Height="150PX" Width="100%" Caption="Tests" DataSourceID="ds">
                                        <AutoSize Enabled="True" MinHeight="150" />
                                        <ContentLayout Orientation="Horizontal" />
                                        <Levels>
                                            <px:PXGridLevel DataMember="EWQCAssociateInspectionPlanVariables">
                                                 <RowTemplate>
<px:PXDropDown runat="server" ID="edOrderLevelInspection" DataField="OrderLevel" CommitChanges="true" />
</RowTemplate>
                                                <Columns>
                                                    <px:PXGridColumn DataField="AddInReports" Width="60" TextAlign="Center" Type="CheckBox" />
                                                    <px:PXGridColumn DataField="VariableID" Width="100" LinkCommand="EWQCViewTestMaster" />
                                                    <px:PXGridColumn DataField="EWQCVariable__TestMethodID" Width="180" />
                                                    <px:PXGridColumn DataField="EWQCVariable__TestCategoryID" Width="180" />
                                                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="70" />
                                                    <px:PXGridColumn DataField="TestGroupID" Width="100" LinkCommand="EWQCViewTestGroupMaster" />
                                                    <px:PXGridColumn DataField="ToolGaugeID" Width="180" LinkCommand="EWQCViewEquipmentMaster" />
                                                        <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolInspectionSteps" CommitChanges="true">
                                      </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="NumMinValue" Width="80" />
                                                    <px:PXGridColumn DataField="NumTargetValue" Width="100" />
                                                    <px:PXGridColumn DataField="NumMaxValue" Width="80" />
                                                    <px:PXGridColumn DataField="BitGoNoGo" Width="60" TextAlign="Center" Type="CheckBox" />
                                                    <px:PXGridColumn DataField="AlphaValue" Width="150" />
                                                    <px:PXGridColumn DataField="LineNbr" Width="70" />
                                                    <px:PXGridColumn DataField="OptionalTest" Width="100" TextAlign="Center" Type="CheckBox" />
                                                    <px:PXGridColumn DataField="OrderLevel" Width="100" CommitChanges="true" />
                                                    <px:PXGridColumn DataField="EWQCVariable__Unit" Width="70" />
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                         <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue"></px:PXControlParam>
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue"></px:PXControlParam>
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false"></Mode>
                                <AutoSize Enabled="True"></AutoSize>
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                                    </px:PXGrid>
                                </Template2>
                            </px:PXSplitContainer>
                        </Template>
                    </px:PXTabItem>
                  <px:PXTabItem Text="Checklist Group" LoadOnDemand="True" RepaintOnDemand="True">
                        <Template>
                            <px:PXSplitContainer runat="server" Orientation="Vertical" Panel1MinSize="100" Panel2MinSize="250" SplitterPosition="20" PositionInPercent="True" ID="splitConditionChkList">
                                <AutoSize Enabled="true" Container="Window" />
                                <Template1>
                                    <px:PXGrid runat="server" SyncPosition="True" Height="150px" SkinID="DetailsInTab" Width="100%" ID="EWQCGridChecklistGroups">
                                        <AutoSize Enabled="True" MinHeight="150" />
                                        <AutoCallBack Enabled="True" ActiveBehavior="True" Command="Refresh" Target="">
                                            <Behavior RepaintControlsIDs="GrdEWQCChecklistBOM" />
                                        </AutoCallBack>
                                        <Levels>
                                            <px:PXGridLevel DataMember="EWQCAssociateChecklistGroups">
                                                <Columns>
                                                    <px:PXGridColumn DataField="ChecklistGroupID" Width="180" CommitChanges="True" />
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                          <AutoSize Container="Parent" Enabled="True" MinHeight="150" />
                                             <Parameters>
                                    <px:PXControlParam ControlID="edTree1" Name="detailLineNbr1" PropertyName="SelectedValue"></px:PXControlParam>
                                    <px:PXControlParam ControlID="edTree2" Name="detailLineNbr2" PropertyName="SelectedValue"></px:PXControlParam>
                                </Parameters>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false"></Mode>
                                <AutoSize Enabled="True"></AutoSize>
                                <ActionBar ActionsText="False">
                                </ActionBar>
                                <AutoCallBack>
                                </AutoCallBack>
                                    </px:PXGrid>
                                </Template1>
                                <Template2>
                                    <px:PXGrid runat="server" ID="GrdEWQCChecklistBOM" Height="150PX" SyncPosition="True" KeepPosition="True" DataSourceID="ds">
                                        <Levels>
                                            <px:PXGridLevel DataMember="EWQCAssociateChecklistGroupVariables">
                                                <Columns>
                                                    <px:PXGridColumn DataField="ChecklistID" Width="180" LinkCommand="ViewCheckListItem" />
                                                    <px:PXGridColumn DataField="EWQCChecklist__Name" Width="180" />
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                      
                                    </px:PXGrid>
                                </Template2>
                            </px:PXSplitContainer>
                        </Template>
                    </px:PXTabItem>
                              
                    </Items>
                  <AutoSize Enabled="True" />
            </px:PXTab>
        </Template2>
    </px:pxsplitcontainer>

</asp:Content>
<asp:Content ID="cont4" ContentPlaceHolderID="phDialogs" runat="server">
    <px:pxsmartpanel id="pnlTestSteps1" runat="server" height="500px" width="1100px" caption="QC Tool" captionvisible="true" autoreload="true" loadondemand="true" key="ToolSteps" style="position: static"
        autocallback-target="StepsGrid1" autocallback-command="Refresh" designview="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel11" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>

    <px:pxsmartpanel id="PXSmartPanel2" runat="server" height="500px" width="1100px" caption="QC Tool" captionvisible="true" autoreload="true" loadondemand="true" key="ToolSteps" style="position: static"
        autocallback-target="StepsGrid3" autocallback-command="Refresh" designview="Content">
        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolInspectionSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel18" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton19" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>

</asp:Content>


<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC204000.aspx.cs" Inherits="Page_QC204000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" typename="EW.QC.EWQCVariableMaint" attributesfound="False" enableattributes="true" primaryview="Variables" suspendunloading="False" pageloadbehavior="GoLastRecord">
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="Variables" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edVariableCD" runat="server" AlreadyLocalized="False" DataField="VariableCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>
            <px:PXDropDown ID="edDataType" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="DataType">
            </px:PXDropDown>
            <px:PXSelector ID="edTestCategoryID" runat="server" AlreadyLocalized="False" DataField="TestCategoryID" AllowEdit="true">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>  <px:PXSelector ID="edTestMethodID" runat="server" AlreadyLocalized="False" DataField="TestMethodID" AllowEdit="true">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="SM" ControlSize="XM"> 
            </px:PXLayoutRule>
           <%-- <px:PXSelector ID="edTestMethodID" runat="server" AlreadyLocalized="False" DataField="TestMethodID" AllowEdit="true">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>--%>
           <%-- <px:PXSelector ID="edToolGaugeID" runat="server" AlreadyLocalized="False" DataField="ToolGaugeID" AllowEdit="true">
                <GridProperties FastFilterFields="ToolGaugeCD,Description"></GridProperties>
            </px:PXSelector>--%>
                <pxa:PXFormulaCombo ID="edChildField" runat="server" DataField="Equation" EditButton="True" FieldsAutoRefresh="True"
												FieldsRootAutoRefresh="true" LastNodeName="Fields" PanelAutoRefresh="True" IsInternalVisible="false"
												IsExternalVisible="false" OnRootFieldsNeeded="edOns_RootFieldsNeeded" CommitChanges="true"/>            
            <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AutoRefresh="true" AlreadyLocalized="False" DataField="LeadTimeDurationType">
            </px:PXDropDown>
            <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
            </px:PXTextEdit> 
             <px:PXNumberEdit ID="edSampleSize" Width="100%" runat="server" AlreadyLocalized="False" DataField="SampleSize">
            </px:PXNumberEdit>
            <px:PXTextEdit ID="edRemarks" runat="server" AlreadyLocalized="False" DataField="Remarks" Height="50" TextMode="MultiLine">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="SM" ControlSize="XM"> 
</px:PXLayoutRule>
            <px:PXSelector ID="edUnit" runat="server" AllowEdit="True" CommitChanges="True" DataField="Unit" Style="margin-right:30px"></px:PXSelector>
            <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
            </px:PXTextEdit>          
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="SM" ControlSize="XM"> 
            </px:PXLayoutRule>           
            <px:PXDropDown ID="edOrderLevel" runat="server" AutoRefresh="true" AlreadyLocalized="False" DataField="OrderLevel">
            </px:PXDropDown>
                <px:PXSelector runat="server" ID="edUsrEWQCLTAttributeID" DataField="AttributeID" AutoRefresh="true" CommitChanges="true">
    <GridProperties FastFilterFields="AttributeID,Description" /></px:PXSelector>
                <px:PXCheckBox ID="edOptionalTest" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="OptionalTest" Text="Optional Test">
    </px:PXCheckBox>
     <px:PXCheckBox ID="edDestructiveTesting" runat="server" AlignLeft="true" AlreadyLocalized="False" CommitChanges="true" DataField="DestructiveTesting" Text="Destructive Testing">
    </px:PXCheckBox> 
            <%-- <px:PXTextEdit ID="edTextEditEquation" runat="server" AlreadyLocalized="False" DataField="Equation">
            </px:PXTextEdit>--%>
        
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">

    <px:pxtab id="tab" runat="server" height="150px" style="z-index: 100;" width="100%">
        <Items>
            <px:PXTabItem Text="Test Steps">
                <Template>

                    <px:PXGrid ID="detailGrid" runat="server" DataSourceID="ds" SkinID="Details"
                         Width="100%" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="TestStepID,TestID" DataMember="TestSteps">
                                <RowTemplate>
                                    <px:PXTextEdit ID="edName1" runat="server" AlreadyLocalized="False" DataField="Name">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescription1" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="Name">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LineNbr">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Parameters">
                <Template>

                    <px:PXGrid ID="parameterGrid" runat="server" DataSourceID="ds" SkinID="Details"
                         Width="100%" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="TestParameterCD,TestID" DataMember="TestParameters">
                                <RowTemplate>
                                    <px:PXTextEdit ID="edTestParameterCD" runat="server" AlreadyLocalized="False" DataField="TestParameterCD" >
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescriptionParameter" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>
                                    <px:PXDropDown ID="edDataType" runat="server" AlreadyLocalized="False" DataField="DataType">
                                    </px:PXDropDown>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="TestParameterCD" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DataType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
                <px:PXTabItem Text="QC Tools">
                <Template>
                    <px:PXGrid ID="detailGrid" runat="server" DataSourceID="ds" SkinID="Details"
                         Width="100%" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="TestToolID,TestID" DataMember="TestTool">
                                <RowTemplate>
                                    <px:PXSelector ID="edToolName1" runat="server" AlreadyLocalized="False" DataField="ToolGaugeID">
                                            <GridProperties FastFilterFields="ToolGaugeCD,Description"></GridProperties>
                                    </px:PXSelector> 
                                       <px:PXTextEdit ID="edDescription2" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edLineNbr2" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                 <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true" >
                                    </px:PXGridColumn>
                                        <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LineNbr">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="20" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="COMBO VALUES" VisibleExp="DataControls[&quot;edDataType&quot;].Value == C" BindingContext="form">
                <Template>

                    <px:PXGrid ID="comboGrid" runat="server" DataSourceID="ds" SkinID="Details"
                         Width="100%" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="TestComboCD,TestID" DataMember="TestComboValues">
                                <RowTemplate>
                                    <px:PXTextEdit ID="edTestComboCD" runat="server" AlreadyLocalized="False" DataField="TestComboCD">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescriptionCombo" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>     
                                    <%--<px:PXCheckBox ID="edComboCheck" runat="server" AlignLeft="true" AlreadyLocalized="False" DataField="ComboCheck" CommitChanges ="true" Text="Optional Test">
            </px:PXCheckBox>--%>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="TestComboCD">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <%--<px:PXGridColumn DataField="ComboCheck" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges ="true">
                                    </px:PXGridColumn>  --%>  
                                    
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">

                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>
</asp:Content>

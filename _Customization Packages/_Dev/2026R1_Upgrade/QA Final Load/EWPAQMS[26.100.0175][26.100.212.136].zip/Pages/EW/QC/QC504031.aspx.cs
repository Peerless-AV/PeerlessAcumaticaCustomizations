﻿using EW.QC;
using PX.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_QC504031:PX.Web.UI.PXPage {
  protected void Page_Load(object sender, EventArgs e) {

    //EWQCToolsManagementProcess processGraph = PXGraph.CreateInstance<EWQCToolsManagementProcess>();
    //processGraph.ToolManagementdata();

  }
}
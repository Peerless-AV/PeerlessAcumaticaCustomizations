<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC405415.aspx.cs" Inherits="Page_QC405415" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" AttributesFound="False" PrimaryView="Plan" SuspendUnloading="False" TypeName="EW.QC.EWQCPlanResultCriteria" PageLoadBehavior="InsertRecord">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" Width="100%" DataMember="Plan" DataSourceID="ds"
        notifyindicator="True" NoteIndicator="true" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" DefaultControlID="edPlan" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule ID="PXLayoutRule15" runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M" ColumnWidth="500px" />
            <px:PXSelector ID="edPlanCD" runat="server" AlreadyLocalized="False" Enabled="false" DataField="PlanCD" AutoRefresh="true" CommitChanges="True">
                <GridProperties FastFilterFields="RevisionNo,Name"></GridProperties>
            </px:PXSelector>
            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
            <px:PXSelector ID="edRevisionNo" Enabled="false" runat="server" AutoRefresh="true" AlreadyLocalized="False" DataField="RevisionNo">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="PXGrid2" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.

Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,SeverityID" DataMember="PlanSeverities">
                <RowTemplate>
                    <px:PXSelector ID="edSeverityID1" runat="server" DataField="SeverityID" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edDefectivesRegorous" runat="server" AlreadyLocalized="False" DataField="DefectivesRegorous">
                    </px:PXSelector>
                    <px:PXSelector ID="edDefectivesModerate" runat="server" AlreadyLocalized="False" DataField="DefectivesModerate">
                    </px:PXSelector>
                    <px:PXSelector ID="edDefectivesFlexible" runat="server" AlreadyLocalized="False" DataField="DefectivesFlexible">
                    </px:PXSelector>
                    <px:PXNumberEdit ID="edRigorousDefects1" runat="server" AlreadyLocalized="False" DataField="RigorousDefects">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="edModerateDefects1" runat="server" AlreadyLocalized="False" DataField="ModerateDefects">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="edFlexibleDefects1" runat="server" AlreadyLocalized="False" DataField="FlexibleDefects">
                    </px:PXNumberEdit>
                </RowTemplate>

                <Columns>
                    <px:PXGridColumn DataField="SeverityID" CommitChanges="True">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="DefectivesRegorous" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="DefectivesModerate" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="DefectivesFlexible" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="RigorousDefects" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ModerateDefects" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="FlexibleDefects" Width="280px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
    </px:PXGrid>
    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" TabIndex="1800" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
        <Levels>
            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,VariableID" DataMember="PlanVariables">
                <RowTemplate>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                    <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports">
                    </px:PXCheckBox>
                    <px:PXSelector ID="edVariableID" runat="server" DataField="VariableID">
                        <GridProperties FastFilterFields="VariableCD,Name"></GridProperties>
                    </px:PXSelector>
                    <px:PXTextEdit ID="edEWQCVariableName" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Name">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Description">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edEquation" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Equation">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edTestGroupID" runat="server" DataField="TestGroupID">
                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                    </px:PXSelector>
                    <px:PXDropDown ID="edDataType" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__DataType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edToolSteps" runat="server" AlreadyLocalized="False" DataField="ToolSteps">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edSeverityLevel" runat="server" DataField="SeverityLevel">
                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                    </px:PXSelector>
                    <px:PXSelector ID="edTestCategoryID" runat="server" DataField="EWQCVariable__TestCategoryID">
                    </px:PXSelector>
                    <px:PXSelector ID="edTestMethodID" runat="server" DataField="EWQCVariable__TestMethodID">
                    </px:PXSelector>
                    <px:PXDropDown ID="edQCOperator" runat="server" AlreadyLocalized="False" DataField="QCOperator">
                    </px:PXDropDown>
                    <px:PXNumberEdit ID="edNumMinValue" runat="server" AlreadyLocalized="False" DataField="NumMinValue">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="edNumMaxValue" runat="server" AlreadyLocalized="False" DataField="NumMaxValue">
                    </px:PXNumberEdit>
                    <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                    </px:PXTextEdit>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                    <px:PXCheckBox ID="edDestructiveTesting" runat="server" AlreadyLocalized="False" DataField="DestructiveTesting" Text="Go/NoGo">
                    </px:PXCheckBox>
                    <px:PXNumberEdit ID="edSampleSize" runat="server" AlreadyLocalized="False" DataField="SampleSize">
                    </px:PXNumberEdit>
                    <px:PXSelector ID="ewqcSelectorUOM" runat="server" DataField="UOM" Style="margin-right: 30px"></px:PXSelector>
                    <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                    </px:PXTextEdit>
                    <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="Go/NoGo">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest">
                    </px:PXCheckBox>
                    <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                    </px:PXDropDown>
                    <px:PXDropDown ID="PXDropDownCalculationType" runat="server" AlreadyLocalized="False" DataField="CalculationType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edComboValue" runat="server" AlreadyLocalized="False" DataField="ComboValue">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>

                    <px:PXGridColumn DataField="VariableID">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Equation" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="TestGroupID" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LineNbr" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__DataType">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ToolSteps" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SeverityLevel">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__TestCategoryID">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__TestMethodID">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="CalculationType">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QCOperator">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="NumMinValue" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="NumMaxValue" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="TestResultUOM" Width="220px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="AlphaValue" Width="220px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="DestructiveTesting" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SampleSize" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="UOM" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="OrderLevel" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ComboValue" Width="280px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
        <Mode InitNewRow="False" AllowFormEdit="False" AllowDragRows="True" AutoInsert="False"></Mode>
    </px:PXGrid>
</asp:Content>


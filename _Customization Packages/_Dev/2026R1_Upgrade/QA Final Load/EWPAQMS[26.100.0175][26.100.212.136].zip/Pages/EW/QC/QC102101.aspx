﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC102101.aspx.cs" Inherits="Page_QC102101" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCServiceQCSetupMaint" PageLoadBehavior="InsertRecord" AttributesFound="False" PrimaryView="Setup" SuspendUnloading="False">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds"  Width="100%" DataMember="Setup"  Height ="100%" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
          <AutoSize Enabled="True" Container="Window" MinHeight="200"></AutoSize>
        <Activity Width="" Height=""></Activity>
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />
             <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="NUMBERING SETTINGS" />
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True"></px:PXLayoutRule>
          <px:PXSelector ID="edServiceQCNumerSequenceID" runat="server" DataField="ServiceQCNumerSequenceID" Size="XL" Width="230" LabelWidth="300" AllowEdit="true">
          </px:PXSelector>
          <px:PXSelector ID="edQCChecklistOrderNumberSequenceID" runat="server" DataField="QCChecklistOrderNumberSequenceID" Size="XL" Width="230" LabelWidth="300" AllowEdit="True">
          </px:PXSelector>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />
               <px:PXLayoutRule runat="server" StartGroup="True"  GroupCaption="Data Entry Settings"  />
                <px:PXCheckBox ID="edErrorRequiredOnServiceQC" runat="server" style="margin-left:22%"  AlreadyLocalized="False" DataField="ErrorRequiredOnServiceQC" Text="Error Required On Service QC" >
                    </px:PXCheckBox>
            <%--<px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Allow By-passing QC" />--%>
              <px:PXCheckBox ID="edEnableServiceQCRequired" runat="server" style="margin-left:22%"  AlreadyLocalized="False" DataField="EnableServiceQCRequired" Text="Service QC">
  </px:PXCheckBox>
        </Template>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXFormView>
</asp:Content>

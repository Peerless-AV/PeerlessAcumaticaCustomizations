<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505701.aspx.cs" Inherits="Page_QC505701" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="False" runat="server" Visible="True" Width="100%" PrimaryView="LotStatusList"
        TypeName="EW.QC.EWQCInvLotQtyProcess">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" BPEventsIndicator="True"
        Width="100%" DataMember="Filter" TabIndex="3700">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" CommitChanges="True" AutoRefresh="true" AllowEdit="true" />
            <px:PXTextEdit ID="edLotSerNumVal" runat="server" DataField="LotSerNumVal" CommitChanges="True" AutoRefresh="true"></px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edWarehouseID" runat="server" DataField="WarehouseID" CommitChanges="True" AutoRefresh="true" />
            <px:PXSelector ID="edLocationID" runat="server" DataField="LocationID" CommitChanges="True" AutoRefresh="true" />
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
        AllowPaging="True" AllowSearch="true" SyncPosition="true" AdjustPageSize="Auto" DataSourceID="ds" SkinID="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataKeyNames="InventoryID,LotSerialNbr,SiteID,LocationID" DataMember="LotStatusList">
                <RowTemplate>
                    <px:PXSelector ID="edInventoryID1" runat="server" DataField="InventoryID" AllowEdit="true" CommitChanges="true" Enabled="false">
                    </px:PXSelector>
                    <px:PXTextEdit ID="edLotSerialNbr" runat="server" DataField="LotSerialNbr" CommitChanges="true" Enabled="false">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edSiteID" runat="server" DataField="SiteID" AllowEdit="true" Enabled="false" CommitChanges="true">
                    </px:PXSelector>
                    <px:PXSelector ID="edLocationID1" runat="server" DataField="LocationID" AllowEdit="true" Enabled="false" CommitChanges="true">
                    </px:PXSelector>

                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="InventoryID" Width="150" />
                    <px:PXGridColumn DataField="InventoryItem__descr" Width="150" />
                    <px:PXGridColumn DataField="LotSerialNbr" Width="150" />
                    <px:PXGridColumn DataField="SiteID" Width="100" />
                    <px:PXGridColumn DataField="LocationID" Width="100" />
                    <px:PXGridColumn DataField="AcumaticaQty" Width="100" />
                    <px:PXGridColumn DataField="EWQCQty" Width="100" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC401067.aspx.cs" Inherits="Page_QC401067" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="False" TypeName="EW.QC.EWQCServOrderNavigationMaint"
        PageLoadBehavior="InsertRecord"
        AttributesFound="False" EnableAttributes="true" PrimaryView="Documents" SuspendUnloading="False">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="Documents" notifyindicator="True" NoteIndicator="true" FilesIndicator="True" ActivityIndicator="True" TabIndex="1400" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule ID="PXLayoutRule1" runat="server" GroupCaption="Service QC Planning" StartColumn="True" LabelsWidth="350px" />
            <px:PXPanel ID="PXPanel3" runat="server" RenderStyle="Simple">
                <px:PXDropDown ID="edServItemType" runat="server" CommitChanges="true" Width="300px" DataField="ServItemType" Size="S"></px:PXDropDown>
            </px:PXPanel>
            <px:PXPanel ID="PXPanel4" runat="server" RenderStyle="Simple">
                <px:PXSelector CommitChanges="True" ID="edEquipmentId" AutoRefresh="true" runat="server" Width="300px" DataField="EquipmentId"></px:PXSelector>
            </px:PXPanel>

        </Template>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXFormView>
</asp:Content>




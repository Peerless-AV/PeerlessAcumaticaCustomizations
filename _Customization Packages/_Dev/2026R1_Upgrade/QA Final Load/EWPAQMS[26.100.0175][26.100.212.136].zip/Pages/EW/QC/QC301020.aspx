﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301020.aspx.cs" Inherits="Page_QC301020" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="true" TypeName="EW.QC.EWQCToolsManagementOrderEntry" PrimaryView="ToolsManagementOrders" AttributesFound="false" EnableAttributes="true" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="CheckListSteps" Visible="false" DependOnGrid="PXGridCheckList" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="ToolsManagementOrders" TabIndex="4900" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />

            <px:PXLayoutRule runat="server" StartColumn="true" ControlSize="M" LabelsWidth="M" />
            <px:PXDropDown ID="edOrderType" runat="server" DataField="OrderType" Width="100%" Enabled="false">
            </px:PXDropDown>
            <px:PXSelector ID="edTnCOrderCD" runat="server" DataField="TnCOrderCD" CommitChanges="true">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" DataField="OrderDate" Width="100%" Enabled="false" TimeMode="false">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edClosingDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Enabled="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edOnHold" runat="server" DataField="OnHold" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXDropDown ID="edStatus" Enabled="false" ReadOnly="true" runat="server" DataField="Status">
            </px:PXDropDown>
             <px:PXTextEdit ID="edRemarks" runat="server" AlreadyLocalized="False" DataField="Remarks" TextMode="MultiLine" MinHeight="50px" Height="60" Width="225" >
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" ColumnSpan="2">
            </px:PXLayoutRule>
           <px:PXLayoutRule runat="server" StartColumn="True" ControlSize="M" LabelsWidth="M">
            </px:PXLayoutRule>
            <px:PXDropDown ID="ededCalibrationScheduledType" runat="server" AlreadyLocalized="False" DataField="CalibrationScheduledType" Enabled="false">
            </px:PXDropDown>
            <px:PXDropDown ID="edToolSource" runat="server" AlreadyLocalized="False" DataField="ToolSource" Enabled="false">
            </px:PXDropDown>
            <px:PXTextEdit ID="edToolID" Enabled="false" runat="server" CommitChanges="true" DataField="ToolID">
                <LinkCommand Command="ViewToolID" Target="ds"></LinkCommand>
            </px:PXTextEdit>
             <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" Enabled="false">
            </px:PXTextEdit>
            <px:PXDropDown ID="edToolStatus" runat="server" AlreadyLocalized="False" DataField="ToolStatus" Enabled="false">
            </px:PXDropDown>
           
            <px:PXSelector ID="edCalibrationChecklistID" runat="server" DataField="CalibrationChecklistID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" Enabled="false" />

             <px:PXTextEdit ID="edChkgroupDesc" runat="server" AlreadyLocalized="False" DataField="ChkgroupDesc" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" ControlSize="M" LabelsWidth="M">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edRefDocumentNbr" runat="server" DataField="RefDocumentNbr" DisplayMode="Text" CommitChanges="True">
                <LinkCommand Command="RefDocNumbers" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDocType" runat="server" DataField="DocType" DisplayMode="Text" CommitChanges="True"></px:PXTextEdit>

            

             

        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tabParent" runat="server" Width="100%" Height="100%" DataSourceID="ds">
        <Items>
            <px:PXTabItem Text="CheckList ">
                <Template>
                    
                            <px:PXGrid id="grdchecklist" runat="server" DataSourceID="ds" SyncPosition="true" SkinID="DetailsInTab" TabIndex="27364" Width="100%" Height="100%" AutoAdjustColumns ="true" >
                                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                                    AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                    ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                    FilteredAddMessage="No records found.
Try to change filter to see records here."
                                    FilteredMessage="No records found.
Try to change filter to see records here."
                                    NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                    NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                    NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                                    NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                                <Levels>
                                    <px:PXGridLevel DataKeyNames="ToolsManagementOrderChkListID " DataMember="ChecklistGroupVariable">
                                        <RowTemplate>
                                         </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="EWQCChecklist__ChecklistCD" LinkCommand="ViewCheckListItem" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCChecklist__Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCChecklist__Description" Width="280px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Completed" TextAlign="Center" Type="CheckBox" Width="90px" CommitChanges="false">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedBy" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedDate" Width="150px">
                                            </px:PXGridColumn>   
                                            <px:PXGridColumn DataField="Remarks" Width="280px">
                                            </px:PXGridColumn>


                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" />
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="TaskGrid" CommitChanges="true" PostData="Page" RepaintControls="All"></Behavior>
                                </AutoCallBack>
                            </px:PXGrid>
                        
                        
                            <px:PXGrid ID="TaskGrid" runat="server" Caption="Tasks" DataSourceID="ds" SkinID="DetailsInTab" SyncPosition="true"
                                Width="100%" Height="100%" AutoAdjustColumns ="true" AdjustPageSize="Auto">

                                <Levels>
                                    <px:PXGridLevel DataMember="TnCChkListTask">
                                        <Columns>
                                            <px:PXGridColumn DataField="Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Description" Width="200px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Completed" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="90px" CommitChanges="false" AllowSort="False" AllowMove="False">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedBy" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedDate" Width="150px">
                                            </px:PXGridColumn>   
                                            <px:PXGridColumn DataField="Remark" Width="500px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                                <AutoSize Enabled="True" Container="Window" />
                                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                    <Behavior RepaintControlsIDs="grdchecklist" CommitChanges="true" PostData="Page" RepaintControls="All"></Behavior>
                                </AutoCallBack>
                            </px:PXGrid>
                        
                    
                </Template>
                <AutoCallBack Target="grdchecklist" Command="Refresh">
                    <Behavior RepaintControlsIDs="grdchecklist,TaskGrid" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" Width="180px" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" Width="240px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>
</asp:Content>
<%--<asp:Content ID="cont4" ContentPlaceHolderID="phDialogs" runat="server">
    <px:PXSmartPanel ID="PXSmartPanelChecklistSteps" runat="server" Height="500px" Width="1100px" Caption="Test Steps"
        CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ChkListSteps" Style="position: static"
        AutoCallBack-Target="PXGridChecklistSteps" AutoCallBack-Command="Refresh" DesignView="Content">

        <px:PXGrid ID="PXGridChecklistSteps" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%" TabIndex="-272">

            <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                FilteredAddMessage="No records found.
Try to change filter to see records here."
                FilteredMessage="No records found.
Try to change filter to see records here."
                NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
            <Levels>
                <px:PXGridLevel DataMember="ChkListSteps">
                    <Columns>


                        <px:PXGridColumn DataField="EWQCChecklistStep__Name" Width="180px">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="EWQCChecklistStep__Description" Width="280px">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanelChecklistSteps" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButtonChecklistStepsOK" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

</asp:Content>--%>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209001.aspx.cs" Inherits="Page_QC209001" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">

    <px:pxdatasource id="ds" primaryview="Checklists" typename="EW.QC.EWQCChecklistMaint" runat="server" visible="True" width="100%" attributesfound="False" enableattributes="true" suspendunloading="False" pageloadbehavior="InsertRecord">
        <CallbackCommands>
        </CallbackCommands>
    </px:pxdatasource>

</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="Checklists" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edChecklistCD" runat="server" AlreadyLocalized="False" DataField="ChecklistCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" width="100%" height="150px" datasourceid="ds">
        <Items>
            <px:PXTabItem Text="Tasks">
                <Template>
                    <px:PXGrid ID="detailGrid" runat="server" DataSourceID="ds" SkinID="Details"
                       Width="100%" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="ChecklistStepID,ChecklistID" DataMember="ChecklistSteps">
                <RowTemplate>
                    <px:PXTextEdit ID="edName1" runat="server" AlreadyLocalized="False" DataField="Name">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edDescription1" runat="server" AlreadyLocalized="False" DataField="Description">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr" CommitChanges ="true">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Name">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LineNbr">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>
</asp:Content>

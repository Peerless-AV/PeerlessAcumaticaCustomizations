﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC506300.aspx.cs" Inherits="Page_QC506300" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">

    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="ProcessRecord" TypeName="EW.QC.EWQCLcUsrTranProcess">
        <CallbackCommands>
            
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
        AllowPaging="True" AllowSearch="true" AdjustPageSize="Auto"  DataSourceID="ds" SkinID="Primary">
        <Levels>
            <px:PXGridLevel DataMember="ProcessRecord">

                <RowTemplate>

                    <px:PXTextEdit ID="edData" runat="server" DataField="Data"  />
                </RowTemplate>

                <Columns>

                    <px:PXGridColumn DataField="Selected" TextAlign="Center" Type="CheckBox" Width="30px" CommitChanges="true" AllowCheckAll="True" AllowSort="False" />
                    <px:PXGridColumn DataField="Data" Width="500px" AutoCallBack="True" />
                    <px:PXGridColumn DataField="TranCount" Width="100px" AutoCallBack="True" />
                </Columns>

            </px:PXGridLevel>

        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
</asp:Content>

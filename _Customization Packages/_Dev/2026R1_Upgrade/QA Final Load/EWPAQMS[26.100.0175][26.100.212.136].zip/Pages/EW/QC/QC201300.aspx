<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC201300.aspx.cs" Inherits="Page_QC201300" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" attributesfound="False" enableattributes="False" primaryview="TestMethods" suspendunloading="False" typename="EW.QC.EWQCTestMethodMaint">
	</px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="True" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" tabindex="3900" syncposition="true" bpeventsindicator="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="Name" DataMember="TestMethods">
			    <RowTemplate>
                    <px:PXMaskEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name" CommitChanges ="true">
                    </px:PXMaskEdit>
                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description" Width="280px">
                    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	</px:pxgrid>
</asp:Content>

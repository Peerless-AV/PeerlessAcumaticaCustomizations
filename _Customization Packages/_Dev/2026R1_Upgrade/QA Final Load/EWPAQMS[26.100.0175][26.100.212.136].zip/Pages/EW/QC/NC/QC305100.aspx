<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC305100.aspx.cs" Inherits="Page_QC305100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" PrimaryView="NCTran" TypeName="EW.QC.EWQCNCTranEntry" PageLoadBehavior="InsertRecord" AttributesFound="False" EnableAttributes="true" SuspendUnloading="False" Visible="True" Width="100%">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="OnClickAddCapa" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="AddNewRootAnalysis" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="EWQCNCTranRootCauseEdit" Visible="False" CommitChanges="true" DependOnGrid="PXGridNCTranRootCauseAnalysis"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddEditRootCauseOK" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="RefDocNumbers" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="AddNewActionTaken" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="EditActionTaken" Visible="False" CommitChanges="true" DependOnGrid="PXGridNCTranActionTaken"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddEditActionTakenOK" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewAssignedToID" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewRCPerformedBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewActionPerformedBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="EdQCOrderNumbers" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <%--  <px:PXDSCallbackCommand Name="capaNumbers" Visible="False" DependOnGrid="PXGrid1" />--%>
            <%--  </px:PXDSCallbackCommand>--%>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="capaNumbers" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="capaNbr" DependOnGrid="PXGrid4">
            </px:PXDSCallbackCommand>

        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataMember="NCTran" DataSourceID="ds" Style="z-index: 100" Width="100%" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="true" />
            <px:PXSelector ID="edTranCD" runat="server" AlreadyLocalized="False" DataField="NCTranCD" AutoRefresh="true" CommitChanges="True">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edNCDate" runat="server" AlreadyLocalized="False" DataField="NCDate">
            </px:PXDateTimeEdit>
            <px:PXTextEdit ID="edQCOrderNo" runat="server" AlreadyLocalized="False" DataField="QCOrderNo" AutoRefresh="true" CommitChanges="True">
                <LinkCommand Command="EdQCOrderNumbers" Target="ds"></LinkCommand>
            </px:PXTextEdit>
             <px:PXTextEdit ID="edNonStockQCOrderNumber" runat="server" AlreadyLocalized="False" DataField="NonStockQCOrderNumber" AutoRefresh="true" CommitChanges="True">
                <LinkCommand Command="EdQCNonStockOrderNumbers" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edSummary" runat="server" DataField="Summary" TextMode="MultiLine" Height="50" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="true" />
            <px:PXSelector ID="edRepotedBy" runat="server" AlreadyLocalized="False" DataField="RepotedBy" AutoRefresh="true" CommitChanges="True">
                <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
            </px:PXSelector>
            <px:PXSelector ID="edOwner" runat="server" AlreadyLocalized="False" DataField="Owner" AutoRefresh="true" CommitChanges="True">
                <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
            </px:PXSelector>
            <px:PXDropDown ID="edSource" Enabled="false" ReadOnly="true" runat="server" DataField="Source">
            </px:PXDropDown>
            <px:PXSelector ID="edNCType" runat="server" DataField="NCType">
            </px:PXSelector>

            <px:PXLayoutRule runat="server" StartColumn="true" />
            <px:PXDropDown ID="edStatus" Enabled="false" runat="server" DataField="Status" CommitChanges="true">
            </px:PXDropDown>
            <px:PXSelector ID="edPriorty" runat="server" AlreadyLocalized="False" DataField="Priority" AutoRefresh="true" CommitChanges="True">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>
            <px:PXTextEdit ID="edRefDocNo" runat="server" AlreadyLocalized="False" DataField="RefDocNumber" Enabled="False">
                <LinkCommand Command="RefDocNumbers" Target="ds"></LinkCommand>
            </px:PXTextEdit>
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tab" runat="server" Width="100%" Height="120px" DataSourceID="ds">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
            <px:PXTabItem Text="NC Details">
                <Template>
                    <px:PXFormView ID="nonConformanceDtls" runat="server" Width="100%" DataMember="NCTran"
                        DataSourceID="ds" SkinID="Transparent">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True"></px:PXLayoutRule>
                            <px:PXGroupBox RenderStyle="Simple" ID="gpbox1" runat="server" CommitChanges="true"
                                DataField="ItemType" Width="200px">
                                <Template>
                                    <px:PXRadioButton runat="server" ID="ItemTypeStockItem" Value="S" Text="Stock Item" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="ItemTypeTools" Value="T" Text="Tools" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="ItemTypeMachine" Value="M" Text="Machine" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="ItemTypeFixedAsset" Value="F" Text="Fixed Assets" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="ItemTypeNonStock" Value="N" Text="Non-Stock" CommitChanges="true" />
                                </Template>
                            </px:PXGroupBox>
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXSelector ID="edDepartment" runat="server" AlreadyLocalized="False" DataField="Department">
                                <GridProperties FastFilterFields="DepartmentID,Description"></GridProperties>
                            </px:PXSelector>
                            <px:PXSelector runat="server" ID="edCategory" DataField="Category">
                                <GridProperties FastFilterFields="Name,Description"></GridProperties>
                            </px:PXSelector>
                            <px:PXSelector ID="edEmployeeID" runat="server" DataField="EmployeeID" Width="250" CommitChanges="true"></px:PXSelector>
                             <px:PXSelector ID="edCustomer" runat="server" AlreadyLocalized="False" DataField="CustomerID" AutoRefresh="true" CommitChanges="True" AllowEdit="true">
                            </px:PXSelector>
                            <px:PXSelector ID="edInventoryItem" runat="server" AllowEdit="true" AlreadyLocalized="False" DataField="InventoryID" AutoRefresh="true" CommitChanges="True">
                            </px:PXSelector> 
                            <px:PXSelector ID="edTools" runat="server" AllowEdit="true" AlreadyLocalized="False" DataField="ToolsID" AutoRefresh="true" CommitChanges="True">
                            </px:PXSelector> 
                             <px:PXSelector ID="edMachine" runat="server" AllowEdit="true" AlreadyLocalized="False" DataField="MachineID" AutoRefresh="true" CommitChanges="True">
                            </px:PXSelector> 
                             <px:PXSelector ID="edFixedAsset" runat="server" AllowEdit="true" AlreadyLocalized="False" DataField="FixedAssetsID" AutoRefresh="true" CommitChanges="True">
                            </px:PXSelector> 
                             <px:PXSelector ID="edNonStock" runat="server" AllowEdit="true" AlreadyLocalized="False" DataField="NSItemID" AutoRefresh="true" CommitChanges="True">
                            </px:PXSelector> 
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule> 
                            <px:PXTextEdit ID="PXTextEdit1" runat="server" AlreadyLocalized="False" DataField="VendorLotNumber">
                            </px:PXTextEdit>
                            <px:PXSelector ID="edVendor" runat="server" AlreadyLocalized="False" DataField="VendorID" AutoRefresh="true" CommitChanges="True" AllowEdit="true">
                            </px:PXSelector>
                            <px:PXSelector ID="edLotNumber" runat="server" AlreadyLocalized="False" DataField="LotNumber" AutoRefresh="true" CommitChanges="True">
                            </px:PXSelector>
                            <px:PXDateTimeEdit ID="edExpiryDate" runat="server" AlreadyLocalized="False" DataField="ExpiryDate">
                            </px:PXDateTimeEdit>                            

                            <px:PXLayoutRule runat="server" StartRow="true" />
                            <%-- <px:PXRichTextEdit ID="edNCTranDesc" runat="server" AlreadyLocalized="False" DataField="Description" Width="100%" Height="100%" AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                            </px:PXRichTextEdit>--%>
                            <px:PXRichTextEdit ID="edDeliveryNotes" runat="server" DataField="Description"
                                Style="width: 100%; height: 120px" AllowAttached="true" AllowSearch="true"
                                AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                                <AutoSize Enabled="True" MinHeight="216" />
                            </px:PXRichTextEdit>
                            <%--  <px:PXCheckBox ID="edDetailCompleted" runat="server" AlreadyLocalized="False" DataField="IsDetailProcessed">--%>
                            <px:PXCheckBox ID="edDetailCompleted" runat="server" DataField="IsDetailProcessed" AlignLeft="true" CommitChanges="true"></px:PXCheckBox>

                        </Template>
                    </px:PXFormView>

                    <!-- BEGIN: Test Grid -->

                    <px:PXGrid ID="PXGrid2" runat="server" OnRowDataBound="grid2_RowDataBound" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" TabIndex="2600">

                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderSamplingDetails">
                                <RowTemplate>
                                    <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="edTestValue" />
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Steps" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestCategory__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestMethod__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCToolGauge__ToolGaugeCD" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true" LinkCommand="viewAssignedToID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ExpectedValue" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DestructiveTesting" TextAlign="Center" Type="CheckBox">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SampleSize" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Unit" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestValue" CommitChanges="true" MatrixMode="true" />
                                    <px:PXGridColumn DataField="TestResultUOM" Width="220px" />
                                    <%-- <px:PXGridColumn DataField="NumTargetValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <%--<px:PXGridColumn DataField="AlphaValue" Width="280px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="ActualResult">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FinalResult">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__LeadTimeDurationType" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__LeadTimeDuration" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Remarks" Width="280px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                    </px:PXGrid>

                    <!-- END: Test Grid -->

                    <!-- BEGIN: Non Stock Test Grid -->

                    <px:PXGrid ID="PXGrid1" runat="server" OnRowDataBound="grid2_RowDataBound" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" TabIndex="2600">

                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="QCOrderTestNonStockDetailID" DataMember="QCOrderTestDetailNS">
                                <RowTemplate>
                                    <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="PXTextEdit2" />
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Steps" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestCategory__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestMethod__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCToolGauge__ToolGaugeCD" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ExpectedValue" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Unit" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestValue" CommitChanges="true" MatrixMode="true" />
                                    <px:PXGridColumn DataField="TestResultUOM" Width="220px" />                                   
                                    <px:PXGridColumn DataField="ActualResult">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FinalResult">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__LeadTimeDurationType" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__LeadTimeDuration" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Remarks" Width="280px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                    </px:PXGrid>

                    <!-- END: Non Stock Test Grid -->
                </Template>
                <AutoCallBack Target="nonConformanceDtls" Command="Refresh">
                    <Behavior RepaintControlsIDs="nonConformanceDtls" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="RC Analysis" RepaintOnDemand="false">
                <Template>
                    <px:PXGrid ID="PXGridNCTranRootCauseAnalysis" RepaintColumns="true" runat="server" Caption="Root Cause Analysis" DataSourceID="ds" Height="150px" Width="100%" SkinID="Details" SyncPosition="true" AutoAdjustColumns="true">
                        <%-- <Mode InitNewRow="false" />--%>
                        <ActionBar>
                            <Actions>
                                <%--<AddNew Enabled="false" />--%>
                            </Actions>
                            <CustomItems>
                                <px:PXToolBarButton Text="ADD">
                                    <AutoCallBack Command="AddNewRootAnalysis" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="NCTranRootCauseId" DataMember="NCTranRootCauseAnalysis">
                                <RowTemplate>
                                   <px:PXSelector ID="gdRootcauseId" runat="server" AlreadyLocalized="False" DataField="RootCauseId" AutoRefresh="true" CommitChanges="true"  >
                                    </px:PXSelector>
                                    <px:PXSelector ID="gdAnalysisPerformedBy" AutoRefresh="true" runat="server" AlreadyLocalized="False" DataField="AnalysisPerformedBy">
                                    </px:PXSelector>
                                    <px:PXDateTimeEdit ID="gdDatetImePerformOn" runat="server" DataField="AnalysisPerformedOn" Enabled="false"></px:PXDateTimeEdit>
                                    <px:PXTextEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="LineNbr"  Width="0">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="true" DataField="View" LinkCommand="EWQCNCTranRootCauseEdit"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="RootCauseId" CommitChanges="true"  />
                                   <px:PXGridColumn DataField="Description" Width="0" CommitChanges="true" />
                                     <px:PXGridColumn DataField="UnformattedDescription"  CommitChanges="true" />
                                    <px:PXGridColumn DataField="AnalysisPerformedBy" CommitChanges="true" LinkCommand="viewRCPerformedBy" />
                                    <px:PXGridColumn DataField="AnalysisPerformedOn" />
                                    <%--<px:PXGridColumn DataField="IsRCCompleted" TextAlign="Center" Type="CheckBox" Width="80px" />--%>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" />
                            </px:PXGridLevel>

                           
                        </Levels>
                        <AutoCallBack Enabled="true" Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="rootCauseAnalysisTab"></Behavior>
                        </AutoCallBack>
                    </px:PXGrid>
                    <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    <px:PXFormView ID="rootCauseAnalysisTab" SyncPosition="true" runat="server" Width="100%"
                        DataSourceID="ds" DataMember="NCTran" SkinID="Transparent">
                        <Template>
                            <px:PXPanel ID="pnlNCTran" RenderStyle="Simple" DataMember="NCTran" ContentLayout-LabelsWidth="SM" ContentLayout-ControlSize="M" runat="server">
                                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                                <px:PXCheckBox ID="edIsRCCompleted" runat="server" AlreadyLocalized="False" DataField="IsRCCompleted" AlignLeft="true" CommitChanges ="true">
                                </px:PXCheckBox>                               
                                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                                <px:PXDateTimeEdit ID="edAnalysisCompletedOn" TimeMode="false" runat="server" AlreadyLocalized="False" DataField="RCCompletedDate">
                                </px:PXDateTimeEdit>
                                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                                <px:PXSelector ID="edRCCompletedBy" runat="server" AlreadyLocalized="False" DataField="RCCompletedBy">
                                </px:PXSelector>
                            </px:PXPanel>
                        </Template>
                    </px:PXFormView>
                    <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    <px:PXFormView ID="PXFormViewCAPA" SyncPosition="true" runat="server" Width="100%"
                        DataSourceID="ds" DataMember="NCTran" SkinID="Transparent">
                        <Template>

                            <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                            <px:PXSelector ID="edCapaId" runat="server" AllowEdit="true" CommitChanges="true" AlreadyLocalized="False" DataField="UnboundCAPAId" >
                            </px:PXSelector>
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXButton ID="edAddCapa" runat="server" CommandName="OnClickAddCapa" CommandSourceID="ds" Text="Add CAPA"></px:PXButton>
                        </Template>
                    </px:PXFormView>


                    <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    <px:PXGrid ID="PXGrid4" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true" AutoRefresh="true">
                        <ActionBar>
                            <Actions>
                                <AddNew Enabled="false" />
                                <Delete Enabled="true" />
                                <EditRecord Enabled="false" />
                            </Actions>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataMember="NCTranCapaDetail">
                                <Columns>
                                    <px:PXGridColumn DataField="EWQCNCCapaTran__CapaTranCD" Width="70" LinkCommand="capaNbr" CommitChanges="true" />
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <%-- <AutoCallBack Enabled="true" Target="PXGrid4" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="edAddCapa"></Behavior>
                        </AutoCallBack>--%>
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="tree" Command="Refresh, AddNewRootAnalysis, OnClickAddCapa">
                    <Behavior RepaintControlsIDs="PXGridNCTranRootCauseAnalysis, rootCauseAnalysisTab, PXFormViewCAPA,PXGrid4" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Action Taken" RepaintOnDemand="false">
                <Template>
                    <px:PXGrid ID="PXGridNCTranActionTaken" RepaintColumns="true" runat="server" Caption="Action Taken" DataSourceID="ds" Height="150px" Width="100%" SkinID="Details" SyncPosition="true" AutoAdjustColumns="true">
                        <ActionBar>
                            <Actions>
                                <%--<AddNew Enabled="false" />--%>
                            </Actions>
                            <CustomItems>
                                <px:PXToolBarButton Text="ADD">
                                    <AutoCallBack Command="AddNewActionTaken" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="NCTranActionId" DataMember="NCTranAction">
                                <RowTemplate>
                                    <px:PXSelector ID="gdActionPerformedBy" AllowEdit="true" runat="server" AlreadyLocalized="False" DataField="ActionPerformedBy" AutoRefresh="true">
                                    </px:PXSelector>
                                    <px:PXTextEdit ID="edLineNbr1" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>

                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="LineNbr"  Width="0">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="true" DataField="View" LinkCommand="EditActionTaken"></px:PXGridColumn>
                                     <px:PXGridColumn DataField="UnformattedDescription"  CommitChanges ="true"  />
                                    <px:PXGridColumn DataField="Description" Width="0" CommitChanges ="true" />
                                    <px:PXGridColumn DataField="ActionPerformedBy" CommitChanges="true" LinkCommand="viewActionPerformedBy" />
                                    <px:PXGridColumn DataField="ActionPerformedOn"  CommitChanges="true"/>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>

                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoCallBack Enabled="true" Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="actionTakenTab"></Behavior>
                        </AutoCallBack>
                    </px:PXGrid>
                    <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    <px:PXFormView ID="actionTakenTab" runat="server" Width="100%" DataMember="NCTran"
                        DataSourceID="ds" SkinID="Transparent">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
                            <px:PXCheckBox ID="edActionCompleted" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="ActionCompleted" AlignLeft="true">
                            </px:PXCheckBox>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edActionCompletedOn" TimeMode="false" runat="server" AlreadyLocalized="False" DataField="ActionCompletedDate">
                            </px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
                            <px:PXSelector ID="edActionCompletedBy" runat="server" AlreadyLocalized="False" DataField="ActionCompletedBy">
                            </px:PXSelector>
                        </Template>
                    </px:PXFormView>
                </Template>
                <AutoCallBack Target="actionTakenTab" Command="Refresh, AddNewActionTaken">
                    <Behavior RepaintControlsIDs="actionTakenTab,PXGridNCTranActionTaken" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <ActionBar>
                            <Actions>
                                <AddNew Enabled="false" />
                                <Delete Enabled="false" />
                                <EditRecord Enabled="false" />
                            </Actions>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AbsoluteRefNbr" Width="108px" LinkCommand="capaNumbers" />
                                    <px:PXGridColumn DataField="RefDocType" Width="108px" />
                                    <px:PXGridColumn DataField="ActionBy" Width="108px" />
                                    <px:PXGridColumn DataField="LineNumber" Width="108px" />
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>

    <px:PXSmartPanel ID="pnlRootCause" runat="server" Height="400px" Style="z-index: 108; left: 216px; position: absolute; top: 171px" Width="873px" CommandSourceID="ds" Caption="Root Cause Analysis" CaptionVisible="True" LoadOnDemand="true" CallBackMode-CommitChanges="True" CallBackMode-PostData="Page" AutoRepaint="true" Key="RootCauseSmartPanel" AutoCallBack-Target="PXGridNCTranRootCauseAnalysis" AutoCallBack-Command="Refresh">
        <px:PXFormView ID="PXGridNCTranRootCauseAnalysis" runat="server" SkinID="Transparent" DataMember="RootCauseSmartPanel" DataSourceID="ds" EmailingGraph="">
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true" ControlSize="M" LabelsWidth="SM" StartColumn="True" />
               <%-- <px:PXSelector ID="edRootcauseId" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="RootCauseId" AutoRefresh="true" AllowEdit="true">
                </px:PXSelector>--%>
                <px:PXSelector ID="edRootcauseId" runat="server" AlreadyLocalized="False" DataField="RootcauseId" AutoRefresh="true" CommitChanges="True">        </px:PXSelector>
                <px:PXLayoutRule runat="server" StartRow="true" ControlSize="XM" LabelsWidth="SM" StartColumn="True" />
                
                <%--    <px:PXRichTextEdit ID="edRootCauseTranDesc" runat="server" AlreadyLocalized="False" DataField="Description" AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                </px:PXRichTextEdit>--%>
                   <px:PXRichTextEdit ID="edRootCauseTranDesc" runat="server" DataField="Description"
                                Style="width: 100%; height: 120px" AllowAttached="true" AllowSearch="true"
                                AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                                <AutoSize Enabled="True" MinHeight="216" Container="Parent"  />
                            </px:PXRichTextEdit>
              
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXSelector ID="edAnalysisPerformedBy" runat="server" AlreadyLocalized="False" DataField="AnalysisPerformedBy" AutoRefresh="true">
                </px:PXSelector>

                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edAnalysisPerformedOn" runat="server" AlreadyLocalized="False" DataField="AnalysisPerformedOn">
                </px:PXDateTimeEdit>

                <px:PXPanel ID="PXPanel1" runat="server" SkinID="Buttons">
                    <%--CommandSourceID="ds"--%>
                    <px:PXButton ID="btnMyCommandOK" SyncVisible="false" Text="OK" DialogResult="OK" runat="server">
                        <AutoCallBack Command="AddEditRootCauseOK" Target="ds"></AutoCallBack>
                    </px:PXButton>
                    <px:PXButton ID="btnMyCommandCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
                </px:PXPanel>
            </Template>
        </px:PXFormView>
    </px:PXSmartPanel>


    <px:PXSmartPanel ID="pnlSmartActionTaken" runat="server" Height="400px" Style="z-index: 108; left: 216px; position: absolute; top: 171px" Width="873px" CommandSourceID="ds" Caption="Action Taken" CaptionVisible="True" LoadOnDemand="true" CallBackMode-CommitChanges="True" CallBackMode-PostData="Page" AutoRepaint="true" Key="ActionTakenSmartPanel" AutoCallBack-Target="frmActionTakeCommand" AutoCallBack-Command="Refresh">
        <px:PXFormView ID="frmActionTakeCommand" runat="server" SkinID="Transparent" DataMember="ActionTakenSmartPanel" DataSourceID="ds" EmailingGraph="">
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true" ControlSize="M" LabelsWidth="SM" StartColumn="True" />
                <%--  <px:PXRichTextEdit ID="edActionTakenTranDesc" runat="server" AlreadyLocalized="False" DataField="Description" AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                </px:PXRichTextEdit>--%>
               <px:PXRichTextEdit ID="edActionTakenTranDesc" runat="server" DataField="Description"
                                Style="width: 100%; height: 120px" AllowAttached="true" AllowSearch="true"
                                AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                                <AutoSize Enabled="True" MinHeight="216" />
                            </px:PXRichTextEdit>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXSelector ID="edActionPerformedBy" runat="server" AlreadyLocalized="False" DataField="ActionPerformedBy" AutoRefresh="true">
                </px:PXSelector>

                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edActionPerformedOn" runat="server" AlreadyLocalized="False" DataField="ActionPerformedOn">
                </px:PXDateTimeEdit>

                <px:PXPanel ID="PXPanel2" runat="server" SkinID="Buttons">
                    <%--CommandSourceID="ds"--%>
                    <px:PXButton ID="btnActionTakenCommandOK" DialogResult="OK" SyncVisible="false" Text="OK" runat="server">
                        <AutoCallBack Command="AddEditActionTakenOK" Target="ds"></AutoCallBack>
                    </px:PXButton>
                    <px:PXButton ID="btnActionTakenCommandCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
                </px:PXPanel>
            </Template>
        </px:PXFormView>
    </px:PXSmartPanel>

</asp:Content>






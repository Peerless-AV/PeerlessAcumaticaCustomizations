<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC302000.aspx.cs" Inherits="Page_QC302000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="true" runat="server" visible="True" attributesfound="False" primaryview="Documents" suspendunloading="False" typename="EW.QC.EWQCInspectionPlanMaint" pageloadbehavior="InsertRecord">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="Insert" PostData="Self" />
            <px:PXDSCallbackCommand CommitChanges="True" Name="Save" />
            <px:PXDSCallbackCommand Name="First" PostData="Self" StartNewGroup="True" />
            <px:PXDSCallbackCommand Name="Last" PostData="Self" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="gridInspectionPlanVariables" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="gridInspectionPlanVariables" />
                 <px:PXDSCallbackCommand Name="AddQCTool" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datamember="Documents" datasourceid="ds" style="z-index: 100" width="100%" defaultcontrolid="edInspectionPlanCD"
        filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True"  LabelsWidth="SM" ControlSize="XM" />
            <px:PXSelector ID="edInspectionPlanCD" runat="server" AlreadyLocalized="False" DataField="InspectionPlanCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRemarks" runat="server" Height="60" AlreadyLocalized="False" DataField="Remarks" TextMode="MultiLine">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <%-- <px:PXTextEdit ID="edRevisionNo" Enabled="true" ReadOnly="true" runat="server" AlreadyLocalized="False" DataField="RevisionNo">
            </px:PXTextEdit>--%>
            <px:PXSelector ID="edRevisionNo" Enabled="true" ReadOnly="true" runat="server" AutoRefresh="true" AlreadyLocalized="False" DataField="RevisionNo">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edEffectiveFromDate" runat="server" AlreadyLocalized="False" DataField="EffectiveFromDate">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edEffectiveToDate" runat="server" AlreadyLocalized="False" DataField="EffectiveToDate">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edStatus" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="Hold" Text="Hold">
            </px:PXCheckBox>
             <px:PXDropDown ID="edStatusText" Enabled="false" ReadOnly="true" runat="server" DataField="Status">
            </px:PXDropDown>
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" width="100%" height="150px" datasourceid="ds">
        <Items>
            <px:PXTabItem Text="Tests">
                <Template>
                    <px:PXGrid ID="gridInspectionPlanVariables" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                           <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
                        <ActionBar ActionsText="False">
                             <CustomItems>
                                <px:PXToolBarButton Text="QCTool" PopupPanel="AttributePanel" Visible="false" Enabled="True">
                                      <AutoCallBack Command="AddQCTool" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>

                        </ActionBar>
                        <Levels>

                            <px:PXGridLevel DataKeyNames="InspectionPlanVariableID,EWQCVariable_VariableID" DataMember="PlanVariables">
                                <RowTemplate>
                                     <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports">
                                    </px:PXCheckBox>
                                    <px:PXSelector ID="edVariableID" AllowEdit="true" runat="server" DataField="VariableID" CommitChanges="True">
                                         <GridProperties FastFilterFields="VariableCD,Name" ></GridProperties>
                                    </px:PXSelector>
                                     <px:PXTextEdit ID="edEWQCVariableName" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Name">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Description">
                                    </px:PXTextEdit>
                                      <px:PXDropDown ID="edDataType" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__DataType">
                                    </px:PXDropDown>
                                     <px:PXTextEdit ID="edToolSteps" runat="server" AlreadyLocalized="False" DataField="ToolSteps">
                                    </px:PXTextEdit>
                                   <%-- <px:PXSelector ID="edToolGaugeID" AllowEdit="true" runat="server" DataField="ToolGaugeID">
                                          <GridProperties FastFilterFields="ToolGaugeCD,Description" ></GridProperties>
                                    </px:PXSelector>--%>
                                    <px:PXSelector ID="edSeverityLevel" AllowEdit="true" runat="server" DataField="SeverityLevel">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edTestCategoryID" runat="server" DataField="EWQCVariable__TestCategoryID" AllowEdit="true">
                                    </px:PXSelector>
                                     <px:PXSelector ID="edTestMethodID" runat="server" DataField="EWQCVariable__TestMethodID" AllowEdit="true">
                                    </px:PXSelector>
                                   <%-- <px:PXNumberEdit ID="edNumTargetValue" runat="server" AlreadyLocalized="False" DataField="NumTargetValue">
                                    </px:PXNumberEdit>--%>
                                     <px:PXDropDown ID="edQCOperator" runat="server" AlreadyLocalized="False" DataField="QCOperator">
                                    </px:PXDropDown>
                                    <px:PXNumberEdit ID="edNumMinValue" runat="server" AlreadyLocalized="False" DataField="NumMinValue">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edNumMaxValue" runat="server" AlreadyLocalized="False" DataField="NumMaxValue">
                                    </px:PXNumberEdit>
                                    <px:PXTextEdit ID="edEquation" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Equation">
                                    </px:PXTextEdit>
                                   <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                                    </px:PXTextEdit>
                                     <px:PXSelector ID="edEWQCVariableUnit" runat="server" DataField="EWQCVariable__Unit" AllowEdit="true">
                                    </px:PXSelector>
                                     <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                                    </px:PXTextEdit>  
                                    <%--  <px:PXCheckBox ID="edBitPassFail" runat="server" AlreadyLocalized="False" DataField="BitPassFail" Text="Pass/Fail">
                                    </px:PXCheckBox>--%>
                                    <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="Go/NoGo">
                                    </px:PXCheckBox>
                                      <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest">
                                    </px:PXCheckBox>
                                     <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                                    </px:PXDropDown>
                                    <px:PXSelector ID="edTestGroupId" runat="server" DataField="TestGroupID" AllowEdit="true" CommitChanges="True">
                                         <GridProperties FastFilterFields="Name,Description" ></GridProperties>
                                    </px:PXSelector>
                                    
                                                                      
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VariableID" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__DataType">
                                    </px:PXGridColumn>                                    
                                   <%-- <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                     <%--  <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="ToolInspectionSteps" CommitChanges="true">
                                      </px:PXGridColumn>--%>
                                     <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="AddQCTool" CommitChanges="true">
                                      </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SeverityLevel" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__TestCategoryID" LinkCommand="ViewTestCategoryMaster" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__TestMethodID" LinkCommand="ViewTestMethod" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="QCOperator" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="NumMinValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>
                                   <%-- <px:PXGridColumn DataField="NumTargetValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="NumMaxValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn> 
                                     <px:PXGridColumn DataField="EWQCVariable__Equation" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestResultUOM" Width="220px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AlphaValue" Width="220px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Unit" Width="220px">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="BitPassFail" TextAlign="Center" Type="CheckBox" Width="60px">
                                    </px:PXGridColumn>--%>
                                       <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                                    </px:PXGridColumn> 
                                    <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="OrderLevel" CommitChanges="true" Width="120px">
                                    </px:PXGridColumn>
                                
                                    <%-- <px:PXGridColumn DataField="TestGroupID" Width="120px" LinkCommand="ViewGroupMaster"></px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="TestGroupID" Width="120px" CommitChanges="true"></px:PXGridColumn>
                                    <%--<px:PXGridColumn DataField="LineNbr" Width="120px"></px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="ComboValue" Width="280px" LinkCommand="AddCombo" CommitChanges ="true">
                                    </px:PXGridColumn>
                                    
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />                        
                    </px:PXGrid>

                </Template>
            </px:PXTabItem>
               <px:PXTabItem Text="Event History">

                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
         <%--   <px:PXTabItem Text="CheckLists">
                <Template>
                    <px:PXGrid ID="gridChecklist" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="InspectionPlanChecklistID,EWQCChecklist_ChecklistID" DataMember="Checklist">
                                <RowTemplate>
                                    <px:PXSelector ID="edChecklistID" runat="server" DataField="ChecklistID" CommitChanges="True" AllowEdit="true">
                                    </px:PXSelector>

                                </RowTemplate>
                                <Columns>
                                   
                                    <px:PXGridColumn DataField="ChecklistID" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCChecklist__Name">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCChecklist__Description">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>--%>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>
</asp:Content>
<asp:Content ID="cont4" ContentPlaceHolderID="phDialogs" runat="server">
    <%--  <px:PXSmartPanel ID="pnlTestSteps1" runat="server" Height="500px" Width="1100px" Caption="QC Tool" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ToolSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel1" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton1" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
    --%>
    <px:pxsmartpanel id="AttributePanel" runat="server" width="720px" height="360px" caption="Tools" captionvisible="True"
        autocallback-command="Refresh" autocallback-target="AttributesGrid" designview="Content">
        <px:PXGrid ID="AttributesGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="InsapectionToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>          
        </px:PXGrid>
        <px:PXPanel ID="AttributeButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="AttributeSaveButton" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
            <px:PXButton ID="AttributeCancelButton" runat="server" DialogResult="Cancel" Text="Cancel"></px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>
    <px:pxsmartpanel id="ComboBoxPanel" runat="server" width="720px" height="360px" key="TestInspectionComboValues" caption="Combo Values" captionvisible="True"
        autocallback-command="Refresh" autocallback-target="ComboBoxGrid" designview="Content">
        <px:PXGrid ID="ComboBoxGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="TestInspectionComboValues">
                    <Columns>
                        <px:PXGridColumn DataField="TestComboCD">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ComboCheck" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn> 
                    </Columns>                   
                </px:PXGridLevel>                
            </Levels>  
             <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
        </px:PXGrid>         
        <px:PXPanel ID="ComboButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="ComboSaveButton" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="ComboSaveButton" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="ComboCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
              
            </px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>
</asp:Content>

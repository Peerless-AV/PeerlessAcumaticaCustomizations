<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC101100.aspx.cs" Inherits="Page_QC101100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="NCCAPASetup" typename="EW.QC.EWQCNCCAPASetupMaint">
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Width="100%" DataMember="Setup" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        NotifyIndicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Numbering Settings" />
            <px:PXSelector ID="edCapaNumberSequenceID" runat="server" DataField="CapaNumberSequenceID" Size="XL" LabelWidth="300" AllowEdit="True" />
            <px:PXSelector ID="edNCNumberSequenceID" runat="server" DataField="NCNumberSequenceID" Size="XL" LabelWidth="300" AllowEdit="True" />
        </Template>
    </px:PXFormView>
</asp:Content>
<%--<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Width="100%" DataMember="Setup" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True"/>
        <Template>
            <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Numbering Settings" />
            <px:PXSelector ID="edCapaNumberSequenceID" runat="server" DataField="CapaNumberSequenceID" Size="XL" LabelWidth="300" AllowEdit="True">
            </px:PXSelector>
            <px:PXSelector ID="edNCNumberSequenceID" runat="server" DataField="NCNumberSequenceID" Size="XL" LabelWidth="300" AllowEdit="True">
            </px:PXSelector>  
        </Template>
    </px:pxformview>
</asp:Content>--%>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <%--<px:pxgrid id="grid" runat="server" groupcaptions="NC-CAPA Entry" datasourceid="ds" style="z-index: 100"
        width="100%" height="150px" skinid="Details">--%>
        <px:PXGrid ID="PXGrid1" Caption="NC-CAPA Entry" CaptionVisible="true" runat="server"  width="100%" height="150px" style="z-index: 100"
            DataSourceID="ds" SkinID="Details">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataMember="NCCAPASetup">
                <RowTemplate>
                    
                    <px:PXDropDown ID="edQCType" runat="server" AlreadyLocalized="False" CommitChanges="true" DataField="QCType">
                    </px:PXDropDown>
                    <px:PXDropDown ID="edNctype" runat="server" AlreadyLocalized="False" DataField="Nctype" >
                    </px:PXDropDown>
                    <px:PXCheckBox ID="edIsAutoGenerateNCCAPA" runat="server" AlreadyLocalized="False" DataField="IsAutoGenerateNCCAPA" >
                    </px:PXCheckBox>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QCType" CommitChanges="true"  Width="240px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Nctype" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="IsAutoGenerateNCCAPA" TextAlign="Center" Type="CheckBox"  Width="190px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>
</asp:Content>

using System;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using static PX.Data.BQL.BqlPlaceholder;
using static PX.Objects.IN.INAlternateType;

public partial class Page_QC201111:PX.Web.UI.PXPage {
	protected void Page_Load(object sender, EventArgs e) {
		this.Master.PopupHeight = 968;
		this.Master.PopupWidth = 1178;
	}
}

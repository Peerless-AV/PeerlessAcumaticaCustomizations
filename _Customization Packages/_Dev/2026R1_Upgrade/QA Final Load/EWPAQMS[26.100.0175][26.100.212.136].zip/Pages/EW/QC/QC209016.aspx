﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209016.aspx.cs" Inherits="Page_QC209016" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="VendorPerformance" typename="EW.QC.EWQCEvaluateLastVendorPerformanceMaint">
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="frmMyCommand" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="VendorPerformance" bpeventsindicator="True">
        <Template>
             <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
              <px:PXDropDown ID="edType" AlreadyLocalized="False" runat="server" DataField="Type" AutoRefresh="true" CommitChanges="true">
            </px:PXDropDown>            
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" width="100%" height="150px" datasourceid="ds">
        <Items>
            <px:PXTabItem Text="Price" VisibleExp="DataControls[&quot;edType&quot;].Value == P" BindingContext="frmMyCommand">
                <Template>
                    <px:PXGrid ID="PriceGrid" runat="server" DataSourceID="ds" SkinID="Details"
                       Width="100%" SyncPosition="true" AutoAdjustColumns="true" OnRowDataBound="grid_RowDataBound">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="VendorPerformancePOPRDetailID" DataMember="PriceCriteria">
                                <RowTemplate>
                                    <px:PXCheckBox ID="edRatingScore" runat="server" AlreadyLocalized="False" DataField="RatingScore" Text="Rating Score" >
                                    </px:PXCheckBox>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="VendorID" CommitChanges="true" LinkCommand="ViewVendors">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PONbr" Width="180px" LinkCommand="POOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PODate" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="POQty">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="POUOM">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="ReceiptNbr" LinkCommand="PROrder">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptDate">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptQty">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PRUOM">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QCOrderID"  LinkCommand="ViewOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="InventoryID"  LinkCommand="ViewStockItem">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PriceScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PriceVariance">
                                     </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PriceRank">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllRank">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RatingScore" Width="0px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

            
       
     
            <px:PXTabItem Text="Quality" VisibleExp="DataControls[&quot;edType&quot;].Value == Q" BindingContext="frmMyCommand">
                <Template>
                    <px:PXGrid ID="QualityGrid" runat="server" DataSourceID="ds" SkinID="Details"
                       Width="100%" SyncPosition="true" AutoAdjustColumns="true" OnRowDataBound="grid2_RowDataBound">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="VendorPerformancePOPRDetailID,VendorPerformanceID" DataMember="QualityCriteria">
                                <RowTemplate>
                                    <px:PXCheckBox ID="edRatingScore2" runat="server" AlreadyLocalized="False" DataField="RatingScore" Text="Rating Score">
                                    </px:PXCheckBox>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="VendorID" CommitChanges="true" LinkCommand="ViewVendors">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PONbr" Width="180px" LinkCommand="POOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PODate" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="POQty">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="POUOM">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="ReceiptNbr" LinkCommand="PROrder">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptDate">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptQty">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PRUOM">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QCOrderID"  LinkCommand="ViewOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="InventoryID"  LinkCommand="ViewStockItem">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QualityScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QualityVariance">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="QualityRank">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllRank">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RatingScore" Width="0px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

          <px:PXTabItem Text="Quantity Supplied" VisibleExp="DataControls[&quot;edType&quot;].Value == S" BindingContext="frmMyCommand">
                <Template>
                    <px:PXGrid ID="QuantitySuppliedGrid" runat="server" DataSourceID="ds" SkinID="Details"
                       Width="100%" SyncPosition="true" AutoAdjustColumns="true"  OnRowDataBound="grid3_RowDataBound">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="VendorPerformancePOPRDetailID" DataMember="QuantitySuppliedCriteria">
                                <RowTemplate>
                                    <px:PXCheckBox ID="edRatingScore3" runat="server" AlreadyLocalized="False" DataField="RatingScore" Text="Rating Score">
                                    </px:PXCheckBox>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="VendorID" CommitChanges="true" LinkCommand="ViewVendors">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PONbr" Width="180px" LinkCommand="POOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PODate" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="POQty">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="POUOM">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="ReceiptNbr" LinkCommand="PROrder">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptDate">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptQty">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PRUOM">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QCOrderID"  LinkCommand="ViewOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="InventoryID"  LinkCommand="ViewStockItem">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QuantitySuppliedScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QuantitySuppliedVariance">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="QuantitySuppliedRank">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllRank">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RatingScore" Width="0px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

            
       

    
            <px:PXTabItem Text="On Time Delivery" VisibleExp="DataControls[&quot;edType&quot;].Value == D" BindingContext="frmMyCommand">
                <Template>
                    <px:PXGrid ID="DeliveryGrid" runat="server" DataSourceID="ds" SkinID="Details"
                       Width="100%" SyncPosition="true" AutoAdjustColumns="true" OnRowDataBound="grid4_RowDataBound">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="VendorPerformancePOPRDetailID" DataMember="OnTimeDeliveryCriteria">
                                <RowTemplate>
                                    <px:PXCheckBox ID="edRatingScore4" runat="server" AlreadyLocalized="False" DataField="RatingScore" Text="Rating Score">
                                    </px:PXCheckBox>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="VendorID" CommitChanges="true" LinkCommand="ViewVendors">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PONbr" Width="180px" LinkCommand="POOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PODate" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="POQty">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="POUOM">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="ReceiptNbr" LinkCommand="PROrder">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptDate">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ReceiptQty">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="PRUOM">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="QCOrderID"  LinkCommand="ViewOrder">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="InventoryID"  LinkCommand="ViewStockItem">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="OnTimeDeliverScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="OnTimeDeliverVariance">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="OnTimeDeliverRank">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllScore">
                                    </px:PXGridColumn>
                                     <px:PXGridColumn DataField="EWQCEvaluateVendorPerformanceOverAllScore__OverAllRank">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RatingScore" Width="0px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

            
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>

</asp:Content>


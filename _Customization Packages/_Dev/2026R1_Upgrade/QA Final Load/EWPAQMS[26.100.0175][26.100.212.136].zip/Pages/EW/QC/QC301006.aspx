<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC301006.aspx.cs" Inherits="Page_QC301006" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" TypeName="EW.QC.EWQCOrderSamplingDetailEntry" AttributesFound="False" EnableAttributes="true" PrimaryView="QCOrders" SuspendUnloading="False" PageLoadBehavior="GoLastRecord">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="GotoEquation" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="DeleteSample" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="SubmitFormula" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" DataMember="QCOrders" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" LabelsWidth="M" ControlSize="M" />
            <px:PXSelector ID="edQCOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edQCLotDetail" runat="server" DataField="DisplayLotSerNumVal" AutoRefresh="true" CommitChanges="true">
            </px:PXSelector>
        </Template>
    </px:PXFormView>
    <px:PXSmartPanel ID="pnlEquation" runat="server" Height="500px" Width="800px" Caption="Equation" CaptionVisible="true" AutoReload="true" Key="QCOrderTestFormula" Style="position: static"
        AutoCallBack-Target="PXGridEquation" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="PXGridEquation" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataKeyNames="QCOrderSamplingDetailID" DataMember="QCOrderTestFormula">
                    <RowTemplate>

                        <px:PXTextEdit ID="edParameter" runat="server" AlreadyLocalized="False" DataField="ParameterName" Enabled="false" Width="600px">
                        </px:PXTextEdit>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ParameterName">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="EWQCTestParameter__Description"></px:PXGridColumn>
                        <px:PXGridColumn DataField="FormulaValue">
                        </px:PXGridColumn>

                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel10" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton2" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitFormula" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnInvCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">

    <px:PXTab ID="tabDetails" runat="server" Width="100%" Height="100%">
        <Items>
            <px:PXTabItem Text="Test Results">
                <Template>
                    <px:PXGrid ID="PXGrid2" runat="server" OnRowDataBound="grid2_RowDataBound" DataSourceID="ds" Style="z-index: 100; left: 0px; top: 0px; height: 455px; overflow: hidden" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" TabIndex="2600">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <AutoSize Container="Window" Enabled="True" MinHeight="100"></AutoSize>
                        <ActionBar ActionsText="False">
                            <CustomItems>
                                <px:PXToolBarButton Text="QCTool" PopupPanel="AttributePanel" Visible="false" Enabled="True">
                                    <AutoCallBack Command="AddQCTool" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderSamplingDetails" SortOrder="LineNbr">
                                <RowTemplate>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXTextEdit ID="edSamplingSerailNum" runat="server" AlreadyLocalized="False" DataField="SamplingSerailNum">
                                    </px:PXTextEdit>
                                    <px:PXSelector ID="edSerialNumber" runat="server" AlreadyLocalized="False" DataField="SerialNumber">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edAssignedToID" runat="server" DataField="AssignedToID">
                                        <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
                                    </px:PXSelector>
                                    <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="edTestValue" />
                                    <px:PXTextEdit runat="server" DataField="TestResultUOM" CommitChanges="True" ID="edTestResultUOM" />
                                    <px:PXCheckBox ID="edTested" runat="server" AlreadyLocalized="False" DataField="Tested" Text="Tested">
                                    </px:PXCheckBox>
                                    <px:PXDropDown ID="edActualResult" runat="server" DataField="ActualResult">
                                    </px:PXDropDown>
                                    <px:PXDropDown ID="edFinalResult" runat="server" DataField="FinalResult">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="PXTextEdit1" runat="server" AlreadyLocalized="False" DataField="Remarks" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports" Enabled="false">
                                    </px:PXCheckBox>
                                    <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest" Enabled="false">
                                    </px:PXCheckBox>
                                    <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                                    </px:PXTextEdit>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXTextEdit ID="edName" runat="server" DataField="EWQCVariable__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edVariableCD" runat="server" DataField="EWQCVariable__VariableCD" LinkCommand="ViewTestMaster" Width="180px">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edTGName" runat="server" DataField="EWQCTestGroup__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edSteps" runat="server" DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescription" runat="server" DataField="EWQCVariable__Description" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDataType" runat="server" DataField="EWQCVariable__DataType" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edTestCategoryName" runat="server" DataField="EWQCTestCategory__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edTestMethodName" runat="server" DataField="EWQCTestMethod__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edTool" runat="server" DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edSeverity" runat="server" DataField="EWQCSeverityLevel__Name" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edAssignto" runat="server" DataField="AssignedToID" LinkCommand="viewAssignedToID" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edExpected" runat="server" DataField="ExpectedValue" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="PXTextEdit6" runat="server" DataField="UOM" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edEquation" runat="server" DataField="Equation" Width="180px" AlreadyLocalized="False" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXLayoutRule runat="server" Merge="False" />
                                    <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                                    </px:PXDropDown>
                                    <px:PXCheckBox ID="edDestructiveTesting" runat="server" AlreadyLocalized="False" DataField="DestructiveTesting" Enabled="false">
                                    </px:PXCheckBox>
                                    <px:PXSelector ID="edUOM" runat="server" AlreadyLocalized="False" DataField="UOM" Enabled="false">
                                    </px:PXSelector>
                                    <px:PXNumberEdit ID="edSampleSize" runat="server" AlreadyLocalized="False" DataField="SampleSize" Enabled="false">
                                    </px:PXNumberEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SerialNumber" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__VariableCD" LinkCommand="ViewTestMaster" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestGroup__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestCategory__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestMethod__Name" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="AddQCTool" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true" LinkCommand="viewAssignedToID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ExpectedValue" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DestructiveTesting" TextAlign="Center" Type="CheckBox">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SampleSize" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="UOM" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Equation" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Formula" Width="180px" LinkCommand="GotoEquation" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestValue" CommitChanges="true" MatrixMode="true" />
                                    <px:PXGridColumn DataField="TestResultUOM" CommitChanges="true" />
                                    <px:PXGridColumn DataField="ActualResult" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FinalResult" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>

                                    <px:PXGridColumn DataField="OrderLevel" CommitChanges="true" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Remarks" Width="280px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="NCNbr" Width="200px" LinkCommand="ViewTestNC">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="QCOrderSamplingDetailID" Width="1px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <Mode AllowUpload="True" AllowAddNew="False" AllowDelete="false" />
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                        <ActionBar>
                            <CustomItems>
                                <px:PXToolBarButton Text="Add Sample" Key="cmdSample" CommandName="AddSample" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                    <AutoCallBack>
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                                <px:PXToolBarButton Text="Delete Sample" Key="cmdDeleteSample" CommandName="DeleteSample" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                    <AutoCallBack>
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                                <px:PXToolBarButton Text="Copy Test" Key="cmdCopyTest" CommandName="CopyTest" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                    <AutoCallBack>
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                                <px:PXToolBarButton Text="Line Detail" Key="cmdQCOrderLotDetailsSmartPanel" CommandSourceID="ds" DependOnGrid="PXGrid2" CommandName="addLineDetails">
                                    <AutoCallBack>
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                                <px:PXToolBarButton Text="Calibration/Maintenace Order" Key="cmdCalibrationMaintenace" CommandName="CalibrationMaintenace" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                            <AutoCallBack>
                                                <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                            </AutoCallBack>
                                        </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <AutoSize Enabled="True" MinHeight="10"></AutoSize>
                        <Mode InitNewRow="True" AllowFormEdit="False" AllowDragRows="True" AutoInsert="true"></Mode>
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid2" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid2" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="CALIBRATION AND MAINTENANCE ORDERS">
                        <Template>
                            <px:PXGrid ID="transactionGrid" runat="server" BorderStyle="None" SkinID="DetailsInTab" Width="100%" DataSourceID="ds" SyncPosition="true">
                                <AutoSize Enabled="True" MinHeight="150" />
                                <ActionBar>
                                    <Actions>
                                        <AddNew Enabled="false" />
                                        <Delete Enabled="false" />
                                        <EditRecord Enabled="false" />
                                    </Actions>
                                </ActionBar>
                                <Levels>
                                    <px:PXGridLevel DataMember="ToolManagementView">
                                        <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                                        <Columns>
                                            <px:PXGridColumn DataField="TnCOrderCD" Width="115px" LinkCommand="RefOrderNbr" />
                                            <px:PXGridColumn DataField="Status" Width="115px" />
                                            <px:PXGridColumn DataField="OrderType" Width="115px" />
                                            <px:PXGridColumn DataField="CalibrationScheduledType" Width="130px" />
                                            <px:PXGridColumn DataField="ToolID" Width="130px" LinkCommand="ViewToolID" CommitChanges="true" />


                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="transactionGrid" Command="Refresh">
                            <Behavior RepaintControlsIDs="transactionGrid" />
                        </AutoCallBack>
                    </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="100" />
    </px:PXTab>

    <px:PXSmartPanel ID="pnlCopyTestRecords" runat="server" Height="400px" Width="1100px" Caption="Copy Test Result" CaptionVisible="true" AutoReload="true" Key="QCOrderSamplingDetails" Style="position: static"
        AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXFormView ID="frmMyCommand" runat="server" SkinID="Transparent" DataMember="QCOrders" DataSourceID="ds" EmailingGraph="">
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true" />
                <px:PXLayoutRule runat="server" StartColumn="true" ControlSize="M" LabelsWidth="SM" />
                <px:PXDropDown ID="edlevel" runat="server" AlreadyLocalized="False" AutoRefresh="true" CommitChanges="true" DataField="Level">
                </px:PXDropDown>
                <px:PXSelector ID="edLots" runat="server" DataField="Lots" AutoRefresh="true" CommitChanges="true">
                </px:PXSelector>
                <px:PXLayoutRule runat="server" StartColumn="true" ControlSize="M" LabelsWidth="SM" />
                <px:PXSelector ID="edSamples" runat="server" DataField="Samples" AutoRefresh="true" CommitChanges="true">
                </px:PXSelector>
                <px:PXSelector ID="edTests" runat="server" DataField="Tests" AutoRefresh="true" CommitChanges="true">
                </px:PXSelector>
            </Template>
        </px:PXFormView>
        <px:PXTab ID="tab" runat="server">
            <Items>
                <px:PXTabItem Text="Copy To Lot/Serial" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edlevel&quot;].Value == L" BindingContext="frmMyCommand">
                    <Template>
                        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Details" AllowPaging="false"
                            Width="1100px" Height="600px" SyncPosition="true" TabIndex="2600">
                            <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                FilteredMessage="No records found.
Try to change filter to see records here."
                                FilteredAddMessage="No records found.
Try to change filter to see records here."
                                NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                            <Levels>
                                <px:PXGridLevel DataKeyNames="QCOrderLotDetailID" DataMember="QCOrderLot">
                                    <RowTemplate>
                                        <px:PXCheckBox ID="pxcheck" runat="server" AlreadyLocalized="False" DataField="itemcheck" Text="Check">
                                        </px:PXCheckBox>
                                    </RowTemplate>
                                    <Columns>
                                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="DisplayLotSerNumVal" Width="180px">
                                        </px:PXGridColumn>
                                    </Columns>
                                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                                </px:PXGridLevel>
                            </Levels>
                            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                            <AutoSize Enabled="True" />
                            <AutoCallBack />
                            <ActionBar>
                                <CustomItems>
                                    <px:PXToolBarButton Text="Copy" Key="cmdCopy" CommandName="CopyData" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                        <AutoCallBack>
                                            <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                        </AutoCallBack>
                                    </px:PXToolBarButton>
                                </CustomItems>
                            </ActionBar>
                            <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
                        </px:PXGrid>
                        <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    </Template>
                </px:PXTabItem>
                <px:PXTabItem Text="Copy Sample Nbr" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edlevel&quot;].Value == S" BindingContext="frmMyCommand">
                    <Template>
                        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Details" AllowPaging="false"
                            Width="1100px" Height="600px" SyncPosition="true" TabIndex="2600">
                            <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                FilteredMessage="No records found.
Try to change filter to see records here."
                                FilteredAddMessage="No records found.
Try to change filter to see records here."
                                NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                            <Levels>
                                <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderSample">
                                    <RowTemplate>
                                        <px:PXCheckBox ID="pxcheck1" runat="server" AlreadyLocalized="False" DataField="itemcheck" Text="Check">
                                        </px:PXCheckBox>
                                    </RowTemplate>
                                    <Columns>
                                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="EWQCOrderLotDetail__DisplayLotSerNumVal" Width="180px">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                        </px:PXGridColumn>
                                    </Columns>
                                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                                </px:PXGridLevel>
                            </Levels>
                            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                            <AutoSize Enabled="True" />
                            <AutoCallBack />
                            <ActionBar>
                                <CustomItems>
                                    <px:PXToolBarButton Text="Copy" Key="cmdCopy" CommandName="CopyData" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                        <AutoCallBack>
                                            <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                        </AutoCallBack>
                                    </px:PXToolBarButton>
                                </CustomItems>
                            </ActionBar>
                            <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
                        </px:PXGrid>
                        <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    </Template>
                </px:PXTabItem>
                <px:PXTabItem Text="Copy To Test" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edlevel&quot;].Value == T" BindingContext="frmMyCommand">
                    <Template>
                        <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" SkinID="Details" AllowPaging="false"
                            Width="1100px" Height="600px" SyncPosition="true" TabIndex="2600">
                            <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                FilteredMessage="No records found.
Try to change filter to see records here."
                                FilteredAddMessage="No records found.
Try to change filter to see records here."
                                NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                            <Levels>
                                <px:PXGridLevel DataKeyNames="QCOrderLotDetailID,QCOrderSamplingDetailID" DataMember="QCOrderTest">
                                    <RowTemplate>
                                        <px:PXCheckBox ID="pxcheck2" runat="server" AlreadyLocalized="False" DataField="itemcheck" Text="Check">
                                        </px:PXCheckBox>
                                    </RowTemplate>
                                    <Columns>
                                        <px:PXGridColumn DataField="itemcheck" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="EWQCOrderLotDetail__DisplayLotSerNumVal" Width="180px">
                                        </px:PXGridColumn>
                                        <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                        </px:PXGridColumn>
                                    </Columns>
                                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                                </px:PXGridLevel>
                            </Levels>
                            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
                            <AutoSize Enabled="True" />
                            <AutoCallBack />
                            <ActionBar>
                                <CustomItems>
                                    <px:PXToolBarButton Text="Copy" Key="cmdCopy" CommandName="CopyData" CommandSourceID="ds" DependOnGrid="PXGrid2">
                                        <AutoCallBack>
                                            <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                        </AutoCallBack>
                                    </px:PXToolBarButton>
                                </CustomItems>
                            </ActionBar>
                            <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
                        </px:PXGrid>
                        <px:PXLayoutRule runat="server" StartRow="true" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
                    </Template>
                </px:PXTabItem>
            </Items>
        </px:PXTab>
    </px:PXSmartPanel>
    <px:PXSmartPanel ID="pnlTestSteps1" runat="server" Height="500px" Width="1100px" Caption="QC Tool" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ToolSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel11" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel ID="pnlTestSteps" runat="server" Height="400px" Width="1100px" Caption="Test Steps" CaptionVisible="true" AutoReload="true" Key="TestSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="StepsGrid" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataMember="TestSteps">
                    <Columns>
                        <px:PXGridColumn DataField="Name">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel ID="AttributePanel" runat="server" Width="720px" Height="360px" Caption="Tools" CaptionVisible="True"
        AutoCallBack-Command="Refresh" AutoCallBack-Target="AttributesGrid" DesignView="Content">
        <px:PXGrid ID="AttributesGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="OrderToolSteps">
                    <RowTemplate>
                        <px:PXSelector ID="edToolGaugeID" runat="server" DataField="ToolGaugeID">
                            <GridProperties FastFilterFields="ToolGaugeID, Description" />
                        </px:PXSelector>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="AttributeButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="AttributeSaveButton" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
            <px:PXButton ID="AttributeCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
                <AutoCallBack Command="CancelQCTools" Target="ds"></AutoCallBack>
            </px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
    <px:PXSmartPanel ID="PanelAddNCLine" runat="server" Height="500px" Width="1100px" Caption="Add Line Details" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="QCOrderLotDetailsSmartPanel" Style="position: static"
        AutoCallBack-Target="AddLine Grid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="gridOL" runat="server" Height="50px" Width="100%" DataSourceID="ds" AutoAdjustColumns="true" PageSize="200" SkinID="Inquire">
            <AutoSize Enabled="true" />
            <Levels>
                <px:PXGridLevel DataMember="QCOrderLotDetailsSmartPanel">
                    <Columns>
                        <px:PXGridColumn DataField="SerialNumber">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="itemcheck" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true" AllowCheckAll="true">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
            <AutoSize Enabled="true" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel13" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton4" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitSerialNo" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="PXButton5" runat="server" DialogResult="No" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301003.aspx.cs" Inherits="Page_QC301003" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="true" TypeName="EW.QC.EWQCInspectionOrderEntry" PrimaryView="InspectionOrderEntry" AttributesFound="false" EnableAttributes="true" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewInspectionPlan" Visible="false" DependOnGrid="PXGridPlanDetail" />
            <px:PXDSCallbackCommand Name="ViewItemClass" Visible="false" DependOnGrid="PXGridPlanDetail" />
            <px:PXDSCallbackCommand Name="ViewInventoryItem" Visible="false" DependOnGrid="PXGridPlanDetail" />
            <px:PXDSCallbackCommand Name="ViewTest" Visible="false" DependOnGrid="PXGridTestResult" />
            <px:PXDSCallbackCommand Name="ViewTestCategory" Visible="false" DependOnGrid="PXGridTestResult" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="false" DependOnGrid="PXGridTestResult" />
            <px:PXDSCallbackCommand Name="ViewTooGauge" Visible="false" DependOnGrid="PXGridTestResult" />
            <px:PXDSCallbackCommand Name="GotoSteps" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="ViewAssignedToID" Visible="false" DependOnGrid="PXGridTestResult" />
            <px:PXDSCallbackCommand Name="ViewCheckListItem" Visible="false" DependOnGrid="PXGridCheckList" />
            <px:PXDSCallbackCommand Name="CheckListSteps" Visible="false" DependOnGrid="PXGridCheckList" />
            <px:PXDSCallbackCommand Name="ViewChecklistGroup" Visible="false" DependOnGrid="gridChecklistGroup" />
            <px:PXDSCallbackCommand Name="RefDocNumbers" Visible="False" CommitChanges="true" />
              <px:PXDSCallbackCommand Name="GoToEquation" Visible="False" CommitChanges="true" />
              <px:PXDSCallbackCommand Name="GotoToolSteps" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="SubmitFormulaMobile" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="InspectionOrderEntry" TabIndex="4900" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />

            <px:PXLayoutRule runat="server" StartColumn="true" ControlSize="M" LabelsWidth="M" />
            <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" DataField="OrderDate" Width="100%" Enabled="false" TimeMode="false">
            </px:PXDateTimeEdit>
            <px:PXSelector ID="edQCInspectionOrderCD" runat="server" DataField="QCInspectionOrderCD" CommitChanges="true">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edClosingDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Enabled="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edOhHold" runat="server" DataField="OnHold" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXDropDown ID="edStatus" Enabled="false" ReadOnly="true" runat="server" DataField="Status">
            </px:PXDropDown>

            <px:PXLayoutRule runat="server" ColumnSpan="2">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edRemarks" runat="server" AlreadyLocalized="False" DataField="Remarks" TextMode="MultiLine" MinHeight="50px" Height="60px">
            </px:PXTextEdit>

            <px:PXLayoutRule runat="server" StartColumn="True" ControlSize="M" LabelsWidth="M">
            </px:PXLayoutRule>
            <px:PXDropDown ID="edRefDocumentType" runat="server" AlreadyLocalized="False" DataField="RefDocumentType" Enabled="false">
            </px:PXDropDown>
            <px:PXTextEdit ID="edRefDocumentNbr" runat="server" AlreadyLocalized="False" DataField="RefDocumentNbr" Enabled="false">
                <LinkCommand Command="RefDocNumbers" Target="ds"></LinkCommand>
            </px:PXTextEdit>

        </Template>
    </px:PXFormView>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <%-- <px:PXSplitContainer ID="SptCont1" runat="server" SkinID="Horizontal" SplitterPosition="250" Height="600px" Panel1MinSize="100" Panel2MinSize="100">
        <AutoSize Container="Window" Enabled="true" MinHeight="600" />--%>
    <%--<Template1>
            <px:PXGrid runat="server" ID="PXGridPlanDetail" Caption="Plan Detail" CaptionVisible="true" DataSourceID="ds" Width="100%" Height="100%" SkinID="Details" SyncPosition="True" AutoAdjustColumns="True" OnRowDataBound="PXGridPlanDetail_RowDataBound">
                <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                    AnonFilteredMessage="No records found.
Try to change filter to see records here."
                    ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                    FilteredAddMessage="No records found.
Try to change filter to see records here."
                    FilteredMessage="No records found.
Try to change filter to see records here."
                    NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                    NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                    NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                    NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                    <Behavior RepaintControlsIDs="form,PXGridTestResult,PXGridCheckList"></Behavior>
                </AutoCallBack>
                <Levels>
                    <px:PXGridLevel DataMember="InspectionOrderPlanDetail" DataKeyNames="QCInspectionOrderPlanDetailID">
                        <RowTemplate>
                            <px:PXSelector ID="edQCInspectionPlanID" runat="server" AlreadyLocalized="False" DataField="QCInspectionPlanID" Enabled="False" AllowAddNew="false" AllowEdit="false">
                            </px:PXSelector>
                            <px:PXTextEdit ID="edEWQCInspectionPlan__InspectionPlanCD" runat="server" AlreadyLocalized="False" DataField="EWQCInspectionPlan__InspectionPlanCD" Enabled="False">
                            </px:PXTextEdit>
                            <px:PXTextEdit ID="edEWQCInspectionPlan__Description" runat="server" AlreadyLocalized="False" DataField="EWQCInspectionPlan__Description">
                            </px:PXTextEdit>
                            <px:PXSegmentMask ID="edINItemClass__ItemClassCD" runat="server" DataField="INItemClass__ItemClassCD">
                            </px:PXSegmentMask>
                            <px:PXSegmentMask ID="edInventoryItem__InventoryCD" runat="server" DataField="InventoryItem__InventoryCD">
                            </px:PXSegmentMask>
                            <px:PXNumberEdit ID="edPassedTestCount" runat="server" AlreadyLocalized="False" DataField="PassedTestCount" CommitChanges="true">
                            </px:PXNumberEdit>
                            <px:PXNumberEdit ID="edFailedTestCount" runat="server" AlreadyLocalized="False" DataField="FailedTestCount" CommitChanges="true">
                            </px:PXNumberEdit>
                        </RowTemplate>
                        <Columns>
                            <px:PXGridColumn DataField="EWQCInspectionPlan__InspectionPlanCD" Width="180px" LinkCommand="ViewInspectionPlan" CommitChanges="true">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="EWQCInspectionPlan__Name" Width="180px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="EWQCInspectionPlan__Description" Width="280px">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="INItemClass__ItemClassCD" Width="140px" LinkCommand="ViewItemClass">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="InventoryItem__InventoryCD" Width="140px" LinkCommand="ViewInventoryItem">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="DisplayBOMID">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="OperationCD">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="PassedTestCount">
                            </px:PXGridColumn>
                            <px:PXGridColumn DataField="FailedTestCount">
                            </px:PXGridColumn>
                        </Columns>
                    </px:PXGridLevel>
                </Levels>
            </px:PXGrid>
        </Template1>--%>

    <px:PXTab ID="tabParent" runat="server" Width="100%" Height="100%" DataSourceID="ds">
        <Items>
            <px:PXTabItem Text="Plans">
                <Template>
                    <px:PXGrid runat="server" ID="PXGridPlanDetail" Caption="Plan Detail" CaptionVisible="true" DataSourceID="ds" Width="100%" Height="120px" SkinID="Details" SyncPosition="True" AutoAdjustColumns="True" OnRowDataBound="PXGridPlanDetail_RowDataBound">
                        <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                            NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />

                        <Levels>
                            <px:PXGridLevel DataMember="InspectionOrderPlanDetail" DataKeyNames="QCInspectionOrderPlanDetailID">
                                <RowTemplate>
                                    <px:PXSelector ID="edQCInspectionPlanID" runat="server" AlreadyLocalized="False" DataField="QCInspectionPlanID" Enabled="False" AllowAddNew="false" AllowEdit="false">
                                    </px:PXSelector>
                                    <px:PXTextEdit ID="edEWQCInspectionPlan__InspectionPlanCD" runat="server" AlreadyLocalized="False" DataField="EWQCInspectionPlan__InspectionPlanCD" Enabled="False">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edEWQCInspectionPlan__Description" runat="server" AlreadyLocalized="False" DataField="EWQCInspectionPlan__Description">
                                    </px:PXTextEdit>
                                    <%-- <px:PXSegmentMask ID="edINItemClass__ItemClassCD" runat="server" DataField="INItemClass__ItemClassCD">
                            </px:PXSegmentMask>--%>
                                    <px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID">
                                    </px:PXSegmentMask>
                                    <px:PXNumberEdit ID="edPassedTestCount" runat="server" AlreadyLocalized="False" DataField="PassedTestCount" CommitChanges="true">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edFailedTestCount" runat="server" AlreadyLocalized="False" DataField="FailedTestCount" CommitChanges="true">
                                    </px:PXNumberEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__InspectionPlanCD" Width="180px" LinkCommand="ViewInspectionPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCInspectionPlan__Description" Width="280px">
                                    </px:PXGridColumn>
                                    <%--<px:PXGridColumn DataField="INItemClass__ItemClassCD" Width="140px" LinkCommand="ViewItemClass">
                            </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="InventoryItem__InventoryCD" Width="140px" LinkCommand="ViewInventoryItem">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DisplayBOMID">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="OperationCD">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PassedTestCount">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FailedTestCount">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="PXGridTestResult,StepsGrid1"></Behavior>
                        </AutoCallBack>
                        <AutoSize Enabled="True" />
                    </px:PXGrid>

                    <px:PXGrid ID="PXGridTestResult" runat="server" Caption="Tests" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" TabIndex="2600" OnRowDataBound="PXGridTestResult_RowDataBound">
                        <AutoSize Enabled="true" MinHeight="300" />
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>

                        <Levels>
                            <px:PXGridLevel DataMember="InspectionOrderPlanTestDetail" DataKeyNames="QCInspectionOrderPlanDetailID,QCInspectionOrderPlanTestDetailID">
                                <RowTemplate>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXSelector ID="edEWQCVariableVariableCD" runat="server" DataField="EWQCVariable__VariableCD" CommitChanges="True" AllowEdit=" true">
                                    </px:PXSelector>
                                    <px:PXTextEdit ID="edEWQCVariableName" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Name">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Description">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edSteps" runat="server" AlreadyLocalized="False" DataField="Steps">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="EWQCTestCategoryName" runat="server" DataField="EWQCTestCategory__Name" AllowEdit="true">
                                    </px:PXTextEdit>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXTextEdit ID="edEWQCTestMethodName" runat="server" AlreadyLocalized="False" DataField="EWQCTestMethod__Name" CommitChanges="True">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edToolSteps" runat="server" AlreadyLocalized="False" DataField="ToolSteps">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edEWQCSeverityLevelName" runat="server" DataField="EWQCSeverityLevel__Name" AllowEdit="true">
                                    </px:PXTextEdit>
                                    <px:PXSelector ID="edEWQCVariableUnit" runat="server" DataField="EWQCVariable__Unit" AllowEdit="true">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edAssignedToID" runat="server" DataField="AssignedToID">
                                        <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
                                    </px:PXSelector>
                                     <px:PXTextEdit ID="edEquation" runat="server" DataField="Equation" Width="180px" AlreadyLocalized="False" CommitChanges="true"/>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXDropDown ID="edDataType" runat="server" DataField="DataType" Enabled="False">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edExpectedValue" runat="server" AlreadyLocalized="False" DataField="ExpectedValue" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="edTestValue" />
                                    <%-- <px:PXNumberEdit ID="edNumTargetValue" runat="server" AlreadyLocalized="False" DataField="NumTargetValue">
                                            </px:PXNumberEdit>
                                              <px:PXCheckBox ID="edBitPassFail" runat="server" AlreadyLocalized="False" DataField="BitPassFail" Text="Bit Pass Fail" >
                                            </px:PXCheckBox>
                                            <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="Bit Go No Go">
                                            </px:PXCheckBox>--%>
                                    <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
                                    </px:PXTextEdit>
                                    <px:PXDropDown ID="edActualResult" runat="server" DataField="ActualResult">
                                    </px:PXDropDown>

                                    <px:PXDropDown ID="edFinalResult" runat="server" DataField="FinalResult">
                                    </px:PXDropDown>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest" Enabled="false">
                                    </px:PXCheckBox>
                                    <px:PXTextEdit runat="server" DataField="Remarks" CommitChanges="True" ID="edRemarks" TextMode="MultiLine" />
                                    <px:PXCheckBox ID="edIncludeInReport" runat="server" AlreadyLocalized="False" DataField="IncludeInReport">
                                    </px:PXCheckBox>
                                    <%--  <px:PXSelector ID="edToolgauge" runat="server" DataField="ToolGaugeID">
                                            </px:PXSelector>--%>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px" LinkCommand="ViewTest" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestCategory__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCTestMethod__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="ToolGaugeID" Width="180px" >
                                            </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Unit" Width="80px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true" LinkCommand="viewAssignedToID"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="DataType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Equation" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Formula" Width="180px" LinkCommand="GoToEquation" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ExpectedValue" Width="280px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestValue" CommitChanges="true" MatrixMode="true" />
                                    <px:PXGridColumn DataField="TestResultUOM" Width="220px"></px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="NumTargetValue" CommitChanges="True" Width="100px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="AlphaValue" CommitChanges="True" Width="280px">
                                            </px:PXGridColumn>--%>
                                    <%-- <px:PXGridColumn DataField="BitPassFail" CommitChanges="True" TextAlign="Center" Type="CheckBox" Width="60px">
                                            </px:PXGridColumn>--%>
                                    <%--<px:PXGridColumn DataField="BitGoNoGo" CommitChanges="True" TextAlign="Center" Type="CheckBox" Width="120px">
                                            </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="ActualResult" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FinalResult" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Remarks" Width="280px">
                                    </px:PXGridColumn>

                                    <px:PXGridColumn DataField="IncludeInReport" Width="60px" TextAlign="Center" Type="CheckBox">
                                    </px:PXGridColumn>

                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <Mode InitNewRow="True" AllowFormEdit="True" AllowDragRows="True" AutoInsert="true"></Mode>
                    </px:PXGrid>

                </Template>
                <AutoCallBack Target="PXGridTestResult" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGridTestResult,StepsGrid1" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="CheckList Group">
                <Template>
                 <%-- <px:PXSplitContainer runat="server" Orientation="Horizontal" Panel1MinSize="200" Panel2MinSize="100" SplitterPosition="40" PositionInPercent="True" ID="splitConditions">
                        <AutoSize Container="Window" Enabled="true" />
                        <Template1>--%>
       
                           <px:PXGrid runat="server" DataSourceID="ds" ID="PXGridCheckList" Caption="Checklist" SkinID="DetailsInTab" TabIndex="27364" Width="100%" Height="100%" NoteIndicator="true" FilesIndicator="true" SyncPosition="true">
                                        <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                            ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                                            FilteredMessage="No records found.
Try to change filter to see records here."
                                            NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                            NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                            NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                                            NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                                        <Levels>
                                            <px:PXGridLevel DataMember="InspectionOrderPlanChkList" DataKeyNames="QCInspectionOrderChecklistGroupDetailID,QCInspectionOrderPlanChkListID" > 
                                                <Columns>
                                                     <px:PXGridColumn DataField="EWQCChecklistGroup__ChecklistGroupCD" LinkCommand="ViewChecklistGroup" Width="150px"></px:PXGridColumn>
                                                     <px:PXGridColumn DataField="EWQCChecklistGroup__Description" Width="160px"></px:PXGridColumn>
                                                    <px:PXGridColumn DataField="EWQCChecklist__ChecklistCD" LinkCommand="ViewCheckListItem" Width="150px">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="EWQCChecklist__Name" Width="150px">
                                                    </px:PXGridColumn>
                                                    <px:PXGridColumn DataField="EWQCChecklist__Description" Width="280px">
                                                    </px:PXGridColumn>
                                                    <%--<px:PXGridColumn DataField="Steps" Width="150px" LinkCommand="CheckListSteps">
                                                    </px:PXGridColumn>--%>
                                                    <px:PXGridColumn DataField="Completed" TextAlign="Center" Type="CheckBox" Width="90px" CommitChanges="true">
                                                    </px:PXGridColumn>
                                                     <px:PXGridColumn DataField="Executedby" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedDate" Width="150px">
                                            </px:PXGridColumn>   
                                                    <px:PXGridColumn DataField="Remarks" Width="250px">
                                                    </px:PXGridColumn>
                                                </Columns>
                                            </px:PXGridLevel>
                                        </Levels>
                                      <AutoSize Enabled="True" Container="Window" />
                                        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
                                            <Behavior RepaintControlsIDs="TaskGrid"></Behavior>
                                        </AutoCallBack>
                                    </px:PXGrid>
                        <%--</Template1>
                        <Template2>--%>
                            <px:PXGrid ID="TaskGrid" runat="server" Caption="Tasks" DataSourceID="ds" SkinID="DetailsInTab"
                                Width="100%" Height="100%" AutoAdjustColumns ="true" SyncPosition ="True">

                                <Levels>
                                    <px:PXGridLevel DataMember="InsOrdPlanChkListTask">
                                        <Columns>
                                            <px:PXGridColumn DataField="Name" Width="400px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Description" Width="600px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Completed" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="90px" CommitChanges="true" AllowSort="False" AllowMove="False">
                                            </px:PXGridColumn>
                                             <px:PXGridColumn DataField="Executedby" Width="150px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExecutedDate" Width="150px">
                                            </px:PXGridColumn>   
                                            <px:PXGridColumn DataField="Remark" Width="600px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                                <AutoSize Enabled="True" />
                            </px:PXGrid>
                       <%-- </Template2>
                    </px:PXSplitContainer>--%>
                </Template>
                <AutoCallBack Target="PXGridCheckList" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGridCheckList, TaskGrid" />
                </AutoCallBack>
            </px:PXTabItem>	
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">
                        <%--AutoAdjustColumns="true"--%>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" Width="240px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>

    <%-- <Template2>
            <px:PXTab ID="tab2" runat="server" Width="100%" Height="100%" DataSourceID="ds">
                <Items>
                    <px:PXTabItem Text="Tests">
                        <Template>
                            
                        </Template>
                        <AutoCallBack Target="PXGridTestResult" Command="Refresh">
                            <Behavior RepaintControlsIDs="PXGridTestResult" />
                        </AutoCallBack>
                    </px:PXTabItem>       
                    <px:PXTabItem Text="Event History">
                        <Template>
                            <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">
                               
                                <Levels>
                                    <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                        <Columns>
                                            <px:PXGridColumn DataField="CreatedDateTime" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Description" Width="240px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EventType" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="CreatedByID" Width="180px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" />
                                <AutoCallBack />
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="PXGrid3" Command="Refresh">
                            <Behavior RepaintControlsIDs="PXGrid3" />
                        </AutoCallBack>
                    </px:PXTabItem>
                </Items>
                <AutoSize Container="Window" Enabled="True" MinHeight="150" />
            </px:PXTab>
        </Template2>
    </px:PXSplitContainer>--%>
</asp:Content>
<asp:Content ID="cont4" ContentPlaceHolderID="phDialogs" runat="server">
    <px:PXSmartPanel ID="pnlTestSteps" runat="server" Height="500px" Width="1100px" Caption="Test Steps" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="TestSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid" AutoCallBack-Command="Refresh" DesignView="Content">

        <px:PXGrid ID="StepsGrid" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">

            <Levels>
                <px:PXGridLevel DataMember="TestSteps">
                    <Columns>
                        <px:PXGridColumn DataField="Name">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="PXSmartPanelChecklistSteps" runat="server" Height="500px" Width="1100px" Caption="Test Steps"
        CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="InspectionOrderPlanChkListSteps" Style="position: static"
        AutoCallBack-Target="PXGridChecklistSteps" AutoCallBack-Command="Refresh" DesignView="Content">

        <px:PXGrid ID="PXGridChecklistSteps" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%" TabIndex="-272">

            <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                AnonFilteredMessage="No records found.
Try to change filter to see records here."
                ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                FilteredAddMessage="No records found.
Try to change filter to see records here."
                FilteredMessage="No records found.
Try to change filter to see records here."
                NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
            <Levels>
                <px:PXGridLevel DataMember="InspectionOrderPlanChkListSteps">
                    <Columns>
                        <%--<px:PXGridColumn DataField="QCInspectionOrderPlanChkListID">
                        </px:PXGridColumn>--%>
                        <px:PXGridColumn DataField="EWQCChecklistStep__ChecklistStepID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="EWQCChecklistStep__Name" Width="180px">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="EWQCChecklistStep__Description" Width="280px">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanelChecklistSteps" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButtonChecklistStepsOK" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="pnlTestSteps1" runat="server" Height="500px" Width="1100px" Caption="QC Tool" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ToolSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel11" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="pnlEquation" runat="server" Height="500px" Width="800px" Caption="Equation" CaptionVisible="true" AutoReload="true" Key="QCOrderTestFormula" Style="position: static"
        AutoCallBack-Target="PXGridEquation" AutoCallBack-Command="Refresh" DesignView="Content" AutoRepaint="true">
        <px:PXGrid ID="PXGridEquation" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataKeyNames="QCOrderSamplingDetailID" DataMember="QCOrderTestFormula">
                    <RowTemplate>

                        <px:PXTextEdit ID="edParameter" runat="server" AlreadyLocalized="False" DataField="ParameterName" Enabled="false" Width="600px">
                        </px:PXTextEdit>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ParameterName">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="EWQCTestParameter__Description"></px:PXGridColumn>
                        <px:PXGridColumn DataField="FormulaValue">
                        </px:PXGridColumn>

                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode InitNewRow="False" AllowFormEdit="False" AllowDragRows="True" AutoInsert="False" AllowAddNew="False" AllowDelete="False"></Mode>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel10" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton2" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitFormula" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnInvCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>





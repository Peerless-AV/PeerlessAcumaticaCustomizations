﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" CodeFile="QC209003.aspx.cs" Inherits="Pages_QC209003" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">

    <px:pxdatasource id="ds" primaryview="EWQCcertificate" typename="EW.QC.EWQCCertificationMaint" runat="server" visible="True" width="100%" attributesfound="False" enableattributes="true" suspendunloading="False" pageloadbehavior="InsertRecord">
        <CallbackCommands>
        </CallbackCommands>
    </px:pxdatasource>

</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="EWQCcertificate" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edCertificateCD" runat="server" AlreadyLocalized="False" DataField="CertificateCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" Height="50" DataField="Description" TextMode="MultiLine">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M">
            </px:PXLayoutRule>
            <%--<px:PXCheckBox ID="edMandatoryCertificate" runat="server" alignright="true" AlreadyLocalized="False" DataField="MandatoryCertificate" Text="Mandatory Certificate">
            </px:PXCheckBox>--%>
            <%--<px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>--%>
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="detailGrid" runat="server" datasourceid="ds" skinid="Details"
        caption="attributes" captionvisible="True" width="100%" syncposition="true" autoadjustcolumns="true">
        <Levels>
            <px:PXGridLevel DataKeyNames="CertificateVariableStepID" DataMember="EWQCCertificatevariable">
                <RowTemplate>
                    <px:PXTextEdit ID="edName1" runat="server" AlreadyLocalized="False" DataField="Name">
                    </px:PXTextEdit>
                     <px:PXDropDown ID="edDataType" runat="server" AlreadyLocalized="False" DataField="DataType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edDescription1" runat="server" AlreadyLocalized="False" DataField="Description">
                    </px:PXTextEdit>
                     <%--<px:PXTextEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                    </px:PXTextEdit>--%>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Name">
                    </px:PXGridColumn>
                     <px:PXGridColumn DataField="DataType">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description">
                    </px:PXGridColumn>
                    <%--<px:PXGridColumn DataField="LineNbr">
                    </px:PXGridColumn>--%>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>




<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC305200.aspx.cs" Inherits="Page_QC305200" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="true" runat="server" visible="True" width="100%" typename="EW.QC.EWQCNCCapaTranEntry" primaryview="NCCapaTran" attributesfound="False" suspendunloading="False" pageloadbehavior="InsertRecord">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="AddInvestigation" Visible="False" RepaintControls="All" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="UpdateInvestigation" Visible="False" CommitChanges="true" DependOnGrid="PXGrid2"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddUpdateInvestigation" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>

            <px:PXDSCallbackCommand Name="AddCorrectiveAction" Visible="False" RepaintControls="All" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="UpdateCorrectiveAction" Visible="False" CommitChanges="true" DependOnGrid="PXGrid3"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddUpdateCorrectiveAction" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>

            <px:PXDSCallbackCommand Name="AddPreventiveAction" Visible="False" RepaintControls="All" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="UpdatePreventiveAction" Visible="False" CommitChanges="true" DependOnGrid="PXGrid4"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddUpdatePreventiveAction" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>

            <px:PXDSCallbackCommand Name="AddVerification" Visible="False" RepaintControls="All" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="UpdateVerification" Visible="False" CommitChanges="true" DependOnGrid="PXGrid5"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="AddUpdateVerification" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>

            <px:PXDSCallbackCommand Name="ViewVerifiedBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewApprovedBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewCAActionBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewPAActionBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewReportedBy" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="viewNcNumber" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
               <px:PXDSCallbackCommand Name="viewNcDocNumber" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
               <px:PXDSCallbackCommand Name="viewInventoryId" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="PXFormView1" runat="server" datasourceid="ds" style="z-index: 100" width="100%" datamember="NCCapaTran" caption="CAPA Transaction" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
            <px:PXSelector ID="edCapaTranCD" runat="server" AlreadyLocalized="False" DataField="CapaTranCD" AutoRefresh="true" CommitChanges="True">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edCreatedDate" runat="server" DataField="CreatedDate"></px:PXDateTimeEdit>

            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
            <px:PXDropDown ID="edStatus" runat="server" ReadOnly="true" DataField="Status" />
            <px:PXSelector ID="edPriority" runat="server" DataField="Priority">
                <GridProperties FastFilterFields="Name,Description" ></GridProperties>
                 </px:PXSelector>

            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
            <px:PXSelector ID="edOwner" runat="server" DataField="Owner">
                <GridProperties FastFilterFields="AcctCD,AcctName" ></GridProperties>
            </px:PXSelector>
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" width="100%" height="120px">
       <AutoSize Enabled="True" Container="Window" MinHeight="350"></AutoSize>
        <Items>
            <px:PXTabItem Text="Origin Tab">
                <Template>
                    <px:PXFormView ID="formOrigin" runat="server" DataMember="NCCapaTranSelected" Style="z-index: 100" Width="100%"
                        DataSourceID="ds" SkinID="Transparent">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
                            <px:PXSelector runat="server" ID="edAssignedTo" DataField="AssignedTo">
                                 <GridProperties FastFilterFields="AcctCD,AcctName" ></GridProperties>
                            </px:PXSelector>
                            <px:PXSelector runat="server" ID="edCategory" DataField="Category">
                                 <GridProperties FastFilterFields="Name,Description" ></GridProperties>
                            </px:PXSelector>
                            <px:PXSelector runat="server" ID="edType" DataField="Type">
                                 <GridProperties FastFilterFields="Name,Description" ></GridProperties>
                            </px:PXSelector>

                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXSelector ID="edDepartment" runat="server" AlreadyLocalized="False" DataField="Department">
                                 <GridProperties FastFilterFields="DepartmentID,Description" ></GridProperties>
                            </px:PXSelector>
                            <px:PXDateTimeEdit ID="edtartDate" runat="server" DataField="StartDate"></px:PXDateTimeEdit>
                            <px:PXDateTimeEdit ID="edCompletionDate" runat="server" DataField="CompletionDate"></px:PXDateTimeEdit>

                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
                            <px:PXSelector ID="edReasonCode" runat="server" DataField="ReasonCode">
                                 <GridProperties FastFilterFields="Name,Description" ></GridProperties>
                            </px:PXSelector>         
                            <px:PXDateTimeEdit ID="edDetailCompletedDate" runat="server" DataField="DetailCompletedDate"></px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
                          <%--  <px:PXRichTextEdit ID="edDescription" runat="server" DataField="Description" AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">--%>
                               <px:PXRichTextEdit ID="edDeliveryNotes" runat="server" DataField="Description" 
                            Style="width: 100%;height: 120px" AllowAttached="true" AllowSearch="true"
                            AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                            <AutoSize Enabled="True" MinHeight="216" />
                        </px:PXRichTextEdit>
                                <%--<AutoSize Enabled="True" MinHeight="155"></AutoSize>--%>
                           <%-- //</px:PXRichTextEdit>--%>
                            <px:PXCheckBox ID="edIsOriginCompleted" runat="server" DataField="IsOriginCompleted" AlignLeft="true" CommitChanges="true"></px:PXCheckBox>
                        </Template>
                    </px:PXFormView>
                    <!-- BEGIN: Related NC Grid -->

                    <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" TabIndex="2600" >
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <ActionBar>
                            <Actions>
                               <%-- <AddNew Enabled="false" />--%>
                            </Actions>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="NCCAPADetailID" DataMember="NCCAPADetails">
                                <Columns>
                                    <px:PXGridColumn DataField="NCTranCD" Width="180px" LinkCommand="viewNcNumber">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="NCDate" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Status" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPriority__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RepotedBy" Width="180px" CommitChanges="true" LinkCommand="viewReportedBy">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Source" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RefDocNumber" Width="180px" LinkCommand="viewNcDocNumber">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InventoryItem__InventoryCD" Width="180px" LinkCommand="viewInventoryId">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LotNumber" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                    </px:PXGrid>

                    <!-- END: Related NC Grid -->
                </Template>
                <AutoCallBack Target="formOrigin" Command="Refresh">
                    <Behavior RepaintControlsIDs="formOrigin" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Investigation" RepaintOnDemand="false">
                <Template>
                    <!-- BEGIN: Related Investigation Grid -->
                    <px:PXGrid ID="PXGrid2" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" SyncPosition="true" RepaintColumns="true" Height="150px" AutoAdjustColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                     <%--  // <Mode InitNewRow="false" />--%>
                        <ActionBar>
                            <Actions>
                              <%--  <AddNew Enabled="false" />--%>
                                <EditRecord Enabled="false" />
                            </Actions>
                            <CustomItems>
                                <px:PXToolBarButton Text="Add">
                                    <AutoCallBack Command="AddInvestigation" Target="ds">
                                        <Behavior PostData="Page" CommitChanges="True"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="CapaTranID,CAPATranInvestigationID" DataMember="NCCapaInvestigation">
                                <%--<RowTemplate>
                                    <px:PXSelector ID="gdAnalysisPerformedBy" AllowEdit="true" runat="server" AlreadyLocalized="False" DataField="AnalysisPerformedBy" AutoRefresh="true">
                                    </px:PXSelector>
                                </RowTemplate>--%>
                                 <RowTemplate>                                 
                                      <px:PXTextEdit ID="edLineNbr1" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                        <px:PXGridColumn DataField="LineNbr"  Width="0" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="true" DataField="View" LinkCommand="UpdateInvestigation"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="InvDescription" Width="0" CommitChanges ="true" />
                                    <px:PXGridColumn DataField="UnformattedDescription" Width="180px" CommitChanges ="true" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InvStartDate" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="InvEndDate" Width="180px">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g"  Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                                 <Mode AllowAddNew="false" AllowUpdate="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <%--<AutoSize Enabled="True" MinHeight="150"></AutoSize>--%>
                        <AutoCallBack Enabled="true" Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="formInvestigation"></Behavior>
                        </AutoCallBack>
                    </px:PXGrid>
                    <!-- END: Related Investigation Grid -->
                    <px:PXFormView ID="formInvestigation" runat="server" DataSourceID="ds" DataMember="NCCapaTranSelected" RenderStyle="Simple">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="XM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXCheckBox ID="edIsInvCompleted" runat="server" Width="200px" DataField="IsInvCompleted" AlignLeft="true" CommitChanges="true"></px:PXCheckBox>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edInvCompletedDate" runat="server" DataField="InvCompletedDate"></px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXSelector ID="edInvCompletedBy" runat="server" AlreadyLocalized="False" DataField="InvCompletedBy">
                            </px:PXSelector>
                        </Template>
                    </px:PXFormView>
                </Template>
                <AutoCallBack Target="tree" Command="Refresh, AddNewInvestigation">
                    <Behavior RepaintControlsIDs="formInvestigation, PXGrid2" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Corrective Action" RepaintOnDemand="false">
                <Template>
                    <!-- BEGIN: Related Corrective Grid -->
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" SyncPosition="True" TabIndex="2600" Height="150px"  AutoAdjustColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
<%--                        <Mode InitNewRow="false" />--%>
                        <ActionBar>
                            <Actions>
                               <%-- <AddNew Enabled="false" />--%>
                                <EditRecord Enabled="false" />
                            </Actions>
                            <CustomItems>
                                <px:PXToolBarButton Text="Add">
                                    <AutoCallBack Command="AddCorrectiveAction" Target="ds">
                                        <Behavior PostData="Page" CommitChanges="True"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="CapaTranID,CAPATranCorrectiveActionID" DataMember="NCCapaCorrectiveAction">
                                 <RowTemplate>                                 
                                      <px:PXTextEdit ID="edLineNbr2" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                       <px:PXGridColumn DataField="LineNbr"  Width="0" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="true" DataField="View" LinkCommand="UpdateCorrectiveAction"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="CADescription" Width="0" CommitChanges ="true" />
                                    <px:PXGridColumn DataField="UnformattedDescription" Width="180px" CommitChanges ="true" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CAActionBy" Width="180px" CommitChanges="true" LinkCommand="viewCAActionBy">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CAActionOn" Width="180px">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g"  Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                                 <Mode AllowAddNew="false" AllowUpdate="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <%--<AutoSize Enabled="True" MinHeight="150"></AutoSize>--%>
                        <AutoCallBack Enabled="true" Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="formCorrective"></Behavior>
                        </AutoCallBack>
                    </px:PXGrid>
                    <!-- END: Related Corrective Grid -->
                    <px:PXFormView ID="formCorrective" runat="server" DataSourceID="ds" DataMember="NCCapaTranSelected" RenderStyle="Simple">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="XM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXCheckBox ID="edIsCACompleted" runat="server" Width="200px" DataField="IsCACompleted" AlignLeft="true" CommitChanges="true"></px:PXCheckBox>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edCACompletedDate" runat="server" DataField="CACompletedDate"></px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXSelector ID="edCACompletedBy" runat="server" AlreadyLocalized="False" DataField="CACompletedBy">
                            </px:PXSelector>
                        </Template>
                    </px:PXFormView>
                </Template>
                <AutoCallBack Target="tree" Command="Refresh, AddCorrectiveAction">
                    <Behavior RepaintControlsIDs="formCorrective, PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Preventive Action" RepaintOnDemand="false">
                <Template>
                    <!-- BEGIN: Related Preventive Grid -->
                    <px:PXGrid ID="PXGrid4" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" SyncPosition="True" TabIndex="2600" Height="150px"  AutoAdjustColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                      <%--  <Mode InitNewRow="false" />--%>
                        <ActionBar>
                            <Actions>
                         <%--       <AddNew Enabled="false" />--%>
                                <EditRecord Enabled="false" />
                            </Actions>
                            <CustomItems>
                                <px:PXToolBarButton Text="Add">
                                    <AutoCallBack Command="AddPreventiveAction" Target="ds">
                                        <Behavior PostData="Page" CommitChanges="True"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="CapaTranID,CAPATranPreventiveActionID" DataMember="NCCapaPreventiveAction">
                                 <RowTemplate>                                 
                                      <px:PXTextEdit ID="edLineNbr3" runat="server" AlreadyLocalized="False" DataField="LineNbr" >
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                       <px:PXGridColumn DataField="LineNbr"  Width="0" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="true" DataField="View" LinkCommand="UpdatePreventiveAction"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="PADescription" Width="0" CommitChanges ="true" />
                                    <px:PXGridColumn DataField="UnformattedDescription" Width="180px" CommitChanges ="true" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PAActionBy" Width="180px" CommitChanges="true" LinkCommand="viewPAActionBy">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="PAActionOn" Width="180px">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g"  Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                                 <Mode AllowAddNew="false" AllowUpdate="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <%--<AutoSize Enabled="True" MinHeight="150"></AutoSize>--%>
                        <AutoCallBack Enabled="true" Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="formPreventive"></Behavior>
                        </AutoCallBack>
                    </px:PXGrid>
                    <!-- END: Related Preventive Grid -->
                    <px:PXFormView ID="formPreventive" runat="server" DataSourceID="ds" DataMember="NCCapaTranSelected" RenderStyle="Simple">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="XM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXCheckBox ID="edIsPACompleted" runat="server" Width="200px" DataField="IsPACompleted" AlignLeft="true" CommitChanges="true"></px:PXCheckBox>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edPACompletedDate" runat="server" DataField="PACompletedDate"></px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXSelector ID="edPACompletedBy" runat="server" AlreadyLocalized="False" DataField="PACompletedBy">
                            </px:PXSelector>
                        </Template>
                    </px:PXFormView>
                </Template>
                <AutoCallBack Target="tree" Command="Refresh, AddPreventiveAction">
                    <Behavior RepaintControlsIDs="formPreventive, PXGrid4" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Verification" RepaintOnDemand="false">
                <Template>
                    <!-- BEGIN: Related Verification Grid -->
                    <px:PXGrid ID="PXGrid5" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" SyncPosition="True" TabIndex="2600" Height="150px"  AutoAdjustColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                     <%--   <Mode InitNewRow="false" />--%>
                        <ActionBar>
                            <Actions>
                              <%--  <AddNew Enabled="false" />--%>
                                <EditRecord Enabled="false" />
                            </Actions>
                            <CustomItems>
                                <px:PXToolBarButton Text="Add">
                                    <AutoCallBack Command="AddVerification" Target="ds">
                                        <Behavior PostData="Page" CommitChanges="True"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="CapaTranID,CAPATranVerificationID" DataMember="NCCapaVerification">
                                 <RowTemplate>                                 
                                      <px:PXTextEdit ID="edLineNbr4" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                       <px:PXGridColumn DataField="LineNbr"  Width="0" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn CommitChanges="true" DataField="View" LinkCommand="UpdateVerification"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="VrfDescription" Width="0" CommitChanges ="true" />
                                    <px:PXGridColumn DataField="UnformattedDescription" Width="180px" CommitChanges ="true" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VrfVerifiedBy" Width="180px" CommitChanges="true" LinkCommand="viewVerifiedBy">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VrfApprovedBy" Width="180px" CommitChanges="true" LinkCommand="viewApprovedBy">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VrfVerifiedOn" Width="180px" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VrfApprovedOn" Width="180px" >
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                                 <Mode AllowAddNew="false" AllowUpdate="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <%--<AutoSize Enabled="True" MinHeight="150"></AutoSize>--%>
                        <AutoCallBack Enabled="true" Target="tree" Command="Refresh" ActiveBehavior="True">
                            <Behavior RepaintControlsIDs="formVerification"></Behavior>
                        </AutoCallBack>
                    </px:PXGrid>
                    <!-- END: Related Preventive Grid -->
                    <px:PXFormView ID="formVerification" runat="server" DataSourceID="ds" DataMember="NCCapaTranSelected" RenderStyle="Simple">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="XM" ControlSize="M"></px:PXLayoutRule>
                            <px:PXCheckBox ID="edIsVrfCompleted" runat="server" Width="200px" DataField="IsVrfCompleted" AlignLeft="true" CommitChanges="true"></px:PXCheckBox>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edVrfCompletedDate" runat="server" DataField="VrfCompletedDate"></px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
                            <px:PXSelector ID="edVrfCompletedBy" runat="server" AlreadyLocalized="False" DataField="VrfCompletedBy">
                            </px:PXSelector>
                        </Template>
                    </px:PXFormView>
                </Template>
                <AutoCallBack Target="tree" Command="Refresh, AddVerification">
                    <Behavior RepaintControlsIDs="formVerification, PXGrid5" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid6" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <ActionBar>
                            <Actions>
                                <AddNew Enabled="false" />
                                <Delete Enabled="false" />
                                <EditRecord Enabled="false" />
                            </Actions>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                   <px:PXGridColumn DataField="ActionBy" Width="108px"/>
                                      <px:PXGridColumn DataField="VerifiedBy" Width="108px"/>
                                     <px:PXGridColumn DataField="LineNumber" Width="108px"/>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid6" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid6" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
    </px:pxtab>
    <%-- Add Investigation Start --%>
    <px:pxsmartpanel id="PanelAddInvestigation" runat="server" height="400px" style="z-index: 108; left: 216px; position: absolute; top: 171px" width="873px" commandsourceid="ds" caption="Investigation"
        captionvisible="True" loadondemand="true" callbackmode-commitchanges="True" callbackmode-postdata="Page" autorepaint="true" key="InvestigationSmartPanel" autocallback-target="PXGrid2" autocallback-command="Refresh">
        <px:PXFormView ID="PXGrid2" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="InvestigationSmartPanel" CaptionVisible="False" SkinID="Transparent">
            <ContentStyle BackColor="Transparent" BorderStyle="None"></ContentStyle>
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" LabelsWidth="SM" ControlSize="S" SuppressLabel="True" StartColumn="true"></px:PXLayoutRule>
             <%--   <px:PXRichTextEdit ID="edInvDescription" runat="server" DataField="InvDescription" AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                    <AutoSize Enabled="True" ></AutoSize>
                </px:PXRichTextEdit>--%>

                     <px:PXRichTextEdit ID="edInvDescription" runat="server" DataField="InvDescription" 
                            Style="width: 100%;height: 120px" AllowAttached="true" AllowSearch="true"
                            AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                            <AutoSize Enabled="True" MinHeight="216" />
                        </px:PXRichTextEdit>

                <%--<px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edInvStartDate" runat="server" DataField="InvStartDate"></px:PXDateTimeEdit>
                <%--<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edInvEndDate" runat="server" DataField="InvEndDate"></px:PXDateTimeEdit>
            </Template>
        </px:PXFormView>
        <px:PXPanel ID="PXPanel3" runat="server" SkinID="Buttons">
            <px:PXButton ID="btnInvOK" SyncVisible="false" Text="OK" DialogResult="OK" runat="server">
                <AutoCallBack Command="AddUpdateInvestigation" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnInvCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:pxsmartpanel>

    <%-- Add Corrective Start --%>
    <px:pxsmartpanel id="PanelCorrectiveAction" runat="server" height="400px" style="z-index: 108; left: 216px; position: absolute; top: 171px" width="873px" commandsourceid="ds" caption="Corrective Action"
        captionvisible="True" loadondemand="true" callbackmode-commitchanges="True" callbackmode-postdata="Page" autorepaint="true" key="CorrectiveActionSmartPanel" autocallback-target="frmCorrectiveAction" autocallback-command="Refresh">
        <px:PXFormView ID="frmCorrectiveAction" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="CorrectiveActionSmartPanel" CaptionVisible="False" SkinID="Transparent">
            <ContentStyle BackColor="Transparent" BorderStyle="None"></ContentStyle>
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
            <%--    <px:PXRichTextEdit ID="edCADescription" runat="server" DataField="CADescription" Style="border-width: 0px; border-top-width: 1px; width: 100%;"
                    AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                    <AutoSize Enabled="True" ></AutoSize>
                </px:PXRichTextEdit>--%>
                   <px:PXRichTextEdit ID="edCADescription" runat="server" DataField="CADescription" 
                            Style="width: 100%;height: 120px" AllowAttached="true" AllowSearch="true"
                            AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                            <AutoSize Enabled="True" MinHeight="216" />
                        </px:PXRichTextEdit>

               <%-- <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXSelector ID="edCAActionBy" runat="server" DataField="CAActionBy"></px:PXSelector>
                <%--<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edCAActionOn" runat="server" DataField="CAActionOn"></px:PXDateTimeEdit>
            </Template>
        </px:PXFormView>
        <px:PXPanel ID="PXPanel1" runat="server" SkinID="Buttons">
            <px:PXButton ID="btnOkCorrectiveAction" SyncVisible="false" Text="OK" DialogResult="OK" runat="server">
                <AutoCallBack Command="AddUpdateCorrectiveAction" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnCancelCorrectiveAction" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:pxsmartpanel>

    <%-- Add Preventive Start --%>
    <px:pxsmartpanel id="PanelPreventiveAction" runat="server" height="400px" style="z-index: 108; left: 216px; position: absolute; top: 171px" width="873px" commandsourceid="ds" caption="Preventive Action"
        captionvisible="True" loadondemand="true" callbackmode-commitchanges="True" callbackmode-postdata="Page" autorepaint="true" key="PreventiveActionSmartPanel" autocallback-target="frmPreventiveAction" autocallback-command="Refresh">
        <px:PXFormView ID="frmPreventiveAction" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="PreventiveActionSmartPanel" CaptionVisible="False" SkinID="Transparent">
            <ContentStyle BackColor="Transparent" BorderStyle="None"></ContentStyle>
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M"></px:PXLayoutRule>
               <%-- <px:PXRichTextEdit ID="edPADescription" runat="server" DataField="PADescription" Style="border-width: 0px; border-top-width: 1px; width: 100%;"
                    AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                    <AutoSize Enabled="True" ></AutoSize>
                </px:PXRichTextEdit>--%>
                          <px:PXRichTextEdit ID="edPADescription" runat="server" DataField="PADescription" 
                            Style="width: 100%;height: 120px" AllowAttached="true" AllowSearch="true"
                            AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                            <AutoSize Enabled="True" MinHeight="216" />
                        </px:PXRichTextEdit>

                <%--<px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXSelector ID="edPAActionBy" runat="server" DataField="PAActionBy"></px:PXSelector>
                <%--<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edPAActionOn" runat="server" DataField="PAActionOn"></px:PXDateTimeEdit>
            </Template>
        </px:PXFormView>
        <px:PXPanel ID="PXPanel2" runat="server" SkinID="Buttons">
            <px:PXButton ID="btnOkPreventiveAction" SyncVisible="false" Text="OK" DialogResult="OK" runat="server">
                <AutoCallBack Command="AddUpdatePreventiveAction" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="betCancelPreventiveAction" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:pxsmartpanel>

    <%-- Add Verification Start --%>
    <px:pxsmartpanel id="PanelVerification" runat="server" height="400px" style="z-index: 108; left: 216px; position: absolute; top: 171px" width="873px" commandsourceid="ds" caption="Verification"
        captionvisible="True" loadondemand="true" callbackmode-commitchanges="True" callbackmode-postdata="Page" autorepaint="true" key="VerificationSmartPanel" autocallback-target="frmVerification" autocallback-command="Refresh">
        <px:PXFormView ID="frmVerification" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="VerificationSmartPanel" CaptionVisible="False" SkinID="Transparent">
            <ContentStyle BackColor="Transparent" BorderStyle="None"></ContentStyle>
            <Template>
                <px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>
           <%--     <px:PXRichTextEdit ID="edVrfDescription" runat="server" DataField="VrfDescription" Style="border-width: 0px; border-top-width: 1px; width: 100%;"
                    AllowAttached="true" AllowSearch="true" AllowLoadTemplate="false" AllowSourceMode="true">
                    <AutoSize Enabled="True" ></AutoSize>
                </px:PXRichTextEdit>--%>
                 <px:PXRichTextEdit ID="edVrfDescription" runat="server" DataField="VrfDescription" 
                            Style="width: 100%;height: 120px" AllowAttached="true" AllowSearch="true"
                            AllowMacros="true" AllowLoadTemplate="false" AllowSourceMode="true">
                            <AutoSize Enabled="True" MinHeight="216" />
                        </px:PXRichTextEdit>


                <%--<px:PXLayoutRule runat="server" StartRow="true"></px:PXLayoutRule>
                <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXSelector ID="edVrfVerifiedBy" runat="server" DataField="VrfVerifiedBy"></px:PXSelector>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edVrfVerifiedOn" runat="server" DataField="VrfVerifiedOn"></px:PXDateTimeEdit>


                <%--<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M"></px:PXLayoutRule>--%>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXSelector ID="edVrfApprovedBy" runat="server" DataField="VrfApprovedBy"></px:PXSelector>
                <px:PXLayoutRule runat="server" StartRow="true" StartColumn="True" ControlSize="XM" LabelsWidth="SM"></px:PXLayoutRule>
                <px:PXDateTimeEdit ID="edVrfApprovedOn" runat="server" DataField="VrfApprovedOn"></px:PXDateTimeEdit>
            </Template>
        </px:PXFormView>
        <px:PXPanel ID="PXPanel4" runat="server" SkinID="Buttons">
            <px:PXButton ID="benOkVerification" SyncVisible="false" Text="OK" DialogResult="OK" runat="server">
                <AutoCallBack Command="AddUpdateVerification" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnCancelVerification" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:pxsmartpanel>
</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209005.aspx.cs" Inherits="Page_QC209005" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCRatingScoreCriteriaMaint" AttributesFound="False" PrimaryView="Filter" SuspendUnloading="False">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <!--For View-->
    <px:PXTab ID="PXTab1" runat="server" Width="100%" Height="120px" DataSourceID="ds" DataMember="Filter" BPEventsIndicator="True">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
            <px:PXTabItem Text="Variance(+)">
                <Template>
                    <px:PXGrid ID="grid1" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="RatingScoreID" DataMember="PosRatingScores">
                                <RowTemplate>
                                    <px:PXDropDown ID="edCriteria" runat="server" DataField="Criteria" CommitChanges="true">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edVarianceIn" runat="server" AlreadyLocalized="False" DataField="VarianceIn" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edFromVar" runat="server" AlreadyLocalized="False" DataField="FromVar" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXCheckBox ID="edisabove" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="isabove">
                                    </px:PXCheckBox>
                                    <px:PXTextEdit ID="edToVar" runat="server" AlreadyLocalized="False" DataField="ToVar" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edScore" runat="server" AlreadyLocalized="False" DataField="Score" CommitChanges="true">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="Criteria" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VarianceIn" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FromVar" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="isabove" CommitChanges="true" Width="100px" TextAlign="Center" Type="CheckBox">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ToVar" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Score" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Enabled="True" Target="ds" Command="PositiveVariance" />
            </px:PXTabItem>
            <px:PXTabItem Text="Variance(-)">
                <Template>
                    <px:PXGrid ID="grid2" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="RatingScoreID" DataMember="NegRatingScores">
                                <RowTemplate>

                                    <px:PXDropDown ID="edCriterias" runat="server" DataField="Criteria" CommitChanges="true">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edDescriptions" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edVarianceIns" runat="server" AlreadyLocalized="False" DataField="VarianceIn" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edFromVars" runat="server" AlreadyLocalized="False" DataField="FromVar" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXCheckBox ID="edisaboves" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="isabove">
                                    </px:PXCheckBox>
                                    <px:PXTextEdit ID="edToVars" runat="server" AlreadyLocalized="False" DataField="ToVar" CommitChanges="true">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edScores" runat="server" AlreadyLocalized="False" DataField="Score" CommitChanges="true">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="Criteria" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="VarianceIn" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FromVar" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Isbelow" CommitChanges="true" Width="100px" TextAlign="Center" Type="CheckBox">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ToVar" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Score" CommitChanges="true" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Enabled="True" Target="ds" Command="NegativeVariance" />
            </px:PXTabItem>
            <px:PXTabItem Text="Weightage Criteria">
                <Template>
                    <px:PXGrid ID="Grid3" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="300" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="VendorRatingID" DataMember="VenRatingCriWeightage">
                                <RowTemplate>
                                    <px:PXDropDown ID="edCriteriaWeightage" runat="server" DataField="Criteria" Enabled="false">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edWeightage" runat="server" AlreadyLocalized="False" DataField="Weightage">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="PXDescription" runat="server" AlreadyLocalized="False" DataField="Description">
                                    </px:PXTextEdit>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="Criteria" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Weightage" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" AllowUpload="false" />
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Enabled="True" Target="ds" Command="WeightageVariance" />
            </px:PXTabItem>
        </Items>
    </px:PXTab>
</asp:Content>



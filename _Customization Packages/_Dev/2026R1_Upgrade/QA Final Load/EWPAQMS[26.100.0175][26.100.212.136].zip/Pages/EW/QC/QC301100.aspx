<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC301100.aspx.cs" Inherits="Page_QC301100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="False" runat="server" Visible="True" Width="100%" TypeName="EW.QC.EWQCAdhocOrderEntry" PrimaryView="adhocOrder">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="Release" CommitChanges="True"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="adhocOrder" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <%--<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM" />--%>
            <%--  <px:PXTextEdit ID="edAdhocQCOrderCD" runat="server" AlreadyLocalized="False" DataField="AdhocQCOrderCD" CommitChanges="true">
            </px:PXTextEdit>            
          
            <px:PXDropDown ID="edStatus" runat="server" AllowNull="False" DataField="Status" Enabled="False" />
                 <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />--%>

             <px:PXTextEdit ID="edBarcode" runat="server" DataField="Barcode">
            </px:PXTextEdit>

            <px:PXPanel ID="PXPanel1" runat="server" DataMember="adhocOrder" RenderStyle="Simple">
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" AutoRefresh="true" CommitChanges="true" Width="200px">
                <GridProperties FastFilterFields="InventoryCD,Descr"></GridProperties>
            </px:PXSelector>
            <px:PXSelector ID="edUsrInventoryID" runat="server" DataField="UsrInventoryID" AutoRefresh="true" CommitChanges="true" Width="200px">
                <GridProperties FastFilterFields="InventoryCD,Descr"></GridProperties>
            </px:PXSelector>
            <px:PXTextEdit ID="edDescription" runat="server" DataField="Description" Enabled="false" Width="200px" />

            <px:PXSelector ID="edPLanIDSelector" runat="server" DataField="PlanID" CommitChanges="true" Width="100%" AutoRefresh="true">
                <GridProperties FastFilterFields="Name,RevisonNo"></GridProperties>
            </px:PXSelector>
            <px:PXTextEdit ID="edPlanDescription" runat="server" DataField="PlanDescription" Enabled="false" Width="100%" />

            <px:PXSelector ID="edSamplingPlanID" runat="server" DataField="SamplingPlanID" CommitChanges="true" Enabled="false" AllowEdit="true" Width="100%" AutoRefresh="true"/>
                  
            </px:PXPanel>
            <%--  <px:PXTextEdit ID="edPlanId" runat="server" DataField="PlanName"  Enabled="false">               
            </px:PXTextEdit>   --%>
          
            <px:PXPanel ID="XX" runat="server" DataMember="InventoryDetail" RenderStyle="Simple">                           
                <px:PXTextEdit ID="PXTextEdit2" runat="server" DataField="EWQCSamplingPlan__Description" Enabled="false" Width="200px" />
            </px:PXPanel>

            <%-- <px:PXTextEdit ID="edSamplingDescription" runat="server" DataField="SamplingDescription" Enabled="false" Width="200px" />--%>
            <%--<px:PXDateTimeEdit CommitChanges="True" ID="edAdhocQCOrderDate" runat="server" DataField="AdhocQCOrderDate" LabelWidth="100" />--%>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edLotSerWarehouseID" runat="server" AlreadyLocalized="False" DataField="LotSerWarehouseID" CommitChanges="true" AutoRefresh="true" Width="450">
            </px:PXSelector>
            <px:PXSelector ID="edNonTrkWarehouseID" runat="server" AlreadyLocalized="False" DataField="NonTrkWarehouseID" CommitChanges="true" AutoRefresh="true" Width="450">
            </px:PXSelector>
            <px:PXSelector ID="edLocationID" runat="server" AlreadyLocalized="False" DataField="LocationID" CommitChanges="true" AutoRefresh="true" Width="450">
            </px:PXSelector>
            <px:PXSelector ID="edQCWarehouseID" runat="server" AlreadyLocalized="False" DataField="UsrQCWarehouseID" CommitChanges="true" AutoRefresh="true" Width="450">
                <GridProperties FastFilterFields="Descr"></GridProperties>
            </px:PXSelector>
            <%-- <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M">
            </px:PXLayoutRule>--%>
            <px:PXSelector ID="edUsrQCLocationID" runat="server" AlreadyLocalized="False" DataField="UsrQCLocationID" CommitChanges="true" AutoRefresh="true" Width="450">
            </px:PXSelector>
        </Template>
    </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" DataMember="adhocOrderDetail" NoteIndicator="True" FilesIndicator="True">
        <Items>
            <px:PXTabItem Text="Document Details" BindingContext="form">
                <Template>
                    <px:PXSplitContainer ID="PXSplitContainer" runat="server" SkinID="vertical" SplitterPosition="800" FixedPanel="Panel1" >                        
                            <Template1>
                                <px:PXGrid ID="formOrders" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" BorderStyle="None" SyncPosition="true">
                                    <EmptyMsg AnonFilteredAddMessage="No records found.
Try to change filter to see records here."
                                        AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                        ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                        FilteredAddMessage="No records found.
Try to change filter to see records here."
                                        FilteredMessage="No records found.
Try to change filter to see records here."
                                        NamedComboAddMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                        NamedComboMessage="No records found as '{0}'.
Try to change filter or modify parameters above to see records here."
                                        NamedFilteredAddMessage="No records found as '{0}'.
Try to change filter to see records here."
                                        NamedFilteredMessage="No records found as '{0}'.
Try to change filter to see records here." />
                                                    <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
    <Behavior RepaintControlsIDs="edlotserialstatus"></Behavior>
</AutoCallBack>
                                    <Levels>
                                        <px:PXGridLevel DataKeyNames="AdhocQCOrderDetailID" DataMember="adhocOrderDetail">
                                            <RowTemplate>
                                                <px:PXSelector ID="edBranchID" runat="server" AlreadyLocalized="False" DataField="BranchID"></px:PXSelector>
                                                <px:PXSelector ID="edLotSerialNbr" runat="server" AlreadyLocalized="False" DataField="LotSerialNbr" AutoRefresh="true" CommitChanges="true" SyncStateWithCommand="true"></px:PXSelector>
                                                <px:PXNumberEdit ID="edQty" runat="server" AlreadyLocalized="false" DataField="Qty"></px:PXNumberEdit>
                                            </RowTemplate>
                                            <Columns>
                                                 <px:PXGridColumn DataField="BranchID" Width="150" CommitChanges="true" />
                                                 <px:PXGridColumn DataField="InventorySource" Width="150" CommitChanges="true" />
                                                 <px:PXGridColumn DataField="ProjectID" Width="150" CommitChanges="true" />
                                                 <px:PXGridColumn DataField="TaskID" Width="150" CommitChanges="true" />
                                                 <px:PXGridColumn DataField="CostCenterID" Width="0" CommitChanges="true" />
                                                 <px:PXGridColumn DataField="LotSerialNbr" CommitChanges="true" />
                                                 <px:PXGridColumn DataField="Qty" Width="150" CommitChanges="true" />                                
                                            </Columns>
                                        </px:PXGridLevel>
                                    </Levels>
                                    <Mode InitNewRow="True" AllowUpload="True" />
                                    <AutoSize Enabled="True" MinHeight="150" />
                                </px:PXGrid>
                            </Template1>


                            <Template2>
                                <px:PXGrid  runat="server" ID="edlotserialstatus" SkinID="Details" Width="100%" Caption="Lot/Serial Status" DataSourceID="ds" NoteIndicator="false">
    <AutoSize Enabled="true" />
    <Levels>
      <px:PXGridLevel DataMember="EWQCLotPanelView">
        <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
        <Layout ColumnsMenu="False" />
        <RowTemplate>
          <px:PXTextEdit runat="server" ID="edLotQty" DataField="LotQty" /></RowTemplate>
        <Columns>
          <px:PXGridColumn DataField="QCOrderCD"  Width="150" />
          <px:PXGridColumn DataField="StatusID" Width="150" />
          <px:PXGridColumn DataField="Qty"  Width="100" />
          <px:PXGridColumn DataField="LotQty"  Width="100" CommitChanges="true" /></Columns></px:PXGridLevel></Levels></px:PXGrid>
                            </Template2>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXSplitContainer>
                </Template>
                <AutoCallBack Target="edlotserialstatus" Command="Refresh">
    <Behavior RepaintControlsIDs="edlotserialstatus" />
</AutoCallBack>
            </px:PXTabItem>

        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>
</asp:Content>


<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209000.aspx.cs" Inherits="Page_QC209000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>





<%--<%@ Register src="~/Controls/EWQCFormula.ascx" tagName="EWQCFormula" tagPrefix="px_EWQC" %>--%>
<%--<%@ Register src="../../../EWQCCTFormulaInvoicePanel.ascx" tagName="EWQCCTFormulaInvoicePanel" tagPrefix="px" %>--%>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">

    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" AttributesFound="False" PrimaryView="Documents" SuspendUnloading="False" TypeName="EW.QC.EWQCPlanMaint" PageLoadBehavior="InsertRecord">
        <CallbackCommands>

            <px:PXDSCallbackCommand Name="Insert" PostData="Self" />
            <px:PXDSCallbackCommand CommitChanges="True" Name="Save" />
            <px:PXDSCallbackCommand Name="First" PostData="Self" StartNewGroup="True" />
            <px:PXDSCallbackCommand Name="Last" PostData="Self" />
            <px:PXDSCallbackCommand Name="AddTestSuite" Visible="False"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="CopyPanel" Visible="false"></px:PXDSCallbackCommand>
            <%--   //  <px:PXDSCallbackCommand Name="AddQCTool" Visible="False" CommitChanges="True" RepaintControls="All" DependOnGrid="grid" />--%>
            <px:PXDSCallbackCommand Name="AddQCTool" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
            <%-- <px:PXDSCallbackCommand Name="GoToLotHistory" Visible="False" DependOnGrid="PXGrid1" />--%>
            <%--  <px:PXDSCallbackCommand Name="ViewTestMaster" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewSeverityMaster" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewGroupMaster" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewEquipmentMaster" Visible="true" DependOnGrid="grid" />--%>
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="AddUpdateToolDetails" Visible="False" CommitChanges="true" />
            <%--<px:PXDSCallbackCommand Name="ViewGroupMaster" Visible="true" DependOnGrid="grid" />--%>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">

    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" DataMember="Documents" TabIndex="3700" DefaultControlID="edPlanCD" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">

        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" LabelsWidth="SM" ControlSize="XM" />
            <px:PXSelector ID="edPlanCD" runat="server" AlreadyLocalized="False" DataField="PlanCD" AutoRefresh="true" CommitChanges="True">
                <GridProperties FastFilterFields="RevisionNo,Name"></GridProperties>
            </px:PXSelector>
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRemarks" runat="server" AlreadyLocalized="False" DataField="Remarks" Height="105" TextMode="MultiLine">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edRevisionNo" Enabled="true" runat="server" AutoRefresh="true" AlreadyLocalized="False" DataField="RevisionNo">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edEffectiveFromDate" runat="server" AlreadyLocalized="False" DataField="EffectiveFromDate">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edEffectiveToDate" runat="server" AlreadyLocalized="False" DataField="EffectiveToDate">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edStatus" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="Hold" Text="Hold">
            </px:PXCheckBox>
            <px:PXDropDown ID="edStatusText" Enabled="false" ReadOnly="true" runat="server" DataField="Status">
            </px:PXDropDown>
            <px:PXDropDown ID="edResultCriteriaType" runat="server" DataField="ResultCriteriaType" CommitChanges="true">
            </px:PXDropDown>
            <px:PXCheckBox ID="edDestructiveTesting" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="DestructiveTesting" Text="Destructive Testing" Enabled="false">
            </px:PXCheckBox>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXNumberEdit ID="edResultCriteriaTab" runat="server" AlreadyLocalized="False" DataField="ResultCriteriaTab">
            </px:PXNumberEdit>
            <%--<px:EWQCCTFormulaInvoicePanel ID="EWQCCTFormulaInvoicePanel1" runat="server" DataField="Name" />--%>
            <%--  <pxa:CTFormulaInvoiceEditor ID="edDescriptionFormulaInv" runat="server" DataSourceID="ds" DataField="Description"  />--%>
            <%-- <pxa:DynamicDataSource  ID="edDescriptionFormulaInvS" runat="server" DataSourceID="ds" DataField="Description"  />--%>

            <%--<px_EWQC:EWQCFormula ID="EWQCFormula2" runat="server"  DataField="Name"  Visible ="True"/>--%>
        </Template>
    </px:PXFormView>
    <%-- Copy To --%>
    <px:PXSmartPanel ID="panelCopyTo" runat="server" Caption="Copy To" CaptionVisible="true" LoadOnDemand="true" Key="CopyPanel"
        AutoCallBack-Enabled="true" AutoCallBack-Target="formCopyTo" AutoCallBack-Command="Refresh" CallBackMode-CommitChanges="True"
        CallBackMode-PostData="Page">
        <div style="padding: 5px">
            <px:PXFormView ID="formCopyTo" runat="server" DataSourceID="ds" CaptionVisible="False" DataMember="CopyPanel">
                <Activity Height="" HighlightColor="" SelectedColor="" Width=""></Activity>
                <ContentStyle BackColor="Transparent" BorderStyle="None"></ContentStyle>
                <Template>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="SM"></px:PXLayoutRule>
                    <px:PXMaskEdit CommitChanges="True" ID="edPlanCD" runat="server" DataField="PlanCD"></px:PXMaskEdit>
                </Template>
            </px:PXFormView>
        </div>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK" CommandName="CheckCopyParams" CommandSourceID="ds"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>
</asp:Content>
<asp:Content ID="Content1" ContentPlaceHolderID="phG" runat="Server">

    <px:PXTab ID="tab" runat="server" Height="150px" Style="z-index: 100;" Width="100%">
        <Items>
            <px:PXTabItem Text="Tests">
                <Template>
                    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="1800" SyncPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.
Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
                        <ActionBar ActionsText="False">
                            <CustomItems>
                                <px:PXToolBarButton Text="QCTool" PopupPanel="AttributePanel" Visible="false" Enabled="True">
                                    <AutoCallBack Command="AddQCTool" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                                <px:PXToolBarButton Text="ComboBoxValue" PopupPanel="ComboBoxPanel" Visible="false" Enabled="True">
                                    <AutoCallBack Command="AddCombo" Target="ds">
                                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                                    </AutoCallBack>
                                </px:PXToolBarButton>
                            </CustomItems>
                        </ActionBar>

                        <Levels>
                            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,VariableID" DataMember="PlanVariables">
                                <RowTemplate>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports">
                                    </px:PXCheckBox>
                                    <px:PXSelector ID="edVariableID" runat="server" DataField="VariableID" CommitChanges="True" AllowEdit=" true">
                                        <GridProperties FastFilterFields="VariableCD,Name"></GridProperties>
                                    </px:PXSelector>
                                    <px:PXTextEdit ID="edEWQCVariableName" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Name">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Description">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edEquation" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Equation">
                                    </px:PXTextEdit>
                                    <px:PXSelector ID="edTestGroupID" runat="server" DataField="TestGroupID" AllowEdit="true">
                                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                                    </px:PXSelector>
                                    <px:PXDropDown ID="edDataType" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__DataType">
                                    </px:PXDropDown>
                                    <px:PXSelector runat="server" ID="edUsrEWQCLTAttributeID" DataField="AttributeID" AutoRefresh="true" CommitChanges="true">
                                    <GridProperties FastFilterFields="AttributeID,Description" /></px:PXSelector>
                                    <px:PXTextEdit ID="edToolSteps" runat="server" AlreadyLocalized="False" DataField="ToolSteps">
                                    </px:PXTextEdit>
                                    <%--  <px:PXSelector ID="edToolGaugeID" runat="server" DataField="ToolGaugeID" AllowEdit="true">
                                        <GridProperties FastFilterFields="ToolGaugeCD,Description"></GridProperties>
                                    </px:PXSelector>--%>
                                    <px:PXSelector ID="edSeverityLevel" runat="server" DataField="SeverityLevel" AllowEdit="true">
                                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                                    </px:PXSelector>
                                    <px:PXSelector ID="edTestCategoryID" runat="server" DataField="EWQCVariable__TestCategoryID" AllowEdit="true">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edTestMethodID" runat="server" DataField="EWQCVariable__TestMethodID" AllowEdit="true">
                                    </px:PXSelector>
                                    <px:PXDropDown ID="edQCOperator" runat="server" AlreadyLocalized="False" DataField="QCOperator">
                                    </px:PXDropDown>
                                    <px:PXNumberEdit ID="edNumMinValue" runat="server" AlreadyLocalized="False" DataField="NumMinValue">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edNumMaxValue" runat="server" AlreadyLocalized="False" DataField="NumMaxValue">
                                    </px:PXNumberEdit>
                                    <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                                    </px:PXTextEdit>
                                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                                    <px:PXCheckBox ID="edDestructiveTesting" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="DestructiveTesting" Text="Go/NoGo">
                                    </px:PXCheckBox>
                                    <px:PXNumberEdit ID="edSampleSize" runat="server" AlreadyLocalized="False" DataField="SampleSize">
                                    </px:PXNumberEdit>
                                    <px:PXSelector ID="ewqcSelectorUOM" runat="server" CommitChanges="True" DataField="UOM" Style="margin-right: 30px"></px:PXSelector>
                                    <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                                    </px:PXTextEdit>
                                    <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="Go/NoGo">
                                    </px:PXCheckBox>
                                    <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest">
                                    </px:PXCheckBox>
                                    <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                                    </px:PXDropDown>
                                    <%--  <px:PXNumberEdit ID="edNumTargetValue" runat="server" AlreadyLocalized="False" DataField="NumTargetValue">
                                    </px:PXNumberEdit>--%>
                                    <%--<px:PXSelector ID="edUOM" runat="server" AlreadyLocalized="False" DataField="UOM">
                                            <%--<GridProperties FastFilterFields="ToolGaugeCD,Description"></GridProperties>--%>
                                    <%--</px:PXSelector>--%>
                                    <%-- <px:PXCheckBox ID="edBitPassFail" runat="server" AlreadyLocalized="False" DataField="BitPassFail" Text="Pass/Fail">
                                    </px:PXCheckBox>--%>
                                    <%-- <px:PXTextEdit ID="PXTextEdit1" runat="server" AlreadyLocalized="False" DataField="Equation" Enabled="false">
                                    </px:PXTextEdit>--%>
                                    <px:PXDropDown ID="PXDropDownCalculationType" runat="server" AlreadyLocalized="False" DataField="CalculationType">
                                    </px:PXDropDown>
                                    <px:PXTextEdit ID="edComboValue" runat="server" AlreadyLocalized="False" DataField="ComboValue">
                                    </px:PXTextEdit>
                                    <px:PXTextEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>
                                    <%--<px:PXTextEdit ID="edComboCheckValue" runat="server" AlreadyLocalized="False" DataField="ComboCheckValue">
                                    </px:PXTextEdit>--%>
                                    <%--<pxa:PXFormulaCombo ID="edChildField" runat="server" DataField="Equation" EditButton="True" FieldsAutoRefresh="True"
												FieldsRootAutoRefresh="true" LastNodeName="Fields" PanelAutoRefresh="True" IsInternalVisible="false"
												IsExternalVisible="false" OnRootFieldsNeeded="edOns_RootFieldsNeeded" 
                                                SkinID="GI"/>--%>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>

                                    <px:PXGridColumn DataField="VariableID" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__Equation" Width="280px">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="TestGroupID" Width="180px" LinkCommand="ViewGroupMaster" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="TestGroupID" Width="180px" CommitChanges="true">
                                    </px:PXGridColumn>

                                    <px:PXGridColumn DataField="EWQCVariable__DataType">
                                    </px:PXGridColumn>
                                      <px:PXGridColumn DataField="AttributeID"></px:PXGridColumn>
                                    <%--<px:PXGridColumn DataField="ToolGaugeID" LinkCommand="ViewEquipmentMaster" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="AddQCTool" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SeverityLevel" LinkCommand="ViewSeverityMaster" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__TestCategoryID" LinkCommand="ViewTestCategoryMaster" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCVariable__TestMethodID" LinkCommand="ViewTestMethod" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <%--  <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <%-- <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                        </px:PXGridColumn>--%>
                                    <%-- <px:PXGridColumn DataField="SeverityLevel" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="CalculationType" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="QCOperator" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="NumMinValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="NumTargetValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="NumMaxValue" Width="100px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="TestResultUOM" Width="220px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="AlphaValue" Width="220px"></px:PXGridColumn>
                                    <px:PXGridColumn DataField="DestructiveTesting" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="EWQCVariable__Unit" Width="120px">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="SampleSize" Width="120px" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="UOM" Width="120px" CommitChanges="true">
                                    </px:PXGridColumn>

                                    <%--  <px:PXGridColumn DataField="Equation" Width="120px">
                                    </px:PXGridColumn>--%>
                                    <%-- <px:PXGridColumn DataField="BitPassFail" TextAlign="Center" Type="CheckBox" Width="60px">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                    </px:PXGridColumn>

                                    <px:PXGridColumn DataField="OrderLevel" CommitChanges="true" Width="120px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ComboValue" Width="280px" LinkCommand="AddCombo" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <%-- <px:PXGridColumn DataField="ComboCheckValue" Width="220px">
                                    </px:PXGridColumn>--%>
                                    <px:PXGridColumn DataField="LineNbr" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                        <Mode InitNewRow="True" AllowFormEdit="True" AllowDragRows="True" AutoInsert="true" AllowUpload="true"></Mode>
                    </px:PXGrid>

                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Result Criteria-AQL" VisibleExp="DataControls[&quot;edResultCriteriaTab&quot;].Value == 1"
                BindingContext="form"
                RepaintOnDemand="false">
                <Template>
                    <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,SeverityID" DataMember="PlanSeverities">
                                <RowTemplate>
                                    <px:PXSelector ID="edSeverityID" runat="server" DataField="SeverityID" CommitChanges="True">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edDefectivesRegorous" runat="server" AlreadyLocalized="False" DataField="DefectivesRegorous" CommitChanges="True">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edDefectivesModerate" runat="server" AlreadyLocalized="False" DataField="DefectivesModerate" CommitChanges="True">
                                    </px:PXSelector>
                                    <px:PXSelector ID="edDefectivesFlexible" runat="server" AlreadyLocalized="False" DataField="DefectivesFlexible" CommitChanges="True">
                                    </px:PXSelector>
                                </RowTemplate>

                                <Columns>
                                    <px:PXGridColumn DataField="SeverityID" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DefectivesRegorous" Width="180px" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DefectivesModerate" Width="280px" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="DefectivesFlexible" Width="280px" CommitChanges="True">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>

                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>

            <px:PXTabItem Text="Result Criteria-Manual" VisibleExp="DataControls[&quot;edResultCriteriaTab&quot;].Value == 0"
                BindingContext="form"
                RepaintOnDemand="false">
                <Template>
                    <px:PXGrid ID="PXGrid2" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,SeverityID" DataMember="PlanSeverities">
                                <RowTemplate>
                                    <px:PXSelector ID="edSeverityID1" runat="server" DataField="SeverityID" CommitChanges="True">
                                    </px:PXSelector>
                                    <px:PXNumberEdit ID="edRigorousDefects1" runat="server" AlreadyLocalized="False" DataField="RigorousDefects" CommitChanges="True">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edModerateDefects1" runat="server" AlreadyLocalized="False" DataField="ModerateDefects" CommitChanges="True">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="edFlexibleDefects1" runat="server" AlreadyLocalized="False" DataField="FlexibleDefects" CommitChanges="True">
                                    </px:PXNumberEdit>
                                </RowTemplate>

                                <Columns>
                                    <px:PXGridColumn DataField="SeverityID" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="RigorousDefects" Width="180px" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ModerateDefects" Width="280px" CommitChanges="True">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FlexibleDefects" Width="280px" CommitChanges="True">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>

                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Result Criteria-Sample Wise" VisibleExp="DataControls[&quot;edResultCriteriaTab&quot;].Value == 2"
                BindingContext="form"
                RepaintOnDemand="false">
                <Template>
                    <px:PXGrid ID="PXGrid4" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.

Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,SeverityID" DataMember="PlanSeverities">
                                <RowTemplate>
                                    <px:PXNumberEdit ID="PXNumberEdit1" runat="server" AlreadyLocalized="False" DataField="RigorousDefects">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="PXNumberEdit2" runat="server" AlreadyLocalized="False" DataField="ModerateDefects">
                                    </px:PXNumberEdit>
                                    <px:PXNumberEdit ID="PXNumberEdit3" runat="server" AlreadyLocalized="False" DataField="FlexibleDefects">
                                    </px:PXNumberEdit>
                                    <px:PXSelector ID="edSeverityID2" runat="server" Width="0" DataField="SeverityID" CommitChanges="True">
                                    </px:PXSelector>
                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="RigorousDefects" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="ModerateDefects" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="FlexibleDefects" Width="280px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="SeverityID" Width="0" CommitChanges="True">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>

                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>
</asp:Content>
<asp:Content ID="cont4" ContentPlaceHolderID="phDialogs" runat="server">
    <%--  <px:PXSmartPanel ID="pnlTestSteps1" runat="server" Height="500px" Width="1100px" Caption="QC Tool" CaptionVisible="true" AutoReload="true" LoadOnDemand="true" Key="ToolSteps" Style="position: static"
        AutoCallBack-Target="StepsGrid1" AutoCallBack-Command="Refresh" DesignView="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel1" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton1" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>--%>

    <px:PXSmartPanel ID="AttributePanel" runat="server" Width="720px" Height="360px" Caption="Tools" CaptionVisible="True"
        AutoCallBack-Command="Refresh" AutoCallBack-Target="AttributesGrid" DesignView="Content">
        <px:PXGrid ID="AttributesGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="PlanToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="AttributeButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="AttributeSaveButton" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
            <px:PXButton ID="AttributeCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
                <AutoCallBack Command="CancelQCTools" Target="ds"></AutoCallBack>
            </px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

    <px:PXSmartPanel ID="ComboBoxPanel" runat="server" Width="720px" Height="360px" Key="TestComboValues" Caption="Combo Values" CaptionVisible="True"
        AutoCallBack-Command="Refresh" AutoCallBack-Target="ComboBoxGrid" DesignView="Content">
        <px:PXGrid ID="ComboBoxGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="TestComboValues">
                    <Columns>
                        <px:PXGridColumn DataField="TestComboCD">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="ComboCheck" TextAlign="Center" Type="CheckBox" Width="120px">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="ComboButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="ComboSaveButton" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="ComboSaveButton" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="ComboCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
            </px:PXButton>
        </px:PXPanel>
    </px:PXSmartPanel>

</asp:Content>




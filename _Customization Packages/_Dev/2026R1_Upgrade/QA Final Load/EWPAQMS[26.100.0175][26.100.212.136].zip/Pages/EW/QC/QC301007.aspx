<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC301007.aspx.cs" Inherits="Page_QC301007" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="true" runat="server" visible="True" typename="EW.QC.EWQCOrderEntryNS" primaryview="QCOrders" attributesfound="False" suspendunloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewArticleID" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="GotoSteps" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="GotoEquation" Visible="False" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="SubmitFormula" Visible="False" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="First" PostData="Self" StartNewGroup="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Last" PostData="Self"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewTestMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewGroupMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewSeverityMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewEquipmentMaster" Visible="true" DependOnGrid="PXGrid2" />
            <px:PXDSCallbackCommand Name="ViewAssignedToID" Visible="False" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="CreateNC" Visible="False" CommitChanges="true" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" width="100%" datamember="QCOrders" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M" />
            <px:PXDateTimeEdit ID="edCreatedDateTime" runat="server" AlreadyLocalized="False" DataField="OrderDate" TimeMode="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXSelector ID="edQCOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="true">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edClosingDateTime" runat="server" AlreadyLocalized="False" DataField="ClosingDateTime" Enabled="false" Width="100%">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edOhHold" runat="server" DataField="OnHold" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXDropDown ID="edStatus" runat="server" DataField="Status" Enabled="false">
            </px:PXDropDown>
            <px:PXTextEdit ID="edRemarks" runat="server" DataField="Remarks" TextMode="MultiLine" Height="50" CommitChanges="true">
            </px:PXTextEdit>

            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXPanel ID="XX" runat="server" RenderStyle="Simple">
                <px:PXDropDown ID="edQCType" runat="server" DataField="QCType" Enabled="false">
                </px:PXDropDown>
                 <px:PXDropDown ID="edItemType" runat="server" AlreadyLocalized="False" DataField="ItemType" Enabled="false">
            </px:PXDropDown>
            <px:PXTextEdit ID="edArticleID" Enabled="false" runat="server" CommitChanges ="true" DataField="ArticleID">
                  <LinkCommand Command="ViewArticleID" Target="ds"></LinkCommand>
            </px:PXTextEdit>
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name" Enabled="false">
            </px:PXTextEdit>
            <px:PXDropDown ID="edScheduleType" runat="server" DataField="ScheduleType" Enabled="false">
            </px:PXDropDown>
            </px:PXPanel>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="M">
            </px:PXLayoutRule>
            <px:PXPanel ID="PXPanel5" runat="server" RenderStyle="Simple">
                <px:PXSelector ID="PXSelector1" runat="server" DataField="PlanID" DisplayMode="Text" AllowEdit="True" CommitChanges="True" />
            </px:PXPanel>
            <px:PXPanel ID="PXPanel3" runat="server" RenderStyle="Simple" DataMember="Plan">
                <px:PXTextEdit ID="PXNumberEdit2" runat="server" AlreadyLocalized="False" DataField="Description" Enabled="false">
                </px:PXTextEdit>
            </px:PXPanel>

            <px:PXPanel ID="PXPanel4" runat="server" RenderStyle="Simple">
                <px:PXDropDown ID="edResultingCriteria" runat="server" AlreadyLocalized="False" DataField="ResultingCriteria">
                </px:PXDropDown>
                <px:PXDropDown ID="edQCResult" runat="server" AlreadyLocalized="False" DataField="QCResult">
                </px:PXDropDown>
            </px:PXPanel>           
        </Template>
        <CallbackCommands>
            <Refresh CommitChanges="True" PostData="Page" />
            <Search CommitChanges="True" PostData="Page" />
        </CallbackCommands>
    </px:pxformview>
    <px:pxsmartpanel id="pnlTestSteps" runat="server" height="400px" width="1100px" caption="Test Steps" captionvisible="true" autoreload="true" key="TestSteps" style="position: static"
        autocallback-target="StepsGrid" autocallback-command="Refresh" designview="Content" autorepaint="true">
        <px:PXGrid ID="StepsGrid" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataMember="TestSteps">
                    <Columns>
                        <px:PXGridColumn DataField="Name">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>

    <px:pxsmartpanel id="pnlEquation" runat="server" height="500px" width="800px" caption="Equation" captionvisible="true" autoreload="true" key="QCOrderTestFormula" style="position: static"
        autocallback-target="PXGridEquation" autocallback-command="Refresh" designview="Content" autorepaint="true">
        <px:PXGrid ID="PXGridEquation" runat="server" DataSourceID="ds" SkinID="Inquire" Height="87%"
            Width="100%" AutoAdjustColumns="true" SyncPosition="true">

            <Levels>
                <px:PXGridLevel DataKeyNames="QCOrderTestDetailID" DataMember="QCOrderTestFormula">
                    <RowTemplate>
                        <px:PXTextEdit ID="edParameter" runat="server" AlreadyLocalized="False" DataField="ParameterName" Enabled="false" Width="600px">
                        </px:PXTextEdit>
                    </RowTemplate>
                    <Columns>
                        <px:PXGridColumn DataField="ParameterName">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="FormulaValue">
                        </px:PXGridColumn>

                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel10" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton2" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="SubmitFormula" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="btnInvCancel" runat="server" DialogResult="Cancel" Text="Cancel" />
        </px:PXPanel>
    </px:pxsmartpanel>

</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phDialogs" runat="Server">    
            <px:PXTab ID="tab" runat="server" height="150px" style="z-index: 100;" width="100%">
                <Items>
                    <px:PXTabItem Text="Test Results">
                        <Template>
                            <px:PXGrid ID="PXGrid2" runat="server" OnRowDataBound="grid2_RowDataBound" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="Details" TabIndex="1800" SyncPosition="true">
                                <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                                    NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                    NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                                    FilteredMessage="No records found.
Try to change filter to see records here."
                                    FilteredAddMessage="No records found.
Try to change filter to see records here."
                                    NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                    NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                                    AnonFilteredMessage="No records found.
Try to change filter to see records here."
                                    AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                                 <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
                                <Levels>
                                    <px:PXGridLevel DataKeyNames="QCOrderID,QCOrderTestNonStockDetailID" DataMember="QCTestDetailNS">
                                        <RowTemplate>
                                            <px:PXTextEdit ID="edSamplingSerailNum" runat="server" AlreadyLocalized="False" DataField="SamplingSerailNum">
                                            </px:PXTextEdit>
                                            <px:PXSelector ID="edAssignedToID" runat="server" DataField="AssignedToID">
                                                <GridProperties FastFilterFields="AcctCD,AcctName"></GridProperties>
                                            </px:PXSelector>
                                            <%--<px:PXSelector ID="edToolgauge" runat="server" DataField="ToolGaugeID">
                                                <GridProperties FastFilterFields="ToolGaugeCD,Description"></GridProperties>
                                            </px:PXSelector>--%>
                                            <px:PXTextEdit runat="server" DataField="TestValue" CommitChanges="True" ID="edTestValue" />
                                             <px:PXTextEdit runat="server" DataField="TestResultUOM" CommitChanges="True" ID="edTestResultUOM" />
                                            
                                            <%--<px:PXNumberEdit ID="edNumTargetValue" runat="server" AlreadyLocalized="False" DataField="NumTargetValue">
                                            </px:PXNumberEdit>
                                            <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                                            </px:PXTextEdit>
                                            <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="BitGoNoGo">
                                            </px:PXCheckBox>--%>
                                            <px:PXCheckBox ID="edTested" runat="server" AlreadyLocalized="False" DataField="Tested" Text="Tested">
                                            </px:PXCheckBox>
                                            <px:PXDropDown ID="edActualResult" runat="server" DataField="ActualResult">
                                            </px:PXDropDown>
                                            <px:PXDropDown ID="edFinalResult" runat="server" DataField="FinalResult">
                                            </px:PXDropDown>
                                            <px:PXTextEdit ID="PXTextEdit1" runat="server" AlreadyLocalized="False" DataField="Remarks">
                                            </px:PXTextEdit>
                                            <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports" Enabled="false">
                                            </px:PXCheckBox>
                                            <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest" Enabled="false">
                                            </px:PXCheckBox>
                                            <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                                            </px:PXDropDown>
                                            <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                                            </px:PXTextEdit>
                                             <px:PXDropDown ID="edOrderLevel" runat="server" DataField="OrderLevel">
                                            </px:PXDropDown>
                                        </RowTemplate>
                                        <Columns>
                                            <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__VariableCD" LinkCommand="ViewTestMaster" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Steps" Width="180px" LinkCommand="GotoSteps" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCTestGroup__Name" CommitChanges="true" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCTestCategory__Name" CommitChanges="true" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCTestMethod__Name" CommitChanges="true" Width="180px">
                                            </px:PXGridColumn>
                                           <%-- <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true" Width="180px">
                                            </px:PXGridColumn>--%>
                                            <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="GotoToolSteps" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="AssignedToID" Width="140px" CommitChanges="true" LinkCommand="viewAssignedToID">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="ExpectedValue" Width="280px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="UOM" Width="120px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Equation" Width="180px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Formula" Width="180px" LinkCommand="GotoEquation" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="TestValue" CommitChanges ="true" MatrixMode="true" />
                                            <px:PXGridColumn DataField="TestResultUOM" CommitChanges ="true" />
                                            <%--<px:PXGridColumn DataField="NumTargetValue" Width="100px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="AlphaValue" Width="280px" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px" CommitChanges="true">
                                            </px:PXGridColumn>--%>
                                            <px:PXGridColumn DataField="ActualResult" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="FinalResult" CommitChanges="true">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="OrderLevel" CommitChanges="true" Width="120px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Remarks" Width="280px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px"></px:PXGridColumn>                                           
                                            <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="NCNbr" Width="200px" LinkCommand="ViewLotNC">
                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="QCOrderTestNonStockDetailID" Width="1px">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <Mode AllowUpload="True" />
                                <AutoSize Enabled="True" />
                                <AutoCallBack />
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="PXGrid2" Command="Refresh">
                            <Behavior RepaintControlsIDs="PXGrid2" />
                        </AutoCallBack>
                    </px:PXTabItem>
                    <px:PXTabItem Text="Event History">
                        <Template>
                            <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                                <Levels>
                                    <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                        <Columns>
                                            <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="Description">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="EventType">
                                            </px:PXGridColumn>
                                            <px:PXGridColumn DataField="CreatedByID">
                                            </px:PXGridColumn>
                                        </Columns>
                                    </px:PXGridLevel>
                                </Levels>
                                <AutoSize Enabled="True" />
                                <AutoCallBack />
                            </px:PXGrid>
                        </Template>
                        <AutoCallBack Target="PXGrid3" Command="Refresh">
                            <Behavior RepaintControlsIDs="PXGrid3" />
                        </AutoCallBack>
                    </px:PXTabItem>
                </Items>
                <AutoSize Enabled="True"></AutoSize>
            </px:PXTab>
        

    <px:pxsmartpanel id="pnlTestSteps1" runat="server" height="500px" width="1100px" caption="QC Tool" captionvisible="true" autoreload="true" loadondemand="true" key="ToolSteps" style="position: static"
        autocallback-target="StepsGrid1" autocallback-command="Refresh" designview="Content">
        <px:PXGrid ID="StepsGrid1" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="ToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                    <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="false" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="PXPanel11" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton3" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>
</asp:Content>

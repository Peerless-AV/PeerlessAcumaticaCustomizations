﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="QC505100.aspx.cs" Inherits="Page_QC505100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="PrimaryDAC"
        typename="EW.QC.EWQCIdentifyLastNumberingSequence" qptoolbar="false">
        <CallbackCommands>
            
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100" width="100%" bpeventsindicator="True" datamember="PrimaryDAC">
        <Template>
            <%--<px:PXLayoutRule runat="server" StartRow="True" LabelsWidth="SM" />
            <px:PXDropDown ID="edScreeNOption" runat="server" DataField="ScreenOption" CommitChanges="true" AutoRefresh="true"></px:PXDropDown>--%>

<%--            <px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"></px:PXLayoutRule>
            <px:PXSelector ID="edBatchOrderType" runat="server" DataField="BatchOrderType" CommitChanges="true" AutoRefresh="true"></px:PXSelector>
            <px:PXSelector ID="edBatchOrderCD" runat="server" DataField="BatchOrderCD" CommitChanges="true" AutoRefresh="true">
            </px:PXSelector>--%>
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="phG" runat="Server">

    <px:pxtab id="tab" runat="server" width="100%" height="120px" datasourceid="ds">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
            <px:PXTabItem Text="Auto Numbering Records">
                <Template>
                    <px:PXGrid ID="PXGrid5" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" RepaintColumns="true">
                        <Levels>
                            <px:PXGridLevel DataMember="ProcessRecord">
                <RowTemplate>
                </RowTemplate>
                <Columns>
					<px:PXGridColumn DataField="ScreenName" Width="130px" />
                    <px:PXGridColumn DataField="NumberingSequenceIDdisplay" Width="130px" />
					<px:PXGridColumn DataField="ScreenLastRecordNbr" Width="130px" CommitChanges="true"/>
					<px:PXGridColumn DataField="LastNumberingSequence" Width="130px" />
                </Columns>
			</px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                        <ActionBar ActionsText="False" Position="Top" >
                              <Actions>
                                <AddNew Enabled="false" />
                            </Actions>
                             </ActionBar>
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
        </Items>
    </px:pxtab>

</asp:Content>


<%--<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" SkinID="Inquire" SyncPosition="true" TabIndex="300" RepaintColumns="false">
		<Levels>
			
		</Levels>
		<Mode AllowUpload="True" AllowDragRows="true" />
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<ActionBar ActionsText="True">
		</ActionBar>
	</px:PXGrid>
</asp:Content>--%>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505000.aspx.cs" Inherits="Page_QC505000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" typename="EW.QC.EWQCNonStockMaint" attributesfound="False" enableattributes="true"
        primaryview="NonStockView" suspendunloading="False">
    </px:pxdatasource>
    <style>
        #ctl00_phF_form_cont {
            height: 150px !important;
        }
    </style>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="NonStockView" runat="server" datasourceid="ds" style="z-index: 100" 
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXDropDown ID="edItemType" runat="server" DataField="ItemType" Width="200" CommitChanges="true">
            </px:PXDropDown>            
             <px:PXSelector ID="edNSItemID" runat="server" DataField="NSItemID" Width="200" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edToolsID" runat="server" DataField="ToolsID" Width="200" CommitChanges="true">
            </px:PXSelector>
            <px:PXSelector ID="edMachineID" runat="server" DataField="MachineID" Width="200" CommitChanges="true">
            </px:PXSelector>            
            <px:PXSelector ID="edFixedAssetsID" runat="server" DataField="FixedAssetsID" Width="200" CommitChanges="true">
            </px:PXSelector>                                  
            <px:PXSelector ID="edNSItemPlanID" runat="server" DataField="NSItemPlanID" Width="200" AutoRefresh="True" CommitChanges="true" >
            </px:PXSelector>
            <px:PXSelector ID="edToolsPlanID" runat="server" DataField="ToolsPlanID" Width="200" AutoRefresh="True" CommitChanges="true" >
            </px:PXSelector>
            <px:PXSelector ID="edMachinePlanID" runat="server" DataField="MachinePlanID" Width="200" AutoRefresh="True" CommitChanges="true" >
            </px:PXSelector>            
            <px:PXSelector ID="edFixedAssetsPlanID" runat="server" DataField="FixedAssetsPlanID" Width="200" AutoRefresh="True" CommitChanges="true" >
            </px:PXSelector>                                            
            <px:PXTextEdit ID="edPlanDescription" runat="server" Width="200" DataField="PlanDescription" Enabled="false">
            </px:PXTextEdit>            
        </Template>
    </px:pxformview>
</asp:Content>

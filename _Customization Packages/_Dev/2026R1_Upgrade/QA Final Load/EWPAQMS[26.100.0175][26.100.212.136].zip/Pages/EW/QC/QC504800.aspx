<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC504800.aspx.cs" Inherits="Page_QC504800" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="ProdItemRecord"
        typename="EW.QC.EWQCOrderGenerate">
        <CallbackCommands>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100" width="100%" datamember="ProdItemRecord" tabindex="3700">
        <Template>
            <px:PXLayoutRule runat="server" LabelsWidth="S" ControlSize="M" />
            <px:PXSelector CommitChanges="True" ID="edOrderType" runat="server" DataField="OrderType" />
            <px:PXSelector ID="PXSelector1" runat="server" DataField="ProdOrdID" AutoRefresh="True" DataSourceID="ds">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edProdDate" runat="server" DataField="ProdDate" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
            <px:PXSegmentMask ID="edInventoryID" runat="server" DataField="InventoryID" />
            <px:PXSegmentMask ID="edSubItemID" runat="server" DataField="SubItemID" />
            <px:PXSegmentMask ID="edSiteId" runat="server" DataField="SiteId"/>
        </Template>
        <%--<AutoSize Container="Window" Enabled="True" MinHeight="200" />--%>
    </px:pxformview>
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="false" allowsearch="true" adjustpagesize="None" syncposition="true" datasourceid="ds" skinid="Primary">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataMember="ProdItem" DataKeyNames="OperationID,AMProdOper__OperationCD,AMProdItem__InventoryID">
                <RowTemplate>
                    <px:PXCheckBox ID="pxcheck2" runat="server" AlreadyLocalized="False" DataField="OrderSelected" Text="Check">
                    </px:PXCheckBox>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="OrderSelected" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>                    
                    <px:PXGridColumn DataField="QCLotSerialNbr" Width="150px" />                     
                    <px:PXGridColumn DataField="AMProdOper__OperationCD" Width="150px" />
                    <px:PXGridColumn DataField="OrderQCQty" Width="150px" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>

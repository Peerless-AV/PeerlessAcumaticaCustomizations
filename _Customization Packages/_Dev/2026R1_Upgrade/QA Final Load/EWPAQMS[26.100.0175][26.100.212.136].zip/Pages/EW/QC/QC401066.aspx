﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC401066.aspx.cs" Inherits="Page_QC401066" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="Filter"
        typename="EW.QC.EWQCInProgress">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="viewInventory" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" tabindex="3700" bpeventsindicator="True" syncposition=" true">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" /> 
            <px:PXDropDown ID="edDocType" runat="server" Width="150px" DataField="DocType" CommitChanges="true">
            </px:PXDropDown>           
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edQCOrderID" runat="server" DataField="QCOrderCD" Width="170" CommitChanges="true">
            </px:PXSelector>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" Width="170" CommitChanges="true">
            </px:PXSelector>
             <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edWarehouseID" runat="server" DataField="WarehouseID" Width="170" CommitChanges="true">
            </px:PXSelector> 
            <px:PXLayoutRule runat="server" StartColumn="True" />
             <px:PXSelector ID="edLocationID" runat="server" DataField="LocationID" Width="250" CommitChanges="true">
            </px:PXSelector> 
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edAssignedToID" runat="server" DataField="AssignedToID" Width="250" CommitChanges="true">
            </px:PXSelector> 
           
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" width="100%" height="120px" datasourceid="ds">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
                 <px:PXTabItem Text="Stock item"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == S">
                <Template>
                    <px:PXGrid ID="PXGridStockItem" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true"   >
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="EWQCInProgressOrderID"  DataKeyNames="QCOrderID,InventoryID">
                                <Columns>
                                    <px:PXGridColumn DataField="EWQCOrder__QCOrderCD"  LinkCommand="ViewOrder"  CommitChanges="true">
                                    </px:PXGridColumn>                                   
                                    <px:PXGridColumn DataField="EWQCOrder__InventoryID" LinkCommand="ViewStockItem"  CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__PlanCD" LinkCommand="ViewQCPlan"  CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSamplingPlan__SamplingPlanCD" LinkCommand="ViewSamplingPlan"  CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__QCType" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__RefDocumentNbr" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__RefDocumentType" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__Status" >
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                          </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
                 <px:PXTabItem Text="Analyst"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == A">
                <Template>
                    <px:PXGrid ID="PXGridAnalyst" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true"  KeepPosition="true" >
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="EWQCInProgressOrderID"   DataKeyNames="QCOrderID,InventoryID">
                                <Columns>
                                     <px:PXGridColumn DataField="EWQCOrder__QCOrderCD"  LinkCommand="ViewOrder"  CommitChanges="true">
                                    </px:PXGridColumn>                                    
                                    <px:PXGridColumn DataField="EWQCOrder__InventoryID" LinkCommand="ViewStockItem"  CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__PlanCD" LinkCommand="ViewQCPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSamplingPlan__SamplingPlanCD" LinkCommand="ViewSamplingPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__QCType" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__RefDocumentNbr" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__RefDocumentType" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__AssignedToID" >
                                    </px:PXGridColumn>                                   
                                    <px:PXGridColumn DataField="EWQCOrder__Status" >
                                    </px:PXGridColumn>                                 
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                          </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
                 <px:PXTabItem Text="Inventory"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edDocType&quot;].Value == I">
                <Template>
                    <px:PXGrid ID="PXGridInventory" runat="server" DataSourceID="ds" Style="z-index: 100"
                        Width="100%" Height="150px" SkinID="DetailsInTab" AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" TabIndex="3900" AutoAdjustColumns="True" SyncPosition="true" KeepPosition="true">
                        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
                            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
                            FilteredMessage="No records found.
Try to change filter to see records here."
                            FilteredAddMessage="No records found.Try to change filter to see records here."
                            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
                            AnonFilteredMessage="No records found.
Try to change filter to see records here."
                            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
                        <Levels>
                            <px:PXGridLevel DataMember="EWQCInProgressOrderID"  DataKeyNames="QCOrderID,InventoryID">
                                <Columns>
                                     <px:PXGridColumn DataField="EWQCOrder__QCOrderCD"  LinkCommand="ViewOrder"  CommitChanges="true">
                                    </px:PXGridColumn>                                   
                                    <px:PXGridColumn DataField="EWQCOrder__InventoryID" LinkCommand ="ViewStockItem"  CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCPlan__PlanCD" LinkCommand="ViewQCPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCSamplingPlan__SamplingPlanCD" LinkCommand="ViewSamplingPlan" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__QCType" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__RefDocumentNbr" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__RefDocumentType" >
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="INSite__SiteCD">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="INLocation__LocationCD">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCOrder__Status" >
                                    </px:PXGridColumn>
                                </Columns>
                                <Mode AllowAddNew="false" AllowUpdate="false" AllowDelete="false" />
                            </px:PXGridLevel>
                          </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
                    </px:PXGrid>
                </Template>
            </px:PXTabItem>
        </Items>
    </px:pxtab>

</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209007.aspx.cs" Inherits="Page_QC209007" Title="Untitled Page" %>


<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="VendorPerformance"
        typename="EW.QC.EWQCEvaluateVendorPerformanceMaint">       
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" datamember="VendorPerformance" style="z-index: 100"
        width="100%" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edItemClassID" runat="server" DataField="ItemClassID" CommitChanges="True">
            </px:PXSelector>
            <px:PXDropDown ID="edTimePeriod" style="margin-bottom: 40px;" runat="server" DataField="TimePeriod" CommitChanges="True">
            </px:PXDropDown>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edInventoryID" runat="server" AutoRefresh="true" DataField="InventoryID" CommitChanges="True">
            </px:PXSelector>
            <px:PXSelector ID="edYear" runat="server" AutoRefresh="true" DataField="Year" CommitChanges="True">
            </px:PXSelector>
            <px:PXSelector ID="edMonth" runat="server" AutoRefresh="true" DataField="Month" CommitChanges="True">
            </px:PXSelector>
            <px:PXDropDown ID="edQuarter" runat="server" AutoRefresh="true" DataField="Quarter" CommitChanges="True">
            </px:PXDropDown>
            <px:PXDateTimeEdit ID="edDateFrom" runat="server" AlreadyLocalized="False" DataField="EffectiveFromDate">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edDateTo" runat="server" AlreadyLocalized="False" DataField="EffectiveToDate">
            </px:PXDateTimeEdit>                    
        </Template>
    </px:pxformview>

    <px:pxtab id="PXTab1" runat="server" width="100%" height="120px" datasourceid="ds" datamember="VendorPerformance" bpeventsindicator="True">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
            <px:PXTabItem Text="General">
                <Template>        
    <px:PXGrid ID="gridDetails" runat="server" Height="400px" Width="100%" Style="z-index: 100"
        AllowPaging="True" AllowSearch="true" AdjustPageSize="Auto" SyncPosition="true" DataSourceID="ds" SkinID="Primary">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataMember="VendorPerformanceDetail" DataKeyNames="VendorPerformanceDetailID">
                <RowTemplate>
                   <%--<px:PXTextEdit ID="edVendorCode" runat="server" DataField="VendorCode" CommitChanges="true">
                        </px:PXTextEdit>
                    <px:PXTextEdit ID="edVendorName" runat="server" DataField="VendorName" CommitChanges="true">
                        </px:PXTextEdit>--%>
                </RowTemplate>
                <Columns> 
                     <px:PXGridColumn DataField="InventoryID" Width="150px" CommitChanges="true" /> 
                    <px:PXGridColumn DataField="BAccount__AcctCD" Width="150px" CommitChanges="true" />                     
                    <px:PXGridColumn DataField="VendorName" Width="150px" CommitChanges="true" />
                     <px:PXGridColumn DataField="NewRank" Width="150px" />
                    <px:PXGridColumn DataField="NewScore" Width="150px" />                    
                    <px:PXGridColumn DataField="QualityVariance" Width="150px" />
                     <px:PXGridColumn DataField="Quality" Width="150px" />
                    <px:PXGridColumn DataField="QuantitySuppliedVariance" Width="150px" />
                     <px:PXGridColumn DataField="QuantitySupplied" Width="150px" />
                    <px:PXGridColumn DataField="DeliveryVariance" Width="150px" />
                    <px:PXGridColumn DataField="Delivery" Width="150px" />
                    <px:PXGridColumn DataField="PriceVariance" Width="150px" />
                     <px:PXGridColumn DataField="Price" Width="150px" />
                     <px:PXGridColumn DataField="ShowReport" Width="150px" LinkCommand="VenderPerf"/>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
    </Template>
            </px:PXTabItem>
             <px:PXTabItem Text="Weightage Criteria">
                <Template>
                    <px:PXGrid ID="gridWeightage" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="Primary" TabIndex="3900" SyncPosition="true" BPEventsIndicator="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="VendorRatingID" DataMember="VendorRatingCriteriaWeightage">
			    <RowTemplate>
                    <px:PXDropDown ID="edCriteria" runat="server" DataField="Criteria" Enabled="false">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edWeightage" runat="server" AlreadyLocalized="False" DataField="Weightage"  >
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="PXDescription" runat="server" AlreadyLocalized="False" DataField="Description"  >
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Criteria" Width="180px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Weightage" Width="180px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description" Width="180px">
                    </px:PXGridColumn>
                </Columns>
                 <Mode AllowAddNew="false" AllowDelete="false"/>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	</px:PXGrid>
                    </Template>
            </px:PXTabItem>
            </Items>
    </px:pxtab>

</asp:Content>



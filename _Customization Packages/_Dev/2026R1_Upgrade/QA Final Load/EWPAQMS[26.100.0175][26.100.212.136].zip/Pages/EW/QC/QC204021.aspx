﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC204021.aspx.cs" Inherits="Page_QC204021" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <style>
        #ctl00_phG_tab_t2_GeneralDtls_r2_s0 {
            margin-left: 75%;
            margin-top: -3%;
        }
       
    </style>
    <px:PXDataSource ID="ds" runat="server" Visible="True" TypeName="EW.QC.EWQCToolsManagementMaint" AttributesFound="False" EnableAttributes="true"
        PrimaryView="ToolsManagement" SuspendUnloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="RefOrderNbr" Visible="False" CommitChanges="true" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" DataMember="ToolsManagement" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" LabelsWidth="SM" ControlSize="XM" />
            <px:PXDropDown ID="edToolSource" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="ToolSource">
            </px:PXDropDown>
            <px:PXSelector ID="edToolID" runat="server" AlreadyLocalized="False" DataField="ToolID" CommitChanges="true" AutoRefresh="true">
                <GridProperties FastFilterFields="ToolCD,ToolDesc"></GridProperties>
            </px:PXSelector>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXDropDown ID="edToolStatus" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="ToolStatus"></px:PXDropDown>

            <px:PXLayoutRule runat="server" ColumnSpan="2">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edRemarks" runat="server" AlreadyLocalized="False" DataField="Remarks" TextMode="MultiLine" MinHeight="70px" Height="70px">
            </px:PXTextEdit>

            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edManufacturerName" runat="server" AlreadyLocalized="False" DataField="ManufacturerName" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edModelSerialnumber" runat="server" AlreadyLocalized="False" DataField="ModelSerialnumber" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edAssetTag" runat="server" AlreadyLocalized="False" DataField="AssetTag" CommitChanges="true">
            </px:PXTextEdit>
            <px:PXSelector ID="edDepartment" runat="server" AlreadyLocalized="False" DataField="Department" AllowEdit="true" CommitChanges="true">
                <GridProperties FastFilterFields="Name,Description"></GridProperties>
            </px:PXSelector>
          <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM"/>
             <px:PXTextEdit ID="edLeadTime" runat="server" AlreadyLocalized="False" DataField="LeadTime" CommitChanges="true">
            </px:PXTextEdit>

        </Template>        
    </px:PXFormView>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXTab ID="tab" runat="server" Width="100%" Height="120px" DataSourceID="ds">
        <AutoSize Enabled="True" Container="Window" MinHeight="250"></AutoSize>
        <Items>
            <px:PXTabItem Text="Calibration ">
                <Template>
                    <px:PXFormView ID="CalibrationScheduleDtls" runat="server" Width="100%" DataMember="ToolsManagement"
                        DataSourceID="ds" SkinID="Transparent">
                        <Template>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="M" />

                            <px:PXLayoutRule runat="server" StartColumn="True" GroupCaption="Calibration Schedule Type "></px:PXLayoutRule>
                            <px:PXLabel Style="margin-bottom: -4%;" ID="edlbl" runat="server" Text=" "></px:PXLabel>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="M" />
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXGroupBox RenderStyle="Simple" ID="gpbox1" runat="server"
                                DataField="CalibrationScheduledType" CommitChanges="true" Caption="test">
                                <Template>

                                    <px:PXRadioButton runat="server" ID="CalibrationNoofDays" Value="1" Text="No. of Days" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="CalibrationUsages" Value="2" Text="Usages" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="CalibrationBeforeUse" Value="3" Text="Before Use" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="CalibrationAfterUse" Value="4" Text="After Use" CommitChanges="true" />
                                    <px:PXRadioButton runat="server" ID="Maual" Value="5" Text="Manual" CommitChanges="true" Checked="true" />
                                </Template>
                            </px:PXGroupBox>
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXTextEdit ID="edDays" runat="server" AlreadyLocalized="False" DataField="Days" CommitChanges="true">
                            </px:PXTextEdit>
                            <px:PXTextEdit ID="edUsage" runat="server" AlreadyLocalized="False" DataField="Usage" CommitChanges="true">
                            </px:PXTextEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edStartDateManual" runat="server" AlreadyLocalized="False" DataField="StartDateManual" CommitChanges="true">
                            </px:PXDateTimeEdit>
                            <px:PXDateTimeEdit ID="edStartDateUsage" runat="server" AlreadyLocalized="False" DataField="StartDateUsage" CommitChanges="true">
                            </px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartColumn="True" ControlSize="M" LabelsWidth="SM"></px:PXLayoutRule>
                            <px:PXDateTimeEdit ID="edNextCalDate" runat="server" AlreadyLocalized="False" DataField="NextCalDate" CommitChanges="true">
                            </px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartRow="True"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="M" />
                            <px:PXCheckBox runat="server" AlignLeft="true" ID="edOrderRequired" DataField="OrderRequired" CommitChanges="true"></px:PXCheckBox>
                            <px:PXSelector ID="edCalibrationChecklistID" runat="server" AlreadyLocalized="False" DataField="CalibrationChecklistID" CommitChanges="true" AllowEdit="true">
                                <GridProperties FastFilterFields="Name,Description"></GridProperties>
                            </px:PXSelector>
                             <px:PXTextEdit ID="edChkgroupDesc" runat="server" AlreadyLocalized="False" DataField="ChkgroupDesc" CommitChanges="true">
                             </px:PXTextEdit>
                            <px:PXDateTimeEdit ID="edLastCalibrationDate" runat="server" AlreadyLocalized="False" DataField="LastCalibrationDate" CommitChanges="true">
                            </px:PXDateTimeEdit>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="M"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXDropDown ID="edCalibrationSource" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="CalibrationSource"></px:PXDropDown>
                            <px:PXLayoutRule runat="server" StartColumn="True" ControlSize="M" LabelsWidth="M"></px:PXLayoutRule>
                            <px:PXTextEdit ID="edSourceRemarks" runat="server" AlreadyLocalized="False" DataField="SourceRemarks" CommitChanges="true">
                            </px:PXTextEdit>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="M" />

                            <px:PXSelector ID="edAssignEmployee" runat="server" DataField="AssignEmployee" CommitChanges="true"></px:PXSelector>
                        </Template>
                    </px:PXFormView>
                </Template>
                <AutoCallBack Target="CalibrationScheduleDtls" Command="Refresh">
                    <Behavior RepaintControlsIDs="CalibrationScheduleDtls" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Maintenance" RepaintOnDemand="false">
                <Template>
                    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="300px" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns ="true">                    
                        <Levels>
                            <px:PXGridLevel DataMember="MaintenanceDetail">
                                                    <RowTemplate>
                                                        <px:PXCheckBox runat="server" ID="edOrderRequired" DataField="OrderRequired" CommitChanges="true"></px:PXCheckBox>
                                                        <px:PXTextEdit ID="edScheduleName" runat="server" AlreadyLocalized="False"      DataField="ScheduleName" CommitChanges="true">
                                                        </px:PXTextEdit>
                                                        <px:PXSelector ID="edMaintenanceChecklistID" runat="server" AlreadyLocalized="False" DataField="MaintenanceChecklistID" CommitChanges="true" AllowEdit="true">                                               
                                                        </px:PXSelector>  
                                                 <px:PXDropDown ID="edMainSource" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="MainSource"></px:PXDropDown>
                                                        <px:PXDropDown ID="edMainScheduleType" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="MainScheduleType"></px:PXDropDown>
                                                        <px:PXTextEdit ID="edDays" runat="server" AlreadyLocalized="False" DataField="Days" CommitChanges="true">
                                                        </px:PXTextEdit>                                         
                                                        <px:PXTextEdit ID="edUsage" runat="server" AlreadyLocalized="False" DataField="Usage" CommitChanges="true">
                                                        </px:PXTextEdit>
                                                         <px:PXDateTimeEdit ID="edStartDateManual" runat="server" AlreadyLocalized="False" DataField="StartDateManual" CommitChanges="true">
                                                         </px:PXDateTimeEdit>
                                                        <px:PXDateTimeEdit ID="edNextCalDate" runat="server" AlreadyLocalized="False" DataField="NextCalDate" CommitChanges="true">
                                                        </px:PXDateTimeEdit>
                                                        <px:PXDateTimeEdit ID="edLastMaintenanceDate" runat="server" AlreadyLocalized="False" DataField="LastMaintenanceDate" CommitChanges="true">
                                                        </px:PXDateTimeEdit>
                                            
                                                    </RowTemplate>
                                                    <Columns>
                                                        <px:PXGridColumn DataField="OrderRequired" Type="CheckBox" CommitChanges="true"></px:PXGridColumn>
                                                        <px:PXGridColumn DataField="ScheduleName" CommitChanges="true">
                                                        </px:PXGridColumn>
                                                        <px:PXGridColumn DataField="MaintenanceChecklistID" CommitChanges="true">
                                                        </px:PXGridColumn> 
                                                        <px:PXGridColumn DataField="ChkgroupDesc" CommitChanges="true">
                                                        </px:PXGridColumn >                                         
                                                        <px:PXGridColumn DataField="MainSource" CommitChanges="true">
                                                        </px:PXGridColumn>
                                                        <px:PXGridColumn DataField="MainScheduleType" CommitChanges="true">
                                                        </px:PXGridColumn>
                                                        <px:PXGridColumn DataField="Days" CommitChanges="true" TextAlign="left">
                                                        </px:PXGridColumn>                                        
                                                        <px:PXGridColumn DataField="Usage" CommitChanges="true" TextAlign="left">
                                                        </px:PXGridColumn>
                                                        <px:PXGridColumn DataField="StartDateManual" CommitChanges="true" TextAlign="left">
                                                        </px:PXGridColumn>
                                                         <px:PXGridColumn DataField="NextCalDate" CommitChanges="true">
                                                        </px:PXGridColumn>
                                                        <px:PXGridColumn DataField="LastMaintenanceDate" CommitChanges="true">
                                                        </px:PXGridColumn>
                                                    </Columns>
                                                </px:PXGridLevel>
                        </Levels>                    
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>                 
                 <AutoCallBack Target="grid" Command="Refresh">
                    <Behavior RepaintControlsIDs="grid" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="General">
                 <Template>
                    <px:PXFormView ID="GeneralDtls" runat="server" Width="100%" DataMember="ToolsManagement"
                        DataSourceID="ds" SkinID="Transparent">
                <Template>
                   

                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="SM" />
                            <px:PXLayoutRule runat="server" StartColumn="True" ColumnSpan="6"></px:PXLayoutRule>
                            <px:PXLayoutRule runat="server" StartColumn="True" GroupCaption="Attachments" ColumnSpan="6"></px:PXLayoutRule>
                            <px:PXLabel Style="margin-bottom: -4%;" ID="edlbl" runat="server" Text=" "></px:PXLabel>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="SM" />
                            <px:PXAttachedFiles Height="320px" Width="430px" ID="Usermanual" runat="server" DataField="Usermanual" AllowUpload="true" AllowNoImage="true" ShowComment="true" CommitChanges="true" AllowResize="true" Caption="true"></px:PXAttachedFiles>
                            <px:PXLayoutRule runat="server" StartColumn="True"></px:PXLayoutRule>
                            <px:PXLabel Style="margin-bottom: -4%;" ID="PXLabel1" runat="server" Text=" "></px:PXLabel>
                            <px:PXLayoutRule runat="server" StartRow="True" ControlSize="M" LabelsWidth="SM" ColumnSpan="6" />
                            <px:PXImageUploader Height="320px" Width="430px" ID="ImageUrl" runat="server" DataField="ImageUrl" AllowUpload="true" AllowNoImage="false" ShowComment="true" DataMember="ToolsManagement" CommitChanges="true" ></px:PXImageUploader>


                </Template>
                        </px:PXFormView>

                </Template>
                <AutoCallBack Target="GeneralDtls" Command="Refresh">
                    <Behavior RepaintControlsIDs="GeneralDtls" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Transaction History">
                <Template>
                    <px:PXGrid ID="transactionGrid" runat="server" BorderStyle="None" SkinID="DetailsInTab" Width="100%" DataSourceID="ds" SyncPosition="true">
                        <AutoSize Enabled="True" MinHeight="150" />
                        <ActionBar>
                            <Actions>
                                <AddNew Enabled="false" />
                                <Delete Enabled="false" />
                                <EditRecord Enabled="false" />
                            </Actions>
                        </ActionBar>
                        <Levels>
                            <px:PXGridLevel DataMember="EWQCToolManagementView">
                                <Mode AllowAddNew="false" AllowDelete="false" AllowUpload="false" />
                                <Columns>
                                    <px:PXGridColumn DataField="TnCOrderCD" Width="115px" LinkCommand="RefOrderNbr"  />
                                    <px:PXGridColumn DataField="Status" Width="115px" />
                                    <px:PXGridColumn DataField="OrderType" Width="115px" />
                                    <px:PXGridColumn DataField="CalibrationScheduledType" Width="130px" />
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                           <Mode AllowAddNew="false" AllowDelete="false" AllowUpdate="false" AllowUpload="false" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="transactionGrid" Command="Refresh">
                    <Behavior RepaintControlsIDs="transactionGrid" />
                </AutoCallBack>
            </px:PXTabItem>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True">

                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" Width="180px"  DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description" Width="240px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType" Width="180px">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID" Width="180px">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXTab>
</asp:Content>

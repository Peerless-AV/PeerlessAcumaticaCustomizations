<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC205600.aspx.cs" Inherits="Page_QC205600" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" typename="EW.QC.EWQCNCategoryMaint" primaryview="Categories">
	</px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="True" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" tabindex="-1336" bpeventsindicator="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="Name" DataMember="Categories">
			    <RowTemplate>
                        <px:PXDropDown ID="edNcCapaType" runat="server" DataField="NcCapaType" CommitChanges="True" />
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name" IsClientControl="True">
                </px:PXTextEdit>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" IsClientControl="True">
        </px:PXTextEdit>              
        </RowTemplate>
    <Columns>
    <px:PXGridColumn DataField="NcCapaType" Width="280px">
    </px:PXGridColumn>
    <px:PXGridColumn DataField="Name" Width="180px">
    </px:PXGridColumn>
    <px:PXGridColumn DataField="Description" Width="280px">
    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	</px:pxgrid>
</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC102102.aspx.cs" Inherits="Page_QC102102" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" TypeName="EW.QC.EWQCInspectionChecklistSetupMaint" PageLoadBehavior="InsertRecord" AttributesFound="False" PrimaryView="Setup" SuspendUnloading="False">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds"  Width="100%" DataMember="Setup"  Height ="100%" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
          <AutoSize Enabled="True" Container="Window" MinHeight="200"></AutoSize>
        <Activity Width="" Height=""></Activity>
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />
            <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="NUMBERING SETTINGS" />
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True"></px:PXLayoutRule>
            <px:PXSelector ID="edQCINSPlanNumberSequenceID" runat="server" DataField="QCINSPlanNumberSequenceID" Size="XL" Width="230" LabelWidth="300" AllowEdit="True">
            </px:PXSelector>
            <px:PXSelector ID="edQCINSOrderNumberSequenceID" runat="server" DataField="QCInspectionOrderNumberSequenceID" Size="XL" Width="230" LabelWidth="300" AllowEdit="True">
            </px:PXSelector>
            <px:PXLayoutRule runat="server" StartColumn="True"  LabelsWidth="M" ControlSize="XM" />
            <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Data Entry Settings"/>
            <px:PXTextEdit ID="edInspectionPlanRevisionNo" runat="server" AlreadyLocalized="False" DataField="InspectionPlanRevisionNo" LabelWidth="300px">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server"   StartColumn="True"  LabelsWidth="M" ControlSize="XM" />
 <px:PXLayoutRule runat="server" StartGroup="True" GroupCaption="Restrict use of Inspection plan that are Inactive, On Hold, or Obsolete." />
 <px:PXCheckBox ID="edErrorRequiredOnPR" runat="server" style="margin-left:22%" AlreadyLocalized="False" DataField="ErrorRequiredOnPRIns" Text="Error Required On PR">
 </px:PXCheckBox>
 <px:PXCheckBox ID="edErrorRequiredOnProduction" runat="server" style="margin-left:22%" AlreadyLocalized="False" DataField="ErrorRequiredOnProductionIns" Text="Error Required On Production">
 </px:PXCheckBox>
 <%--<px:PXCheckBox ID="edErrorRequiredOnInprocess" runat="server" style="margin-left:22%"  AlreadyLocalized="False" DataField="ErrorRequiredOnShipmentIns" Text="Error Required On Inprocess ">
 </px:PXCheckBox>--%>
        </Template>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXFormView>
</asp:Content>

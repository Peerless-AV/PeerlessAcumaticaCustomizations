﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209023.aspx.cs" Inherits="Page_QC209023" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="true" runat="server" Visible="True" AttributesFound="False" PrimaryView="LotLocStatus" SuspendUnloading="False" TypeName="EW.QC.EWQCLotLocStatusMaint" PageLoadBehavior="InsertRecord">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="True" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" tabindex="3200" syncposition="true" bpeventsindicator="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="Status" DataMember="LotLocStatus">
			    <RowTemplate>
                    <px:PXTextEdit ID="edStatus" runat="server" AlreadyLocalized="False" DataField="Status">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edStatusDescription" runat="server" AlreadyLocalized="False" DataField="Description">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Status" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description" Width="280px">
                    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
	</px:pxgrid>
</asp:Content>

<%--<asp:Content ID="formContent" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="formLotStatus" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="100%" DataMember="LotLocStatus" TabIndex="3700" DefaultControlID="edStatus" FilesIndicator="True" ActivityIndicator="True" ActivityField="NoteActivity" NoteIndicator="True"
        notifyindicator="True" BPEventsIndicator="True">
          <AutoSize Enabled="True" Container="Window" MinHeight="200"></AutoSize>
<Activity Width="" Height=""></Activity>
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" LabelsWidth="SM"  ControlSize="XM" />
            <px:PXSelector ID="edStatus" runat="server" DataField="Status" Width="350" style="margin-bottom:3%">
            </px:PXSelector>
            <px:PXTextEdit ID="edDescription" runat="server" DataField="Description"
                TextMode="MultiLine" Rows="12" Width="450" Height="150%" />
        </Template>
    </px:PXFormView>
</asp:Content>--%>

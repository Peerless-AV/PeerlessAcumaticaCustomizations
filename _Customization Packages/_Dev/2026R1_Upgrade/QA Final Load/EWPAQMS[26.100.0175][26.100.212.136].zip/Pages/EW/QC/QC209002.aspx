﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC209002.aspx.cs" Inherits="Page_QC209002" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">

    <px:pxdatasource id="ds" primaryview="EWQCChecklistGroup" typename="EW.QC.EWQCChecklistGroupMaint" runat="server" visible="True" width="100%" attributesfound="False" enableattributes="true" suspendunloading="False" pageloadbehavior="InsertRecord">
        <CallbackCommands>
        </CallbackCommands>
    </px:pxdatasource>

</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="EWQCChecklistGroup" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edChecklistCD" runat="server" AlreadyLocalized="False" DataField="ChecklistGroupCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" Height="50" DataField="Description" TextMode="MultiLine">
            </px:PXTextEdit>
            <%--<px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>--%>
        </Template>
    </px:pxformview>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" width="100%" height="150px" datasourceid="ds">
        <Items>
            <px:PXTabItem Text="CheckList">
                <Template>
                    <px:PXGrid ID="detailGrid" runat="server" DataSourceID="ds" SkinID="Details"
                       Width="100%" SyncPosition="true" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="ChecklistID,ChecklistGroupID" DataMember="EWQCChecklistGroupVariable">
                                <RowTemplate>
                                    <px:PXSelector ID="edName1" runat="server" AlreadyLocalized="False" DataField="ChecklistID" CommitChanges="True" AllowEdit=" true">
                                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                                    </px:PXSelector>
                                    <px:PXTextEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                                    </px:PXTextEdit>

                                </RowTemplate>
                                <Columns>
                                    <px:PXGridColumn DataField="ChecklistID" CommitChanges="true">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EWQCChecklist__Name" Width="180px">
                                    </px:PXGridColumn>

                                    <px:PXGridColumn DataField="LineNbr">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>

            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>

</asp:Content>


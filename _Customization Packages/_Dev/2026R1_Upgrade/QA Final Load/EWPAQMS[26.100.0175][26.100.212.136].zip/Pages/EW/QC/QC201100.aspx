<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC201100.aspx.cs" Inherits="Page_QC201100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="true" runat="server" visible="True" attributesfound="False" primaryview="Documents" suspendunloading="False" typename="EW.QC.EWQCSamplingPlanMaint" pageloadbehavior="InsertRecord">
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="Documents" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edSamplingPlanCD" runat="server" AlreadyLocalized="False" DataField="SamplingPlanCD" CommitChanges="True">
                <GridProperties FastFilterFields="RevisionNo,Name" ></GridProperties>
            </px:PXSelector>
            <px:PXTextEdit ID="edName" runat="server" AlreadyLocalized="False" DataField="Name">
            </px:PXTextEdit>

            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edRemarks" TextMode="MultiLine" Height="60" runat="server" AlreadyLocalized="False" DataField="Remarks">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>

            <px:PXSelector ID="edRevisionNo" runat="server" AutoRefresh="true" AlreadyLocalized="False" DataField="RevisionNo">
                <GridProperties FastFilterFields="Name,Description" ></GridProperties>
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edEffectiveFromDate" runat="server" AlreadyLocalized="False" DataField="EffectiveFromDate">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edEffectiveToDate" runat="server" AlreadyLocalized="False" DataField="EffectiveToDate">
            </px:PXDateTimeEdit>
            <px:PXCheckBox ID="edHold" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="Hold" Text="On Hold">
            </px:PXCheckBox>
             <px:PXDropDown ID="edStatusText" Enabled="false" ReadOnly="true" runat="server" DataField="Status">
            </px:PXDropDown>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXDropDown ID="edSamplingMethodType" runat="server" DataField="SamplingMethodType" CommitChanges="true">
            </px:PXDropDown>

            <px:PXDropDown ID="edAQLInspectionLevel" runat="server" AlreadyLocalized="False" DataField="AQLInspectionLevel" CommitChanges="true">
            </px:PXDropDown>
            <px:PXDropDown ID="edSelectSerializedSample" runat="server" DataField="SelectSerializedSample" CommitChanges="true">
            </px:PXDropDown>
            <px:PXNumberEdit ID="edSampleSize" runat="server" DataField="SamplingSize" />

            <pxa:PXFormulaCombo ID="edEquation" runat="server" DataField="Equation" EditButton="True" hide=""
                FieldsAutoRefresh="True" FieldsRootAutoRefresh="true" PanelAutoRefresh="True"
                LastNodeName="Custom Functions" OnRootFieldsNeeded="edOns_RootFieldsNeeded"
                IsInternalVisible="false" IsExternalVisible="false" SelectButton="true"
                CommitChanges="true" ToolTip="*Example - SQRT(n) - n is lot size or quantity received" />  

          <px:PXSelector ID="edQtyUOM" runat="server" CommitChanges="true" AutoRefresh="true" AlreadyLocalized="False" DataField="QtyUOM">                
            </px:PXSelector>

             <px:PXSelector ID="edSampleUOM" runat="server" CommitChanges="true" AutoRefresh="true" AlreadyLocalized="False" DataField="SampleUOM">                
            </px:PXSelector>
          <%--  <px:PXDropDown ID="edStatus" runat="server" DataField="Status">
            </px:PXDropDown>--%>
        </Template>
    </px:pxformview>

</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" height="150px" style="z-index: 100;" width="100%">
        <Items>
            <px:PXTabItem Text="Manual" RepaintOnDemand="false">
                <Template>

    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true" RepaintColumns ="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="SamplingPlanDetailID" DataMember="SamplingPlanDetails">
                <RowTemplate>
                    <px:PXNumberEdit ID="edNumQuantityFrom" runat="server" AlreadyLocalized="False" DataField="QuantityFrom">
                    </px:PXNumberEdit>
                    <px:PXTextEdit ID="edUnitTargetValue" runat="server" AlreadyLocalized="False" DataField="UnitQuantityFrom">
                    </px:PXTextEdit>
                     <px:PXCheckBox ID="edisabove" CommitChanges="true" runat="server" AlreadyLocalized="False" DataField="isabove">
                    </px:PXCheckBox>
                    <px:PXNumberEdit ID="edNumQuantityTo" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                     <px:PXTextEdit ID="edUnitMaxValue" runat="server" AlreadyLocalized="False" DataField="UnitQuantityTo">
                    </px:PXTextEdit>
                    <px:PXNumberEdit ID="edNumNoOfSample" runat="server" AlreadyLocalized="False" DataField="NoOfSamples">
                    </px:PXNumberEdit> 
                    <px:PXNumberEdit ID="edSampleSize" runat="server" AlreadyLocalized="False" DataField="SampleSize">
                    </px:PXNumberEdit>
                    <px:PXSelector ID="edUnitNumNoOfSample" Size="s" runat="server" AllowEdit="True" CommitChanges="True" DataField="UnitNumNoOfSample" Style="margin-right:30px"></px:PXSelector>                    
                    <px:PXNumberEdit ID="edLineNbr" runat="server" AlreadyLocalized="False" DataField="LineNbr">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityFrom" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="UnitQuantityFrom" CommitChanges="true" Width="100px" >
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="isabove" CommitChanges="true" Width="100px" TextAlign="Center" Type="CheckBox" >
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="UnitQuantityTo" CommitChanges="true" Width="100px" >
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="NoOfSamples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SampleSize" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="UnitNoOfSamples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                      <px:PXGridColumn DataField="LineNbr" CommitChanges="true" Width="100px" SyncVisible ="false" >
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>
                          </Template>
            </px:PXTabItem>

               <px:PXTabItem Text="General Insp Lvl � I"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevel1">
                <Template>
    <px:PXGrid ID="PXGrid2" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="QuantityForm2" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="QuantityTo2" runat="server" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="LevelOneSamples" runat="server" AlreadyLocalized="False" DataField="LevelOneSamples">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LevelOneSamples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>

                </Template>
            </px:PXTabItem>

                          <px:PXTabItem Text="General Insp Lvl � II"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevel2">
                <Template>
    <px:PXGrid ID="PXGrid1" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="PXNumberEdit1" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="PXNumberEdit2" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="PXNumberEdit3" runat="server" AlreadyLocalized="False" DataField="NoOfSample">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="NoOfSample" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>

                </Template>
            </px:PXTabItem>


   <px:PXTabItem Text="General Insp Lvl � III"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevel3">
                <Template>
    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="QuantityForm3" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="QuantityTo3" runat="server" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="LevelThreeSamples" runat="server" AlreadyLocalized="False" DataField="LevelThreeSamples">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LevelThreeSamples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>

                </Template>
            </px:PXTabItem>

            <px:PXTabItem Text="Special Insp Lvl � S1"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevelS1">
                <Template>
    <px:PXGrid ID="PXGrid4" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="QuantityForm4" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="QuantityTo4" runat="server" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="LevelS1Samples" runat="server" AlreadyLocalized="False" DataField="LevelS1Samples">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LevelS1Samples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>

                </Template>
            </px:PXTabItem>

              <px:PXTabItem Text="Special Insp Lvl � S2"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevelS2">
                <Template>
    <px:PXGrid ID="PXGrid5" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="QuantityForm5" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="QuantityTo5" runat="server" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="LevelS2Samples" runat="server" AlreadyLocalized="False" DataField="LevelS2Samples">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LevelS2Samples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>
            </Template>
            </px:PXTabItem>

    <px:PXTabItem Text="Special Insp Lvl � S3"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevelS3">
                <Template>
    <px:PXGrid ID="PXGrid6" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="QuantityForm6" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="QuantityTo6" runat="server" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="LevelS3Samples" runat="server" AlreadyLocalized="False" DataField="LevelS3Samples">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LevelS3Samples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>

                </Template>
            </px:PXTabItem>

              <px:PXTabItem Text="Special Insp Lvl � S4"  BindingContext="form" RepaintOnDemand="false" VisibleExp="DataControls[&quot;edAQLInspectionLevel&quot;].Value == InspectionLevelS4">
                <Template>
    <px:PXGrid ID="PXGrid6" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Details" SyncPosition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <Levels>
            <px:PXGridLevel DataKeyNames="StandardAQLID" DataMember="StandardAQL">
                <RowTemplate>
                    <px:PXNumberEdit ID="QuantityForm7" runat="server" AlreadyLocalized="False" DataField="QuantityForm">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="QuantityTo7" runat="server" AlreadyLocalized="False" DataField="QuantityTo">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="LevelS4Samples" runat="server" AlreadyLocalized="False" DataField="LevelS4Samples">
                    </px:PXNumberEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="QuantityForm" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QuantityTo" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LevelS4Samples" CommitChanges="true" Width="100px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:PXGrid>

                </Template>
            </px:PXTabItem>

             <px:PXTabItem Text="Event History">

                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>
</asp:Content>

﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC504041.aspx.cs" Inherits="Page_QC504041" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" EnableAttributes="False" runat="server" Visible="True" Width="100%" PrimaryView="AdhocQCOrderProcess"
        TypeName="EW.QC.EWQCAdhocQCOrderProcess">
        <CallbackCommands> 
            <px:PXDSCallbackCommand Name="ProcessEvents" Visible="False" DependOnGrid="grid" CommitChanges="true" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" DataMember="PrimaryDAC" TabIndex="3700" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM" />
            <px:PXSelector ID="edInventoryID" runat="server" AlreadyLocalized="False" DataField="InventoryID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edLotSerialNbr" runat="server" AlreadyLocalized="False" DataField="LotSerialNbr" AutoRefresh="True" CommitChanges="True">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edSiteID" runat="server" AlreadyLocalized="False" DataField="SiteID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
            </px:PXSelector>
            <px:PXSelector ID="edLotStatus2" runat="server" AlreadyLocalized="False" DataField="LotStatus" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
            </px:PXSelector>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>           
            <px:PXSelector ID="edLocationID" runat="server" AlreadyLocalized="False" DataField="LocationID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
            </px:PXSelector>
             <px:PXDateTimeEdit ID="edExpireDate" runat="server" AlreadyLocalized="False" DataField="ExpireDate" TimeMode="false" Width="100%">
            </px:PXDateTimeEdit>
        </Template>
    </px:PXFormView>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
        AllowPaging="True" AllowSearch="true" SyncPosition="true" AdjustPageSize="Auto" bpeventsindicator="true" DataSourceID="ds" SkinID="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataMember="AdhocQCOrderProcess">
                <RowTemplate>
                    <px:PXSelector ID="PXSelector1" runat="server" AlreadyLocalized="False" DataField="InventoryID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edItemClassID" runat="server" AlreadyLocalized="False" DataField="ItemClassID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="PXSelector2" runat="server" AlreadyLocalized="False" DataField="SiteID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="PXSelector3" runat="server" AlreadyLocalized="False" DataField="LocationID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edLotStatus" runat="server" AlreadyLocalized="False" DataField="LotStatus" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edPlanID" runat="server" AlreadyLocalized="False" DataField="PlanID" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                    <px:PXSelector ID="edQCOrderCD" runat="server" AlreadyLocalized="False" DataField="QCOrderCD" AllowAddNew="True" AllowEdit="True" AutoRefresh="True" CommitChanges="True">
                    </px:PXSelector>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" TextAlign="Center" Type="CheckBox" Width="60px" />
                    <px:PXGridColumn DataField="InventoryID" Width="100px" />
                    <px:PXGridColumn DataField="InventoryDesc" Width="100px" />
                    <px:PXGridColumn DataField="ItemClassID" Width="100px" />
                    <px:PXGridColumn DataField="LotSerialNbr" Width="100px" />
                    <px:PXGridColumn DataField="QtyOnHand" Width="80px" />
                    <px:PXGridColumn DataField="ExpireDate" Width="100px" />
                    <px:PXGridColumn DataField="SiteID" Width="100px" />
                    <px:PXGridColumn DataField="LocationID" Width="100px" />
                    <px:PXGridColumn DataField="LotStatus" Width="100px" />
                    <px:PXGridColumn DataField="PlanID" Width="150px" />
                    <px:PXGridColumn DataField="QCOrderCD" Width="100px" />
                    <px:PXGridColumn DataField="OrderDate" Width="100px" />
                </Columns>
            </px:PXGridLevel>
        </Levels>        
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:PXGrid>
</asp:Content>

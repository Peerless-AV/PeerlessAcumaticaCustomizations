<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC504100.aspx.cs" Inherits="Page_QC504100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="Filter"
        typename="EW.QC.EWQCCopyItemClassInspectionSettingProcess">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewInventory" DependOnGrid="grid"></px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" tabindex="3700" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXDropDown ID="edQMSSettings" runat="server" DataField="QMSSettings" CommitChanges="True" Width="150px"/>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXSelector ID="edItemClassID" runat="server" DataField="ItemClassID" CommitChanges="True">
                 <GridProperties FastFilterFields="Descr" ></GridProperties>
            </px:PXSelector>
        </Template>
    </px:pxformview>
   <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" syncposition="true" adjustpagesize="Auto" datasourceid="ds" skinid="PrimaryInquire" AutoAdjustColumns="true">
        <Levels>
            <px:PXGridLevel DataKeyNames="InventoryCD" DataMember="StockItems">
                <RowTemplate>
                     <px:PXSelector ID="edDfltSiteID" AllowEdit="true" runat="server" DataField="DfltSiteID">
                    </px:PXSelector>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="InventoryCD" LinkCommand="ViewInventory"  Width="150px" />
                    <px:PXGridColumn DataField="Descr" Width="300px" Visible="False" />
                    <px:PXGridColumn DataField="ItemType"  Type="DropDownList" Width="80px" />
                    <px:PXGridColumn DataField="DfltSiteID" Width="100px"  />
                    <px:PXGridColumn DataField="BasePrice" Width="108px"/>
                    <px:PXGridColumn DataField="ItemStatus" Type="DropDownList"/>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>

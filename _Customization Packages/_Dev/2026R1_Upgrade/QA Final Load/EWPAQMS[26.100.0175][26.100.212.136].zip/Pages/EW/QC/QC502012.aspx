﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC502012.aspx.cs" Inherits="Page_QC502012" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="Content1" ContentPlaceHolderID="phDS" runat="Server">

    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" typename="EW.QC.EWQCOrderNSProcess" primaryview="Filter">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="ViewOrder" Visible="false" CommitChanges="true" DependOnGrid="grid" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="phL" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" tabindex="3700" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXDropDown ID="edItemType" runat="server" DataField="ItemType" CommitChanges="True" Width ="150"/>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXDateTimeEdit ID="edDueDate" runat="server" DataField="DueDate" CommitChanges="True" Width ="150"/>
            <px:PXLayoutRule runat="server" StartColumn="True" />
            <px:PXDropDown ID="edStatus" runat="server" DataField="Status" CommitChanges="True" Width ="150"/>
        </Template>
    </px:pxformview>

    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100" bpeventsindicator="True"
        allowpaging="True" allowsearch="true" adjustpagesize="Auto" datasourceid="ds" skinid="Primary" syncposition="true">
        <Levels>
            <px:PXGridLevel DataMember="OrderNSProcess" DataKeyNames="RowNum">
                <Columns>
                    <px:PXGridColumn DataField="Selected" TextAlign="Center" Type="CheckBox" Width="30" AllowCheckAll="True" AllowSort="False"  CommitChanges="true"/>
                    <px:PXGridColumn DataField="ItemType" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ArticleID" LinkCommand="ViewArticleID" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Name">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="PlanID" LinkCommand="ViewPlanID" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="IntervalBy">
                    </px:PXGridColumn>  
                     <px:PXGridColumn DataField="Interval">
                    </px:PXGridColumn> 
                     <px:PXGridColumn DataField="LastQCOrderID" LinkCommand="ViewDQCOrder" CommitChanges="true">
                    </px:PXGridColumn> 
                      <px:PXGridColumn DataField="QCStatus">
                    </px:PXGridColumn> 
                     <px:PXGridColumn DataField="DueDate">
                    </px:PXGridColumn> 
                     <px:PXGridColumn DataField="Status">
                    </px:PXGridColumn> 
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>


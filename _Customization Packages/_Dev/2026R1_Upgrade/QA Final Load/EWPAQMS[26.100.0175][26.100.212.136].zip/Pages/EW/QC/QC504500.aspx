<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC504500.aspx.cs" Inherits="Page_QC504500" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" width="100%" primaryview="Filter"
        typename="EW.QC.EWQCChangePlanProcess">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewBOM" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" tabindex="3700" bpeventsindicator="True">
        <Template>
             <px:PXLayoutRule runat="server" StartColumn="True" />
                <px:PXDropDown ID="edReplace" runat="server" DataField="Replace" CommitChanges="True"  Width="150px"/>
                <px:PXLayoutRule runat="server" StartColumn="True" />
                <px:PXSelector ID="PXSelector1" runat="server" DataField="PlanID" CommitChanges="True"/>
                <px:PXSelector ID="PXSelector3" runat="server" DataField="SamplingPlanID" CommitChanges="True"/>
                <px:PXSelector ID="PXSelector5" runat="server" DataField="InsPlanID" CommitChanges="True"/>
                <px:PXSelector ID="PXSelector7" runat="server" DataField="ChecklistGroupID" CommitChanges="True"/>
                 <px:PXDropDown ID="edInspectionType" runat="server" DataField="InspectionType" CommitChanges="True" Width="150px"/>
                <px:PXLayoutRule runat="server" StartColumn="True"   LabelsWidth="M" ControlSize="XM"/>
                <px:PXSelector ID="PXSelector2" runat="server" DataField="NewPlanID" CommitChanges="True"/>
                <px:PXSelector ID="PXSelector4" runat="server" DataField="NewSamplingPlanID" CommitChanges="True"/>
                 <px:PXSelector ID="PXSelector6" runat="server" DataField="NewInsPlanid" CommitChanges="True"/>
                <px:PXSelector ID="PXSelector8" runat="server" DataField="NewChecklistGroupID" CommitChanges="True"/>
                <px:PXDropDown ID="edNewInspectionType" runat="server" LabelWidth="150px" DataField="NewInspectionType" CommitChanges="True" Width="150px"/>
                <px:PXLayoutRule runat="server" StartColumn="True" />
                <px:PXSelector ID="edSamplingPlanIDInstype" runat="server" LabelWidth="150px" DataField="SamplingPlanIDInstype" CommitChanges="True" Width="150px">
                </px:PXSelector>
         </Template>
    </px:pxformview>
    </asp:Content>

  <asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:PXGrid ID="grid" runat="server" DataSourceID="ds" Height="150px" Style="z-index: 100" Width="100%" AllowPaging="true" AdjustPageSize="Auto" SkinID="PrimaryInquire" 
        AllowSearch="true" BatchUpdate="true" Caption="Orders" SyncPosition="True" AutoAdjustColumns="true">
        <Levels>        
            <px:PXGridLevel DataMember="EWQCDataReplaceView" DataKeyNames="Action,ItemKey">
                <RowTemplate>
                     
                 
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px" >
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Field1" Width="500px" LinkCommand="ViewField" />              
                    <px:PXGridColumn DataField="Field2" Width="500px" />      
                    <px:PXGridColumn DataField="Field3" Width="500px" />  
                    <px:PXGridColumn DataField="Action" Width="500px" /> 
                    <px:PXGridColumn DataField="UsrEWQCPlanID" Width="500px"  CommitChanges="true"/> 
                   <px:PXGridColumn DataField="InspectionType" Width="500px"  CommitChanges="true" />
                    <px:PXGridColumn DataField="UsrEWQCSamplingPlanID" Width="500px"  CommitChanges="true" /> 
                </Columns>
            </px:PXGridLevel>
               </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
       
    </px:PXGrid>
</asp:Content>


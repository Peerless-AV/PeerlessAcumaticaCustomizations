<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC206000.aspx.cs" Inherits="Page_QC206000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" visible="True" typename="EW.QC.EWQCToolGaugeMaint" attributesfound="False" enableattributes="true"
        primaryview="ToolGauges" suspendunloading="False">
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" datamember="ToolGauges" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edToolGaugeCD" runat="server" AlreadyLocalized="False" DataField="ToolGaugeCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXTextEdit ID="edComment" runat="server" AlreadyLocalized="False" DataField="Comment">
            </px:PXTextEdit>
            <px:PXDropDown ID="edStatus" runat="server" DataField="Status">
            </px:PXDropDown>

            <px:PXLayoutRule runat="server" StartColumn="True"   LabelsWidth="SM" ControlSize="XM"/>
            <px:PXDateTimeEdit ID="edLastCalibrationDate" runat="server" AlreadyLocalized="False" DataField="LastCalibrationDate">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edNextCalibrationDate" runat="server" AlreadyLocalized="False" DataField="NextCalibrationDate">
            </px:PXDateTimeEdit>            
            <px:PXTextEdit ID="edSerialNo" runat="server" AlreadyLocalized="False" DataField="SerialNo">
            </px:PXTextEdit>

            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description">
            </px:PXTextEdit>

        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxtab id="tab" runat="server" height="150px" style="z-index: 100;" width="100%">
        <Items>
            <px:PXTabItem Text="Event History">
                <Template>
                    <px:PXGrid ID="PXGrid3" runat="server" DataSourceID="ds" Width="100%" Height="100%" SkinID="DetailsInTab" SyncPosition="True" AutoAdjustColumns="true">
                        <Levels>
                            <px:PXGridLevel DataKeyNames="EWQCEventID" DataMember="EventHistory">
                                <Columns>
                                    <px:PXGridColumn DataField="CreatedDateTime" DisplayFormat="g">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="Description">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="EventType">
                                    </px:PXGridColumn>
                                    <px:PXGridColumn DataField="CreatedByID">
                                    </px:PXGridColumn>
                                </Columns>
                            </px:PXGridLevel>
                        </Levels>
                        <AutoSize Enabled="True" />
                        <AutoCallBack />
                    </px:PXGrid>
                </Template>
                <AutoCallBack Target="PXGrid3" Command="Refresh">
                    <Behavior RepaintControlsIDs="PXGrid3" />
                </AutoCallBack>
            </px:PXTabItem>
        </Items>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
    </px:pxtab>
</asp:Content>





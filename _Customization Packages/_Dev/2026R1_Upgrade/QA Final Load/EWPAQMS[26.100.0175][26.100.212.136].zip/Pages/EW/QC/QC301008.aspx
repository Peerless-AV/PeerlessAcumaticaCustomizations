<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC301008.aspx.cs" Inherits="Page_QC301008" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="true" runat="server" visible="True" typename="EW.QC.EWQCStabilityEntry" primaryview="StabilityQC" attributesfound="False" suspendunloading="False">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="AddQCTool" Visible="false" CommitChanges="true"></px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="ViewTestMethod" Visible="true" DependOnGrid="grid" />
            <px:PXDSCallbackCommand Name="ViewTestCategoryMaster" Visible="true" DependOnGrid="grid" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" width="100%" datamember="StabilityQC" filesindicator="True" activityindicator="True" activityfield="NoteActivity" noteindicator="True"
        notifyindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />           
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" AutoRefresh="true" CommitChanges="true" Width="100%"  Allowedit ="true">
            </px:PXSelector>
             <px:PXDropDown ID="edQCOrderCreation" runat="server" DataField="QCOrderCreation" Width="100%">
            </px:PXDropDown>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />           
            <px:PXSelector ID="edRetentionWarehouseID" runat="server" CommitChanges="true" DataField="RetentionWarehouseID" Width="100%">
            </px:PXSelector>
            <px:PXSelector ID="edRetentionLocationID" runat="server" AutoRefresh="true" DataField="RetentionLocationID" Width="100%">
            </px:PXSelector>
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phDialogs" runat="Server">
    <px:pxgrid id="PXGrid2" runat="server" datasourceid="ds" width="100%" height="100%" skinid="DetailsInTab" syncposition="True" tabindex="2600">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <AutoCallBack Target="tree" Command="Refresh" ActiveBehavior="True">
            <Behavior RepaintControlsIDs="form,grid"></Behavior>
        </AutoCallBack>
        <Levels>
            <px:PXGridLevel DataKeyNames="QCStabilityID,QCStabilityPlanID" DataMember="StabilityPlanningQC">
                <RowTemplate>
                    <px:PXCheckBox ID="edRecur" runat="server" DataField="Recur">
                    </px:PXCheckBox>
                     <px:PXNumberEdit ID="edExecutionLimit" runat="server" DataField="ExecutionLimit">
                    </px:PXNumberEdit>                   
                    <px:PXNumberEdit ID="edInterval" runat="server" DataField="Interval">
                    </px:PXNumberEdit>
                    <px:PXDropDown ID="edIntervalBy" runat="server" DataField="IntervalBy" CommitChanges="true">
                    </px:PXDropDown>
                    <px:PXSelector ID="edQCPlanID" runat="server" CommitChanges="true" DataField="QCPlanID">
                    </px:PXSelector>
                    <px:PXDropDown ID="edResultCriteria" runat="server" DataField="ResultCriteria">
                    </px:PXDropDown>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Recur" Width="150px" TextAlign="Center" Type="CheckBox">
                    </px:PXGridColumn>
                     <px:PXGridColumn DataField="ExecutionLimit" Width="150px">
                    </px:PXGridColumn>                   
                    <px:PXGridColumn DataField="Interval" Width="150px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="IntervalBy" Width="150px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QCPlanID" CommitChanges="true" LinkCommand="EWQCViewPlanMaster" Width="250px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCPlan__Name" Width="200px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCPlan__Description" Width="200px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCPlan__Status" Width="200px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ResultCriteria" Width="200px">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <Mode AllowUpload="True" />
        <AutoSize Enabled="True" />
        <AutoCallBack Command="Refresh" Target="grid" ActiveBehavior="true">
            <Behavior RepaintControlsIDs="grid"></Behavior>
        </AutoCallBack>
    </px:pxgrid>
    <px:pxgrid id="grid" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" height="150px" skinid="Details" tabindex="1800" syncposition="true">
        <EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here."
            NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here."
            FilteredMessage="No records found.
Try to change filter to see records here."
            FilteredAddMessage="No records found.
Try to change filter to see records here."
            NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here."
            AnonFilteredMessage="No records found.
Try to change filter to see records here."
            AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
        <AutoSize Container="Window" Enabled="True" MinHeight="250"></AutoSize>
        <ActionBar ActionsText="False">
            <CustomItems>
                <px:PXToolBarButton Text="QCTool" PopupPanel="AttributePanel" Visible="false" Enabled="True">
                    <AutoCallBack Command="AddQCTool" Target="ds">
                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                    </AutoCallBack>
                </px:PXToolBarButton>
                <px:PXToolBarButton Text="ComboBoxValue" PopupPanel="ComboBoxPanel" Visible="false" Enabled="True">
                    <AutoCallBack Command="AddCombo" Target="ds">
                        <Behavior CommitChanges="True" PostData="Page"></Behavior>
                    </AutoCallBack>
                </px:PXToolBarButton>
            </CustomItems>
        </ActionBar>
        <Levels>
            <px:PXGridLevel DataKeyNames="PlanCD,RevisionNo,VariableID" DataMember="PlanVariables">
                <RowTemplate>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                    <px:PXCheckBox ID="edAddInReports" runat="server" AlreadyLocalized="False" DataField="AddInReports">
                    </px:PXCheckBox>
                    <px:PXSelector ID="edVariableID" runat="server" DataField="VariableID" CommitChanges="True" AllowEdit=" true">
                        <GridProperties FastFilterFields="VariableCD,Name"></GridProperties>
                    </px:PXSelector>
                    <px:PXTextEdit ID="edEWQCVariableName" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Name">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Description">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edEquation" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__Equation">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edTestGroupID" runat="server" DataField="TestGroupID" AllowEdit="true">
                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                    </px:PXSelector>
                    <px:PXDropDown ID="edDataType" runat="server" AlreadyLocalized="False" DataField="EWQCVariable__DataType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edToolSteps" runat="server" AlreadyLocalized="False" DataField="ToolSteps">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edSeverityLevel" runat="server" DataField="SeverityLevel" AllowEdit="true">
                        <GridProperties FastFilterFields="Name,Description"></GridProperties>
                    </px:PXSelector>
                    <px:PXSelector ID="edTestCategoryID" runat="server" DataField="EWQCVariable__TestCategoryID" AllowEdit="true">
                    </px:PXSelector>
                    <px:PXSelector ID="edTestMethodID" runat="server" DataField="EWQCVariable__TestMethodID" AllowEdit="true">
                    </px:PXSelector>
                    <px:PXDropDown ID="edQCOperator" runat="server" AlreadyLocalized="False" DataField="QCOperator">
                    </px:PXDropDown>
                    <px:PXNumberEdit ID="edNumMinValue" runat="server" AlreadyLocalized="False" DataField="NumMinValue">
                    </px:PXNumberEdit>
                    <px:PXNumberEdit ID="edNumMaxValue" runat="server" AlreadyLocalized="False" DataField="NumMaxValue">
                    </px:PXNumberEdit>
                    <px:PXTextEdit ID="edAlphaValue" runat="server" AlreadyLocalized="False" DataField="AlphaValue">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edTestResultUOM" runat="server" AlreadyLocalized="False" DataField="TestResultUOM">
                    </px:PXTextEdit>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="S" ControlSize="XM" />
                    <px:PXCheckBox ID="edDestructiveTesting" runat="server" CommitChanges="true" AlreadyLocalized="False" DataField="DestructiveTesting" Text="Go/NoGo">
                    </px:PXCheckBox>
                    <px:PXNumberEdit ID="edSampleSize" runat="server" AlreadyLocalized="False" DataField="SampleSize">
                    </px:PXNumberEdit>
                    <px:PXSelector ID="ewqcSelectorUOM" runat="server" CommitChanges="True" DataField="UOM" Style="margin-right: 30px"></px:PXSelector>
                    <px:PXDropDown ID="edLeadTimeDurationType" runat="server" AlreadyLocalized="False" DataField="LeadTimeDurationType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edLeadTimeDuration" runat="server" AlreadyLocalized="False" DataField="LeadTimeDuration">
                    </px:PXTextEdit>
                    <px:PXCheckBox ID="edBitGoNoGo" runat="server" AlreadyLocalized="False" DataField="BitGoNoGo" Text="Go/NoGo">
                    </px:PXCheckBox>
                    <px:PXCheckBox ID="edOptionalTest" runat="server" AlreadyLocalized="False" DataField="OptionalTest">
                    </px:PXCheckBox>
                    <px:PXDropDown ID="edOrderLevel" runat="server" AlreadyLocalized="False" DataField="OrderLevel">
                    </px:PXDropDown>
                    <px:PXDropDown ID="PXDropDownCalculationType" runat="server" AlreadyLocalized="False" DataField="CalculationType">
                    </px:PXDropDown>
                    <px:PXTextEdit ID="edComboValue" runat="server" AlreadyLocalized="False" DataField="ComboValue">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="AddInReports" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>                   
                    <px:PXGridColumn DataField="VariableID" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Equation" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="TestGroupID" Width="180px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__DataType">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ToolSteps" Width="180px" LinkCommand="AddQCTool" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SeverityLevel" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__TestCategoryID" LinkCommand="ViewTestCategoryMaster" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__TestMethodID" LinkCommand="ViewTestMethod" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="CalculationType" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="QCOperator" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="NumMinValue" Width="100px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="NumMaxValue" Width="100px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="AlphaValue" Width="220px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="TestResultUOM" Width="220px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="DestructiveTesting" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SampleSize" Width="120px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="UOM" Width="120px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LeadTimeDurationType" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LeadTimeDuration" Width="100px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="OptionalTest" TextAlign="Center" Type="CheckBox" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="OrderLevel" CommitChanges="true" Width="120px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ComboValue" Width="280px" LinkCommand="AddCombo" CommitChanges="true">
                    </px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="150" />
        <Mode InitNewRow="false" AllowFormEdit="false" AllowDragRows="false" AutoInsert="false" AllowAddNew="false" AllowUpdate="false" AllowDelete="false" AllowUpload="false"></Mode>
    </px:pxgrid>
    <px:pxsmartpanel id="AttributePanel" runat="server" width="720px" height="360px" caption="Tools" captionvisible="True"
        autocallback-command="Refresh" autocallback-target="AttributesGrid" designview="Content">
        <px:PXGrid ID="AttributesGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="PlanToolSteps">
                    <Columns>
                        <px:PXGridColumn DataField="ToolGaugeID" CommitChanges="true">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode InitNewRow="false" AllowFormEdit="false" AllowDragRows="false" AutoInsert="false" AllowAddNew="false" AllowUpdate="false" AllowDelete="false" AllowUpload="false"></Mode>
        </px:PXGrid>
        <px:PXPanel ID="AttributeButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="AttributeSaveButton" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
            <px:PXButton ID="AttributeCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
                <AutoCallBack Command="CancelQCTools" Target="ds"></AutoCallBack>
            </px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>

    <px:pxsmartpanel id="ComboBoxPanel" runat="server" width="720px" height="360px" key="TestComboValues" caption="Combo Values" captionvisible="True"
        autocallback-command="Refresh" autocallback-target="ComboBoxGrid" designview="Content">
        <px:PXGrid ID="ComboBoxGrid" runat="server" DataSourceID="ds" SkinID="Details" AutoAdjustColumns="True" SyncPosition="true"
            AdjustPageSize="Auto" AllowPaging="True" AllowSearch="true" Width="685px" Height="200px">
            <Levels>
                <px:PXGridLevel DataMember="TestComboValues">
                    <Columns>
                        <px:PXGridColumn DataField="TestComboCD">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="ComboCheck" TextAlign="Center" Type="CheckBox" Width="120px">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
            <Mode AllowAddNew="false" AllowDelete="false" AutoInsert="false" AllowUpdate="true" AllowUpload="false" />
        </px:PXGrid>
        <px:PXPanel ID="ComboButtonPanel" runat="server" SkinID="Buttons">
            <px:PXButton ID="ComboSaveButton" runat="server" DialogResult="OK" Text="OK">
                <AutoCallBack Command="ComboSaveButton" Target="ds"></AutoCallBack>
            </px:PXButton>
            <px:PXButton ID="ComboCancelButton" runat="server" DialogResult="Cancel" Text="Cancel">
            </px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC600100.aspx.cs" Inherits="Page_QC600100" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" runat="server" enableattributes="true" visible="True" width="100%" typename="EW.QC.EWQCLotTraceabilityReport" primaryview="Filter">
        <CallbackCommands>
            <px:PXDSCallbackCommand Name="GenerateForwardLotTraceReport" CommitChanges="true" />
            <px:PXDSCallbackCommand Name="GenerateBackwardLotTraceReport" CommitChanges="true" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="Filter" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" AlreadyLocalized="False" AutoRefresh="true" CommitChanges="true">
            </px:PXSelector>

            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXSelector ID="edLotSerialNbr" runat="server" DataField="LotSerialNbr" AlreadyLocalized="False" AutoRefresh="true" CommitChanges="True">
            </px:PXSelector>

            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" ControlSize="S">
            </px:PXLayoutRule>
            <px:PXDropDown ID="edDecimalPrecision" runat="server" DataField="DecimalPrecision" CommitChanges="True">
            </px:PXDropDown>

            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edReceiving" runat="server" DataField="Receiving" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>

            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edReturnToVendor" runat="server" DataField="ReturnToVendor" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>

            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edTransfer" runat="server" DataField="Transfer" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>

            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edKitAssembly" runat="server" DataField="KitAssembly" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>

            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edProduction" runat="server" DataField="Production" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>

            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edSales" runat="server" DataField="Sales" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>

            <px:PXLayoutRule runat="server" StartColumn="True" ColumnWidth="150px">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edCustomerReturn" runat="server" DataField="CustomerReturn" CommitChanges="True" AlignLeft="true"></px:PXCheckBox>            

        </Template>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxformview>
</asp:Content>

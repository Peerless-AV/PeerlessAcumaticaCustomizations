﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC401056.aspx.cs" Inherits="Page_QC401056" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <asp:Label ID="lbl1" Text="Hello" runat="server"></asp:Label>
    <px:pxdatasource id="ds" runat="server" visible="False" typename="EW.QC.EWQCOrderNavigationMaint"
        pageloadbehavior="InsertRecord"
        attributesfound="False" enableattributes="true" primaryview="Documents" suspendunloading="False">
</px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100" width="100%" datamember="Documents" notifyindicator="True" noteindicator="true" filesindicator="True" activityindicator="True" tabindex="1400" bpeventsindicator="True">
<Template>
<px:PXLayoutRule ID="PXLayoutRule1" runat="server" GroupCaption="QC order " StartColumn="True" LabelsWidth="350px" />
<px:PXTextEdit ID="edRefDocumentType" runat="server" DataField="RefDocumentType" CommitChanges="True" Size="XXS" Width="300" />
<px:PXTextEdit ID="edRefDocumentNbr" runat="server" DataField="RefDocumentNbr" CommitChanges="True" Size="XXS" Width="300" />

</Template>
<AutoSize Container="Window" Enabled="True" MinHeight="200" />
</px:pxformview>
</asp:Content>




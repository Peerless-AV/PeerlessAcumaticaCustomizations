<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC505700.aspx.cs" Inherits="Page_QC505700" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:pxdatasource id="ds" enableattributes="False" runat="server" visible="True" width="100%" primaryview="EWQCStabilityQC"
        typename="EW.QC.EWQCStabilityDataProcess">
        <CallbackCommands>
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datasourceid="ds" style="z-index: 100"
        width="100%" datamember="PrimaryDAC" tabindex="3700">
        <Template>
        </Template>
    </px:pxformview>
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="false" allowsearch="true" adjustpagesize="None" syncposition="true" datasourceid="ds" skinid="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataMember="EWQCStabilityQC" DataKeyNames="QCStabilityPlanID,QCStabilityID">
                <RowTemplate>
                    <px:PXDateTimeEdit ID="edDueDate" runat="server" TimeMode="false" DataField="DueDate" Width="100%">
                    </px:PXDateTimeEdit>
                    <px:PXDropDown ID="edDueStatus" runat="server" TimeMode="false" DataField="DueStatus" Width="100%">
                    </px:PXDropDown>
                    <px:PXDropDown ID="edQCOrderCreation" runat="server" TimeMode="false" DataField="QCOrderCreation" Width="100%">
                    </px:PXDropDown>
                    <px:PXSelector ID="edInventoryID" runat="server" DataField="InventoryID" Width="100%">
                    </px:PXSelector>
                    <px:PXTextEdit ID="edDesc" runat="server" DataField="ItemDesc" Width="100%">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edLotSerialNbr" runat="server" DataField="LotSerialNbr" Width="100%">
                    </px:PXTextEdit>
                    <px:PXSelector ID="edQCPlanID" runat="server" DataField="QCPlanID">
                    </px:PXSelector>
                    <px:PXTextEdit ID="edLastQCOrder" runat="server" DataField="LastQCOrder" Width="100%">
                    </px:PXTextEdit>
                    <px:PXDateTimeEdit ID="edLastQCDate" runat="server" TimeMode="false" DataField="LastQCDate" Width="100%">
                    </px:PXDateTimeEdit>
                     <px:PXNumberEdit ID="edQCExecuted" runat="server" TimeMode="false" DataField="QCExecuted" Width="100%">
                    </px:PXNumberEdit>
                    <px:PXTextEdit ID="edRemark" runat="server" DataField="Remark" Width="100%">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="DueDate" Width="150px" />
                    <px:PXGridColumn DataField="DueStatus" Width="150px" />
                    <px:PXGridColumn DataField="QCOrderCreation" Width="150px" />
                    <px:PXGridColumn DataField="InventoryID" LinkCommand="gotoStabilityQCInventory" Width="150px" />
                    <px:PXGridColumn DataField="ItemDesc" Width="150px" />
                    <px:PXGridColumn DataField="LotSerialNbr" Width="150px" />
                    <px:PXGridColumn DataField="QCPlanID" LinkCommand="EWQCViewPlanMaster" Width="150px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="LastQCOrder" LinkCommand="gotoStabilityQCOrders" Width="150px" />
                    <px:PXGridColumn DataField="LastQCDate" Width="150px" />
                    <px:PXGridColumn DataField="QCExecuted" Width="150px" />
                    <px:PXGridColumn DataField="Remark" Width="150px" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>

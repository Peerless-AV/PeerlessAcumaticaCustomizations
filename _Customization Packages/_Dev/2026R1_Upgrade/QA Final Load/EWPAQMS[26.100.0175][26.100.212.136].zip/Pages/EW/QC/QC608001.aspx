﻿<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC608001.aspx.cs" Inherits="Page_QC608001" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="FilterWizard" TypeName="EW.QC.EWQCVendorPerformanceReportMaint">
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="FilterWizard" Style="z-index: 100"
        Width="100%" BPEventsIndicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" />
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXDropDown ID="edTimePeriod" runat="server" DataField="TimePeriod" CommitChanges="True">
            </px:PXDropDown>
            <px:PXSelector ID="edVendorID" runat="server" DataField="VendorID" CommitChanges="True">
            </px:PXSelector>
            <px:PXSelector ID="edInventoryID" runat="server" AutoRefresh="true" DataField="InventoryID" CommitChanges="True">
            </px:PXSelector>
            <px:PXCheckBox ID="edIncTranDtl" runat="server" AlreadyLocalized="False" DataField="IncTranDtl" Text="Check" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXCheckBox ID="edVenGenInfo" runat="server" AlreadyLocalized="False" DataField="VenGenInfo" Text="Check" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXCheckBox ID="edRatCriNdWigt" Style="margin-bottom: 20%;" runat="server" AlreadyLocalized="False" DataField="RatCriNdWigt" Text="Check" CommitChanges="true">
            </px:PXCheckBox>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edYear" runat="server" AutoRefresh="true" DataField="Year" CommitChanges="True">
            </px:PXSelector>
            <px:PXDateTimeEdit ID="edDateFrom" runat="server" AlreadyLocalized="False" DataField="DateFrom" CommitChanges="True">
            </px:PXDateTimeEdit>
            <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="XM">
            </px:PXLayoutRule>
            <px:PXSelector ID="edMonth" runat="server" AutoRefresh="true" DataField="Month" CommitChanges="True">
            </px:PXSelector>
            <px:PXDropDown ID="edQuarter" runat="server" AutoRefresh="true" DataField="Quarter" CommitChanges="True">
            </px:PXDropDown>
            <px:PXDateTimeEdit ID="edDateTo" runat="server" AlreadyLocalized="False" DataField="DateTo" CommitChanges="True">
            </px:PXDateTimeEdit>

        </Template>
    </px:PXFormView>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="QC501011.aspx.cs" Inherits="Page_QC501011" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">

    <px:pxdatasource id="ds" enableattributes="False" runat="server" typename="EW.QC.EWQCOrderAssignToProcess" primaryview="OrderSampling" visible="True" width="100%">
        <CallbackCommands>
            <px:PXDSCallbackCommand Visible="false" CommitChanges="true"
                Name="ViewOrder" DependOnGrid="grid">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="GotoSteps" Visible="False" DependOnGrid="grid" />
        </CallbackCommands>
    </px:pxdatasource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:pxformview id="form" runat="server" datamember="Filter" datasourceid="ds" style="z-index: 100"
        width="100%" bpeventsindicator="True">
        <Template>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edOrderCD" runat="server" DataField="QCOrderCD" CommitChanges="True">
            </px:PXSelector>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXLabel ID="edAssignGrp" runat="server" Text="Select Assign To User"></px:PXLabel>
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True" />
            <px:PXSelector ID="edAssignTo" runat="server" DataField="AssignedToID" CommitChanges="True">
                 <GridProperties FastFilterFields="AcctCD,AcctName" ></GridProperties>
            </px:PXSelector>
        </Template>
    </px:pxformview>

    <px:pxsmartpanel id="pnlTestSteps" runat="server" height="500px" width="1100px" caption="Test Steps" captionvisible="true" autoreload="true" loadondemand="true" key="TestSteps" style="position: static"
        autocallback-target="StepsGrid" autocallback-command="Refresh" designview="Content">

        <px:PXGrid ID="StepsGrid" runat="server" DataSourceID="ds" SkinID="Inquire"
            Width="100%">
            <Levels>
                <px:PXGridLevel DataMember="TestSteps">
                    <Columns>
                        <px:PXGridColumn DataField="Name">
                        </px:PXGridColumn>
                        <px:PXGridColumn DataField="Description">
                        </px:PXGridColumn>
                    </Columns>
                </px:PXGridLevel>
            </Levels>
        </px:PXGrid>
        <px:PXPanel ID="PXPanel7" runat="server" SkinID="Buttons">
            <px:PXButton ID="PXButton9" runat="server" DialogResult="OK" Text="OK"></px:PXButton>
        </px:PXPanel>
    </px:pxsmartpanel>

</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
    <px:pxgrid id="grid" runat="server" height="400px" width="100%" style="z-index: 100"
        allowpaging="True" allowsearch="true" syncposition="true" adjustpagesize="Auto" datasourceid="ds" skinid="PrimaryInquire">
        <Levels>
            <px:PXGridLevel DataKeyNames="QCOrderSamplingDetailID,EWQCOrder__QCOrderCD" DataMember="OrderSampling">
                <RowTemplate>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="Selected" AllowCheckAll="true" CommitChanges="true" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrder__QCOrderCD" LinkCommand="ViewOrder" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="SamplingSerailNum" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderLotDetail__LotSerNumVal" Width="120px">
                    </px:PXGridColumn>

                    <px:PXGridColumn DataField="EWQCVariable__VariableCD" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Steps" Width="180px" LinkCommand="GotoSteps">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__Description" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCVariable__DataType" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCTestCategory__Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCTestMethod__Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCToolGauge__ToolGaugeCD" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCSeverityLevel__Name" Width="180px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="AssignedToID" Width="140px">
                    </px:PXGridColumn>

                    <%-- <px:PXGridColumn DataField="EWQCVariable__Unit" Width="180px">
                    </px:PXGridColumn>

                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__NumTargetValue" TextAlign="Right" Width="100px">
                    </px:PXGridColumn>

                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__AlphaValue" Width="280px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__BitPassFail" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__BitGoNoGo" TextAlign="Center" Type="CheckBox" Width="60px">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__Tested" TextAlign="Center" Type="CheckBox" Width="60px" CommitChanges="true">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__ActualResult">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__FinalResult">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="EWQCOrderSamplingDetail__Remarks" Width="280px">
                    </px:PXGridColumn>--%>
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Container="Window" Enabled="True" MinHeight="200" />
    </px:pxgrid>
</asp:Content>

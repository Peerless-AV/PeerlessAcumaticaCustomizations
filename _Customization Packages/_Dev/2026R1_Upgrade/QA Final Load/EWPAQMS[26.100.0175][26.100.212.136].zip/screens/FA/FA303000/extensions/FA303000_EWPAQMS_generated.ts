import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
  createCollection,
  PXActionState,
  actionConfig
} from "client-controls";
import { FA303000 } from "src/screens/FA/FA303000/FA303000";
import { FixedAsset } from "src/screens/FA/FA303000/views";
 
export interface FA303000_EWPAQMS_generated extends FA303000 {}
export class FA303000_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Asset Detail(EWQCGlobalPlanDetail)" })
  EWQCGlobalPlanDetail = createCollection(EWQCAssetDetail);
 
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Asset Variable(EWQCAssetVariables)" })
  EWQCAssetVariables = createCollection(EWQCAssetVariable);
 
  @gridConfig({ preset: GridPreset.ReadOnly  })
  @viewInfo({ containerName: "Event(EWQCEventHistory)" })
  EWQCEventHistory = createCollection(EWQCEvent);
 
  @gridConfig({ preset: GridPreset.ReadOnly })
  EWQCComboSaveButton : PXActionState;
  @viewInfo({ containerName: "Test Combo Values(EWQCTestComboValues)" })
  EWQCTestComboValues = createCollection(EWQCTestComboValues);
 
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Plan Test Tool(EWQCToolSteps)" })
  EWQCToolSteps = createCollection(EWQCPlanTestTool);
}
 
export interface FixedAsset_EWPAQMS_generated extends FixedAsset {}
export class FixedAsset_EWPAQMS_generated {
  UsrEWQCIsQCRequired:  PXFieldState<PXFieldOptions.CommitChanges>;
}
 
 
@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  initNewRow: true,
  autoRepaint: ["EWQCAssetVariables"],
})
 
export class EWQCAssetDetail extends PXView {
 @linkCommand("EWQCViewPlanMaster")
  @columnConfig({width: 180, editorConfig : {displayMode:"text",fastFilterFields:["PlanCD","Name","RevisionNo"]}}) PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 70})  EWQCPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 70})  ResultCriteria : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 100}) NSQC : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 150}) IntervalBy : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 150}) Interval : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 200}) StartDate : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 200}) EndDate : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 200}) NotificationDays : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 100}) LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.Details,
    repaintColumns: true,
  
})
 
export class EWQCAssetVariable extends PXView {
  AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
 @linkCommand("EWQCViewTestMaster")
  VariableID: PXFieldState<PXFieldOptions.CommitChanges>;
 
  EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCGotoToolSteps")
  ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;
 
  TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
 
  SeverityLevel: PXFieldState<PXFieldOptions.CommitChanges>;
 
  EWQCVariable__Description: PXFieldState<PXFieldOptions.CommitChanges>;
 
  EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;
 
  EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;
 
  EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
 
  UOM: PXFieldState<PXFieldOptions.CommitChanges>;
 
  CalculationType: PXFieldState<PXFieldOptions.CommitChanges>;
 
  QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;
 
  NumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;
 
  NumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;
 
  TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;
 
  BitGoNoGo: PXFieldState<PXFieldOptions.CommitChanges>;
 
  AlphaValue: PXFieldState<PXFieldOptions.CommitChanges>;
 
  EWQCVariable__Equation: PXFieldState<PXFieldOptions.CommitChanges>;
 
  OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;
 
  OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;
 
  LeadTimeDurationType: PXFieldState<PXFieldOptions.CommitChanges>;
 
  LeadTimeDuration: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCAddCombo")
  ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;
 
 
}
 
 
 
export class EWQCEvent extends PXView {
  @columnConfig({width: 180, format: "g"})  CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 180}) Description : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 180}) EventType : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 180}) CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}
 
@gridConfig({
  allowDelete : false,
  allowInsert: false,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
  autoAdjustColumns:true,
})
 
export class EWQCTestComboValues extends PXView {  
  
  TestComboCD : PXFieldState<PXFieldOptions.CommitChanges>;
  Description : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 120}) ComboCheck : PXFieldState<PXFieldOptions.CommitChanges>;
}
 
@gridConfig({
  syncPosition: true,
  allowDelete : false,
  allowInsert: false,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
 
})
 
export class EWQCPlanTestTool extends PXView {
  ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
  Description : PXFieldState<PXFieldOptions.CommitChanges>;
}
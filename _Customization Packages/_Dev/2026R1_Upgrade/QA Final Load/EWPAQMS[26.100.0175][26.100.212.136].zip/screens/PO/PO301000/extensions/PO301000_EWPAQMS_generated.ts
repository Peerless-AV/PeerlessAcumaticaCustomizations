import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
    createCollection,
    PXActionState,
} from "client-controls";
import { PO301000,POLine } from "src/screens/PO/PO301000/PO301000";

export interface PO301000_EWPAQMS_generated extends PO301000 {}
export class PO301000_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Vendor Certificate(EWQCvendorcertificate)" })
    EWQCvendorcertificate = createCollection(EWQCVendorCertificate);

    EWQCOKVendor: PXActionState;
    @viewInfo({ containerName: "View Vendor Rating(EWQCVendorRating)" })
    EWQCVendorRating = createCollection(EWQCEvaluateVendorPerformanceDetail);
}

export interface POLine_EWPAQMS_generated extends POLine { }



export class POLine_EWPAQMS_generated {

    EWQCCheckVendor: PXActionState;
    @placeAfterProperty("InventoryID")
    UsrEWQCRank: PXFieldState<PXFieldOptions.CommitChanges>; 
    @placeAfterProperty("InventoryID")
    UsrEWQCVendorScore: PXFieldState<PXFieldOptions.CommitChanges>; 
  
  
}

export class EWQCVendorCertificate extends PXView {
  CertificateCD:  PXFieldState<PXFieldOptions.CommitChanges>;

  EffectiveFromDate:  PXFieldState<PXFieldOptions.CommitChanges>;

  EffectiveToDate:  PXFieldState<PXFieldOptions.CommitChanges>;
}


@gridConfig({
    autoAdjustColumns: true,
    showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.ReadOnly
})
export class EWQCEvaluateVendorPerformanceDetail extends PXView {
    
    Selected: PXFieldState;
    @columnConfig({ hideViewLink: true }) BAccount__AcctCD: PXFieldState;
    BAccount__AcctName: PXFieldState;
    NewScore: PXFieldState;
    NewRank: PXFieldState;
    TimePeriod: PXFieldState;
}

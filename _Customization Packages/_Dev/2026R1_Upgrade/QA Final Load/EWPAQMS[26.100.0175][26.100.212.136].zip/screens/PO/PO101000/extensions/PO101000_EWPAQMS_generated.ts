import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode
} from "client-controls";
import { PO101000, POSetup } from "src/screens/PO/PO101000/PO101000";

export interface PO101000_EWPAQMS_generated extends PO101000 {}
export class PO101000_EWPAQMS_generated {}

export interface POSetup_EWPAQMS_generated extends POSetup {}
export class POSetup_EWPAQMS_generated {
  UsrEWQCCertificationLevel:  PXFieldState<PXFieldOptions.CommitChanges>;

  UsrEWQCPurchaseforExpiredcertificate:  PXFieldState<PXFieldOptions.CommitChanges>;

  UsrEWQCPurchaseReceiptforExpiredcertificate:  PXFieldState<PXFieldOptions.CommitChanges>;

  UsrEWQCBillsforExpiredcertificate:  PXFieldState<PXFieldOptions.CommitChanges>;
  
  UsrEWQCPOqtyisgreaterthansamplinglotrange:  PXFieldState<PXFieldOptions.CommitChanges>;
}

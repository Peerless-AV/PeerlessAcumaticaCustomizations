import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
  createCollection
} from "client-controls";
import {
  PO302000,
  POReceiptHeader,
  POReceiptLine
} from "src/screens/PO/PO302000/PO302000";

export interface PO302000_EWPAQMS_generated extends PO302000 {}
export class PO302000_EWPAQMS_generated {

  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Vendor Certificate(EWQCvendorcertificate)" })
  EWQCvendorcertificate = createCollection(EWQCVendorCertificate);

}

export interface POReceiptHeader_EWPAQMS_generated extends POReceiptHeader {}
export class POReceiptHeader_EWPAQMS_generated {
 @linkCommand("EWQCViewInspectionOrder")
  UsrEWQCInspectionOrderNumber: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface POReceiptLine_EWPAQMS_generated extends POReceiptLine {}
export class POReceiptLine_EWPAQMS_generated {

   

  @linkCommand("EWQCViewInspectionOrder")
  @placeAfterProperty("ReceiptQty")
  UsrEWQCInspectionOrderNumber: PXFieldState<PXFieldOptions.CommitChanges>; 
  @placeAfterProperty("ReceiptQty")
  UsrEWQCRequired: PXFieldState<PXFieldOptions.CommitChanges>; 
  @placeAfterProperty("ReceiptQty")
  @linkCommand("EWQCViewQCOrder")
  UsrEWQCOrderNumber:PXFieldState<PXFieldOptions.CommitChanges>; 
  @placeAfterProperty("ReceiptQty")
  UsrEWQCSiteID: PXFieldState<PXFieldOptions.CommitChanges>; 
  @placeAfterProperty("ReceiptQty")
  UsrEWQCLocationID: PXFieldState<PXFieldOptions.CommitChanges>; 
  
}
@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly
})
export class EWQCVendorCertificate extends PXView {
  CertificateCD:  PXFieldState<PXFieldOptions.CommitChanges>;

  EffectiveFromDate:  PXFieldState<PXFieldOptions.CommitChanges>;

  EffectiveToDate:  PXFieldState<PXFieldOptions.CommitChanges>;
}

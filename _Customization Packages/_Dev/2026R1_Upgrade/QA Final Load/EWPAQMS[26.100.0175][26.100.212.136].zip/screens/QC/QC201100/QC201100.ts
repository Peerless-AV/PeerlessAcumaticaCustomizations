import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import {
	EWQCSamplingPlan, EWQCSamplingPlanDetail, EWQCStandardAQLLvlone, EWQCStandardAQLLvlTwo, EWQCStandardAQLLvlThree
	, EWQCStandardAQLSPLvlone, EWQCStandardAQLSPLvlTwo, EWQCStandardAQLSPLvlThree, EWQCStandardAQLSPLvlFour, EWQCEvent
} from "./views";

@graphInfo({ graphType: "EW.QC.EWQCSamplingPlanMaint", primaryView: "Documents", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true })
export class QC201100 extends PXScreen {

	Documents = createSingle(EWQCSamplingPlan);
	@viewInfo({ containerName: "Manual" })
	SamplingPlanDetails = createCollection(EWQCSamplingPlanDetail);
	@viewInfo({ containerName: "General Insp Lvl - I" })
	StandardAQLLvlone = createCollection(EWQCStandardAQLLvlone);
	@viewInfo({ containerName: "General Insp Lvl - II" })
	StandardAQLLvlTwo = createCollection(EWQCStandardAQLLvlTwo);
	@viewInfo({ containerName: "General Insp Lvl - III" })
	StandardAQLLvlThree = createCollection(EWQCStandardAQLLvlThree);
	@viewInfo({ containerName: "Special Insp Lvl - S1" })
	StandardAQLSPLvlone = createCollection(EWQCStandardAQLSPLvlone);
	@viewInfo({ containerName: "Special Insp Lvl - S2" })
	StandardAQLSPLvlTwo = createCollection(EWQCStandardAQLSPLvlTwo);
	@viewInfo({ containerName: "Special Insp Lvl - S3" })
	StandardAQLSPLvlThree = createCollection(EWQCStandardAQLSPLvlThree);
	@viewInfo({ containerName: "Special Insp Lvl - S4" })
	StandardAQLSPLvlFour = createCollection(EWQCStandardAQLSPLvlFour);
	@viewInfo({ containerName: "Event History" })
	EventHistory = createCollection(EWQCEvent);
}
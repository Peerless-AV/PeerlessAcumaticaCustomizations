import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC201100 } from "./QC201100";


// Views

export class EWQCSamplingPlan extends PXView {

	@controlConfig<ISelectorControlConfig>({ fastFilterFields: ["RevisionNo", "Name"] })
	SamplingPlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Name: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ rows: 4 })
	Remarks: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({ fastFilterFields: ["Name", "Description"] })
	RevisionNo: PXFieldState<PXFieldOptions.Multiline>;
	EffectiveFromDate: PXFieldState<PXFieldOptions.CommitChanges>;
	EffectiveToDate: PXFieldState<PXFieldOptions.CommitChanges>;
	Hold: PXFieldState<PXFieldOptions.CommitChanges>;
	Status: PXFieldState<PXFieldOptions.Disabled>;
	SamplingMethodType: PXFieldState<PXFieldOptions.CommitChanges>;
	AQLInspectionLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	SelectSerializedSample: PXFieldState<PXFieldOptions.CommitChanges>;
	SamplingSize: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({
		editorType: "qp-formula-editor"
	})
	Equation: PXFieldState<PXFieldOptions.CommitChanges>;
	QtyUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	SampleUOM: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCSamplingPlanDetail extends PXView {

	@columnConfig({ width: 100 }) QuantityFrom: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, hideViewLink: true }) UnitQuantityFrom: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) isabove: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, hideViewLink: true }) UnitQuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NoOfSamples: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) SampleSize: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, hideViewLink: true }) UnitNoOfSamples: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}


gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStandardAQLLvlone extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LevelOneSamples: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details

})
export class EWQCStandardAQLLvlTwo extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NoOfSample: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStandardAQLLvlThree extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LevelThreeSamples: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStandardAQLSPLvlone extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LevelS1Samples: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStandardAQLSPLvlTwo extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LevelS2Samples: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStandardAQLSPLvlThree extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LevelS3Samples: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStandardAQLSPLvlFour extends PXView {

	@columnConfig({ width: 100 }) QuantityForm: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QuantityTo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LevelS4Samples: PXFieldState<PXFieldOptions.CommitChanges>;

}


@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView {

	@columnConfig({ format: "g" }) CreatedDateTime: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	EventType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 130 }) CreatedByID: PXFieldState<PXFieldOptions.CommitChanges>;
}
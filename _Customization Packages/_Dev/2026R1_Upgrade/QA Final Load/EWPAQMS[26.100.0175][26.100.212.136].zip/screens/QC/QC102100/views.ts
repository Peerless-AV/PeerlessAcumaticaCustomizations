import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC102100 } from "./QC102100";


// Views

export class EWQCSetup extends PXView  {

	@controlConfig({allowEdit:true})
	QCTnCNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCTnCMaintNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	TnCValidationType : PXFieldState<PXFieldOptions.CommitChanges>;
	TnCMaintValidationType : PXFieldState<PXFieldOptions.CommitChanges>;
}
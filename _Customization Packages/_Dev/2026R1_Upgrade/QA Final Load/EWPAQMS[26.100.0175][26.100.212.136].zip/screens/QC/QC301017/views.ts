import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301017 } from "./QC301017";

export class EWQCOrderLotDistributionDetailType {
	BaseUOM : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCOrder extends PXView  {

	QCOrderCD : PXFieldState<PXFieldOptions.Disabled>;
	QCType : PXFieldState<PXFieldOptions.Disabled>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	ClosingDateTime: PXFieldState<PXFieldOptions.Disabled>;
	PlanID: PXFieldState<PXFieldOptions.Disabled>;
	SamplingPlanID: PXFieldState<PXFieldOptions.Disabled>;
	TranDescription: PXFieldState<PXFieldOptions.CommitChanges>;
	TranType : PXFieldState<PXFieldOptions.Disabled>;
}

export class InventoryItem extends PXView  {

	InventoryCD : PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderLotDetail extends PXView  {

	@columnConfig({width: 180})	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	TestQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	BaseUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	AcceptedQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	RejectedQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	RejectionCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ScappedQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ScrapCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	DestructiveQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	addLineDetails: {index: 0, config: {commandName: "addLineDetails", text: "Line Detail"}},
}
})
export class EWQCOrderLotDistributionDetail extends PXView  {

	addLineDetails : PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	EWQCOrderLotDetail : EWQCOrderLotDistributionDetailType;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	addLineDetails: {index: 0, config: {commandName: "addLineDetails", text: "Line Detail"}},
}
})
export class EWQCOrderLotDistributionDetail2 extends PXView  {

	addLineDetails : PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	EWQCOrderLotDetail : EWQCOrderLotDistributionDetailType;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	addLineDetails: {index: 0, config: {commandName: "addLineDetails", text: "Line Detail"}},
}
})
export class EWQCOrderLotDistributionDetail3 extends PXView  {

	addLineDetails : PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	EWQCOrderLotDetail : EWQCOrderLotDistributionDetailType;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	addLineDetails: {index: 0, config: {commandName: "addLineDetails", text: "Line Detail"}},
}
})
export class EWQCOrderLotDistributionDetail4 extends PXView  {

	addLineDetails : PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	EWQCOrderLotDetail : EWQCOrderLotDistributionDetailType;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderLotSerialDistributionDetail extends PXView  {

	SerialNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})	itemcheck : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})	itemcheckrejected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})	itemcheckscrapped : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})	itemcheckdestructive : PXFieldState<PXFieldOptions.CommitChanges>;
}
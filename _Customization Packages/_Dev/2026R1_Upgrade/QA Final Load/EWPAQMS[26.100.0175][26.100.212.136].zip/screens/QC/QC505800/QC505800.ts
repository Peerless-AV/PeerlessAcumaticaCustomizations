import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCLotStatusFilter, INLotSerialStatusByCostCenter } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInventoryLotStatusProcess", primaryView: "Filter", bpEventsIndicator: true})
export class QC505800 extends PXScreen {

	Filter = createSingle(EWQCLotStatusFilter);
	EWQCLotStatus = createCollection(INLotSerialStatusByCostCenter);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505800 } from "./QC505800";

export class INLotSerialStatusByCostCenterType {
	descr : PXFieldState<PXFieldOptions.CommitChanges>;	
	StatusID : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCLotStatusFilter extends PXView  {

	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class INLotSerialStatusByCostCenter extends PXView  {

	@columnConfig({ width: 60, allowCheckAll: true }) Selected: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150, editorConfig: { allowEdit: true } }) InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 200 }) InventoryItem__descr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, editorConfig: { allowEdit: true } }) WarehouseID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, editorConfig: { allowEdit: true } }) LocationID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 90 }) Qty: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, editorConfig: {} }) StatusID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QCOrderCD: PXFieldState;
	@columnConfig({ width: 100 }) NewQty: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, editorConfig: {} }) NewStatusID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 200 }) NewReason: PXFieldState<PXFieldOptions.CommitChanges>;
}
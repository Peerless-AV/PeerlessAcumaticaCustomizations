import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505000 } from "./QC505000";


// Views

export class EWQCNonStock extends PXView  {

	ItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	NSItemID : PXFieldState<PXFieldOptions.CommitChanges>;
	ToolsID : PXFieldState<PXFieldOptions.CommitChanges>;
	MachineID : PXFieldState<PXFieldOptions.CommitChanges>;
	FixedAssetsID : PXFieldState<PXFieldOptions.CommitChanges>;
	NSItemPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	ToolsPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	MachinePlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	FixedAssetsPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	PlanDescription : PXFieldState<PXFieldOptions.Disabled>;
}
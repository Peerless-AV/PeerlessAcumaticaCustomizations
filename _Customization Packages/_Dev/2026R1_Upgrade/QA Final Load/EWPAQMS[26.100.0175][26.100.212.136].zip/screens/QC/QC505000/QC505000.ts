import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCNonStock } from "./views";

@graphInfo({graphType: "EW.QC.EWQCNonStockMaint", primaryView: "NonStockView", showUDFIndicator: true})
export class QC505000 extends PXScreen {

	NonStockView = createSingle(EWQCNonStock);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter ,CellCssHandlerArgs} from "client-controls";
import { EWQCNCTran, EWQCOrderSamplingDetail, EWQCTestDetailNS, EWQCNCTranRootCause, EWQCNCCAPADetail, EWQCNCTranAction, EWQCEvent, EWQCNCTranRootCause2, EWQCNCTranAction2 } from "./views";

@graphInfo({graphType: "EW.QC.EWQCNCTranEntry", primaryView: "NCTran", bpEventsIndicator: true, pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC305100 extends PXScreen {
	OnClickAddCapa: PXActionState;

	NCTran = createSingle(EWQCNCTran);
   	@viewInfo({containerName: "NC Details"})
	QCOrderSamplingDetails = createCollection(EWQCOrderSamplingDetail);
   	@viewInfo({containerName: "NC Details"})
	QCOrderTestDetailNS = createCollection(EWQCTestDetailNS);
   	@viewInfo({containerName: "Root Cause Analysis"})
	NCTranRootCauseAnalysis = createCollection(EWQCNCTranRootCause);
   	@viewInfo({containerName: "RC Analysis"})
	NCTranCapaDetail = createCollection(EWQCNCCAPADetail);
   	@viewInfo({containerName: "Action Taken"})
	NCTranAction = createCollection(EWQCNCTranAction);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "Root Cause Analysis"})
	RootCauseSmartPanel = createSingle(EWQCNCTranRootCause2);
   	@viewInfo({containerName: "Action Taken"})
	ActionTakenSmartPanel = createSingle(EWQCNCTranAction2);

		@handleEvent(CustomEventType.GetCellCss, { view: "QCOrderSamplingDetails", column: "ActualResult" })
		getEWQCOrderSamplingDetailActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderSamplingDetail>>) {
			const row = args?.selector?.row;
			if (row?.ActualResult.value === "F")
				return "FailTest";
			else if (row?.ActualResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
	
		@handleEvent(CustomEventType.GetCellCss, { view: "QCOrderSamplingDetails", column: "FinalResult" })
		getEWQCOrderSamplingDetailFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderSamplingDetail>>) {
			const row = args?.selector?.row;
			if (row?.FinalResult.value === "F")
				return "FailTest";
			else if (row?.FinalResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
		@handleEvent(CustomEventType.GetCellCss, { view: "QCOrderTestDetailNS", column: "ActualResult" })
		getQCOrderTestDetailNSActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCTestDetailNS>>) {
			const row = args?.selector?.row;
			if (row?.ActualResult.value === "F")
				return "FailTest";
			else if (row?.ActualResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
	
		@handleEvent(CustomEventType.GetCellCss, { view: "QCOrderTestDetailNS", column: "FinalResult" })
		getQCOrderTestDetailNSFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCTestDetailNS>>) {
			const row = args?.selector?.row;
			if (row?.FinalResult.value === "F")
				return "FailTest";
			else if (row?.FinalResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
}
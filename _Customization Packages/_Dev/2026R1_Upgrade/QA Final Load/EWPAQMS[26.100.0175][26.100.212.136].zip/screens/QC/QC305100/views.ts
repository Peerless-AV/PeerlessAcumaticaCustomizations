import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC305100 } from "./QC305100";

export class EWQCOrderSamplingDetailType {
	VariableCD :PXFieldState<PXFieldOptions.CommitChanges>;	
	Name :PXFieldState<PXFieldOptions.CommitChanges>;	
	Description :PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType :PXFieldState<PXFieldOptions.CommitChanges>;	
	ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Unit :PXFieldState<PXFieldOptions.CommitChanges>;	
	LeadTimeDurationType :PXFieldState<PXFieldOptions.CommitChanges>;	
	LeadTimeDuration :PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCTestDetailNSType {
	VariableCD :PXFieldState<PXFieldOptions.CommitChanges>;	
	Name :PXFieldState<PXFieldOptions.CommitChanges>;	
	Description :PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType :PXFieldState<PXFieldOptions.CommitChanges>;	
	ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Unit :PXFieldState<PXFieldOptions.CommitChanges>;	
	LeadTimeDurationType :PXFieldState<PXFieldOptions.CommitChanges>;	
	LeadTimeDuration :PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCNCCAPADetailType {
	CapaTranCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCNCTran extends PXView  {

	@actionConfig({ popupCommand: "OK" })
	addEditRootCauseOK: PXActionState;

	@actionConfig({ popupCommand: "OK" })
	addEditActionTakenOK: PXActionState;

	NCTranCD : PXFieldState<PXFieldOptions.CommitChanges>;
	NCDate :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ allowEdit: true, linkCommand: "EdQCOrderNumbers" })
	QCOrderNo : PXFieldState<PXFieldOptions.CommitChanges>;
	NonStockQCOrderNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	Summary : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({displayMode:"text",fastFilterFields:["AcctCD","AcctName"]})
	RepotedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({displayMode:"text",fastFilterFields:["AcctCD","AcctName"]})
	Owner : PXFieldState<PXFieldOptions.CommitChanges>;
	Source : PXFieldState<PXFieldOptions.Disabled>;
	NCType :PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	Priority : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ allowEdit: true, linkCommand: "RefDocNumbers" })
	RefDocNumber : PXFieldState<PXFieldOptions.Disabled>;
	@fieldConfig({
  controlType: "qp-radio",
  controlConfig: {
    class: "vertical"
  }
})
	ItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["DepartmentID","Description"]})
	Department :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	Category :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	EmployeeID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	CustomerID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	ToolsID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	MachineID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	FixedAssetsID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	NSItemID : PXFieldState<PXFieldOptions.CommitChanges>;
	VendorLotNumber :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true,displayMode:"id"})
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	ExpiryDate :PXFieldState<PXFieldOptions.CommitChanges>;
	Description :PXFieldState<PXFieldOptions.CommitChanges>;
	IsDetailProcessed : PXFieldState<PXFieldOptions.CommitChanges>;
	IsRCCompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	RCCompletedDate :PXFieldState<PXFieldOptions.CommitChanges>;
	RCCompletedBy :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	UnboundCAPAId : PXFieldState<PXFieldOptions.CommitChanges>;
	ActionCompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	ActionCompletedDate :PXFieldState<PXFieldOptions.CommitChanges>;
	ActionCompletedBy :PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderSamplingDetail extends PXView  {

	@columnConfig({width: 180})	SamplingSerailNum  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__Name  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})Steps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__Description  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__DataType  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCTestCategory__Name  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCTestMethod__Name  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCToolGauge__ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCSeverityLevel__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({width: 220})AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})ExpectedValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})DestructiveTesting : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__Unit : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})TestValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})FinalResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})Remarks: PXFieldState<PXFieldOptions.CommitChanges>;
	
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestDetailNS extends PXView  {

	
	@columnConfig({width: 180})	SamplingSerailNum  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__Name  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})Steps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__Description  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__DataType  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCTestCategory__Name  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCTestMethod__Name  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCToolGauge__ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCSeverityLevel__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({width: 220})AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})ExpectedValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})DestructiveTesting : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__Unit : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})TestValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})FinalResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})EWQCVariable__LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})Remarks: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowInsert: false,
	topBarItems: {
	AddNewRootAnalysis: {index: 0, config: {commandName: "AddNewRootAnalysis", text: "ADD"}},
}
})
export class EWQCNCTranRootCause extends PXView  {

	AddNewRootAnalysis : PXActionState;
	@columnConfig({width: 0})	LineNbr :PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCNCTranRootCauseEdit")
	View : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {}})	RootCauseId : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	UnformattedDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewRCPerformedBy")
	@columnConfig({editorConfig : {displayMode:"text"}})	AnalysisPerformedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	AnalysisPerformedOn :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({format: "g"})	CreatedDateTime :PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowDelete:true,
	allowInsert:false,

})
export class EWQCNCCAPADetail extends PXView  {

	@linkCommand("capaNbr")
	@columnConfig({width: 70})	EWQCNCCapaTran : EWQCNCCAPADetailType;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowInsert: false,
	topBarItems: {
	AddNewActionTaken: {index: 0, config: {commandName: "AddNewActionTaken", text: "ADD"}},
}
})
export class EWQCNCTranAction extends PXView  {

	AddNewActionTaken : PXActionState;
	@columnConfig({width: 0})	LineNbr :PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EditActionTaken")
	View : PXFieldState<PXFieldOptions.CommitChanges>;
	UnformattedDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewActionPerformedBy")
	@columnConfig({editorConfig : {allowEdit:true,displayMode:"text"}})	ActionPerformedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	ActionPerformedOn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({format: "g"})	CreatedDateTime :PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime :PXFieldState<PXFieldOptions.CommitChanges>;
	Description :PXFieldState<PXFieldOptions.CommitChanges>;
	EventType :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID :PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("capaNumbers")
	@columnConfig({width: 108})	AbsoluteRefNbr :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	RefDocType :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	ActionBy :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	LineNumber :PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCTranRootCause2 extends PXView  {

	RootcauseId : PXFieldState<PXFieldOptions.CommitChanges>;
	Description :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	AnalysisPerformedBy :PXFieldState<PXFieldOptions.CommitChanges>;
	AnalysisPerformedOn :PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCTranAction2 extends PXView  {

	Description :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	ActionPerformedBy :PXFieldState<PXFieldOptions.CommitChanges>;
	ActionPerformedOn :PXFieldState<PXFieldOptions.CommitChanges>;
}
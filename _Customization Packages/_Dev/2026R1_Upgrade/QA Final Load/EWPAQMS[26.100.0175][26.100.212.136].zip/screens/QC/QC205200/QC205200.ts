import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCNCRootCause } from "./views";

@graphInfo({graphType: "EW.QC.EWQCNCRootCauseMaint", primaryView: "NCRootCauses", })
export class QC205200 extends PXScreen {

	NCRootCauses = createCollection(EWQCNCRootCause);
}
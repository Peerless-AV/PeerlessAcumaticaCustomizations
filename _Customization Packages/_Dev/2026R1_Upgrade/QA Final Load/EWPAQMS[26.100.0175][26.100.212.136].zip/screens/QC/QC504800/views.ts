import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC504800 } from "./QC504800";

export class EWQCProductionOrderSplitLotDetailsType {
	OperationCD: PXFieldState<PXFieldOptions.CommitChanges>;
}

// Views

export class AMProdItem extends PXView {

	OrderType: PXFieldState<PXFieldOptions.CommitChanges>;
	ProdOrdID: PXFieldState<PXFieldOptions.CommitChanges>;
	ProdDate: PXFieldState<PXFieldOptions.Disabled>;
	InventoryID: PXFieldState<PXFieldOptions.Disabled>;
	SubItemID: PXFieldState<PXFieldOptions.Disabled>;
	SiteId: PXFieldState<PXFieldOptions.Disabled>;
}
@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCProductionOrderSplitLotDetails extends PXView {

	@columnConfig({ width: 60, allowCheckAll: true }) OrderSelected: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) QCLotSerialNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) AMProdOper__OperationCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) OrderQCQty: PXFieldState<PXFieldOptions.CommitChanges>;
}
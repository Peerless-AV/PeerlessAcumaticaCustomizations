import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401067 } from "./QC401067";


// Views


export class EWQCServQC extends PXView  {

	ServItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	EquipmentId : PXFieldState<PXFieldOptions.CommitChanges>;
}
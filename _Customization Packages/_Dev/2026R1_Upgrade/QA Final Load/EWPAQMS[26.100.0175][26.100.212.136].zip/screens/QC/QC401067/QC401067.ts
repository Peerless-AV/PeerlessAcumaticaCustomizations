import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCServQC } from "./views";

@graphInfo({graphType: "EW.QC.EWQCServOrderNavigationMaint", primaryView: "Documents", bpEventsIndicator: true, pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC401067 extends PXScreen {

	Documents = createSingle(EWQCServQC);
}
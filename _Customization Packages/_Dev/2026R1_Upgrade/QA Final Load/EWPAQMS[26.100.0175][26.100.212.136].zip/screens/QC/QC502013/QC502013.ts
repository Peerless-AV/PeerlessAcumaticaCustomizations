import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCNSUnionData } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderNSDataProcess", primaryView: "OrderNSProcess", })
export class QC502013 extends PXScreen {

	OrderNSProcess = createCollection(EWQCNSUnionData);
}
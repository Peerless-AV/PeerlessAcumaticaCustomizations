import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC502013 } from "./QC502013";


// Views

export class EWQCNSUnionData extends PXView  {

	@columnConfig({allowSort: false, width: 30 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	ItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewArticleID")
	ArticleID : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState;
	@linkCommand("ViewPlanID")
	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	IntervalBy : PXFieldState;
	Interval : PXFieldState;
	@linkCommand("ViewDQCOrder")
	LastQCOrderID : PXFieldState<PXFieldOptions.CommitChanges>;
	QCStatus : PXFieldState;
	DueDate : PXFieldState;
	Status : PXFieldState;
}
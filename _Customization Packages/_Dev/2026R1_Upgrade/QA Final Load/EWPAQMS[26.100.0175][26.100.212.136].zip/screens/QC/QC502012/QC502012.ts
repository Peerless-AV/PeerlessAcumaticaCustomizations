import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCOrderNSFilter, EWQCOrderNSProcessData } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderNSProcess", primaryView: "Filter", bpEventsIndicator: true})
export class QC502012 extends PXScreen {

	Filter = createSingle(EWQCOrderNSFilter);
	OrderNSProcess = createCollection(EWQCOrderNSProcessData);
}
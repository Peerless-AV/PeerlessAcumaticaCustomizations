import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC502012 } from "./QC502012";


// Views

export class EWQCOrderNSFilter extends PXView  {

	ItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	DueDate : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCOrderNSProcessData extends PXView  {

	@columnConfig({allowSort: false, width: 30 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	ItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewArticleID")
	ArticleID : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewPlanID")
	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	IntervalBy : PXFieldState<PXFieldOptions.CommitChanges>;
	Interval : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewDQCOrder")
	LastQCOrderID : PXFieldState<PXFieldOptions.CommitChanges>;
	QCStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	DueDate : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.CommitChanges>;
}
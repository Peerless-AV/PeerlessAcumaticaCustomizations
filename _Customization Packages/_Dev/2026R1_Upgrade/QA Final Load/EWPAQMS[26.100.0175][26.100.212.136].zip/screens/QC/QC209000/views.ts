import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209000 } from "./QC209000";

export class EWQCPlanVariableType {
	Name : PXFieldState;	
	Description : PXFieldState;	
	Equation : PXFieldState;	
	DataType : PXFieldState;	
	TestCategoryID : PXFieldState<PXFieldOptions.CommitChanges>;	
	TestMethodID : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCPlan extends PXView  {
	@actionConfig({ popupCommand: "OK" })
	ComboSaveButton: PXActionState;

	@controlConfig<ISelectorControlConfig>({fastFilterFields:["RevisionNo","Name"]})
	PlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState;
	Description : PXFieldState;
	Remarks : PXFieldState;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	RevisionNo : PXFieldState;
	EffectiveFromDate : PXFieldState;
	EffectiveToDate : PXFieldState;
	Hold : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	ResultCriteriaType : PXFieldState<PXFieldOptions.CommitChanges>;
	DestructiveTesting : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	ResultCriteriaTab : PXFieldState;
}

export class EWQCCopyPlanPanelDAC extends PXView  {

	PlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCPlanVariable extends PXView  {

	@columnConfig({width: 120})	AddInReports : PXFieldState;
	@columnConfig({editorConfig : {allowEdit:true,fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable : EWQCPlanVariableType;
	@columnConfig({ width: 180, editorConfig: { allowEdit: true, fastFilterFields: ["Name", "Description"] } }) TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
	AttributeID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddQCTool")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewSeverityMaster")
	@columnConfig({editorConfig : {allowEdit:true,fastFilterFields:["Name","Description"]}})	SeverityLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	CalculationType : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOperator : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})	TestResultUOM : PXFieldState;
	@columnConfig({width: 220})	AlphaValue : PXFieldState;
	@columnConfig({width: 120})	DestructiveTesting : PXFieldState;
	@columnConfig({width: 120})	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120, editorConfig : {}})	UOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDurationType : PXFieldState;
	@columnConfig({width: 100})	LeadTimeDuration : PXFieldState;
	@columnConfig({width: 120})	BitGoNoGo : PXFieldState;
	@columnConfig({width: 120})	OptionalTest : PXFieldState;
	@columnConfig({width: 120})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddCombo")
	@columnConfig({width: 280})	ComboValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) LineNbr: PXFieldState;	
}



@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns:true,
})
export class EWQCPlanSeverityAQLStandard extends PXView  {

	@columnConfig({width: 180 ,caption:'Severity'})	SeverityID : PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({width: 180 ,caption:'Rigorous (Maximum Defects Allow(%))'})	DefectivesRegorous : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280 ,caption:'Moderate (Maximum Defects Allow(%))'})	DefectivesModerate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280 ,caption:'Flexible (Maximum Defects Allow(%))'})	DefectivesFlexible : PXFieldState<PXFieldOptions.CommitChanges>;
	
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns:true,
})
export class EWQCPlanSeverityManualRQL extends PXView  {

	@columnConfig({width: 180,caption:'Severity'})	SeverityID : PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({width: 180,caption:'Rigorous (Maximum Defects Allow)'})	RigorousDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280,caption:'Moderate (Maximum Defects Allow)'})	ModerateDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280,caption:'Flexible (Maximum Defects Allow)'})	FlexibleDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns:true,
})

export class EWQCPlanSeverityManualAQL extends PXView  {

	@columnConfig({width: 180,caption:'Severity'})	SeverityID : PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({width: 180,caption:'Rigorous (Minimum Passed Tests)'})	RigorousDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280,caption:'Moderate (Minimum Passed Tests)'})	ModerateDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280,caption:'Flexible (Minimum Passed Tests)'})	FlexibleDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	
}


@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns:true,
})

export class EWQCPlanSeveritySampleWise extends PXView  {

	@columnConfig({width: 0,caption:'Severity' , visible:false})	SeverityID : PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({width: 280,caption:'Rigorous (Min Passed Sample Count)'}) RigorousDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280,caption:'Moderate (Min Passed Sample Count)'})	ModerateDefects : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280,caption:'Flexible (Min Passed Sample Count)'})	FlexibleDefects : PXFieldState<PXFieldOptions.CommitChanges>;

}
 
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState;
	Description : PXFieldState;
	EventType : PXFieldState;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
})
export class EWQCTestComboValues extends PXView  {

	TestComboCD : PXFieldState;
	Description : PXFieldState;
	@columnConfig({width: 120})	ComboCheck : PXFieldState;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCPlan, EWQCCopyPlanPanelDAC, EWQCPlanVariable,  EWQCEvent, EWQCPlanTestTool, EWQCTestComboValues,EWQCPlanSeverityAQLStandard,EWQCPlanSeveritySampleWise,EWQCPlanSeverityManualRQL,EWQCPlanSeverityManualAQL } from "./views";

@graphInfo({graphType: "EW.QC.EWQCPlanMaint", primaryView: "Documents", bpEventsIndicator: true, pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC209000 extends PXScreen {

	Documents = createSingle(EWQCPlan);
   	@viewInfo({containerName: "Copy To"})
	CopyPanel = createSingle(EWQCCopyPlanPanelDAC);
   	@viewInfo({containerName: "Tests"})
	PlanVariables = createCollection(EWQCPlanVariable);
    @viewInfo({containerName: "Result Criteria-AQL"})
	PlanSeveritiesAQLStandard = createCollection(EWQCPlanSeverityAQLStandard);
	@viewInfo({containerName: "Result Criteria-Manual"})
	PlanSeveritiesManualRQL = createCollection(EWQCPlanSeverityManualRQL);
	@viewInfo({containerName: "Result Criteria-Manual"})
	PlanSeveritiesManualAQL = createCollection(EWQCPlanSeverityManualAQL);
	@viewInfo({containerName: "Result Criteria Sample-Wise"})
	PlanSeveritiesSampleWise = createCollection(EWQCPlanSeveritySampleWise);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "Tools"})
	PlanToolSteps = createCollection(EWQCPlanTestTool);
   	@viewInfo({containerName: "Combo Values"})
	TestComboValues = createCollection(EWQCTestComboValues);
}
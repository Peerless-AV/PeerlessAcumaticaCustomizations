import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505600 } from "./QC505600";


// Views
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCStabilityLotDetail extends PXView  {
	@columnConfig({width: 60,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	DueDate :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	DueStatus :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	QCOrderCreation :PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("gotoStabilityQCInventory")
	@columnConfig({width: 150, editorConfig : {}})	InventoryID :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ItemDesc :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LotSerialNbr :PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewPlanMaster")
	@columnConfig({width: 150, editorConfig : {displayMode:"text"}})	QCPlanID :PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("gotoStabilityQCOrders")
	@columnConfig({width: 150})	LastQCOrder :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LastQCDate :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	QCExecuted :PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Remark :PXFieldState<PXFieldOptions.CommitChanges>;
	
}
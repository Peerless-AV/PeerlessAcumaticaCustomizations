import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs, RowCssHandlerArgs } from "client-controls";
import { EWQCStabilityLotDetail } from "./views";
import { EWQCPrimaryFilter } from "../common/view";
@graphInfo({ graphType: "EW.QC.EWQCStabilityProcess", primaryView: "EWQCStabilityQC", bpEventsIndicator: true })
export class QC505600 extends PXScreen {

	EWQCStabilityQC = createCollection(EWQCStabilityLotDetail);
	@viewInfo({ containerName: "Primary Filter View" })
	PrimaryDAC = createSingle(EWQCPrimaryFilter);

	@handleEvent(CustomEventType.GetRowCss, { view: "EWQCStabilityQC" })
	getQCOrderCreationCss(args: RowCssHandlerArgs<PXViewCollection<EWQCStabilityLotDetail>>) {
		const row = args?.selector?.row;
		if (row?.QCOrderCreation.value === "A")
			return "RowRed";
		else
			return undefined;
	}
}
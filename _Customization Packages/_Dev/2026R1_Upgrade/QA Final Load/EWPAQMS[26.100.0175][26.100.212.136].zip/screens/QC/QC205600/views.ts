import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC205600 } from "./QC205600";


// Views

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCNCCategory extends PXView  {

	@columnConfig({ width: 180 }) NcCapaType: PXFieldState;
	@columnConfig({width: 180})	Name : PXFieldState;
	@columnConfig({width: 280})	Description : PXFieldState;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCNCCategory } from "./views";

@graphInfo({graphType: "EW.QC.EWQCNCategoryMaint", primaryView: "Categories", })
export class QC205600 extends PXScreen {

	Categories = createCollection(EWQCNCCategory);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301013 } from "./QC301013";

export class EWQCChkListOrderChkListType {
	ChecklistGroupCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	ChecklistCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCChkListOrder extends PXView  {

	QCChkListOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	CheckListType : PXFieldState<PXFieldOptions.Disabled>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	OnHold : PXFieldState<PXFieldOptions.CommitChanges>;
	OrderDate : PXFieldState<PXFieldOptions.Disabled>;
	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	RefDocument : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand:"ViewServAppointment"})
	RefDocumentNbr : PXFieldState<PXFieldOptions.Disabled>;
	RefDocumentLineNbr : PXFieldState<PXFieldOptions.Disabled>;
	RefDocumentSrc : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand:"ViewServEquipment"})
	RefDocumentID : PXFieldState<PXFieldOptions.Disabled>;
    @controlConfig({ allowEdit: true, linkCommand: "ViewInventory" })	
	InventoryID : PXFieldState<PXFieldOptions.Disabled>;
	CustomerCD : PXFieldState<PXFieldOptions.Disabled>;
	CustomerName : PXFieldState<PXFieldOptions.Disabled>;
	Project : PXFieldState<PXFieldOptions.Disabled>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
    autoRepaint: ["ChkListOrderChkListTask"],
})
export class EWQCChkListOrderChkList extends PXView  {

	@linkCommand("ViewChecklistGroup")
	@columnConfig({width: 150})	EWQCChecklistGroup__ChecklistGroupCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewCheckListItem")
	@columnConfig({width: 150})	EWQCChecklist__ChecklistCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})EWQCChecklist__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})EWQCChecklist__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 90})	Completed : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150 ,hideViewLink:true})	Executedby : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ExecutedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 250})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCChkListOrderChkListTask extends PXView  {

	@columnConfig({width: 300})	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 400})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 90 ,allowCheckAll:true})	Completed : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	ExecutedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200 ,hideViewLink:true})	Executedby : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 350})	Remark : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({width: 180})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 240})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180 ,hideViewLink:true})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}
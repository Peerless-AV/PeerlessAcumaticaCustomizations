import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCChkListOrder, EWQCChkListOrderChkList, EWQCChkListOrderChkListTask, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCChkListOrderEntry", primaryView: "ChkListOrderEntry", bpEventsIndicator: true, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC301013 extends PXScreen {

	ChkListOrderEntry = createSingle(EWQCChkListOrder);
   	@viewInfo({containerName: "Checklist"})
	ChkListOrderChkList = createCollection(EWQCChkListOrderChkList);
   	@viewInfo({containerName: "Tasks"})
	ChkListOrderChkListTask = createCollection(EWQCChkListOrderChkListTask);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
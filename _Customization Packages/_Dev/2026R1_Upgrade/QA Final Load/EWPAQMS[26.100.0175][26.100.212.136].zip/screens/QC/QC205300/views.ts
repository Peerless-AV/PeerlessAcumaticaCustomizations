import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC205300 } from "./QC205300";


// Views

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCCAPATypes extends PXView  {

	@columnConfig({width: 500})	NcCapaType : PXFieldState;
	@columnConfig({width: 180})	Name : PXFieldState;
	@columnConfig({width: 500})	Description : PXFieldState;
}
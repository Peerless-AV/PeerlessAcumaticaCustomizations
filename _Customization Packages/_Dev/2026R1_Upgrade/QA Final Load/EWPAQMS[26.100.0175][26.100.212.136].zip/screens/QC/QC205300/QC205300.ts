import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCCAPATypes } from "./views";

@graphInfo({graphType: "EW.QC.EWQCCAPATypesMaint", primaryView: "CAPATypes", })
export class QC205300 extends PXScreen {

	CAPATypes = createCollection(EWQCCAPATypes);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCInprogressFilter, EWQCOrder ,EWQCOrderAnalyst ,EWQCOrderInventory} from "./views";

@graphInfo({graphType: "EW.QC.EWQCInProgress", primaryView: "Filter", })
export class QC401066 extends PXScreen {

	Filter = createSingle(EWQCInprogressFilter);
   	@viewInfo({containerName: "Stock item"})
	EWQCInProgressOrderIDStock = createCollection(EWQCOrder);
   	@viewInfo({containerName: "Analyst"})
	EWQCInProgressOrderIDAnalyst= createCollection(EWQCOrderAnalyst);
	@viewInfo({containerName: "Inventory"})
	EWQCInProgressOrderID= createCollection(EWQCOrderInventory);


}
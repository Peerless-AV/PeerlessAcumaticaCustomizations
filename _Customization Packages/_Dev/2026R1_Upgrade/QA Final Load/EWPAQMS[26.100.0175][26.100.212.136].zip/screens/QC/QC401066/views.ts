import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401066 } from "./QC401066";

export class EWQCOrderType {
	QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	PlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	SamplingPlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	QCType: PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentType: PXFieldState<PXFieldOptions.CommitChanges>;
	Status: PXFieldState<PXFieldOptions.CommitChanges>;
	AssignedToID: PXFieldState<PXFieldOptions.CommitChanges>;
	SiteCD: PXFieldState<PXFieldOptions.CommitChanges>;
	LocationCD: PXFieldState<PXFieldOptions.CommitChanges>;
}

// Views

export class EWQCInprogressFilter extends PXView {

	DocType: PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	WarehouseID: PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	AssignedToID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCOrder extends PXView {


	EWQCOrder__QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewQCPlan")
	EWQCPlan__PlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewSamplingPlan")
	EWQCSamplingPlan__SamplingPlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__QCType: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__RefDocumentNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__RefDocumentType: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__Status: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCOrderAnalyst extends PXView {

	EWQCOrder__QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewQCPlanAnalyst")
	EWQCPlan__PlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewSamplingPlanAnalyst")
	EWQCSamplingPlan__SamplingPlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__QCType: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__RefDocumentNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__RefDocumentType: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrderSamplingDetail__AssignedToID: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__Status: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCOrderInventory extends PXView {


	EWQCOrder__QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewQCPlanInventory")
	EWQCPlan__PlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewSamplingPlanInventory")
	EWQCSamplingPlan__SamplingPlanCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__QCType: PXFieldState<PXFieldOptions.CommitChanges>;
	INSite__SiteCD: PXFieldState<PXFieldOptions.CommitChanges>;
	INLocation__LocationCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__Status: PXFieldState<PXFieldOptions.CommitChanges>;
}
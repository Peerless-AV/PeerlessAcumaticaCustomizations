import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCCAPAReason } from "./views";

@graphInfo({graphType: "EW.QC.EWQCCAPAReasonMaint", primaryView: "CAPAReasons", })
export class QC205500 extends PXScreen {

	CAPAReasons = createCollection(EWQCCAPAReason);
}
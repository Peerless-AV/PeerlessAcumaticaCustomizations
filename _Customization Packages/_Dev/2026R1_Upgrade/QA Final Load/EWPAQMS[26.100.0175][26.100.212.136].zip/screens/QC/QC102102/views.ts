import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC102102 } from "./QC102102";


// Views

export class EWQCSetup extends PXView  {

	@controlConfig({allowEdit:true})
	QCINSPlanNumberSequenceID : PXFieldState;
	@controlConfig({allowEdit:true})
	QCInspectionOrderNumberSequenceID : PXFieldState;
	InspectionPlanRevisionNo : PXFieldState;
	ErrorRequiredOnPRIns : PXFieldState;
	ErrorRequiredOnProductionIns : PXFieldState;
}
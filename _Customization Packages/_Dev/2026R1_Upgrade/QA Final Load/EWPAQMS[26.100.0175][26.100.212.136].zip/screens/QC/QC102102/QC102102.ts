import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCSetup } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInspectionChecklistSetupMaint", primaryView: "Setup", bpEventsIndicator: true, pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC102102 extends PXScreen {

	Setup = createSingle(EWQCSetup);
}
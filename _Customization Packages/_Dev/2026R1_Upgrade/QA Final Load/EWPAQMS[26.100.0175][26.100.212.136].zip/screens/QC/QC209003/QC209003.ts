import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCCertificate, EWQCCertificateVariable } from "./views";

@graphInfo({graphType: "EW.QC.EWQCCertificationMaint", primaryView: "EWQCcertificate", bpEventsIndicator: true, pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC209003 extends PXScreen {

	EWQCcertificate = createSingle(EWQCCertificate);
   	@viewInfo({containerName: "attributes"})
	EWQCCertificatevariable = createCollection(EWQCCertificateVariable);
}
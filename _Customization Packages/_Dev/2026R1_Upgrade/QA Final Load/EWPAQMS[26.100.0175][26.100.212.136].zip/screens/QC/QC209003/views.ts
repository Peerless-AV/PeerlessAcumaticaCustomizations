import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";


// Views
@gridConfig({
        syncPosition: true,
        autoAdjustColumns: true,
        showFastFilter: GridFastFilterVisibility.False,
        preset: GridPreset.Details
})
export class EWQCCertificate extends PXView  {

	CertificateCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState;
}

export class EWQCCertificateVariable extends PXView  {

	Name : PXFieldState;
	DataType : PXFieldState;
	Description : PXFieldState;
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505300 } from "./QC505300";

export class EWQCProjectionQCOrderType {
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCOrderFilter extends PXView  {

	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	ProdOrderID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCProjectionQCOrder extends PXView  {

	@columnConfig({width: 60 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewOrder")
	@columnConfig({width: 150})	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewPlan")
	@columnConfig({width: 150})	PlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewStockItem")
	@columnConfig({width: 150})	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewSampling")
	@columnConfig({width: 180})	SamplingPlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
	QCType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewRefNumber")
	@columnConfig({width: 180})	RefDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentType : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrderLotDetail : EWQCProjectionQCOrderType;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCOrderFilter, EWQCProjectionQCOrder } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderCancelProcess", primaryView: "Filter", bpEventsIndicator: true})
export class QC505300 extends PXScreen {

	Filter = createSingle(EWQCOrderFilter);
	EWQCOrders = createCollection(EWQCProjectionQCOrder);
}
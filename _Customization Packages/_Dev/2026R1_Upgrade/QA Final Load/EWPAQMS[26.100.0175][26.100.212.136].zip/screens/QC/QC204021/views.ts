import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC204021 } from "./QC204021";


// Views

export class EWQCTnCMaint extends PXView  {

	ToolSource : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["ToolCD","ToolDesc"]})
	ToolID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	ToolStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	ManufacturerName : PXFieldState<PXFieldOptions.CommitChanges>;
	ModelSerialnumber : PXFieldState<PXFieldOptions.CommitChanges>;
	AssetTag : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({allowEdit:true,fastFilterFields:["Name","Description"]})
	Department : PXFieldState<PXFieldOptions.CommitChanges>;
	LeadTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@fieldConfig({
  controlType: "qp-radio",
  controlConfig: {
    class: "vertical",
    options: [
      {
        value: "1",
        text: "No. of Days"
      },
      {
        value: "2",
        text: "Usages"
      },
      {
        value: "3",
        text: "Before Use"
      },
      {
        value: "4",
        text: "After Use"
      },
      {
        value: "5",
        text: "Manual"
      }
    ]
  }
})
	CalibrationScheduledType : PXFieldState<PXFieldOptions.CommitChanges>;
	Days : PXFieldState<PXFieldOptions.CommitChanges>;
	Usage : PXFieldState<PXFieldOptions.CommitChanges>;
	StartDateManual : PXFieldState<PXFieldOptions.CommitChanges>;
	StartDateUsage : PXFieldState<PXFieldOptions.CommitChanges>;
	NextCalDate : PXFieldState<PXFieldOptions.CommitChanges>;
	OrderRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({allowEdit:true,fastFilterFields:["Name","Description"]})
	CalibrationChecklistID : PXFieldState<PXFieldOptions.CommitChanges>;
	ChkgroupDesc : PXFieldState<PXFieldOptions.CommitChanges>;
	LastCalibrationDate : PXFieldState<PXFieldOptions.CommitChanges>;
	CalibrationSource : PXFieldState<PXFieldOptions.CommitChanges>;
	SourceRemarks : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	AssignEmployee : PXFieldState<PXFieldOptions.CommitChanges>;
	Usermanual : PXFieldState<PXFieldOptions.CommitChanges>;
	ImageUrl : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCDetail extends PXView  {

	OrderRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	ScheduleName : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	MaintenanceChecklistID : PXFieldState<PXFieldOptions.CommitChanges>;
	ChkgroupDesc : PXFieldState<PXFieldOptions.CommitChanges>;
	MainSource : PXFieldState<PXFieldOptions.CommitChanges>;
	MainScheduleType : PXFieldState<PXFieldOptions.CommitChanges>;
	Days : PXFieldState<PXFieldOptions.CommitChanges>;
	Usage : PXFieldState<PXFieldOptions.CommitChanges>;
	StartDateManual : PXFieldState<PXFieldOptions.CommitChanges>;
	NextCalDate : PXFieldState<PXFieldOptions.CommitChanges>;
	LastMaintenanceDate : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCOrder extends PXView  {

	@linkCommand("RefOrderNbr")
	@columnConfig({width: 115})	TnCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 115})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 115})	OrderType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 130})	CalibrationScheduledType : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 240})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, hideViewLink:true})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}
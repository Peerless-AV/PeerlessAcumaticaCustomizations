import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTnCMaint, EWQCTnCDetail, EWQCTnCOrder, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCToolsManagementMaint", primaryView: "ToolsManagement", bpEventsIndicator: true, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC204021 extends PXScreen {

	ToolsManagement = createSingle(EWQCTnCMaint);
   	@viewInfo({containerName: "Maintenance"})
	MaintenanceDetail = createCollection(EWQCTnCDetail);
   	@viewInfo({containerName: "Transaction History"})
	EWQCToolManagementView = createCollection(EWQCTnCOrder);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
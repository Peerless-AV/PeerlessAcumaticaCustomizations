import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC504031 } from "./QC504031";


// Views

export class EWQCTnCProcess extends PXView  {

	@columnConfig({ width: 60, allowCheckAll: true })	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ToolSource : PXFieldState;
	@linkCommand("ViewToolID")
	@columnConfig({width: 150})	ToolID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Description : PXFieldState;
	@columnConfig({width: 150})	ToolStatus : PXFieldState;
	@linkCommand("EWQCViewChecklistGroup")
	@columnConfig({width: 150, editorConfig : {}})	CalibrationChecklistID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LastCalibrationDate : PXFieldState;
	@columnConfig({width: 150})	OrderType : PXFieldState;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTnCProcess } from "./views";
import { EWQCPrimaryFilter } from "../common/view";

@graphInfo({graphType: "EW.QC.EWQCToolsManagementProcess", primaryView: "ToolsProcess", })
export class QC504031 extends PXScreen {

	ToolsProcess = createCollection(EWQCTnCProcess);
	@viewInfo({ containerName: "Primary Filter View" })
	PrimaryDAC = createSingle(EWQCPrimaryFilter);
}
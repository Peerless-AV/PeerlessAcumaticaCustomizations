import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCBOMCompareFilter, AMBOMCompareTreeNode, AMBOMCompareTreeNode2, AMBomMatl, AMBomStep, AMBomTool, AMBomOvhd, EWQCBOMOperVariable, EWQCAssociateInspectionPlan, EWQCAssociateInspectionPlanVariable, EWQCAssociateChecklistGroup, EWQCAssociateChecklistGroupVariable, EWQCPlanTestTool, EWQCInspectionPlanTestTool } from "./views";

@graphInfo({graphType: "EW.QC.EWQCBOMCompareInq", primaryView: "Filter", })
export class QC405411 extends PXScreen {

   	@viewInfo({containerName: "BOM of Material"})
	Filter = createSingle(EWQCBOMCompareFilter);
   	@viewInfo({containerName: "Features"})
	Tree1 = createCollection(AMBOMCompareTreeNode);
   	@viewInfo({containerName: "Features"})
	Tree2 = createCollection(AMBOMCompareTreeNode2);
   	@viewInfo({containerName: "Materials", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	BomMatlRecords = createCollection(AMBomMatl);
   	@viewInfo({containerName: "Steps", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	BomStepRecords = createCollection(AMBomStep);
   	@viewInfo({containerName: "Tools", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	BomToolRecords = createCollection(AMBomTool);
   	@viewInfo({containerName: "Overhead", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	BomOvhdRecords = createCollection(AMBomOvhd);
   	@viewInfo({containerName: "QC Test", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	EWQCBOMVariableRecords = createCollection(EWQCBOMOperVariable);
   	@viewInfo({containerName: "Inspection Plans", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	EWQCInspectionPlanDetail = createCollection(EWQCAssociateInspectionPlan);
   	@viewInfo({containerName: "Tests", parameters: [new ControlParameter("detailLineNbr1", "", ""),new ControlParameter("detailLineNbr2", "", "")]})
	EWQCAssociateInspectionPlanVariables = createCollection(EWQCAssociateInspectionPlanVariable);
   	@viewInfo({containerName: "Checklist Group", parameters: [new ControlParameter("detailLineNbr1", "Tree1", "DetailLineNbr"),new ControlParameter("detailLineNbr2", "Tree2", "DetailLineNbr")]})
	EWQCAssociateChecklistGroups = createCollection(EWQCAssociateChecklistGroup);
   	@viewInfo({containerName: "Checklist Group"})
	EWQCAssociateChecklistGroupVariables = createCollection(EWQCAssociateChecklistGroupVariable);
   	@viewInfo({containerName: "QC Tool"})
	ToolSteps = createCollection(EWQCPlanTestTool);
   	@viewInfo({containerName: "ToolInspectionSteps"})
	ToolInspectionSteps = createCollection(EWQCInspectionPlanTestTool);
}
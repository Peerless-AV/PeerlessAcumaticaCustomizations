import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC405411 } from "./QC405411";

export class AMBomToolType {
	Descr : PXFieldState;	
}
export class AMBomOvhdType {
	Descr : PXFieldState;	
	OvhdType : PXFieldState;	
}
export class EWQCBOMOperVariableType {
	Unit : PXFieldState;	
	Name : PXFieldState;	
}
export class EWQCAssociateInspectionPlanVariableType {
	TestMethodID : PXFieldState;	
	TestCategoryID : PXFieldState;	
	DataType : PXFieldState;	
	Unit : PXFieldState;	
}
export class EWQCAssociateChecklistGroupVariableType {
	Name : PXFieldState;	
}

// Views

export class EWQCBOMCompareFilter extends PXView  {

	IDType1 : PXFieldState<PXFieldOptions.CommitChanges>;
	BOMID1 : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	RevisionID1 : PXFieldState<PXFieldOptions.CommitChanges>;
	ECRID1 : PXFieldState<PXFieldOptions.CommitChanges>;
	ECOID1 : PXFieldState<PXFieldOptions.CommitChanges>;
	IDType2 : PXFieldState<PXFieldOptions.CommitChanges>;
	BOMID2 : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	RevisionID2 : PXFieldState<PXFieldOptions.CommitChanges>;
	ECRID2 : PXFieldState<PXFieldOptions.CommitChanges>;
	ECOID2 : PXFieldState<PXFieldOptions.CommitChanges>;
}

@treeConfig({
  idField: [
    "ParentID",
    "LineNbr",
    "CategoryNbr",
    "DetailLineNbr"
  ],
  textField: "Label",
  valueField: "DetailLineNbr",
  toolTipField: "ToolTip",
  iconField: "Icon",
  dynamic: true,
  hideRootNode: true,
  openedLayers: 4,
  selectFirstNode: true,
  syncPosition: true,
  modifiable: false,
  mode: "single",
  singleClickSelect: true,
  onSelect: "Refresh",
  autoRepaint: [
    "BomMatlRecords",
    "BomStepRecords",
    "BomToolRecords",
    "BomOvhdRecords",
    "EWQCBOMVariableRecords",
    "EWQCInspectionPlanDetail",
    "EWQCAssociateChecklistGroups"
  ],
  topBarItems: {}
})
export class AMBOMCompareTreeNode extends PXView  {

	ParentID : PXFieldState;
	LineNbr : PXFieldState;
	CategoryNbr : PXFieldState;
	DetailLineNbr : PXFieldState;
	Icon : PXFieldState;
	Label : PXFieldState;
	ToolTip : PXFieldState;
}

@treeConfig({
  idField: [
    "ParentID",
    "LineNbr",
    "CategoryNbr",
    "DetailLineNbr"
  ],
  textField: "Label",
  valueField: "DetailLineNbr",
  toolTipField: "ToolTip",
  iconField: "Icon",
  dynamic: true,
  hideRootNode: true,
  openedLayers: 4,
  selectFirstNode: true,
  syncPosition: true,
  modifiable: false,
  mode: "single",
  singleClickSelect: true,
  onSelect: "Refresh",
  autoRepaint: [
    "BomMatlRecords",
    "BomStepRecords",
    "BomToolRecords",
    "BomOvhdRecords",
    "EWQCBOMVariableRecords",
    "EWQCInspectionPlanDetail",
    "EWQCAssociateChecklistGroups"
  ],
  topBarItems: {}
})
export class AMBOMCompareTreeNode2 extends PXView  {

	ParentID : PXFieldState;
	LineNbr : PXFieldState;
	CategoryNbr : PXFieldState;
	DetailLineNbr : PXFieldState;
	Icon : PXFieldState;
	Label : PXFieldState;
	ToolTip : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomMatl extends PXView  {

	@columnConfig({width: 54})	LineID : PXFieldState;
	@columnConfig({width: 54})	SortOrder : PXFieldState;
	@columnConfig({width: 130})	BOMID : PXFieldState;
	@columnConfig({width: 130})	RevisionID : PXFieldState;
	@columnConfig({hideViewLink: true, width: 130, editorConfig : {}})	InventoryID : PXFieldState;
	@columnConfig({width: 81})	OperationID : PXFieldState;
	@columnConfig({hideViewLink: true, width: 81, editorConfig : {}})	SubItemID : PXFieldState;
	@columnConfig({width: 200, maxLength: 255})	Descr : PXFieldState;
	@columnConfig({width: 108})	QtyReq : PXFieldState;
	@columnConfig({width: 108})	BatchSize : PXFieldState;
	@columnConfig({width: 81, editorConfig : {}})	UOM : PXFieldState;
	@columnConfig({width: 108})	UnitCost : PXFieldState;
	@columnConfig({width: 100})	PlanCost : PXFieldState;
	@columnConfig({width: 100})	MaterialType : PXFieldState;
	@columnConfig({width: 110})	PhantomRouting : PXFieldState;
	@columnConfig({width: 85})	BFlush : PXFieldState;
	@columnConfig({hideViewLink: true, width: 130, editorConfig : {}})	SiteID : PXFieldState;
	CompBOMID : PXFieldState;
	@columnConfig({width: 85})	CompBOMRevisionID : PXFieldState;
	@columnConfig({hideViewLink: true, width: 130, editorConfig : {}})	LocationID : PXFieldState;
	@columnConfig({width: 108})	ScrapFactor : PXFieldState;
	@columnConfig({width: 90})	BubbleNbr : PXFieldState;
	@columnConfig({width: 85})	EffDate : PXFieldState;
	@columnConfig({width: 85})	ExpDate : PXFieldState;
	RowStatus : PXFieldState;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomStep extends PXView  {

	@columnConfig({width: 130})	BOMID : PXFieldState;
	@columnConfig({width: 130})	RevisionID : PXFieldState;
	@columnConfig({width: 81})	OperationID : PXFieldState;
	@columnConfig({allowNull: false, width: 351})	Descr : PXFieldState;
	@columnConfig({visible: false})	LineID : PXFieldState<PXFieldOptions.Hidden>;
	RowStatus : PXFieldState;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomTool extends PXView  {

	@columnConfig({width: 130})	BOMID : PXFieldState;
	@columnConfig({width: 130})	RevisionID : PXFieldState;
	@columnConfig({width: 81})	OperationID : PXFieldState;
	@columnConfig({visible: false})	LineID : PXFieldState<PXFieldOptions.Hidden>;
	@columnConfig({allowNull: false, width: 180, editorConfig : {allowEdit:true}})	ToolID : PXFieldState;
	@columnConfig({allowNull: false, width: 351})	Descr : PXFieldState;
	@columnConfig({allowNull: false, width: 117})	QtyReq : PXFieldState;
	@columnConfig({allowNull: false, width: 117})	UnitCost : PXFieldState;
	RowStatus : PXFieldState;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomOvhd extends PXView  {

	@columnConfig({width: 130})	BOMID : PXFieldState;
	@columnConfig({width: 130})	RevisionID : PXFieldState;
	@columnConfig({width: 81})	OperationID : PXFieldState;
	@columnConfig({visible: false})	LineID : PXFieldState<PXFieldOptions.Hidden>;
	@columnConfig({width: 81, editorConfig : {allowEdit:true}})	OvhdID : PXFieldState;
	@columnConfig({allowNull: false, width: 351})	AMOverhead : AMBomOvhdType;
	@columnConfig({allowNull: false, width: 117})	OFactor : PXFieldState;
	RowStatus : PXFieldState;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	 repaintColumns: true,
})
export class EWQCBOMOperVariable extends PXView  {

	@columnConfig({width: 70})	LineNbr : PXFieldState;
	@columnConfig({width: 60})	AddInReports : PXFieldState;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({width: 180, editorConfig : {fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewEquipmentMaster")
	@columnConfig({width: 180, editorConfig : {fastFilterFields:["ToolGaugeCD","Description"]}})	ToolGaugeID : PXFieldState;
	@linkCommand("GotoToolSteps")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewTestGroupMaster")
	@columnConfig({width: 180, editorConfig : {fastFilterFields:["Name","Description"]}})	TestGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewSeverityMaster")
	@columnConfig({width: 180, editorConfig : {fastFilterFields:["Name","Description"]}})	SeverityLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumTargetValue : PXFieldState;
	@columnConfig({width: 100})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	EWQCVariable : EWQCBOMOperVariableType;
	@linkCommand("EWQCViewTestMethod")
	@columnConfig({width: 180})	EWQCTestMethod : EWQCBOMOperVariableType;
	@linkCommand("EWQCViewTestCategoryMaster")
	@columnConfig({width: 180})	EWQCTestCategory : EWQCBOMOperVariableType;
	@columnConfig({width: 60})	BitGoNoGo : PXFieldState;
	@columnConfig({width: 220})	AlphaValue : PXFieldState;
	@columnConfig({width: 70})	Equation : PXFieldState;
	@columnConfig({width: 100})	OptionalTest : PXFieldState;
	@columnConfig({width: 100})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LeadTimeDurationType : PXFieldState;
	@columnConfig({width: 150})	LeadTimeDuration : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCAssociateInspectionPlan extends PXView  {

	@columnConfig({width: 150})	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Empty,
	repaintColumns: true,
})
export class EWQCAssociateInspectionPlanVariable extends PXView  {

	@columnConfig({width: 60})	AddInReports : PXFieldState;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({width: 100})	VariableID : PXFieldState;
	@columnConfig({width: 180})	EWQCVariable : EWQCAssociateInspectionPlanVariableType;
	@linkCommand("EWQCViewTestGroupMaster")
	@columnConfig({width: 100})	TestGroupID : PXFieldState;
	@linkCommand("EWQCViewEquipmentMaster")
	@columnConfig({width: 180})	ToolGaugeID : PXFieldState;
	@linkCommand("GotoToolInspectionSteps")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 80})	NumMinValue : PXFieldState;
	@columnConfig({width: 100})	NumTargetValue : PXFieldState;
	@columnConfig({width: 80})	NumMaxValue : PXFieldState;
	@columnConfig({width: 60})	BitGoNoGo : PXFieldState;
	@columnConfig({width: 150})	AlphaValue : PXFieldState;
	@columnConfig({width: 70})	LineNbr : PXFieldState;
	@columnConfig({width: 100})	OptionalTest : PXFieldState;
	@columnConfig({width: 100})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCAssociateChecklistGroup extends PXView  {

	@columnConfig({width: 180})	ChecklistGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Empty
})
export class EWQCAssociateChecklistGroupVariable extends PXView  {

	@linkCommand("ViewCheckListItem")
	@columnConfig({width: 180})	ChecklistID : PXFieldState;
	@columnConfig({width: 180})	EWQCChecklist : EWQCAssociateChecklistGroupVariableType;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState;
	Description : PXFieldState;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCInspectionPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState;
	Description : PXFieldState;
}
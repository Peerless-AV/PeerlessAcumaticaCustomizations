import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC101000 } from "./QC101000";

export class EWQCLotLocStatusPrefType {
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
}



export class EWQCSetup extends PXView  {

	@controlConfig({allowEdit:true})
	QCTESTNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCPNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCSPNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCORecNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCOShippingNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCOAdhocNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCOProductionNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCOperationQCOrderNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCKitAssemblyQCOrderNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCRMANumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCInventoryAdjustmentNumberingSequence : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCWarehouseTransferNumberingSequence : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCONonStockSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCSNumberSequenceID : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableReceivingQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableRMAQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableShippingQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableWTQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableProductionQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableAdjustQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableKitAssemblyQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableInProcessQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	QCPlanRevisionNo : PXFieldState<PXFieldOptions.CommitChanges>;
	SamplingPlanRevisionNo : PXFieldState<PXFieldOptions.CommitChanges>;
	DecimalPrecision : PXFieldState<PXFieldOptions.CommitChanges>;
	BooleanTypeLabel : PXFieldState<PXFieldOptions.CommitChanges>;
	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	DestructiveInventoryTransfer : PXFieldState<PXFieldOptions.CommitChanges>;
	SoLinkPurchasePO : PXFieldState<PXFieldOptions.CommitChanges>;
	TransactionType : PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnPR : PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnProduction : PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnRMA : PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnAdjustment : PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnKitAssembly : PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnInprocess : PXFieldState<PXFieldOptions.CommitChanges>;
	OverrideTestResult : PXFieldState<PXFieldOptions.CommitChanges>;
	AllowRemarkForOptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	AllowInventoryTransfer : PXFieldState<PXFieldOptions.CommitChanges>;
	AllowPartialQCOrderPosting : PXFieldState<PXFieldOptions.CommitChanges>;
	AutoGenerateQCOrderForProcess : PXFieldState<PXFieldOptions.CommitChanges>;
	ApprovalRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	AllowFailedQCToShip : PXFieldState<PXFieldOptions.CommitChanges>;
	AllowbypassshipmentQC : PXFieldState<PXFieldOptions.CommitChanges>;
	AllowCopyTest : PXFieldState<PXFieldOptions.CommitChanges>;
	FailedQCQtyOnScraped: PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnQCPost: PXFieldState<PXFieldOptions.CommitChanges>;	
	NCCancel: PXFieldState<PXFieldOptions.CommitChanges>;
	SettinglotStatusDefaultSite: PXFieldState<PXFieldOptions.CommitChanges>;
	PartialStatusChange: PXFieldState<PXFieldOptions.CommitChanges>;
	EnablePartialPostForLotStatus: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 370 }) AllowCopyLotAttribute: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCSetupDetail extends PXView  {

	@columnConfig({hideViewLink: true ,editorConfig : {}})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true ,editorConfig : {fastFilterFields:["Descr"]}})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	DefaultWarehouse : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	SetupDetailID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowImport :false
})
export class EWQCSetupDetailScrapped extends PXView  {

	@columnConfig({hideViewLink: true ,editorConfig : {}})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true ,editorConfig : {fastFilterFields:["Descr"]}})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	DefaultWarehouse : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowImport :false
})
export class EWQCSetupDetailRejected extends PXView  {

	@columnConfig({hideViewLink: true ,editorConfig : {}})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
@columnConfig({hideViewLink: true ,editorConfig : {fastFilterFields:["Descr"]}})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	DefaultWarehouse : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowImport :false
})
export class EWQCSetupDetailDestructive extends PXView  {

	@columnConfig({hideViewLink: true ,editorConfig : {}})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({hideViewLink: true ,editorConfig : {fastFilterFields:["Descr"]}})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	DefaultWarehouse : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowImport :false
})
export class EWQCSetupDetailStability extends PXView  {

	@columnConfig({ hideViewLink: true ,editorConfig : {}})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true ,editorConfig : {fastFilterFields:["Descr"]}})LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	DefaultWarehouse : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCLotLocStatusPref extends PXView  {

	@columnConfig({ hideViewLink: true , width: 65, editorConfig : {}})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 250})	EWQCLotLocStatus__Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 65})	AllowProduction : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 65})	AllowSales : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 65})	AllowTransfer : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 65})	AllowAdhoc : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 65 }) AllowAssembly: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 65 }) AllowMoveReversal: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCLotLocDocType extends PXView  {

	DocType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 150, editorConfig : {}})	LotStatus : PXFieldState<PXFieldOptions.CommitChanges>;
    EWQCLotLocStatus__Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCEvent extends PXView  {

	@columnConfig({width: 130, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 370})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true, width: 200})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	AbsoluteRefNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}
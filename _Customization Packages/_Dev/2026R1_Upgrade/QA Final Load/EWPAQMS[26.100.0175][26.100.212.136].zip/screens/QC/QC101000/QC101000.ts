import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCSetup, EWQCSetupDetail, EWQCSetupDetailScrapped, EWQCSetupDetailRejected, EWQCSetupDetailDestructive, EWQCSetupDetailStability, EWQCLotLocStatusPref, EWQCLotLocDocType, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCSetupMaint", primaryView: "Setup", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true })
export class QC101000 extends PXScreen {

	Setup = createSingle(EWQCSetup);
	@viewInfo({containerName: "QC Location"})
	SetupDetailQC = createCollection(EWQCSetupDetail);
	@viewInfo({containerName: "Scrap Location"})
	SetupDetailScrapped = createCollection(EWQCSetupDetailScrapped);
	@viewInfo({containerName: "Rejection Location"})
	SetupDetailRejected = createCollection(EWQCSetupDetailRejected);
	@viewInfo({containerName: "Destructive Location"})
	SetupDetailDestructive = createCollection(EWQCSetupDetailDestructive);
	@viewInfo({containerName: "Stability Location"})
	SetupDetailStability = createCollection(EWQCSetupDetailStability);
	@viewInfo({containerName: "Transaction Configuration "})
	LotLocStatusPref = createCollection(EWQCLotLocStatusPref);
	@viewInfo({containerName: "Transaction Mapping "})
	LotLocDocType = createCollection(EWQCLotLocDocType);
	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
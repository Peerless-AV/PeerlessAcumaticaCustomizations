import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209004 } from "./QC209004";


// Views

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",    
	preset: GridPreset.ReadOnly
})
export class EWQCVendorRatingCriteria extends PXView  {

	@columnConfig({width: 180})	Criteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Weightage : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCVendorRatingCriteria } from "./views";

@graphInfo({graphType: "EW.QC.EWQCVendorRatingCriteriaMaint", primaryView: "VendorRatingCriteria", })
export class QC209004 extends PXScreen {

	VendorRatingCriteria = createCollection(EWQCVendorRatingCriteria);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC501011 } from "./QC501011";

export class EWQCOrderSamplingDetailType {
	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;	
	VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;	
	ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCOrderFilter extends PXView  {

	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["AcctCD","AcctName"]})
	AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestStep extends PXView  {

	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCOrderSamplingDetail extends PXView  {

	@columnConfig({width: 60 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewOrder")
	@columnConfig({width: 180})	EWQCOrder__QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	EWQCOrderLotDetail__LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoSteps")
	@columnConfig({width: 180})	Steps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestCategory__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestMethod__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCToolGauge__ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCSeverityLevel__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 140})	AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCOrderFilter, EWQCTestStep, EWQCOrderSamplingDetail } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderAssignToProcess", primaryView: "OrderSampling", })
export class QC501011 extends PXScreen {

	Filter = createSingle(EWQCOrderFilter);
   	@viewInfo({containerName: "Test Steps"})
	TestSteps = createCollection(EWQCTestStep);
	OrderSampling = createCollection(EWQCOrderSamplingDetail);
}
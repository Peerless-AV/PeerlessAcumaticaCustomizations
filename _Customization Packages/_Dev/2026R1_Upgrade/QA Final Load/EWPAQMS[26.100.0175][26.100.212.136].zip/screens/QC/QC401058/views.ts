import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401058 } from "./QC401058";


// Views

export class EWQCInspectionOrder extends PXView  {

	RefDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentType : PXFieldState<PXFieldOptions.CommitChanges>;
}
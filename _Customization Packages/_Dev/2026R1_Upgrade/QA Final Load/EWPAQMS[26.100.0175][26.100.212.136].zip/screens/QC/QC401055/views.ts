import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401055 } from "./QC401055";

export class EWQCPlanVariableType {
	Name :  PXFieldState<PXFieldOptions.CommitChanges>;	
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;	
	Status :  PXFieldState<PXFieldOptions.CommitChanges>;	
	@columnConfig({ hideViewLink: true }) RevisionNo :  PXFieldState<PXFieldOptions.CommitChanges>;	
	EffectiveFromDate :  PXFieldState<PXFieldOptions.CommitChanges>;	
	EffectiveToDate :  PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCInspectionPlanVariableType {
	Name :  PXFieldState<PXFieldOptions.CommitChanges>;	
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;	
	Status :  PXFieldState<PXFieldOptions.CommitChanges>;	
	@columnConfig({ hideViewLink: true }) RevisionNo :  PXFieldState<PXFieldOptions.CommitChanges>;	
	EffectiveFromDate :  PXFieldState<PXFieldOptions.CommitChanges>;	
	EffectiveToDate :  PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class INItemClassType {
	ReceivingQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	ShippingQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	ProductionQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	AdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	KitAssemblyQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	RMAQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	WTQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	AdjustQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	DefaultAdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCServQCType {
	ServItemDescr :  PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class InventoryItemType {
	VendorID :  PXFieldState<PXFieldOptions.CommitChanges>;	
	CustomerID :  PXFieldState<PXFieldOptions.CommitChanges>;	
	ReceivingQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	ShippingQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	ProductionQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	AdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	KitAssemblyQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	RMAQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	WTQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	AdjustQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
	DefaultAdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class AMBomItemType {
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;	
	ItemType :  PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCWhereusedInq extends PXView  {

	DocType : PXFieldState<PXFieldOptions.CommitChanges>;
	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	Plan : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	SamplingPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	InspectionPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	ChecklistGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCPlanVariable extends PXView  {

	@linkCommand("ViewTestQCPlan")
	PlanCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCPlan__Name:  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCPlan__Description:  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCPlan__Status:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true }) EWQCPlan__RevisionNo:  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCPlan__EffectiveFromDate:  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCPlan__EffectiveToDate:  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCInspectionPlanVariable extends PXView  {

	@linkCommand("ViewTestinspectionPlan")
	InspectionPlanCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInspectionPlan__Name :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInspectionPlan__Description:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInspectionPlan__Status:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 60, hideViewLink: true }) EWQCInspectionPlan__RevisionNo:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInspectionPlan__EffectiveFromDate:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInspectionPlan__EffectiveToDate:  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem extends PXView  {

	@linkCommand("ViewStockitems")
	InventoryCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class INItemClass extends PXView  {

	@linkCommand("ViewItemClass")
	@columnConfig({width: 150})	ItemClassCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ReceivingQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ShippingQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ProductionQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__AdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__KitAssemblyQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__RMAQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__WTQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__AdjustQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__DefaultAdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMToolMst extends PXView  {

	@linkCommand("ViewTools")
	ToolID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMMach extends PXView  {

	@linkCommand("ViewMachine")
	MachID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class FixedAsset extends PXView  {

	@linkCommand("ViewFixedAsset")
	AssetCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem2 extends PXView  {

	@linkCommand("ViewNonStock")
	InventoryCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStabilityPlanning extends PXView  {

	@linkCommand("ViewStabilityPlanning")
	Stability :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	InventoryID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	RetentionWarehouseID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	RetentionLocationID :  PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCreation :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCServQC extends PXView  {

	@linkCommand("viewServPlaningTest")
	ServItemType :  PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewServTest")
	EquipmentId :  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCServQCUnionSelector__ServItemDescr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem3 extends PXView  {

	@linkCommand("ViewStockQCPlan ")
	@columnConfig({width: 150})	InventoryCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__ReceivingQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__ShippingQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__ProductionQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__AdhocQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__KitAssemblyQ:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__RMAQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__WTQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__AdjustQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__DefaultAdhocQC:  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class INItemClass2 extends PXView  {

	@linkCommand("ViewItemClassPlan")
	@columnConfig({width: 150})	ItemClassCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ReceivingQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ShippingQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ProductionQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__AdhocQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__KitAssemblyQC  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__RMAQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__WTQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__AdjustQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__DefaultAdhocQC: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomItem extends PXView  {

	@linkCommand("ViewBomItem")
	InventoryID :  PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryItem : AMBomItemType;
	@linkCommand("ViewBomPlan")
	BOMID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true }) RevisionID :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMToolMst2 extends PXView  {

	@linkCommand("ViewTools")
	ToolID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMMach2 extends PXView  {

	@linkCommand("ViewMachine")
	MachID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class FixedAsset2 extends PXView  {

	@linkCommand("ViewFixedAsset")
	AssetCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem4 extends PXView  {

	@linkCommand("ViewNonStock")
	InventoryCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCStabilityPlanning2 extends PXView  {

	@linkCommand("ViewStability")
	Stability :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	InventoryID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	RetentionWarehouseID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	RetentionLocationID :  PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCreation :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCServQC2 extends PXView  {

	@linkCommand("viewServPlaningPlan")
	ServItemType :  PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewServEquipment")
	EquipmentId :  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCServQCUnionSelector__ServItemDescr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem5 extends PXView  {

	@linkCommand("ViewStockitemSamplingPlan")
	@columnConfig({width: 150})	InventoryCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__VendorID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__CustomerID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__ReceivingQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__ShippingQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__ProductionQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__AdhocQC :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__KitAssemblyQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__RMAQC :   PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__WTQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__AdjustQC:  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCInventoryDetail__DefaultAdhocQC:  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class INItemClass3 extends PXView  {

	@linkCommand("ViewItemClassSamplingPlan")
	@columnConfig({width: 150})	ItemClassCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;	
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ReceivingQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ShippingQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__ProductionQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__AdhocQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__KitAssemblyQC  : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__RMAQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__WTQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__AdjustQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})EWQCItemClassPlanDetail__DefaultAdhocQC: PXFieldState<PXFieldOptions.CommitChanges>;

}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomItem2 extends PXView  {

	@linkCommand("ViewInventorySamplingPlan")
	InventoryID :  PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryItem : AMBomItemType;
	@linkCommand("ViewBomSamplingPlan")
	BOMID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true }) RevisionID :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem6 extends PXView  {

	@linkCommand("ViewInventoryItemInspectionplan")
	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class INItemClass4 extends PXView  {

	@linkCommand("ViewItemClassInspectionplan")
	ItemClassCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomItem3 extends PXView  {

	@linkCommand("ViewInventoryInspection")
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryItem : AMBomItemType;
	@linkCommand("ViewBomInspection")
	BOMID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true }) RevisionID :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem7 extends PXView  {

	@linkCommand("ViewInventoryItemInspectionplan")
	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class INItemClass5 extends PXView  {

	@linkCommand("ViewItemClassInspectionplan")
	ItemClassCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Descr :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class AMBomItem4 extends PXView  {

	@linkCommand("ViewInventoryInspection")
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryItem : AMBomItemType;
	@linkCommand("ViewBomInspection")
	BOMID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true }) RevisionID :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCMaint extends PXView  {

	@linkCommand("ViewtncToolPlaning")
	ToolID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCMaint2 extends PXView  {

	@linkCommand("ViewtncMachinePlaning")
	ToolID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCMaint3 extends PXView  {

	@linkCommand("ViewtncQctoolPlaning")
	ToolID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCServQC3 extends PXView  {

	@linkCommand("ViewServPlaningChecklist")
	ServItemType :  PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewServChecklist")
	EquipmentId :  PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCServQCUnionSelector__ServItemDescr :  PXFieldState<PXFieldOptions.CommitChanges>;
}
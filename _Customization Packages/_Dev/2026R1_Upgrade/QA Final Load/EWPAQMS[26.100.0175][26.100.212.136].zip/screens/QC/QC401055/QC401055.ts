import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCWhereusedInq, EWQCPlanVariable, EWQCInspectionPlanVariable, InventoryItem, INItemClass, AMToolMst, AMMach, FixedAsset, InventoryItem2, EWQCStabilityPlanning, EWQCServQC, InventoryItem3, INItemClass2, AMBomItem, AMToolMst2, AMMach2, FixedAsset2, InventoryItem4, EWQCStabilityPlanning2, EWQCServQC2, InventoryItem5, INItemClass3, AMBomItem2, InventoryItem6, INItemClass4, AMBomItem3, InventoryItem7, INItemClass5, AMBomItem4, EWQCTnCMaint, EWQCTnCMaint2, EWQCTnCMaint3, EWQCServQC3 } from "./views";

@graphInfo({graphType: "EW.QC.EWQCWhereUsed", primaryView: "Tests", bpEventsIndicator: true})
export class QC401055 extends PXScreen {

	Tests = createSingle(EWQCWhereusedInq);
   	@viewInfo({containerName: "QC Plan ID"})
	PlanByTest = createCollection(EWQCPlanVariable);
   	@viewInfo({containerName: "Inspection Plan ID"})
	InspectionPlanByTest = createCollection(EWQCInspectionPlanVariable);
   	@viewInfo({containerName: "Stock Items"})
	StockItemsByTest = createCollection(InventoryItem);
   	@viewInfo({containerName: "Item Class"})
	ItemClassByTest = createCollection(INItemClass);
   	@viewInfo({containerName: "Tools"})
	ToolsByTest = createCollection(AMToolMst);
   	@viewInfo({containerName: "Machines"})
	MachineByTest = createCollection(AMMach);
   	@viewInfo({containerName: "Fixed Assets"})
	FixedAssetByTest = createCollection(FixedAsset);
   	@viewInfo({containerName: "Non-Stock Items"})
	NonStockByTest = createCollection(InventoryItem2);
   	@viewInfo({containerName: "Stability"})
	StabilityByTest = createCollection(EWQCStabilityPlanning);
   	@viewInfo({containerName: "Service"})
	ServiceByTest = createCollection(EWQCServQC);
   	@viewInfo({containerName: "Stock item"})
	StokItem = createCollection(InventoryItem3);
   	@viewInfo({containerName: "Item Class"})
	ItemClassPlanInfo = createCollection(INItemClass2);
   	@viewInfo({containerName: "Bill of Material"})
	BOMItem = createCollection(AMBomItem);
   	@viewInfo({containerName: "Tools"})
	Tools = createCollection(AMToolMst2);
   	@viewInfo({containerName: "Machines"})
	Machine = createCollection(AMMach2);
   	@viewInfo({containerName: "Fixed Assets"})
	FixedAsset = createCollection(FixedAsset2);
   	@viewInfo({containerName: "Non-Stock Items"})
	NonStock = createCollection(InventoryItem4);
   	@viewInfo({containerName: "Stability"})
	StabilityByPlan = createCollection(EWQCStabilityPlanning2);
   	@viewInfo({containerName: "Service"})
	ServiceQCByPlan = createCollection(EWQCServQC2);
   	@viewInfo({containerName: "Stock Item"})
	StokItemSamplingPlan = createCollection(InventoryItem5);
   	@viewInfo({containerName: "Item Class"})
	ItemClassSamplingPlan = createCollection(INItemClass3);
   	@viewInfo({containerName: "Bill of Material"})
	BOMItemSamplingPlan = createCollection(AMBomItem2);
   	@viewInfo({containerName: "Stock item"})
	StockItemInspectionplan = createCollection(InventoryItem6);
   	@viewInfo({containerName: "Item Class"})
	ItemClassInspectionplan = createCollection(INItemClass4);
   	@viewInfo({containerName: "Bill of Material"})
	Bominspection = createCollection(AMBomItem3);
   	@viewInfo({containerName: "Stock item"})
	StockItemsByChecklist = createCollection(InventoryItem7);
   	@viewInfo({containerName: "Item Class"})
	ItemclassByChecklist = createCollection(INItemClass5);
   	@viewInfo({containerName: "Bill of Material"})
	BOMByChecklist = createCollection(AMBomItem4);
   	@viewInfo({containerName: "Tools"})
	ToolsByChecklist = createCollection(EWQCTnCMaint);
   	@viewInfo({containerName: "Machines"})
	MachineByChecklist = createCollection(EWQCTnCMaint2);
   	@viewInfo({containerName: "Qc Tool"})
	QcToolsByChecklist = createCollection(EWQCTnCMaint3);
   	@viewInfo({containerName: "Service"})
	ServiceByChecklist = createCollection(EWQCServQC3);
}
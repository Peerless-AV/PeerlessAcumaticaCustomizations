import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401070 } from "./QC401070";


// Views

export class EWQCLotStatusHis extends PXView  {

	RefNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	TranType : PXFieldState<PXFieldOptions.CommitChanges>;
}
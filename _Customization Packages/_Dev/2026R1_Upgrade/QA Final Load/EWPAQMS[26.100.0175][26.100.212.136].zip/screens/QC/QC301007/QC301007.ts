import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter ,CellCssHandlerArgs } from "client-controls";
import { EWQCOrderNS, EWQCPlan, EWQCTestStep, EWQCOrderNSTestFormula, EWQCTestDetailNS, EWQCEvent, EWQCPlanTestTool } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderEntryNS", primaryView: "QCOrders", showUDFIndicator: true})
export class QC301007 extends PXScreen {

	QCOrders = createSingle(EWQCOrderNS);
	Plan = createSingle(EWQCPlan);
   	@viewInfo({containerName: "Test Steps"})
	TestSteps = createCollection(EWQCTestStep);
   	@viewInfo({containerName: "Equation"})
	QCOrderTestFormula = createCollection(EWQCOrderNSTestFormula);
   	@viewInfo({containerName: "Test Results"})
	QCTestDetailNS = createCollection(EWQCTestDetailNS);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "QC Tool"})
	ToolSteps = createCollection(EWQCPlanTestTool);

    @handleEvent(CustomEventType.GetCellCss, { view: "QCTestDetailNS", column: "ActualResult" })
    getActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCTestDetailNS>>) {
        const row = args?.selector?.row;
        if (row?.ActualResult.value === "F")
            return "FailTest";
        else if (row?.ActualResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }

    @handleEvent(CustomEventType.GetCellCss, { view: "QCTestDetailNS", column: "FinalResult" })
    getFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCTestDetailNS>>) {
        const row = args?.selector?.row;
        if (row?.FinalResult.value === "F")
            return "FailTest";
        else if (row?.FinalResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }
}
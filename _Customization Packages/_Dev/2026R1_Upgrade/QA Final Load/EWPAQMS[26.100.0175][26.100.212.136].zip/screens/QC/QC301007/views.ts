import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301007 } from "./QC301007";

export class EWQCTestDetailNSType {
	VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCOrderNS extends PXView  {
	@actionConfig({ popupCommand: "OK" })
	submitFormula: PXActionState;

	OrderDate : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	OnHold : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	QCType : PXFieldState<PXFieldOptions.Disabled>;
	ItemType: PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand: "ViewArticleID" })
	ArticleID : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	Name : PXFieldState<PXFieldOptions.Disabled>;
	ScheduleType : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	ResultingCriteria : PXFieldState<PXFieldOptions.CommitChanges>;
	QCResult : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCPlan extends PXView  {

	Description : PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestStep extends PXView  {

	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderNSTestFormula extends PXView  {

	ParameterName : PXFieldState<PXFieldOptions.CommitChanges>;
	FormulaValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestDetailNS extends PXView  {

	@columnConfig({width: 180})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewTestMaster")
	@columnConfig({width: 180})	EWQCVariable__VariableCD : EWQCTestDetailNSType;
	@columnConfig({width: 180})EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoSteps")
	@columnConfig({width: 180})	Steps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestGroup__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoToolSteps")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCSeverityLevel__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({width: 140, editorConfig : {displayMode:"text",fastFilterFields:["AcctCD","AcctName"]}})	AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	ExpectedValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	UOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoEquation")
	@columnConfig({width: 180})	Formula : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})TestValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})FinalResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	AddInReports : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewLotNC")
	@columnConfig({width: 200})	NCNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 1})	QCOrderTestNonStockDetailID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}
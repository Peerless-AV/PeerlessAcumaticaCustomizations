import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209001 } from "./QC209001";


// Views

export class EWQCChecklist extends PXView  {

	ChecklistCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState;
	Description : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCChecklistStep extends PXView  {

	Name : PXFieldState;
	Description : PXFieldState;
	LineNbr : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState;
	Description : PXFieldState;
	EventType : PXFieldState;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState;
}
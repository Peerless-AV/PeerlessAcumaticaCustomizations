import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCChecklist, EWQCChecklistStep, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCChecklistMaint", primaryView: "Checklists", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC209001 extends PXScreen {

	Checklists = createSingle(EWQCChecklist);
   	@viewInfo({containerName: "Tasks"})
	ChecklistSteps = createCollection(EWQCChecklistStep);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
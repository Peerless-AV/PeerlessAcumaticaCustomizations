import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCInspectionPlan } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInspectionPlanActivateMaint", primaryView: "ProcessPlan", })
export class QC505103 extends PXScreen {

	ProcessPlan = createCollection(EWQCInspectionPlan);
}
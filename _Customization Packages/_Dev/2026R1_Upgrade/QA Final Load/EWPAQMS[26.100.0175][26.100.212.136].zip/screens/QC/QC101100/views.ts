 import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC101100 } from "./QC101100";


// Views

export class EWQCSetup extends PXView  {

	@controlConfig({allowEdit:true})
	CapaNumberSequenceID : PXFieldState;
	@controlConfig({allowEdit:true})
	NCNumberSequenceID : PXFieldState;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCNCCAPASetup extends PXView  {

	@columnConfig({width: 240})	QCType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	Nctype : PXFieldState;
	@columnConfig({width: 190})	IsAutoGenerateNCCAPA : PXFieldState;
}
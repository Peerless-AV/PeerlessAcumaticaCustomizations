import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCSetup, EWQCNCCAPASetup } from "./views";

@graphInfo({graphType: "EW.QC.EWQCNCCAPASetupMaint", primaryView: "NCCAPASetup", })
export class QC101100 extends PXScreen {

	Setup = createSingle(EWQCSetup);
   	@viewInfo({containerName: "NC-CAPA Entry"})
	NCCAPASetup = createCollection(EWQCNCCAPASetup);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCPlan } from "./views";

@graphInfo({graphType: "EW.QC.EWQCPlanActivateMaint", primaryView: "ProcessPlan", })
export class QC505101 extends PXScreen {

	ProcessPlan = createCollection(EWQCPlan);
}
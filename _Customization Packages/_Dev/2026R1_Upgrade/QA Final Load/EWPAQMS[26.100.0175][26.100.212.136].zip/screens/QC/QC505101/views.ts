import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505101 } from "./QC505101";


// Views

export class EWQCPlan extends PXView  {

	@columnConfig({allowSort: false, width: 30 ,allowCheckAll:true})	Selected : PXFieldState;
	@linkCommand("ViewPlan")
	@columnConfig({width: 90, editorConfig : {allowEdit:true}})	PlanCD : PXFieldState;
	@columnConfig({width: 90})	RevisionNo : PXFieldState;
	Name : PXFieldState;
	@columnConfig({width: 90})	Description : PXFieldState;
	EffectiveFromDate : PXFieldState;
	EffectiveToDate : PXFieldState;
	@columnConfig({width: 80})	Status : PXFieldState;
}
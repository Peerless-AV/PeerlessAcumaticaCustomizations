import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs } from "client-controls";
import { EWQCOrder, EWQCOrderTestFormula, EWQCOrderSamplingDetail, EWQCTnCOrder, EWQCOrderLotDetail, EWQCOrderSamplingDetail2, EWQCOrderSamplingDetail3, EWQCTestStep, EWQCOrderToolDetails, EWQCOrderSerialTrackDetail } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCOrderSamplingDetailEntry", primaryView: "QCOrders", pageLoadBehavior: PXPageLoadBehavior.GoLastRecord, showActivitiesIndicator: true, showUDFIndicator: true })
export class QC301006 extends PXScreen {
	CopyData: PXActionState;

	QCOrders = createSingle(EWQCOrder);
	@viewInfo({ containerName: "Equation" })
	QCOrderTestFormula = createCollection(EWQCOrderTestFormula);
	@viewInfo({ containerName: "Test Results" })
	QCOrderSamplingDetails = createCollection(EWQCOrderSamplingDetail);
	@viewInfo({ containerName: "CALIBRATION AND MAINTENANCE ORDERS" })
	ToolManagementView = createCollection(EWQCTnCOrder);
	@viewInfo({ containerName: "Copy To Lot/Serial" })
	QCOrderLot = createCollection(EWQCOrderLotDetail);
	@viewInfo({ containerName: "Copy Sample Nbr" })
	QCOrderSample = createCollection(EWQCOrderSamplingDetail2);
	@viewInfo({ containerName: "Copy To Test" })
	QCOrderTest = createCollection(EWQCOrderSamplingDetail3);
	// @viewInfo({containerName: "QC Tool"})
	// ToolSteps = createCollection(EWQCPlanTestTool);
	@viewInfo({ containerName: "Test Steps" })
	TestSteps = createCollection(EWQCTestStep);
	@viewInfo({ containerName: "Tools" })
	OrderToolSteps = createCollection(EWQCOrderToolDetails);
	@viewInfo({ containerName: "Add Line Details" })
	QCOrderLotDetailsSmartPanel = createCollection(EWQCOrderSerialTrackDetail);

	 @handleEvent(CustomEventType.GetCellCss, { view: "QCOrderSamplingDetails", column: "ActualResult" })
		getSamplingActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderSamplingDetail>>) {
			const row = args?.selector?.row;
			if (row?.ActualResult.value === "F")
				return "FailTest";
			else if (row?.ActualResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
	
		@handleEvent(CustomEventType.GetCellCss, { view: "QCOrderSamplingDetails", column: "FinalResult" })
		getSamplingFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderSamplingDetail>>) {
			const row = args?.selector?.row;
			if (row?.FinalResult.value === "F")
				return "FailTest";
			else if (row?.FinalResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301006 } from "./QC301006";

export class EWQCOrderSamplingDetailType {
	Name: PXFieldState<PXFieldOptions.CommitChanges>;
	VariableCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	DataType: PXFieldState<PXFieldOptions.CommitChanges>;
	DisplayLotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
}

// Views

export class EWQCOrder extends PXView {

	@actionConfig({ popupCommand: "OK" })
	submitFormula: PXActionState;
	QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	DisplayLotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	Level: PXFieldState<PXFieldOptions.CommitChanges>;
	Lots: PXFieldState<PXFieldOptions.CommitChanges>;
	Samples: PXFieldState<PXFieldOptions.CommitChanges>;
	Tests: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderTestFormula extends PXView {

	ParameterName: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCTestParameter__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	FormulaValue: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowDelete: false,
	allowInsert: false,
	topBarItems: {
		AddQCTool: { index: 0, config: { commandName: "AddQCTool", text: "QCTool" } },
		AddSample: { index: 1, config: { commandName: "AddSample", text: "ADD SAMPLE" } },
		DeleteSample: { index: 2, config: { commandName: "DeleteSample", text: "DELETE SAMPLE" } },
		CopyTest: { index: 3, config: { commandName: "CopyTest", text: "COPT TEST RESULT" } },
		addLineDetails: { index: 4, config: { commandName: "addLineDetails", text: "Line Detail" } },
		CalibrationMaintenace: { index: 5, config: { commandName: "CalibrationMaintenace", text: "CALIBRATION/MAINTENACE ORDER" } },
	}
})
export class EWQCOrderSamplingDetail extends PXView {

	AddSample: PXActionState;
	DeleteSample: PXActionState;
	CopyTest: PXActionState;
	CaptureTestResults: PXActionState;
	AddQCTool: PXActionState;
	CalibrationMaintenace: PXActionState;
	addLineDetails: PXActionState;
	@columnConfig({ width: 180 }) SamplingSerailNum: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180, editorConfig: {} }) SerialNumber: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewTestMaster")
	@columnConfig({ width: 180 }) EWQCVariable__VariableCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoSteps")
	@columnConfig({ width: 180 }) Steps: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCTestGroup__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddQCTool")
	@columnConfig({ width: 180 }) ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCSeverityLevel__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({ width: 140, editorConfig: { displayMode: "text", fastFilterFields: ["AcctCD", "AcctName"] } }) AssignedToID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280 }) ExpectedValue: PXFieldState<PXFieldOptions.CommitChanges>;
	DestructiveTesting: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) SampleSize: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120, editorConfig: {} }) UOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) Equation: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoEquation")
	@columnConfig({ width: 180 }) Formula: PXFieldState<PXFieldOptions.CommitChanges>;
	TestValue: PXFieldState<PXFieldOptions.CommitChanges>;
	TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	ActualResult: PXFieldState<PXFieldOptions.CommitChanges>;
	FinalResult: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280 }) Remarks: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewTestNC")
	@columnConfig({ width: 200 }) NCNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LeadTimeDurationType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LeadTimeDuration: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 1 }) QCOrderSamplingDetailID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCOrder extends PXView {

	@linkCommand("RefOrderNbr")
	@columnConfig({ width: 115 }) TnCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 115 }) Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 115 }) OrderType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 130 }) CalibrationScheduledType: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewToolID")
	@columnConfig({ width: 130 }) ToolID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		CopyData: { index: 0, config: { commandName: "CopyData", text: "COPY" } },
	}
})
export class EWQCOrderLotDetail extends PXView {
	CopyData: PXActionState;
	@columnConfig({ allowCheckAll: true }) itemcheck: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) DisplayLotSerNumVal: PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		CopyData: { index: 0, config: { commandName: "CopyData", text: "COPY" } },
	}
})
export class EWQCOrderSamplingDetail2 extends PXView {
	CopyData: PXActionState;
	@columnConfig({ allowCheckAll: true }) itemcheck: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCOrderLotDetail__DisplayLotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) SamplingSerailNum: PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		CopyData: { index: 0, config: { commandName: "CopyData", text: "COPY" } },
	}
})
export class EWQCOrderSamplingDetail3 extends PXView {
	CopyData: PXActionState;
	@columnConfig({ allowCheckAll: true }) itemcheck: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__VariableCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCOrderLotDetail__DisplayLotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) SamplingSerailNum: PXFieldState;
}

// @gridConfig({
// 	syncPosition: true,
// 	autoAdjustColumns: true,
// 	showFastFilter: GridFastFilterVisibility.False,
// 	preset: GridPreset.Details
// })
// export class EWQCPlanTestTool extends PXView  {

// 	ToolGaugeID : PXFieldState;
// 	Description : PXFieldState;
// }

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestStep extends PXView {

	Name: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCOrderToolDetails extends PXView {

	@columnConfig({ editorConfig: { fastFilterFields: ["ToolGaugeID", "Description"] } }) ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderSerialTrackDetail extends PXView {

	@columnConfig({ width: 180, allowCheckAll: true }) SerialNumber: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) BaseWarehouseID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) BaseLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 60 }) itemcheck: PXFieldState<PXFieldOptions.CommitChanges>;
}
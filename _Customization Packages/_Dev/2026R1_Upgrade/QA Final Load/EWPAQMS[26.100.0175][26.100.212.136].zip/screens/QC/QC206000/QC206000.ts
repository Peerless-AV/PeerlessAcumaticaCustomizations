import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCToolGauge, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCToolGaugeMaint", primaryView: "ToolGauges", showUDFIndicator: true})
export class QC206000 extends PXScreen {

	ToolGauges = createSingle(EWQCToolGauge);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
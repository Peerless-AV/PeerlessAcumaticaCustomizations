import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC206000 } from "./QC206000";


// Views

export class EWQCToolGauge extends PXView  {

	ToolGaugeCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Comment : PXFieldState;
	Status : PXFieldState;
	LastCalibrationDate : PXFieldState;
	NextCalibrationDate : PXFieldState;
	SerialNo : PXFieldState;
	Description : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState;
	Description : PXFieldState;
	EventType : PXFieldState;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState;
}
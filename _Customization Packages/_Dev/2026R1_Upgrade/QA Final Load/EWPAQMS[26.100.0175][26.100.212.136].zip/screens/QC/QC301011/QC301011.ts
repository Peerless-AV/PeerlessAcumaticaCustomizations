import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs } from "client-controls";
import { EWQCServQCOrder, EWQCServQCVariable, EWQCEvent, EWQCPlanTestTool, EWQCTestStep, EWQCServTestFormula } from "./views";

@graphInfo({graphType: "EW.QC.EWQCServiceQCEntry", primaryView: "ServOrders", bpEventsIndicator: true, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC301011 extends PXScreen {

	ServOrders = createSingle(EWQCServQCOrder);
   	@viewInfo({containerName: "Test Results"})
	ServVariables = createCollection(EWQCServQCVariable);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "QC Tool"})
	ToolSteps = createCollection(EWQCPlanTestTool);
   	@viewInfo({containerName: "Test Steps"})
	TestSteps = createCollection(EWQCTestStep);
   	@viewInfo({containerName: "Equation"})
	ServOrderTestFormula = createCollection(EWQCServTestFormula);
	 @handleEvent(CustomEventType.GetCellCss, { view: "ServVariables", column: "ActualResult" })
		getSamplingActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCServQCVariable>>) {
			const row = args?.selector?.row;
			if (row?.ActualResult.value === "F")
				return "FailTest";
			else if (row?.ActualResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
	
		@handleEvent(CustomEventType.GetCellCss, { view: "ServVariables", column: "FinalResult" })
		getSamplingFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCServQCVariable>>) {
			const row = args?.selector?.row;
			if (row?.FinalResult.value === "F")
				return "FailTest";
			else if (row?.FinalResult.value === "P")
				return "PassTest";
			else
				return undefined;
		}
}
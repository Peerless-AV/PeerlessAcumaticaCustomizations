import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301011 } from "./QC301011";

export class EWQCServQCVariableType {
	VariableCD :  PXFieldState<PXFieldOptions.CommitChanges>;	
	Name :  PXFieldState<PXFieldOptions.CommitChanges>;	
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType :  PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCServQCOrder extends PXView  {
	@actionConfig({ popupCommand: "OK" })
	submitFormula: PXActionState;

	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	QCType : PXFieldState<PXFieldOptions.Disabled>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	OnHold : PXFieldState<PXFieldOptions.CommitChanges>;
	OrderDate :  PXFieldState<PXFieldOptions.CommitChanges>;
	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.Disabled>;
	ResultingCriteria :  PXFieldState<PXFieldOptions.CommitChanges>;
	QCResult :  PXFieldState<PXFieldOptions.CommitChanges>;
	PassTest : PXFieldState<PXFieldOptions.Disabled>;
	FailedTest : PXFieldState<PXFieldOptions.Disabled>;
	BRefDocType : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand: "ViewServOrder" })
	BRefDocID : PXFieldState<PXFieldOptions.Disabled>;
	BRefDocLineNbr : PXFieldState<PXFieldOptions.Disabled>;
	RefDocType : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand: "ViewServAppointment" })
	RefDocNbr : PXFieldState<PXFieldOptions.Disabled>;
	LineItemType : PXFieldState<PXFieldOptions.Disabled>;
	RefDocLineNbr : PXFieldState<PXFieldOptions.Disabled>;
	RefDocSource : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand: "ViewServEquipment" })
	RefDocSourceID : PXFieldState<PXFieldOptions.Disabled>;
	InventoryID : PXFieldState<PXFieldOptions.Disabled>;
	InventoryDescr : PXFieldState<PXFieldOptions.Disabled>;
	TrackingMethod : PXFieldState<PXFieldOptions.Disabled>;
	LotSerialNbr : PXFieldState<PXFieldOptions.Disabled>;
	CustomerCD : PXFieldState<PXFieldOptions.Disabled>;
	CustomerName : PXFieldState<PXFieldOptions.Disabled>;
	Project : PXFieldState<PXFieldOptions.Disabled>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	Disposition :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCServQCVariable extends PXView  {

	@columnConfig({width: 1})	ServQCVariableID :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	SamplingSerailNum :  PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewTestMaster")
	@columnConfig({width: 180})	EWQCVariable__VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__Name
	@linkCommand("GotoSteps")
	@columnConfig({width: 180})	Steps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestGroup__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})EWQCTestMethod__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoToolSteps")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCSeverityLevel__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({width: 140, editorConfig : {displayMode:"text",fastFilterFields:["AcctCD","AcctName"]}})	AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	ExpectedValue :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	UOM :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Equation :  PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoEquation")
	@columnConfig({width: 180})	Formula : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120}) TestValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})FinalResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	OptionalTest :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Remarks :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	AddInReports :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDurationType :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDuration :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
	EventType :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true, width: 200})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCPlanTestTool extends PXView  {

	ToolGaugeID :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestStep extends PXView  {

	Name :  PXFieldState<PXFieldOptions.CommitChanges>;
	Description :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCServTestFormula extends PXView  {

	ParameterName :  PXFieldState<PXFieldOptions.CommitChanges>;
	FormulaValue :  PXFieldState<PXFieldOptions.CommitChanges>;
}
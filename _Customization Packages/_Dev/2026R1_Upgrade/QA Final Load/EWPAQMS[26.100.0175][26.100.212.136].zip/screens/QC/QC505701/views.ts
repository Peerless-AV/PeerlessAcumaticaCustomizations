import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505701 } from "./QC505701";


// Views

export class EWQCLotStatusFilter extends PXView  {

	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCLotStatusDisplay extends PXView  {

	@columnConfig({ allowSort: false, width: 30, allowCheckAll: true })	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) InventoryID: PXFieldState;
	@columnConfig({ width: 150 }) InventoryItem__descr: PXFieldState
	@columnConfig({ width: 150 }) LotSerialNbr: PXFieldState;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	SiteID : PXFieldState;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	LocationID : PXFieldState;
	@columnConfig({width: 100})	AcumaticaQty : PXFieldState;
	@columnConfig({width: 100})	EWQCQty : PXFieldState;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCLotStatusFilter, EWQCLotStatusDisplay } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInvLotQtyProcess", primaryView: "LotStatusList", })
export class QC505701 extends PXScreen {

	Filter = createSingle(EWQCLotStatusFilter);
	LotStatusList = createCollection(EWQCLotStatusDisplay);
}
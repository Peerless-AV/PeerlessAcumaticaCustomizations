import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC203000 } from "./QC203000";


// Views

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCSeverityLevel extends PXView  {

	@columnConfig({width: 180})	Name : PXFieldState;
	@columnConfig({width: 280})	Description : PXFieldState;
	@columnConfig({width: 280})	IsSystemDefined : PXFieldState;
}
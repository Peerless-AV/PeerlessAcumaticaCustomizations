import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC504500 } from "./QC504500";


// Views

export class EWQCItemClassFilter extends PXView {

	Replace: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	SamplingPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	InsPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	ChecklistGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
	InspectionType : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	NewPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	NewSamplingPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ displayMode: "text" })
	NewInsPlanid: PXFieldState<PXFieldOptions.CommitChanges>;
	NewChecklistGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
	NewInspectionType : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	SamplingPlanIDInstype : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCCReplaceDataProcess extends PXView {

	@columnConfig({ width: 60, allowCheckAll: true }) Selected: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewField")
	@columnConfig({ width: 500 }) Field1: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 500 }) Field2: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 500 }) Field3: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 500 }) Action: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 500 , hideViewLink:true})	UsrEWQCPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 500 })	InspectionType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 500 , hideViewLink:true})	UsrEWQCSamplingPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
}
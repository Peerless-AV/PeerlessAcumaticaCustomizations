import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCItemClassFilter, EWQCCReplaceDataProcess } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCChangePlanProcess", primaryView: "Filter", bpEventsIndicator: true })
export class QC504500 extends PXScreen {


	Filter = createSingle(EWQCItemClassFilter);
	@viewInfo({ containerName: "Orders" })
	EWQCDataReplaceView = createCollection(EWQCCReplaceDataProcess);
}
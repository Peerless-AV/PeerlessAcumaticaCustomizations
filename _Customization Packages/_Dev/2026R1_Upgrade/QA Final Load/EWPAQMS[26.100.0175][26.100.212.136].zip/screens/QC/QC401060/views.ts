import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401060 } from "./QC401060";


// Views

export class EWQCTnCOrder extends PXView  {

	RefDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	DocType : PXFieldState<PXFieldOptions.CommitChanges>;
	ToolSource : PXFieldState<PXFieldOptions.CommitChanges>;
}
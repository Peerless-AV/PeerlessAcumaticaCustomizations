import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs } from "client-controls";
import { EWQCOrder, EWQCPlan, EWQCTestStep, EWQCOrderLotHistory, EWQCOrderTestFormula, EWQCOrderLotDetail, EWQCOrderSamplingDetail, EWQCEvent, EWQCOrderLotTransferDetail, EWQCTnCOrder, EWQCOrder2, EWQCOrderLotDetail2, EWQCOrderSamplingDetail2, EWQCOrderSamplingDetail3, EWQCOrderSerialTrackDetail, EWQCOrderToolDetails, INItemLotSerialAttribute } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderEntry", primaryView: "QCOrders", bpEventsIndicator: true, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC301000 extends PXScreen {
	CopyData: PXActionState;

	QCOrders = createSingle(EWQCOrder);
	Plan = createSingle(EWQCPlan);
   	@viewInfo({containerName: "Test Steps"})
	TestSteps = createCollection(EWQCTestStep);
   	@viewInfo({containerName: "Lot History"})
	LotHistoryCheck = createCollection(EWQCOrderLotHistory);
   	@viewInfo({containerName: "Equation"})
	QCOrderTestFormula = createCollection(EWQCOrderTestFormula);
   	@viewInfo({containerName: "Details"})
	QCOrderLotDetails = createCollection(EWQCOrderLotDetail);
   	@viewInfo({containerName: "Test Results"})
	QCOrderSamplingDetails = createCollection(EWQCOrderSamplingDetail);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "Lot Transfer Detail"})
	QCLotTransferDetails = createCollection(EWQCOrderLotTransferDetail);
   	@viewInfo({containerName: "CALIBRATION AND MAINTENANCE ORDERS"})
	ToolManagementView = createCollection(EWQCTnCOrder);
   	@viewInfo({containerName: "QCOrdersLot"})
	QCOrdersLot = createSingle(EWQCOrder2);
   	@viewInfo({containerName: "Copy To Lot/Serial"})
	QCOrderLot = createCollection(EWQCOrderLotDetail2);
   	@viewInfo({containerName: "Copy Sample Nbr"})
	QCOrderSample = createCollection(EWQCOrderSamplingDetail2);
   	@viewInfo({containerName: "Copy To Test"})
	QCOrderTest = createCollection(EWQCOrderSamplingDetail3);
   	@viewInfo({containerName: "Add Line Details"})
	QCOrderLotDetailsSmartPanel = createCollection(EWQCOrderSerialTrackDetail);
   	@viewInfo({containerName: "Tools"})
    OrderToolSteps = createCollection(EWQCOrderToolDetails);
    @viewInfo({ containerName: "Attributes" })
    LotSerialAttributes = createCollection(INItemLotSerialAttribute);


    @handleEvent(CustomEventType.GetCellCss, { view: "QCOrderLotDetails", column: "ActualResult" })
    getLotActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderLotDetail>>) {
        const row = args?.selector?.row;
        if (row?.ActualResult.value === "F")
            return "FailTest";
        else if (row?.ActualResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }

    @handleEvent(CustomEventType.GetCellCss, { view: "QCOrderSamplingDetails", column: "ActualResult" })
    getSamplingActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderSamplingDetail>>) {
        const row = args?.selector?.row;
        if (row?.ActualResult.value === "F")
            return "FailTest";
        else if (row?.ActualResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }

    @handleEvent(CustomEventType.GetCellCss, { view: "QCOrderSamplingDetails", column: "FinalResult" })
    getSamplingFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderSamplingDetail>>) {
        const row = args?.selector?.row;
        if (row?.FinalResult.value === "F")
            return "FailTest";
        else if (row?.FinalResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }
}
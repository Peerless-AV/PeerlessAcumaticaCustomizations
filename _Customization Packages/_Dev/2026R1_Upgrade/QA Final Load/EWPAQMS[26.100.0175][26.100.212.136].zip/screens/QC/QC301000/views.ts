import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301000 } from "./QC301000";

export class EWQCOrderLotDetailType {
	SiteCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	LocationCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCOrderSamplingDetailType {
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;	
	DisplayLotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCOrderLotTransferDetailType {
	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCOrder extends PXView  {

	@actionConfig({ popupCommand: "OK" })
	submitFormula: PXActionState;

	OrderDate : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	OnHold : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	QCType : PXFieldState<PXFieldOptions.Disabled>;
	RefDocumentType: PXFieldState<PXFieldOptions.Disabled>;	
	@controlConfig({ allowEdit: true, linkCommand: "RefDocNumbers" })
	RefDocumentNbr: PXFieldState<PXFieldOptions.Disabled>;
	RefDocumentLineNbr : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.Disabled>;
	TrackingMethod : PXFieldState<PXFieldOptions.Disabled>;
	TotalSampleSize : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	PlanID: PXFieldState<PXFieldOptions.CommitChanges>;	
	InspectionType : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	SamplingPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	AQLInspectionLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	ResultingCriteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	AccountID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	AccountName: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ allowEdit: true, linkCommand: "DocNumbers" })
	DocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	VendorName : PXFieldState<PXFieldOptions.CommitChanges>;
	VendorDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	Descr : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	ProjectID : PXFieldState<PXFieldOptions.CommitChanges>;
	QCExecuted : PXFieldState<PXFieldOptions.CommitChanges>;
	IntervalBy : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCPlan extends PXView  {

	Description : PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestStep extends PXView  {

	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderLotHistory extends PXView  {

	@columnConfig({editorConfig : {allowEdit:true}})	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	SamplingPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	QCType : PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentType: PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	preset: GridPreset.ReadOnly,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False
})
export class EWQCOrderTestFormula extends PXView  {

	ParameterName: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCTestParameter__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	FormulaValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["QCOrderSamplingDetails"],
	topBarItems: {
    lotAttributes: { index: 0, config: { commandName: "lotAttributes" } },
	addLineDetails: {index: 1, config: {commandName: "addLineDetails", text: "Line Detail"}},
}
})
export class EWQCOrderLotDetail extends PXView  {

	addLineDetails: PXActionState;
	lotAttributes: PXActionState;
	@columnConfig({width: 180})	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	LotSerNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GoToLotHistory")
	@columnConfig({width: 230})	LotHistory : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	BaseWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	BaseLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) INSite__SiteCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) INLocation__LocationCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	TestQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	BaseUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	PassedSamplesQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	FailedSamplesQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180 ,visible:false})PassedQCtest: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180 ,visible:false})FailedQCTest: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	AcceptedQTY : PXFieldState<PXFieldOptions.CommitChanges>;	
	@columnConfig({width: 180})	RejectedQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, editorConfig : {}  ,hideViewLink:true})	RejectionCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ScappedQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, editorConfig : {}  ,hideViewLink:true})	ScrapCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	DestructiveQTY : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewLotNC")
	@columnConfig({width: 200})	NCNbr : PXFieldState<PXFieldOptions.CommitChanges>;

}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		lotAttributestest: { index: 0, config: { commandName: "lotAttributestest" } },
		AddQCTool: { index: 1, config: { commandName: "AddQCTool", text: "QCTool" } },
		AddSample: { index: 2, config: { commandName: "AddSample", text: "ADD SAMPLE" } },
		DeleteSample: { index: 3, config: { commandName: "DeleteSample", text: "DELETE SAMPLE" } },
		CopyTest: { index: 4, config: { commandName: "CopyTest", text: "COPT TEST RESULT" } },
		CaptureTestResults: { index: 5, config: { commandName: "CaptureTestResults", text: "CAPTURE TEST RESULT" } },
		CalibrationMaintenace: {index: 6, config: {commandName: "CalibrationMaintenace", text: "CALIBRATION/MAINTENACE ORDER"}},
}
})
export class EWQCOrderSamplingDetail extends PXView  {

	lotAttributestest: PXActionState;
	AddSample: PXActionState;
	DeleteSample: PXActionState;
	CopyTest: PXActionState;
	CaptureTestResults: PXActionState;
	AddQCTool : PXActionState;
	CalibrationMaintenace : PXActionState;

	
	@columnConfig({width: 180})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, editorConfig : {}})	SerialNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewTestMaster")
	@columnConfig({ width: 180 }) EWQCVariable__VariableCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoSteps")
	@columnConfig({ width: 180 }) Steps: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
	AttributeID: PXFieldState<PXFieldOptions.CommitChanges>;
	CopyLotAttribute: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCTestGroup__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddQCTool")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCSeverityLevel__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({width: 140, editorConfig : {displayMode:"text",fastFilterFields:["AcctCD","AcctName"]}})	AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	ExpectedValue : PXFieldState<PXFieldOptions.CommitChanges>;
	DestructiveTesting : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120, editorConfig : {}})	UOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoEquation")
	@columnConfig({width: 180})	Formula : PXFieldState<PXFieldOptions.CommitChanges>;
	TestValue : PXFieldState<PXFieldOptions.CommitChanges>;
	TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	FinalResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	AddInReports : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewTestNC")
	@columnConfig({width: 200})	NCNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 1})	QCOrderSamplingDetailID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCOrderLotTransferDetail extends PXView  {

	InventoryItem__InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrderLotDetail__LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	FromWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	RefNbrType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewRefDocument")
	RefNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTnCOrder extends PXView  {

	@linkCommand("RefOrderNbr")
	@columnConfig({width: 115})	TnCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 115})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 115})	OrderType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 130})	CalibrationScheduledType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewToolID")
	@columnConfig({width: 130})	ToolID : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCOrder2 extends PXView  {

	Level : PXFieldState<PXFieldOptions.CommitChanges>;
	Lots : PXFieldState<PXFieldOptions.CommitChanges>;
	Samples : PXFieldState<PXFieldOptions.CommitChanges>;
	Tests : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		CopyData: { index: 0, config: { commandName: "CopyData", text: "COPY" } },
	}
})
export class EWQCOrderLotDetail2 extends PXView  {
	CopyData: PXActionState;
	@columnConfig({ width: 120, allowCheckAll: true })	itemcheck : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	DisplayLotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		CopyData: { index: 0, config: { commandName: "CopyData", text: "COPY" } },
	}
})
export class EWQCOrderSamplingDetail2 extends PXView  {
	CopyData: PXActionState;
	@columnConfig({ width: 120, allowCheckAll: true })	itemcheck : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCOrderLotDetail__DisplayLotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		CopyData: { index: 0, config: { commandName: "CopyData", text: "COPY" } },
	}
})
export class EWQCOrderSamplingDetail3 extends PXView  {
	CopyData: PXActionState;
	@columnConfig({ width: 120, allowCheckAll: true })	itemcheck : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__VariableCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCOrderLotDetail__DisplayLotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderSerialTrackDetail extends PXView  {

	@columnConfig({ width: 180}) SerialNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	BaseWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	BaseLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60 , allowCheckAll: true })	itemcheck : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCOrderToolDetails extends PXView  {

	@columnConfig({editorConfig : {fastFilterFields:["ToolGaugeID","Description"]}})	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Attributes
})
export class INItemLotSerialAttribute extends PXView {
	@columnConfig({	width: 135,	allowShowHide: GridColumnShowHideMode.False, textAlign: TextAlign.Left	})
	AttributeID: PXFieldState<PXFieldOptions.Disabled>;
	@columnConfig({ width: 80 }) Required: PXFieldState<PXFieldOptions.Disabled>;
	@columnConfig({ width: 185 }) Value: PXFieldState<PXFieldOptions.Disabled>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCPlan, EWQCPlanSeverityAQLStandard, EWQCPlanSeverityManualAQL, EWQCPlanSeverityManualRQL, EWQCPlanSeveritySampleWise, EWQCPlanVariable } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCPlanResultCriteria", primaryView: "Plan", bpEventsIndicator: true, pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showActivitiesIndicator: true, showUDFIndicator: true })
export class QC405415 extends PXScreen {

	Plan = createSingle(EWQCPlan);
	@viewInfo({ containerName: "Tests" })
	PlanVariables = createCollection(EWQCPlanVariable);
	@viewInfo({ containerName: "" })
	PlanSeveritiesAQLStandard = createCollection(EWQCPlanSeverityAQLStandard);
	@viewInfo({ containerName: "" })
	PlanSeveritiesManualRQL = createCollection(EWQCPlanSeverityManualRQL);
	@viewInfo({ containerName: "" })
	PlanSeveritiesManualAQL = createCollection(EWQCPlanSeverityManualAQL);
	@viewInfo({ containerName: "" })
	PlanSeveritiesSampleWise = createCollection(EWQCPlanSeveritySampleWise);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC405415 } from "./QC405415";

export class EWQCPlanVariableType {
	Name: PXFieldState;
	Description: PXFieldState;
	Equation: PXFieldState;
	DataType: PXFieldState;
	TestCategoryID: PXFieldState;
	TestMethodID: PXFieldState;
}

// Views

export class EWQCPlan extends PXView {

	@controlConfig<ISelectorControlConfig>({ fastFilterFields: ["RevisionNo", "Name"] })
	PlanCD: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	@controlConfig<ISelectorControlConfig>({ fastFilterFields: ["Name", "Description"] })
	RevisionNo: PXFieldState<PXFieldOptions.Disabled>;
	ResultCriteriaType: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCPlanSeverityAQLStandard extends PXView {

	@columnConfig({ width: 180, caption: 'Severity' }) SeverityID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180, caption: 'Rigorous (Maximum Defects Allow(%))' }) DefectivesRegorous: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Moderate (Maximum Defects Allow(%))' }) DefectivesModerate: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Flexible (Maximum Defects Allow(%))' }) DefectivesFlexible: PXFieldState<PXFieldOptions.CommitChanges>;

}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCPlanSeverityManualRQL extends PXView {

	@columnConfig({ width: 180, caption: 'Severity' }) SeverityID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180, caption: 'Rigorous (Maximum Defects Allow)' }) RigorousDefects: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Moderate (Maximum Defects Allow)' }) ModerateDefects: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Flexible (Maximum Defects Allow)' }) FlexibleDefects: PXFieldState<PXFieldOptions.CommitChanges>;

}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})

export class EWQCPlanSeverityManualAQL extends PXView {

	@columnConfig({ width: 180, caption: 'Severity' }) SeverityID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180, caption: 'Rigorous (Minimum Passed Tests)' }) RigorousDefects: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Moderate (Minimum Passed Tests)' }) ModerateDefects: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Flexible (Minimum Passed Tests)' }) FlexibleDefects: PXFieldState<PXFieldOptions.CommitChanges>;

}


@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})

export class EWQCPlanSeveritySampleWise extends PXView {

	@columnConfig({ width: 0, caption: 'Severity' }) SeverityID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Rigorous (Min Passed Sample Count)' }) RigorousDefects: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Moderate (Min Passed Sample Count)' }) ModerateDefects: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 280, caption: 'Flexible (Min Passed Sample Count)' }) FlexibleDefects: PXFieldState<PXFieldOptions.CommitChanges>;

}


@gridConfig({
	syncPosition: true,
	allowUpdate: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCPlanVariable extends PXView {

	@columnConfig({ width: 120 }) AddInReports: PXFieldState;
	@columnConfig({ editorConfig: { fastFilterFields: ["VariableCD", "Name"] } }) VariableID: PXFieldState;
	@columnConfig({ width: 180 }) EWQCVariable: EWQCPlanVariableType;
	@columnConfig({ width: 180, editorConfig: { fastFilterFields: ["Name", "Description"] } }) TestGroupID: PXFieldState;
	@columnConfig({ width: 180 }) LineNbr: PXFieldState;
	@columnConfig({ width: 180 }) ToolSteps: PXFieldState;
	@columnConfig({ editorConfig: { fastFilterFields: ["Name", "Description"] } }) SeverityLevel: PXFieldState;
	CalculationType: PXFieldState;
	QCOperator: PXFieldState;
	@columnConfig({ width: 100 }) NumMinValue: PXFieldState;
	@columnConfig({ width: 100 }) NumMaxValue: PXFieldState;
	@columnConfig({ width: 220 }) TestResultUOM: PXFieldState;
	@columnConfig({ width: 220 }) AlphaValue: PXFieldState;
	@columnConfig({ width: 120 }) DestructiveTesting: PXFieldState;
	@columnConfig({ width: 120 }) SampleSize: PXFieldState;
	@columnConfig({ width: 120, editorConfig: {} }) UOM: PXFieldState;
	@columnConfig({ width: 100 }) LeadTimeDurationType: PXFieldState;
	@columnConfig({ width: 100 }) LeadTimeDuration: PXFieldState;
	@columnConfig({ width: 120 }) BitGoNoGo: PXFieldState;
	@columnConfig({ width: 120 }) OptionalTest: PXFieldState;
	@columnConfig({ width: 120 }) OrderLevel: PXFieldState;
	@columnConfig({ width: 280 }) ComboValue: PXFieldState;
}
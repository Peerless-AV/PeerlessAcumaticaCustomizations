import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCLastNumberingSequence } from "./views";
import { EWQCPrimaryFilter } from "../common/view";

@graphInfo({ graphType: "EW.QC.EWQCIdentifyLastNumberingSequence", primaryView: "PrimaryDAC", })
export class QC505100 extends PXScreen {

	@viewInfo({containerName: "Auto Numbering Records"})
	ProcessRecord = createCollection(EWQCLastNumberingSequence);
	@viewInfo({ containerName: "Primary Filter View" })
	PrimaryDAC = createSingle(EWQCPrimaryFilter);
}
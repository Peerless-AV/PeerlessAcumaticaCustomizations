import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505100 } from "./QC505100";


// Views
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowInsert: false
})
export class EWQCLastNumberingSequence extends PXView  {

	@columnConfig({width: 130})	ScreenName : PXFieldState;
	@columnConfig({width: 130})	NumberingSequenceIDdisplay : PXFieldState;
	@columnConfig({width: 130})	ScreenLastRecordNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 130})	LastNumberingSequence : PXFieldState;
}
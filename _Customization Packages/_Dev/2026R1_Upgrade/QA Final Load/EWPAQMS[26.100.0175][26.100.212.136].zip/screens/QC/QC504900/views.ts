import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC504900 } from "./QC504900";


// Views
@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCSamplingPlan extends PXView  {

	@columnConfig({width: 60 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	SamplingPlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	RevisionNo : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	DisplayPlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	SamplingMethodType : PXFieldState<PXFieldOptions.CommitChanges>;
}
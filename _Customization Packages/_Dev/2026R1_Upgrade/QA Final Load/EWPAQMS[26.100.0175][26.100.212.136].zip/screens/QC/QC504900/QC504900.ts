import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCSamplingPlan } from "./views";

@graphInfo({graphType: "EW.QC.EWQCSamplingPlanDetailProcess", primaryView: "SamplingPlan", bpEventsIndicator: true})
export class QC504900 extends PXScreen {

	SamplingPlan = createCollection(EWQCSamplingPlan);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209025 } from "./QC209025";


// Views

export class EWQCInventoryLotStatus extends PXView  {

	@columnConfig({width: 150, editorConfig : {}})	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	INSite__SiteCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	INLocation__LocationCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	QtyAvail : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	StatusID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	Reason : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCInventoryLotStatus } from "./views";

@graphInfo({graphType: "EW.QC.EWQCLotSerialExportMaint", primaryView: "EWQCInventoryLotStatus", })
export class QC209025 extends PXScreen {

	EWQCInventoryLotStatus = createCollection(EWQCInventoryLotStatus);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTestCategory } from "./views";

@graphInfo({graphType: "EW.QC.EWQCTestCategoryMaint", primaryView: "TestCategories", })
export class QC201000 extends PXScreen {

	TestCategories = createCollection(EWQCTestCategory);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCVendorPerformanceReport } from "./views";

@graphInfo({graphType: "EW.QC.EWQCVendorPerformanceReportMaint", primaryView: "FilterWizard", bpEventsIndicator: true})
export class QC608001 extends PXScreen {

	FilterWizard = createSingle(EWQCVendorPerformanceReport);
}
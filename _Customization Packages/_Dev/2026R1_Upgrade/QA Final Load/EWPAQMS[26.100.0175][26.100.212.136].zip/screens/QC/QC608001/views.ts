import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC608001 } from "./QC608001";


// Views

export class EWQCVendorPerformanceReport extends PXView  {

	TimePeriod : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"id"})
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	IncTranDtl : PXFieldState<PXFieldOptions.CommitChanges>;
	VenGenInfo : PXFieldState<PXFieldOptions.CommitChanges>;
	RatCriNdWigt : PXFieldState<PXFieldOptions.CommitChanges>;
	Year : PXFieldState<PXFieldOptions.CommitChanges>;
	DateFrom : PXFieldState<PXFieldOptions.CommitChanges>;
	Month : PXFieldState<PXFieldOptions.CommitChanges>;
	Quarter : PXFieldState<PXFieldOptions.CommitChanges>;
	DateTo : PXFieldState<PXFieldOptions.CommitChanges>;
}
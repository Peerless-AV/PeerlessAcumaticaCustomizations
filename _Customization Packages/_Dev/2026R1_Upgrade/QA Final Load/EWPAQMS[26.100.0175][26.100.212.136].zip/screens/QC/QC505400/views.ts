import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505400 } from "./QC505400";


// Views

export class EWQCRetestFilter extends PXView  {

}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCStockRetest extends PXView  {

	@columnConfig({width: 60 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewStockItem")
	@columnConfig({width: 100})	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({textAlign: TextAlign.Left})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	SampleDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewOrder")
	OnGoingQCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	OnGoingQCOrderDate : PXFieldState<PXFieldOptions.CommitChanges>;
	LastQCType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewLastOrder")
	LastQCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	LastQCDate : PXFieldState<PXFieldOptions.CommitChanges>;
	Quantity : PXFieldState<PXFieldOptions.CommitChanges>;
	LastQCStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	TestingDate : PXFieldState<PXFieldOptions.CommitChanges>;
	RetestStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	RetestFrequency : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({textAlign: TextAlign.Left})	Interval : PXFieldState<PXFieldOptions.CommitChanges>;
	LotExpiryDate : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs } from "client-controls";
import { EWQCRetestFilter, EWQCStockRetest } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCStockItemsRetestProcess", primaryView: "Filter", })
export class QC505400 extends PXScreen {

	Filter = createSingle(EWQCRetestFilter);
	EWQCInventory = createCollection(EWQCStockRetest);

	@handleEvent(CustomEventType.GetCellCss, { view: "EWQCInventory", column: "RetestStatus" })
	getRetestStatusCss(args: CellCssHandlerArgs<PXViewCollection<EWQCStockRetest>>) {
		const row = args?.selector?.row;
		if (row?.RetestStatus.value != null && row?.RetestStatus.value === "T")
			return "RowRed";
		else if (row?.RetestStatus.value != null && row?.RetestStatus.value === "U")
			return "RowYellow";
		else if (row?.RetestStatus.value != null && row?.RetestStatus.value === "O")
			return "RowRed";
		else
			return undefined;
	}

	@handleEvent(CustomEventType.GetCellCss, { view: "EWQCInventory", column: "LotExpiryDate" })
	getLotExpiryDateCss(args: CellCssHandlerArgs<PXViewCollection<EWQCStockRetest>>) {
		const row = args?.selector?.row;
		var currentDate = new Date();
		var blankDate = new Date('01/01/0001');
		var LotExpiryDate = new Date(row?.LotExpiryDate.value);
		if (row?.LotExpiryDate.value != null && LotExpiryDate < currentDate && LotExpiryDate != blankDate)
			return "TextRed";
		else
			return undefined;
	}
}
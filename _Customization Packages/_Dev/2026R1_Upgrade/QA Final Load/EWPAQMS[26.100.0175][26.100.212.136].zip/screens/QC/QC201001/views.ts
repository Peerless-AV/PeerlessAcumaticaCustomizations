import { PXView, PXFieldState, gridConfig, IDropDownConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC201001 } from "./QC201001";



export class EWQCAssociateInspection extends PXView {

	ComboInspectionSaveButton: PXActionState;
	DocType: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCAssociateInspectionPlanVariableType {
	DataType: PXFieldState;
	Name: PXFieldState;
	TestCategoryID: PXFieldState;
	TestMethodID: PXFieldState;
	Equation: PXFieldState;
	Unit: PXFieldState;
}
export class EWQCAssociateChecklistGroupVariableType {
	Name: PXFieldState;
	Description: PXFieldState;
}


@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["AssociateInspectionPlanVariables"]
})
export class EWQCAssociateInspectionPlan extends PXView {

	@linkCommand("ViewInspectionPlan")
	@columnConfig({ width: 180, editorConfig: { displayMode: "text", fastFilterFields: ["InspectionPlanCD", "Name", "RevisionNo"] } }) PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	repaintColumns: true,
})
export class EWQCAssociateInspectionPlanVariable extends PXView {


	@columnConfig({ width: 100, editorConfig: { allowEdit: true, fastFilterFields: ["VariableCD", "Name"] } }) VariableID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) EWQCVariable: EWQCAssociateInspectionPlanVariableType;
	@linkCommand("GotoToolInspectionSteps")
	@columnConfig({ width: 180 }) ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) TestGroupID: PXFieldState;
	QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NumMinValue: PXFieldState;
	@columnConfig({ width: 100 }) NumMaxValue: PXFieldState;
	@columnConfig({ width: 220 }) TestResultUOM: PXFieldState;
	@columnConfig({ width: 70 }) BitGoNoGo: PXFieldState;
	@columnConfig({ width: 120 }) OptionalTest: PXFieldState;
	@columnConfig({ width: 120 }) OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) AlphaValue: PXFieldState;
	@columnConfig({ width: 50 }) LineNbr: PXFieldState;
	@linkCommand("addInspectionCombo")
	@columnConfig({ width: 280 }) ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["AssociateChecklistGroupVariable"],


})
export class EWQCAssociateChecklistGroup extends PXView {

	@linkCommand("ViewChecklistGroup")
	@columnConfig({ width: 180, editorConfig: { fastFilterFields: ["Description"] } }) ChecklistGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCAssociateChecklistGroupVariable extends PXView {

	@linkCommand("ViewCheckListItem")
	@columnConfig({ editorConfig: { fastFilterFields: ["Name", "Description"] } }) ChecklistID: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCChecklist: EWQCAssociateChecklistGroupVariableType;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCInspectionPlanTestTool extends PXView {

	ToolGaugeID: PXFieldState;
	Description: PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
})
export class EWQCTestComboValues extends PXView {
	TestComboCD: PXFieldState;
	Description: PXFieldState;
	@columnConfig({ width: 120 }) ComboCheck: PXFieldState;
}
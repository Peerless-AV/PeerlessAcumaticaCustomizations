import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCAssociateInspection, EWQCAssociateInspectionPlan, EWQCAssociateInspectionPlanVariable, EWQCAssociateChecklistGroup, EWQCAssociateChecklistGroupVariable, EWQCInspectionPlanTestTool, EWQCTestComboValues } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCAssociateInspectionPlanMaint", primaryView: "AssociateInspection", pageLoadBehavior: PXPageLoadBehavior.GoFirstRecord, showUDFIndicator: true })
export class QC201001 extends PXScreen {

	AssociateInspection = createSingle(EWQCAssociateInspection);
	@viewInfo({ containerName: "Plans" })
	AssociateInspectionPlan = createCollection(EWQCAssociateInspectionPlan);
	@viewInfo({ containerName: "Tests" })
	AssociateInspectionPlanVariables = createCollection(EWQCAssociateInspectionPlanVariable);
	@viewInfo({ containerName: "Checklist Group" })
	AssociateChecklistGroup = createCollection(EWQCAssociateChecklistGroup);
	@viewInfo({ containerName: "CheckList" })
	AssociateChecklistGroupVariable = createCollection(EWQCAssociateChecklistGroupVariable);
	@viewInfo({ containerName: "Tools" })
	ToolInspectionSteps = createCollection(EWQCInspectionPlanTestTool);
	@viewInfo({ containerName: "Combo Values" })
	TestInspectionComboValues = createCollection(EWQCTestComboValues);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCVendorPerformanceWizardFilter, InventoryItem } from "./views";

@graphInfo({graphType: "EW.QC.EWQCVendorPerformanceProcess", primaryView: "Wizard", bpEventsIndicator: true})
export class QC507400 extends PXScreen {

	Wizard = createSingle(EWQCVendorPerformanceWizardFilter);
	InventoryItems = createCollection(InventoryItem);
}
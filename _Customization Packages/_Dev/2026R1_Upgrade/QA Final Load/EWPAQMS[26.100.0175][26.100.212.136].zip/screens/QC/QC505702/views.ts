import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC505702 } from "./QC505702";

export class EWQCLotStatusDisplayType {
	descr: PXFieldState;
}

// Views

export class EWQCINLotStatusFilter extends PXView {

	ItemClassID: PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	WarehouseID: PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCLotStatusDisplay extends PXView {

	@columnConfig({ width: 60, allowCheckAll: true }) Selected: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150, editorConfig: { allowEdit: true } }) InventoryID: PXFieldState;
	@columnConfig({ width: 150 }) InventoryItem: EWQCLotStatusDisplayType;
	@columnConfig({ width: 150 }) LotSerialNbr: PXFieldState;
	@columnConfig({ width: 100, editorConfig: { allowEdit: true } }) SiteID: PXFieldState;
	@columnConfig({ width: 100, editorConfig: { allowEdit: true } }) LocationID: PXFieldState;
	@columnConfig({ width: 100 }) AcumaticaQty: PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details

})
export class EWQCProcessEvent extends PXView {

	ViewData: PXActionState;
	@columnConfig({ width: 40, format: "g" }) CreatedDateTime: PXFieldState;
	@columnConfig({ hideViewLink: true, width: 40 }) CreatedByID: PXFieldState;
	@linkCommand("ViewData")
	@columnConfig({ width: 40 }) Show: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCProcessEvent2 extends PXView {

	@columnConfig({ textAlign: TextAlign.Left }) InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ textAlign: TextAlign.Left }) InventoryItem__descr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, textAlign: TextAlign.Left }) SiteID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, textAlign: TextAlign.Left }) LocationID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ textAlign: TextAlign.Left }) LotSerialNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ textAlign: TextAlign.Left }) Qty: PXFieldState<PXFieldOptions.CommitChanges>;
}


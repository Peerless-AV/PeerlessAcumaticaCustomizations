import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCINLotStatusFilter, EWQCLotStatusDisplay, EWQCProcessEvent, EWQCProcessEvent2 } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInvLotInsertProcess", primaryView: "LotStatusList", })
export class QC505702 extends PXScreen {

	Filter = createSingle(EWQCINLotStatusFilter);
	LotStatusList = createCollection(EWQCLotStatusDisplay);
	@viewInfo({ containerName: "Event History" })
	ProcessEventSummary = createCollection(EWQCProcessEvent);
	@viewInfo({ containerName: "Event Descriptions" })
	EWQCProcessEventPanel = createCollection(EWQCProcessEvent2);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCVarianceType, EWQCRatingScoreCriteria, EWQCRatingScoreCriteria2, EWQCVendorRatingCriteria } from "./views";

@graphInfo({graphType: "EW.QC.EWQCRatingScoreCriteriaMaint", primaryView: "Filter", showUDFIndicator: true})
export class QC209005 extends PXScreen {

	Filter = createSingle(EWQCVarianceType);
   	@viewInfo({containerName: "Variance(+)"})
	PosRatingScores = createCollection(EWQCRatingScoreCriteria);
   	@viewInfo({containerName: "Variance(-)"})
	NegRatingScores = createCollection(EWQCRatingScoreCriteria2);
   	@viewInfo({containerName: "Weightage Criteria"})
	VenRatingCriWeightage = createCollection(EWQCVendorRatingCriteria);
}
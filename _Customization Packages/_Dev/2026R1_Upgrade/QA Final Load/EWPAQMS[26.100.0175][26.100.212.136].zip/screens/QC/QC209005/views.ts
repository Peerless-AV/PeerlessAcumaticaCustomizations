import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209005 } from "./QC209005";


// Views

export class EWQCVarianceType extends PXView  {

}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCRatingScoreCriteria extends PXView  {

	@columnConfig({width: 180})	Criteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	VarianceIn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	FromVar : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	isabove : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ToVar : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Score : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCRatingScoreCriteria2 extends PXView  {

	@columnConfig({width: 180})	Criteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	VarianceIn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	FromVar : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	Isbelow : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	ToVar : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Score : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
	allowUpdate:false,
})
export class EWQCVendorRatingCriteria extends PXView  {

	@columnConfig({width: 180})	Criteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Weightage : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState;
}
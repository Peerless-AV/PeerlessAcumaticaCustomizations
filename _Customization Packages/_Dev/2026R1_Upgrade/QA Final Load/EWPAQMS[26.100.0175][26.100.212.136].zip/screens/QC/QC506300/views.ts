import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC506300 } from "./QC506300";


// Views

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCLcUsrTran extends PXView  {

	@columnConfig({allowSort: false, width: 30 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 500})	Data : PXFieldState;
	@columnConfig({width: 100})	TranCount : PXFieldState;
}
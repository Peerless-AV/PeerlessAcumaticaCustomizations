import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCLcUsrTran } from "./views";

@graphInfo({graphType: "EW.QC.EWQCLcUsrTranProcess", primaryView: "ProcessRecord", })
export class QC506300 extends PXScreen {

	ProcessRecord = createCollection(EWQCLcUsrTran);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC302000 } from "./QC302000";

export class EWQCInspectionPlanVariableType {
	Name : PXFieldState;	
	Description : PXFieldState;	
	DataType : PXFieldState;	
	TestCategoryID : PXFieldState<PXFieldOptions.CommitChanges>;	
	TestMethodID : PXFieldState<PXFieldOptions.CommitChanges>;	
	Equation : PXFieldState;	
	Unit : PXFieldState;	
}

// Views

export class EWQCInspectionPlan extends PXView  {

	@actionConfig({ popupCommand: "OK" })
	ComboSaveButton: PXActionState;
	InspectionPlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState;
	Description : PXFieldState;
	Remarks : PXFieldState;
	RevisionNo : PXFieldState;
	EffectiveFromDate : PXFieldState;
	EffectiveToDate : PXFieldState;
	Hold : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	initNewRow: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
 
})
export class EWQCInspectionPlanVariable extends PXView  {

	@columnConfig({width: 120})	AddInReports : PXFieldState;
	@columnConfig({editorConfig : {allowEdit:true,fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable : EWQCInspectionPlanVariableType;
	@linkCommand("AddQCTool")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true}})	SeverityLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOperator : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})	TestResultUOM : PXFieldState;
	@columnConfig({width: 220})	AlphaValue : PXFieldState;
	@columnConfig({width: 100})	LeadTimeDurationType : PXFieldState;
	@columnConfig({width: 100})	LeadTimeDuration : PXFieldState;
	@columnConfig({width: 120})	BitGoNoGo : PXFieldState;
	@columnConfig({width: 120})	OptionalTest : PXFieldState;
	@columnConfig({width: 120})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120, editorConfig : {allowEdit:true,fastFilterFields:["Name","Description"]}})	TestGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddCombo")
	@columnConfig({width: 280})	ComboValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState;
	Description : PXFieldState;
	EventType : PXFieldState;
	CreatedByID : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCInspectionPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestComboValues extends PXView  {

	TestComboCD : PXFieldState;
	Description : PXFieldState;
	@columnConfig({width: 120})	ComboCheck : PXFieldState;
}
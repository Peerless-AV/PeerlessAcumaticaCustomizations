import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCInspectionPlan, EWQCInspectionPlanVariable, EWQCEvent, EWQCInspectionPlanTestTool, EWQCTestComboValues } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInspectionPlanMaint", primaryView: "Documents", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC302000 extends PXScreen {

	Documents = createSingle(EWQCInspectionPlan);
   	@viewInfo({containerName: "Tests"})
	PlanVariables = createCollection(EWQCInspectionPlanVariable);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "Tools"})
	InsapectionToolSteps = createCollection(EWQCInspectionPlanTestTool);
   	@viewInfo({containerName: "Combo Values"})
	TestInspectionComboValues = createCollection(EWQCTestComboValues);
}
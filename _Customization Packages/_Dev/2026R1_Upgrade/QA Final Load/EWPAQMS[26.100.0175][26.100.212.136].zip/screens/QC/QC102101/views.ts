import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC102101 } from "./QC102101";


// Views

export class EWQCSetup extends PXView  {

	@controlConfig({allowEdit:true})
	ServiceQCNumerSequenceID :PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	QCChecklistOrderNumberSequenceID :PXFieldState<PXFieldOptions.CommitChanges>;
	ErrorRequiredOnServiceQC : PXFieldState<PXFieldOptions.CommitChanges>;
	EnableServiceQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC504041 } from "./QC504041";


// Views

export class EWQCPrimaryFilter extends PXView  {

	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	SiteID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotStatus: PXFieldState<PXFieldOptions.CommitChanges>;
	ExpireDate : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCAdhocProcess extends PXView  {

	@columnConfig({width: 60 ,allowCheckAll: true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	InventoryDesc : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	ItemClassID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LotSerialNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 80})	QtyOnHand : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	ExpireDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	SiteID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LotStatus: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150, editorConfig : {allowEdit:true,displayMode:"text"}})	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {allowEdit:true}})	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	OrderDate : PXFieldState<PXFieldOptions.CommitChanges>;
}
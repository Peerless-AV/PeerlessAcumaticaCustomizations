import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301008 } from "./QC301008";

export class EWQCStabilityPlanningDetailType {
	Status : PXFieldState;	
}
export class EWQCPlanVariableType {
	Name : PXFieldState;	
	Description : PXFieldState;	
	Equation : PXFieldState;	
	DataType : PXFieldState;	
	TestCategoryID : PXFieldState<PXFieldOptions.CommitChanges>;	
	TestMethodID : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCStabilityPlanning extends PXView  {
@actionConfig({ popupCommand: "OK" })
	ComboSaveButton: PXActionState;

	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCreation : PXFieldState;
	RetentionWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	RetentionLocationID : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
    autoRepaint: ["PlanVariables"],
})
export class EWQCStabilityPlanningDetail extends PXView  {

	@columnConfig({width: 150})	Recur : PXFieldState;
	@columnConfig({width: 150})	ExecutionLimit : PXFieldState;
	@columnConfig({width: 150})	Interval : PXFieldState;
	@columnConfig({width: 150})	IntervalBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewPlanMaster")
	@columnConfig({width: 250, editorConfig : {displayMode:"text"}})	QCPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) EWQCPlan__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) EWQCPlan__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 200 }) EWQCPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	ResultCriteria : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	allowUpdate: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCPlanVariable extends PXView  {

	@columnConfig({width: 120})	AddInReports : PXFieldState;
	@columnConfig({editorConfig : {allowEdit:true,fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable : EWQCPlanVariableType;
	@columnConfig({width: 180, editorConfig : {allowEdit:true,fastFilterFields:["Name","Description"]}})	TestGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddQCTool")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {allowEdit:true,fastFilterFields:["Name","Description"]}})	SeverityLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	CalculationType : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOperator : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})	AlphaValue : PXFieldState;
	@columnConfig({width: 220})	TestResultUOM : PXFieldState;
	@columnConfig({width: 120})	DestructiveTesting : PXFieldState;
	@columnConfig({width: 120})	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120, editorConfig : {}})	UOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LeadTimeDurationType : PXFieldState;
	@columnConfig({width: 100})	LeadTimeDuration : PXFieldState;
	@columnConfig({width: 120})	BitGoNoGo : PXFieldState;
	@columnConfig({width: 120})	OptionalTest : PXFieldState;
	@columnConfig({width: 120})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("AddCombo")
	@columnConfig({width: 280})	ComboValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	allowUpdate: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestComboValues extends PXView  {

	TestComboCD : PXFieldState;
	Description : PXFieldState;
	@columnConfig({width: 120})	ComboCheck : PXFieldState;
}
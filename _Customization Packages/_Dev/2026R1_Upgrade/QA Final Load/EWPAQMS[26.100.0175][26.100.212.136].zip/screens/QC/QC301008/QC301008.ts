import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCStabilityPlanning, EWQCStabilityPlanningDetail, EWQCPlanVariable, EWQCPlanTestTool, EWQCTestComboValues } from "./views";

@graphInfo({graphType: "EW.QC.EWQCStabilityEntry", primaryView: "StabilityQC", showActivitiesIndicator: true, showUDFIndicator: true})
export class QC301008 extends PXScreen {

	StabilityQC = createSingle(EWQCStabilityPlanning);
	StabilityPlanningQC = createCollection(EWQCStabilityPlanningDetail);
	PlanVariables = createCollection(EWQCPlanVariable);
   	@viewInfo({containerName: "Tools"})
	PlanToolSteps = createCollection(EWQCPlanTestTool);
   	@viewInfo({containerName: "Combo Values"})
	TestComboValues = createCollection(EWQCTestComboValues);
}
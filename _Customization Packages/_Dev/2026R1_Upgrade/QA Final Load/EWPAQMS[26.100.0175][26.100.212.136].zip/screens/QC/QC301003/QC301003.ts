import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs } from "client-controls";
import { EWQCInspectionOrder, EWQCInspectionOrderPlanDetail, EWQCInspectionOrderPlanTestDetail, EWQCInspectionOrderPlanChkList, EWQCInsOrdPlanChkListTask, EWQCEvent, EWQCTestStep, EWQCChecklistStep, EWQCInspectionPlanTestTool, EWQCInspectionOrderTestFormula } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInspectionOrderEntry", primaryView: "InspectionOrderEntry", bpEventsIndicator: true, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC301003 extends PXScreen {

	InspectionOrderEntry = createSingle(EWQCInspectionOrder);
   	@viewInfo({containerName: "Plan Detail"})
	InspectionOrderPlanDetail = createCollection(EWQCInspectionOrderPlanDetail);
   	@viewInfo({containerName: "Tests"})
	InspectionOrderPlanTestDetail = createCollection(EWQCInspectionOrderPlanTestDetail);
   	@viewInfo({containerName: "Checklist"})
	InspectionOrderPlanChkList = createCollection(EWQCInspectionOrderPlanChkList);
   	@viewInfo({containerName: "Tasks"})
	InsOrdPlanChkListTask = createCollection(EWQCInsOrdPlanChkListTask);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "Test Steps"})
	TestSteps = createCollection(EWQCTestStep);
   	@viewInfo({containerName: "Test Steps"})
	InspectionOrderPlanChkListSteps = createCollection(EWQCChecklistStep);
   	@viewInfo({containerName: "QC Tool"})
	ToolSteps = createCollection(EWQCInspectionPlanTestTool);
   	@viewInfo({containerName: "Equation"})
	QCOrderTestFormula = createCollection(EWQCInspectionOrderTestFormula);

    @handleEvent(CustomEventType.GetCellCss, { view: "InspectionOrderPlanDetail", column: "PassedTestCount" })
    getPassedTestCountCss(args: CellCssHandlerArgs<PXViewCollection<EWQCInspectionOrderPlanDetail>>) {
        const row = args?.selector?.row;
        if (row?.PassedTestCount.value > 0)
            return "PassTest";
        else
            return undefined;
    }

    @handleEvent(CustomEventType.GetCellCss, { view: "InspectionOrderPlanDetail", column: "FailedTestCount" })
    getFailedTestCountCss(args: CellCssHandlerArgs<PXViewCollection<EWQCInspectionOrderPlanDetail>>) {
        const row = args?.selector?.row;
        if (row?.FailedTestCount.value > 0)
            return "FailTest";
        else
            return undefined;
    }

    @handleEvent(CustomEventType.GetCellCss, { view: "InspectionOrderPlanTestDetail", column: "ActualResult" })
    getActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCInspectionOrderPlanTestDetail>>) {
        const row = args?.selector?.row;
        if (row?.ActualResult.value === "F")
            return "FailTest";
        else if (row?.ActualResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }

    @handleEvent(CustomEventType.GetCellCss, { view: "InspectionOrderPlanTestDetail", column: "FinalResult" })
    getFinalResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCInspectionOrderPlanTestDetail>>) {
        const row = args?.selector?.row;
        if (row?.FinalResult.value === "F")
            return "FailTest";
        else if (row?.FinalResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }
}
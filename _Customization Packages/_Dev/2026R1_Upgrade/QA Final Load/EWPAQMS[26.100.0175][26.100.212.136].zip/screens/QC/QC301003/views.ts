import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301003 } from "./QC301003";

export class EWQCInspectionOrderPlanDetailType {
	InspectionPlanCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCInspectionOrderPlanTestDetailType {
	VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	Unit : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCInspectionOrderPlanChkListType {
	ChecklistGroupCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	ChecklistCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCChecklistStepType {
	ChecklistStepID : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCInspectionOrder extends PXView  {
	
	@actionConfig({ popupCommand: "OK" })
	submitFormula: PXActionState;

	OrderDate : PXFieldState<PXFieldOptions.Disabled>;
	QCInspectionOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	OnHold : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentType : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({ allowEdit: true, linkCommand: "RefDocNumbers" })
	RefDocumentNbr : PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["InspectionOrderPlanTestDetail"]

})
export class EWQCInspectionOrderPlanDetail extends PXView  {

	@linkCommand("ViewInspectionPlan")
	@columnConfig({width: 180}) EWQCInspectionPlan__InspectionPlanCD : PXFieldState<PXFieldOptions.CommitChanges>;
    EWQCInspectionPlan__Name : PXFieldState<PXFieldOptions.CommitChanges>;
    EWQCInspectionPlan__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewInventoryItem")
    @columnConfig({width: 140}) InventoryItem__InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;
	DisplayBOMID : PXFieldState<PXFieldOptions.CommitChanges>;
	OperationCD : PXFieldState<PXFieldOptions.CommitChanges>;
	PassedTestCount : PXFieldState<PXFieldOptions.CommitChanges>;
	FailedTestCount : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCInspectionOrderPlanTestDetail extends PXView  {

	@linkCommand("ViewTest")
	@columnConfig({width: 180, editorConfig : {allowEdit:true}})	EWQCVariable__VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoSteps")
	@columnConfig({width: 180})	Steps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestCategory__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestMethod__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoToolSteps")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCSeverityLevel__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	 @columnConfig({width: 180})	EWQCVariable__Unit : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewAssignedToID")
	@columnConfig({width: 140, editorConfig : {displayMode:"text",fastFilterFields:["AcctCD","AcctName"]}})	AssignedToID : PXFieldState<PXFieldOptions.CommitChanges>;
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("GotoEquation")

	@columnConfig({width: 180})	Formula : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	ExpectedValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})TestValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})	TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})ActualResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220})FinalResult : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 60})	IncludeInReport : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["EWQCInsOrdPlanChkListTask"]
})
export class EWQCInspectionOrderPlanChkList extends PXView  {

	@linkCommand("ViewChecklistGroup")
	@columnConfig({width: 150})	EWQCChecklistGroup__ChecklistGroupCD :  PXFieldState<PXFieldOptions.CommitChanges>;  
	EWQCChecklistGroup__Description :  PXFieldState<PXFieldOptions.CommitChanges>; 
	@linkCommand("ViewCheckListItem")
	@columnConfig({width: 150})	EWQCChecklist__ChecklistCD :  PXFieldState<PXFieldOptions.CommitChanges>; 
	@columnConfig({width: 90})	EWQCChecklist__Name :  PXFieldState<PXFieldOptions.CommitChanges>; 
	@columnConfig({width: 90})	EWQCChecklist__Description :  PXFieldState<PXFieldOptions.CommitChanges>; 
	@columnConfig({width: 90})	Completed : PXFieldState<PXFieldOptions.CommitChanges>;       
	@columnConfig({width: 150})	Executedby : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ExecutedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 250})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCInsOrdPlanChkListTask extends PXView  {

	@columnConfig({width: 400})	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 600})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowSort: false, width: 90})	Completed : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Executedby : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ExecutedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 600})	Remark : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({width: 180})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 240})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestStep extends PXView  {

	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCChecklistStep extends PXView  {

	EWQCChecklistStep : EWQCChecklistStepType;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCInspectionPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCInspectionOrderTestFormula extends PXView  {

	ParameterName: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCTestParameter__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	FormulaValue : PXFieldState<PXFieldOptions.CommitChanges>;
}
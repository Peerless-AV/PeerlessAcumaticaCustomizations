import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209016 } from "./QC209016";


// Views

export class EWQCEvaluateVendorPerformancePOPRDetail extends PXView  {

	Type : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvaluateVendorPerformancePOPRDetail2 extends PXView  {

	@linkCommand("ViewVendors")
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("POOrder")
	@columnConfig({width: 180})	PONbr : PXFieldState;
	@columnConfig({width: 180})	PODate : PXFieldState;
	POQty : PXFieldState;
	POUOM : PXFieldState;
	@linkCommand("PROrder")
	ReceiptNbr : PXFieldState;
	ReceiptDate : PXFieldState;
	ReceiptQty : PXFieldState;
	PRUOM : PXFieldState;
	@linkCommand("ViewOrder")
	QCOrderID : PXFieldState;
	@linkCommand("ViewStockItem")
	InventoryID : PXFieldState;
	PriceScore : PXFieldState;
	PriceVariance : PXFieldState;
	PriceRank : PXFieldState;
	@columnConfig({width: 0})	RatingScore : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvaluateVendorPerformancePOPRDetail3 extends PXView  {

	@linkCommand("ViewVendors")
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("POOrder")
	@columnConfig({width: 180})	PONbr : PXFieldState;
	@columnConfig({width: 180})	PODate : PXFieldState;
	POQty : PXFieldState;
	POUOM : PXFieldState;
	@linkCommand("PROrder")
	ReceiptNbr : PXFieldState;
	ReceiptDate : PXFieldState;
	ReceiptQty : PXFieldState;
	PRUOM : PXFieldState;
	@linkCommand("ViewOrder")
	QCOrderID : PXFieldState;
	@linkCommand("ViewStockItem")
	InventoryID : PXFieldState;
	QualityScore : PXFieldState;
	QualityVariance : PXFieldState;
	QualityRank : PXFieldState;
	@columnConfig({width: 0})	RatingScore : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvaluateVendorPerformancePOPRDetail4 extends PXView  {

	@linkCommand("ViewVendors")
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("POOrder")
	@columnConfig({width: 180})	PONbr : PXFieldState;
	@columnConfig({width: 180})	PODate : PXFieldState;
	POQty : PXFieldState;
	POUOM : PXFieldState;
	@linkCommand("PROrder")
	ReceiptNbr : PXFieldState;
	ReceiptDate : PXFieldState;
	ReceiptQty : PXFieldState;
	PRUOM : PXFieldState;
	@linkCommand("ViewOrder")
	QCOrderID : PXFieldState;
	@linkCommand("ViewStockItem")
	InventoryID : PXFieldState;
	QuantitySuppliedScore : PXFieldState;
	QuantitySuppliedVariance : PXFieldState;
	QuantitySuppliedRank : PXFieldState;
	@columnConfig({width: 0})	RatingScore : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvaluateVendorPerformancePOPRDetail5 extends PXView  {

	@linkCommand("ViewVendors")
	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("POOrder")
	@columnConfig({width: 180})	PONbr : PXFieldState;
	@columnConfig({width: 180})	PODate : PXFieldState;
	POQty : PXFieldState;
	POUOM : PXFieldState;
	@linkCommand("PROrder")
	ReceiptNbr : PXFieldState;
	ReceiptDate : PXFieldState;
	ReceiptQty : PXFieldState;
	PRUOM : PXFieldState;
	@linkCommand("ViewOrder")
	QCOrderID : PXFieldState;
	@linkCommand("ViewStockItem")
	InventoryID : PXFieldState;
	OnTimeDeliverScore : PXFieldState;
	OnTimeDeliverVariance : PXFieldState;
	OnTimeDeliverRank : PXFieldState;
	@columnConfig({width: 0})	RatingScore : PXFieldState;
}
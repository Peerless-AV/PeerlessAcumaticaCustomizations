import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCEvaluateVendorPerformancePOPRDetail, EWQCEvaluateVendorPerformancePOPRDetail2, EWQCEvaluateVendorPerformancePOPRDetail3, EWQCEvaluateVendorPerformancePOPRDetail4, EWQCEvaluateVendorPerformancePOPRDetail5 } from "./views";

@graphInfo({graphType: "EW.QC.EWQCEvaluateLastVendorPerformanceMaint", primaryView: "VendorPerformance", })
export class QC209016 extends PXScreen {

	VendorPerformance = createSingle(EWQCEvaluateVendorPerformancePOPRDetail);
   	@viewInfo({containerName: "Price"})
	PriceCriteria = createCollection(EWQCEvaluateVendorPerformancePOPRDetail2);
   	@viewInfo({containerName: "Quality"})
	QualityCriteria = createCollection(EWQCEvaluateVendorPerformancePOPRDetail3);
   	@viewInfo({containerName: "Quantity Supplied"})
	QuantitySuppliedCriteria = createCollection(EWQCEvaluateVendorPerformancePOPRDetail4);
   	@viewInfo({containerName: "On Time Delivery"})
	OnTimeDeliveryCriteria = createCollection(EWQCEvaluateVendorPerformancePOPRDetail5);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter, IDropDownConfig } from "client-controls";
import { QC209006 } from "./QC209006";


// Views

export class EWQCVendorPerformanceWizard extends PXView  {

	ItemClassID: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<IDropDownConfig>({ required: true })	
	TimePeriod : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	Year : PXFieldState<PXFieldOptions.CommitChanges>;
	Month: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<IDropDownConfig>({ required: true })	
	Quarter : PXFieldState<PXFieldOptions.CommitChanges>;
	DateFrom : PXFieldState<PXFieldOptions.CommitChanges>;
	DateTo : PXFieldState<PXFieldOptions.CommitChanges>;
	InventoryFilter : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class InventoryItem extends PXView  {

	@columnConfig({width: 40 ,allowCheckAll:true})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true, width: 150, editorConfig : {}})	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 300})	Descr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 300, editorConfig: {} }) ItemClassID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300 }) UsrTimePeriod: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300, editorConfig: {} }) UsrYear: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300, editorConfig: {} }) UsrMonth: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300 }) UsrQuarter: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300 }) UsrDateFrom: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300 }) UsrDateTo: PXFieldState<PXFieldOptions.CommitChanges>;

}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCVendorPerformanceWizard, InventoryItem } from "./views";

@graphInfo({graphType: "EW.QC.EWQCVendorPerformanceWizardMaint", primaryView: "InventoryItems", })
export class QC209006 extends PXScreen {

	Wizard = createSingle(EWQCVendorPerformanceWizard);
	InventoryItems = createCollection(InventoryItem);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCSamplingPlan } from "./views";

@graphInfo({graphType: "EW.QC.EWQCSamplingPlanActivateMaint", primaryView: "ProcessPlan", })
export class QC505102 extends PXScreen {

	ProcessPlan = createCollection(EWQCSamplingPlan);
}
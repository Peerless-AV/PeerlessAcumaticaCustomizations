import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC305200 } from "./QC305200";

export class EWQCNCTranType {
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	InventoryCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCNCCapaTran extends PXView  {

	@actionConfig({ popupCommand: "OK" })
	addUpdateInvestigation : PXActionState;
	@actionConfig({ popupCommand: "OK" })
	addUpdateCorrectiveAction : PXActionState;
	@actionConfig({ popupCommand: "OK" })
	addUpdatePreventiveAction : PXActionState;
	@actionConfig({ popupCommand: "OK" })
	addUpdateVerification: PXActionState;

	CapaTranCD : PXFieldState<PXFieldOptions.CommitChanges>;
	CreatedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	Priority : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({displayMode:"text",fastFilterFields:["AcctCD","AcctName"]})
	Owner : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCCapaTran2 extends PXView  {

	@controlConfig<ISelectorControlConfig>({displayMode:"text",fastFilterFields:["AcctCD","AcctName"]})
	AssignedTo : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	Category : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	Type : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["DepartmentID","Description"]})
	Department : PXFieldState<PXFieldOptions.CommitChanges>;
	StartDate : PXFieldState<PXFieldOptions.CommitChanges>;
	CompletionDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Name","Description"]})
	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	DetailCompletedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	IsOriginCompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	IsInvCompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	InvCompletedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	InvCompletedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	IsCACompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	CACompletedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	CACompletedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	IsPACompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	PACompletedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	PACompletedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	IsVrfCompleted : PXFieldState<PXFieldOptions.CommitChanges>;
	VrfCompletedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	VrfCompletedBy : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCNCTran extends PXView  {

	@linkCommand("viewNcNumber")
	@columnConfig({width: 180})	NCTranCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	NCDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCPriority : EWQCNCTranType;
	@linkCommand("viewReportedBy")
	@columnConfig({width: 180})	RepotedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Source : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewNcDocNumber")
	@columnConfig({width: 180})	RefDocNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewInventoryId")
	@columnConfig({width: 180})	InventoryItem : EWQCNCTranType;
	@columnConfig({ hideViewLink: true, width: 180})LotNumber : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowInsert: false,
	topBarItems: {
	AddInvestigation: {index: 0, config: {commandName: "AddInvestigation", text: "Add"}},
}
})
export class EWQCNCCapaInvestigation extends PXView  {

	AddInvestigation : PXActionState;
	@columnConfig({width: 0})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("UpdateInvestigation")
	View : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	InvDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	UnformattedDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	InvStartDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	InvEndDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowInsert: false,
	topBarItems: {
	AddCorrectiveAction: {index: 0, config: {commandName: "AddCorrectiveAction", text: "Add"}},
}
})
export class EWQCNCCapaCorrectiveAction extends PXView  {

	AddCorrectiveAction : PXActionState;
	@columnConfig({width: 0})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("UpdateCorrectiveAction")
	View : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	CADescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	UnformattedDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewCAActionBy")
	@columnConfig({width: 180})	CAActionBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	CAActionOn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowInsert: false,
	topBarItems: {
	AddPreventiveAction: {index: 0, config: {commandName: "AddPreventiveAction", text: "Add"}},
}
})
export class EWQCNCCapaPreventiveAction extends PXView  {

	AddPreventiveAction : PXActionState;
	@columnConfig({width: 0})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("UpdatePreventiveAction")
	View : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	PADescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	UnformattedDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewPAActionBy")
	@columnConfig({width: 180})	PAActionBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	PAActionOn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	allowInsert: false,
	topBarItems: {
	AddVerification: {index: 0, config: {commandName: "AddVerification", text: "Add"}},
}
})
export class EWQCNCCapaVerification extends PXView  {

	AddVerification : PXActionState;
	@columnConfig({width: 0})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("UpdateVerification")
	View : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 0})	VrfDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	UnformattedDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewVerifiedBy")
	@columnConfig({width: 180})	VrfVerifiedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("viewApprovedBy")
	@columnConfig({width: 180})	VrfApprovedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	VrfVerifiedOn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	VrfApprovedOn : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	ActionBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	VerifiedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	LineNumber : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCCapaInvestigation2 extends PXView  {

	InvDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	InvStartDate : PXFieldState<PXFieldOptions.CommitChanges>;
	InvEndDate : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCCapaCorrectiveAction2 extends PXView  {

	CADescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	CAActionBy : PXFieldState<PXFieldOptions.CommitChanges>;
	CAActionOn : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCCapaPreventiveAction2 extends PXView  {

	PADescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	PAActionBy : PXFieldState<PXFieldOptions.CommitChanges>;
	PAActionOn : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCNCCapaVerification2 extends PXView  {

	VrfDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	VrfVerifiedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	VrfVerifiedOn : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({displayMode:"text"})
	VrfApprovedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	VrfApprovedOn : PXFieldState<PXFieldOptions.CommitChanges>;
}
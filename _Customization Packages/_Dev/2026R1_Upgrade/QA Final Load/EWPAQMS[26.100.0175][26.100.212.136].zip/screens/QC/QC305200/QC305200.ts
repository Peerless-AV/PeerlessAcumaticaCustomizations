import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCNCCapaTran, EWQCNCCapaTran2, EWQCNCTran, EWQCNCCapaInvestigation, EWQCNCCapaCorrectiveAction, EWQCNCCapaPreventiveAction, EWQCNCCapaVerification, EWQCEvent, EWQCNCCapaInvestigation2, EWQCNCCapaCorrectiveAction2, EWQCNCCapaPreventiveAction2, EWQCNCCapaVerification2 } from "./views";

@graphInfo({graphType: "EW.QC.EWQCNCCapaTranEntry", primaryView: "NCCapaTran", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC305200 extends PXScreen {

   	@viewInfo({containerName: "CAPA Transaction"})
	NCCapaTran = createSingle(EWQCNCCapaTran);
   	@viewInfo({containerName: "Origin Tab"})
	NCCapaTranSelected = createSingle(EWQCNCCapaTran2);
   	@viewInfo({containerName: "Origin Tab"})
	NCCAPADetails = createCollection(EWQCNCTran);
   	@viewInfo({containerName: "Investigation"})
	NCCapaInvestigation = createCollection(EWQCNCCapaInvestigation);
   	@viewInfo({containerName: "Corrective Action"})
	NCCapaCorrectiveAction = createCollection(EWQCNCCapaCorrectiveAction);
   	@viewInfo({containerName: "Preventive Action"})
	NCCapaPreventiveAction = createCollection(EWQCNCCapaPreventiveAction);
   	@viewInfo({containerName: "Verification"})
	NCCapaVerification = createCollection(EWQCNCCapaVerification);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "Investigation"})
	InvestigationSmartPanel = createSingle(EWQCNCCapaInvestigation2);
   	@viewInfo({containerName: "Corrective Action"})
	CorrectiveActionSmartPanel = createSingle(EWQCNCCapaCorrectiveAction2);
   	@viewInfo({containerName: "Preventive Action"})
	PreventiveActionSmartPanel = createSingle(EWQCNCCapaPreventiveAction2);
   	@viewInfo({containerName: "Verification"})
	VerificationSmartPanel = createSingle(EWQCNCCapaVerification2);
}
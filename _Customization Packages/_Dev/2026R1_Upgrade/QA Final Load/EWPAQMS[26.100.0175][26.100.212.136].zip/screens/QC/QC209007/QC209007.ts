import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCEvaluateVendorPerformance, EWQCEvaluateVendorPerformanceDetail, EWQCVendorRatingCriteria } from "./views";

@graphInfo({graphType: "EW.QC.EWQCEvaluateVendorPerformanceMaint", primaryView: "VendorPerformance", })
export class QC209007 extends PXScreen {

	VendorPerformance = createSingle(EWQCEvaluateVendorPerformance);
   	@viewInfo({containerName: "General"})
	VendorPerformanceDetail = createCollection(EWQCEvaluateVendorPerformanceDetail);
   	@viewInfo({containerName: "Weightage Criteria"})
	VendorRatingCriteriaWeightage = createCollection(EWQCVendorRatingCriteria);
}
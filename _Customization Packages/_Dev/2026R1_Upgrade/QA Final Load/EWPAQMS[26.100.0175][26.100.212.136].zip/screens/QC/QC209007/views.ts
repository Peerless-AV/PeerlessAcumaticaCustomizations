import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209007 } from "./QC209007";

export class EWQCEvaluateVendorPerformanceDetailType {
	AcctCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCEvaluateVendorPerformance extends PXView  {

	ItemClassID : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	TimePeriod : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	Year : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	Month : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	Quarter : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	EffectiveFromDate : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>
	EffectiveToDate : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCEvaluateVendorPerformanceDetail extends PXView  {

	@columnConfig({width: 150})	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	BAccount : EWQCEvaluateVendorPerformanceDetailType;
	@columnConfig({width: 150})	VendorName : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	NewRank : PXFieldState;
	@columnConfig({width: 150})	NewScore : PXFieldState;
	@columnConfig({width: 150})	QualityVariance : PXFieldState;
	@columnConfig({width: 150})	Quality : PXFieldState;
	@columnConfig({width: 150})	QuantitySuppliedVariance : PXFieldState;
	@columnConfig({width: 150})	QuantitySupplied : PXFieldState;
	@columnConfig({width: 150})	DeliveryVariance : PXFieldState;
	@columnConfig({width: 150})	Delivery : PXFieldState;
	@columnConfig({width: 150})	PriceVariance : PXFieldState;
	@columnConfig({width: 150})	Price : PXFieldState;
	@linkCommand("VenderPerf")
	@columnConfig({width: 150})	ShowReport : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class EWQCVendorRatingCriteria extends PXView  {

	@columnConfig({width: 180})	Criteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Weightage : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState;
}
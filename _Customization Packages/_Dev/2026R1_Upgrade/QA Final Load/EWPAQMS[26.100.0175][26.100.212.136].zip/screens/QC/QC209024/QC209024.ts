import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCInventoryLotStatus } from "./views";

@graphInfo({graphType: "EW.QC.EWQCLotSerialIMEX", primaryView: "EWQCInventoryLotStatusImportExport", })
export class QC209024 extends PXScreen {

	EWQCInventoryLotStatusImportExport = createCollection(EWQCInventoryLotStatus);
}
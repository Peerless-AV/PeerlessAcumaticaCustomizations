import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209024 } from "./QC209024";


// Views

export class EWQCInventoryLotStatus extends PXView  {

	@columnConfig({width: 150, editorConfig : {}})	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	WarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, editorConfig : {}})	StatusID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	Reason : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209002 } from "./QC209002";

export class EWQCChecklistGroupVariableType {
	Name : PXFieldState;	
}

// Views

export class EWQCChecklistGroup extends PXView  {

	ChecklistGroupCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCChecklistGroupVariable extends PXView  {

	@columnConfig({editorConfig : {allowEdit:true,fastFilterFields:["Name","Description"]}})	ChecklistID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCChecklist : EWQCChecklistGroupVariableType;
	LineNbr : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState;
	Description : PXFieldState;
	EventType : PXFieldState;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState;
}
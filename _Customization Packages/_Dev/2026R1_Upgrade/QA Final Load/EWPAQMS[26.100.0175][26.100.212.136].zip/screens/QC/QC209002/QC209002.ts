import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCChecklistGroup, EWQCChecklistGroupVariable, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCChecklistGroupMaint", primaryView: "EWQCChecklistGroup", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC209002 extends PXScreen {

	EWQCChecklistGroup = createSingle(EWQCChecklistGroup);
   	@viewInfo({containerName: "CheckList"})
	EWQCChecklistGroupVariable = createCollection(EWQCChecklistGroupVariable);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
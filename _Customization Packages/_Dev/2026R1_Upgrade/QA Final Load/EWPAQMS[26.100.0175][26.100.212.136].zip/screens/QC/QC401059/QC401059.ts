import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTnCMaint } from "./views";

@graphInfo({graphType: "EW.QC.EWQCToolSourceNavigationMaint", primaryView: "Documents", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC401059 extends PXScreen {

	Documents = createSingle(EWQCTnCMaint);
}
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401059 } from "./QC401059";


// Views

export class EWQCTnCMaint extends PXView  {

	ToolID : PXFieldState<PXFieldOptions.CommitChanges>;
	ToolSource : PXFieldState<PXFieldOptions.CommitChanges>;
}
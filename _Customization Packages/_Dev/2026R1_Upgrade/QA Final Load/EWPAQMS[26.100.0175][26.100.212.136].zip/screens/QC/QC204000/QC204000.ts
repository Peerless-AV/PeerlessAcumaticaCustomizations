import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCVariable, EWQCTestStep, EWQCTestParameter, EWQCTestTool, EWQCTestComboValues, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCVariableMaint", primaryView: "Variables", pageLoadBehavior: PXPageLoadBehavior.GoLastRecord, showUDFIndicator: true})
export class QC204000 extends PXScreen {

	Variables = createSingle(EWQCVariable);
   	@viewInfo({containerName: "Test Steps"})
	TestSteps = createCollection(EWQCTestStep);
   	@viewInfo({containerName: "Parameters"})
	TestParameters = createCollection(EWQCTestParameter);
   	@viewInfo({containerName: "QC Tools"})
	TestTool = createCollection(EWQCTestTool);
   	@viewInfo({containerName: "COMBO VALUES"})
	TestComboValues = createCollection(EWQCTestComboValues);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
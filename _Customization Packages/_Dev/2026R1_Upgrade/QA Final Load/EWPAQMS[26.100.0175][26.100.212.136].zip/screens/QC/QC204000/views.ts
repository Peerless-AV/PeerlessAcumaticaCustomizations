import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter, IDropDownConfig } from "client-controls";
import { QC204000 } from "./QC204000";


// Views

export class EWQCVariable extends PXView  {

	VariableCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<IDropDownConfig>({ required: true })	
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({allowEdit:true,fastFilterFields:["Name","Description"]})
	TestCategoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({allowEdit:true,fastFilterFields:["Name","Description"]})
	TestMethodID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({
        editorType: "qp-formula-editor"})
    Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	Unit : PXFieldState<PXFieldOptions.CommitChanges>;
	TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	DestructiveTesting: PXFieldState<PXFieldOptions.CommitChanges>;
	AttributeID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestStep extends PXView  {

	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestParameter extends PXView  {

	TestParameterCD : PXFieldState<PXFieldOptions.CommitChanges>;
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestTool extends PXView  {

	//@columnConfig({ editorConfig: { fastFilterFields: ["ToolGaugeCD", "Description"] } })
	ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestComboValues extends PXView  {

	TestComboCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 130})CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}
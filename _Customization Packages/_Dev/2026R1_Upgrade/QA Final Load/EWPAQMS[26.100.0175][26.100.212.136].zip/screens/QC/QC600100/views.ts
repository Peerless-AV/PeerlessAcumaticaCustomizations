import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC600100 } from "./QC600100";


// Views

export class EWQCLotTraceabilityFilter extends PXView  {

	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	LotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	DecimalPrecision : PXFieldState<PXFieldOptions.CommitChanges>;
	Receiving : PXFieldState<PXFieldOptions.CommitChanges>;
	ReturnToVendor : PXFieldState<PXFieldOptions.CommitChanges>;
	Transfer : PXFieldState<PXFieldOptions.CommitChanges>;
	KitAssembly : PXFieldState<PXFieldOptions.CommitChanges>;
	Production : PXFieldState<PXFieldOptions.CommitChanges>;
	Sales : PXFieldState<PXFieldOptions.CommitChanges>;
	CustomerReturn : PXFieldState<PXFieldOptions.CommitChanges>;
}
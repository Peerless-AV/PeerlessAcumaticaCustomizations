import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTestMethod } from "./views";

@graphInfo({graphType: "EW.QC.EWQCTestMethodMaint", primaryView: "TestMethods", })
export class QC201300 extends PXScreen {

	TestMethods = createCollection(EWQCTestMethod);
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCPriority } from "./views";

@graphInfo({graphType: "EW.QC.EWQCPriorityMaint", primaryView: "Priorities", })
export class QC205100 extends PXScreen {

	Priorities = createCollection(EWQCPriority);
}
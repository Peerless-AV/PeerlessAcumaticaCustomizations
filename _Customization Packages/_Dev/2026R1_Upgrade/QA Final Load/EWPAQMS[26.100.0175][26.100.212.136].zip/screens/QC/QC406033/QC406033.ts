import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCInventorySummaryEnqFilter, EWQCInventorySummaryEnquiryResult, EWQCInventoryLotStatus } from "./views";

@graphInfo({graphType: "EW.QC.EWQCInventorySummaryEnq", primaryView: "Filter", pageLoadBehavior: PXPageLoadBehavior.PopulateSavedValues})
export class QC406033 extends PXScreen {

   	@viewInfo({containerName: "Selection"})
	Filter = createSingle(EWQCInventorySummaryEnqFilter);
   	@viewInfo({containerName: "Inventory Summary"})
	ISERecords = createCollection(EWQCInventorySummaryEnquiryResult);
   	@viewInfo({containerName: "Lot Status Details"})
	LotStatusDetails = createCollection(EWQCInventoryLotStatus);
}
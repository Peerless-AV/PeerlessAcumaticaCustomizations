import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC406033 } from "./QC406033";

export class EWQCInventoryLotStatusType {
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCInventorySummaryEnqFilter extends PXView  {

	OrgBAccountID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({allowEdit:true})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	ExpandByLotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	ExpandByCostLayerType : PXFieldState<PXFieldOptions.CommitChanges>;
	ExpandByLotSerialStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Descr"]})
	SubItemCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Descr"]})
	SiteID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Descr"]})
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	fastFilterByAllFields: false,
	showFastFilter: GridFastFilterVisibility.ToolBar,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry,
	topBarItems: {
	ViewLotStatusDetails: {index: 0, config: {commandName: "ViewLotStatusDetails", text: "LotStatus"}},
}
})
export class EWQCInventorySummaryEnquiryResult extends PXView  {

	ViewLotStatusDetails : PXActionState;
	@linkCommand("ViewAllocDet")
	@columnConfig({format: ">AAAAAAAAAA", allowFastFilter: true})	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({format: ">AA-A-A"})	SubItemID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ format: ">AAAAAAAAAA", allowFastFilter: true, hideViewLink: true })	SiteID : PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewLotStatusDetails")
	LotStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowShowHide: GridColumnShowHideMode.Server})	CostLayerType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyAvail : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyHardAvail : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyActual : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyNotAvail : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOBooked : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOShipping : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOShipped : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOBackOrdered : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyINIssues : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyINReceipts : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyInTransit : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyInTransitToSO : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProductionSupplyPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProductionSupply : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProdFixedProdOrdersPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProdFixedProdOrders : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedProductionPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedProductionOrders : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProdFixedSalesOrdersPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProdFixedSalesOrders : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProductionDemandPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProductionDemand : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProductionAllocated : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProdFixedProduction : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyProdFixedPurchase : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOFixedProduction : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyInAssemblyDemand : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyInAssemblySupply : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOOrders : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOReceipts : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyExpired : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyOnHand : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySOFixed : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedOrders : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedReceipts : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtySODropShip : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPODropShipOrders : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPODropShipPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPODropShipReceipts : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyFSSrvOrdPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyFSSrvOrdBooked : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyFSSrvOrdAllocated : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyFixedFSSrvOrd : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedFSSrvOrd : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedFSSrvOrdPrepared : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowNull: false, width: 100})	QtyPOFixedFSSrvOrdReceipts : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true , allowNull: false, format: ">aaaaaa"})	BaseUnit : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	UnitCost : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	TotalCost : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120, allowShowHide: GridColumnShowHideMode.Server})	LotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 90, allowShowHide: GridColumnShowHideMode.Server})	ExpireDate : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCInventoryLotStatus extends PXView  {

	@columnConfig({width: 150})	LotSerNumVal : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	StatusID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) EWQCLotLocStatus__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 80})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
}
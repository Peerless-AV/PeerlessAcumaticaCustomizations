
import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC501012 } from "./QC501012";


// Views

export class EWQCOrderFilter extends PXView {

	QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Action: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Inquiry
})
export class EWQCOrder extends PXView {

	@columnConfig({ width: 60, allowCheckAll: true }) Selected: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewOrder")
	@columnConfig({ width: 100 }) QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewPlan")
	@columnConfig({ width: 100 }) PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewStockItem")
	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewSampling")
	@columnConfig({ width: 100 }) SamplingPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	QCType: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewRefNumber")
	RefDocumentNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentType: PXFieldState<PXFieldOptions.CommitChanges>;
	Status: PXFieldState<PXFieldOptions.CommitChanges>;
}
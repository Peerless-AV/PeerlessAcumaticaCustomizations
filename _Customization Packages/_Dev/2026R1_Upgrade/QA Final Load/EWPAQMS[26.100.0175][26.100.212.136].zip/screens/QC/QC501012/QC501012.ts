import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCOrderFilter, EWQCOrder } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCOrderStatusChangeProcess", primaryView: "Filter", bpEventsIndicator: true})
export class QC501012 extends PXScreen {

	Filter = createSingle(EWQCOrderFilter);
	OrderSampling = createCollection(EWQCOrder);
}
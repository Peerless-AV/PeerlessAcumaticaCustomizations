import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401056 } from "./QC401056";


// Views

export class EWQCOrder extends PXView  {

	RefDocumentType : PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCOrder } from "./views";

@graphInfo({graphType: "EW.QC.EWQCOrderNavigationMaint", primaryView: "Documents", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC401056 extends PXScreen {

	Documents = createSingle(EWQCOrder);
}
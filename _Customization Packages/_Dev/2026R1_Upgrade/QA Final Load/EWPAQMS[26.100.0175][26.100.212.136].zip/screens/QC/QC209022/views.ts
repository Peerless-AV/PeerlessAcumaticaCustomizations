import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209022 } from "./QC209022";


// Views

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTnCOrder extends PXView  {

	@linkCommand("ViewToolID")
	@columnConfig({width: 364})	ToolID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 364})	ToolSource : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("RefOrderNbr")
	@columnConfig({width: 365})	TnCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 364})	Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 364})	CalibrationScheduledType : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTnCOrder } from "./views";

@graphInfo({graphType: "EW.QC.EWQCTnCDisplay", primaryView: "TnCOrder", })
export class QC209022 extends PXScreen {

	TnCOrder = createCollection(EWQCTnCOrder);
}
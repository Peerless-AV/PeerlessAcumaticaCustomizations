import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC401057 } from "./QC401057";


// Views

export class EWQCOrderNS extends PXView  {

	ItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	ArticleID : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCAdhocOrder, EWQCInventoryDetail, EWQCAdhocOrderDetail, EWQCInventoryLotStatusQC } from "./views";

@graphInfo({graphType: "EW.QC.EWQCAdhocOrderEntry", primaryView: "adhocOrder", bpEventsIndicator: true, showActivitiesIndicator: true})
export class QC301100 extends PXScreen {

	adhocOrder = createSingle(EWQCAdhocOrder);
	InventoryDetail = createSingle(EWQCInventoryDetail);
	adhocOrderDetail = createCollection(EWQCAdhocOrderDetail);
	
	EWQCLotPanelView = createCollection(EWQCInventoryLotStatusQC);
}
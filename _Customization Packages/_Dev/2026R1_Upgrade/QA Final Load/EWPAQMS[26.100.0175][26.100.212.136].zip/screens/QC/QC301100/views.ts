import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301100 } from "./QC301100";

export class EWQCInventoryDetailType {
	Description : PXFieldState<PXFieldOptions.Disabled>;	
}

// Views

export class EWQCAdhocOrder extends PXView  {

	Barcode : PXFieldState;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["InventoryCD","Descr"]})
	InventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["InventoryCD","Descr"]})
	UsrInventoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig<ISelectorControlConfig>({displayMode:"text",fastFilterFields:["Name","RevisonNo"]})
	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	PlanDescription : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true,displayMode:"text"})
	SamplingPlanID : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	LotSerWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	NonTrkWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	LocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({fastFilterFields:["Descr"]})
	UsrQCWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrQCLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCInventoryDetail extends PXView  {

	EWQCSamplingPlan : EWQCInventoryDetailType;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	allowInsert: true,
	initNewRow: true,
	autoRepaint: ["EWQCLotPanelView"],
})
export class EWQCAdhocOrderDetail extends PXView  {

	@columnConfig({ hideViewLink: true, width: 80, editorConfig: {} }) BranchID: PXFieldState<PXFieldOptions.CommitChanges>;
	InventorySource: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink:true , width: 80, editorConfig : {}})	LotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 80})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink:true , width: 80})	ProjectID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 80})	TaskID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
	
})
export class EWQCInventoryLotStatusQC extends PXView {

	@columnConfig({ width: 150 }) QCOrderCD: PXFieldState;
	@columnConfig({ width: 150 }) StatusID: PXFieldState;
	@columnConfig({ width: 100 }) Qty: PXFieldState;
	@columnConfig({ width: 100 }) LotQty: PXFieldState<PXFieldOptions.CommitChanges>;
}
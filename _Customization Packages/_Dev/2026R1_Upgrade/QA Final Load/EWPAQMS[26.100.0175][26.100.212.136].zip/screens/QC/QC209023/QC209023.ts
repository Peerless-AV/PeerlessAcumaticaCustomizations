import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCLotLocStatus } from "./views";

@graphInfo({graphType: "EW.QC.EWQCLotLocStatusMaint", primaryView: "LotLocStatus", pageLoadBehavior: PXPageLoadBehavior.InsertRecord, showUDFIndicator: true})
export class QC209023 extends PXScreen {

	LotLocStatus = createCollection(EWQCLotLocStatus);
}
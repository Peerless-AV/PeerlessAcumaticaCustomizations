import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCItemClassFilter, InventoryItem } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCCopyItemClassInspectionSettingProcess", primaryView: "Filter", bpEventsIndicator: true })
export class QC504100 extends PXScreen {

	Filter = createSingle(EWQCItemClassFilter);
	StockItems = createCollection(InventoryItem);
}
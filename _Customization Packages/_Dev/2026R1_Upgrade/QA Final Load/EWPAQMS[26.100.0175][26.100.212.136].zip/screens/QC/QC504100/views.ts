import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC504100 } from "./QC504100";


// Views

export class EWQCItemClassFilter extends PXView {

	QMSSettings: PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig<ISelectorControlConfig>({ fastFilterFields: ["Descr"] })
	ItemClassID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	mergeToolbarWith: "ScreenToolbar",
	preset: GridPreset.Primary
})
export class InventoryItem extends PXView {

	@columnConfig({ width: 60, allowCheckAll: true }) Selected: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewInventory")
	@columnConfig({ width: 150 }) InventoryCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 300, visible: true }) Descr: PXFieldState<PXFieldOptions.Hidden>;
	@columnConfig({ width: 80 }) ItemType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, editorConfig: { allowEdit: true } }) DfltSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 108 }) BasePrice: PXFieldState<PXFieldOptions.CommitChanges>;
	ItemStatus: PXFieldState<PXFieldOptions.CommitChanges>;
}
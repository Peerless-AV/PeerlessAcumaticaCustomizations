import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";

export class EWQCOrderLotDetailType {
	SiteCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	LocationCD : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCOrderLotDistributionDetailType {
	BaseUOM : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCOrder extends PXView  {

	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	TranDescription : PXFieldState<PXFieldOptions.CommitChanges>;
	TranType : PXFieldState<PXFieldOptions.CommitChanges>;
	QCOrderCD : PXFieldState<PXFieldOptions.Disabled>;
}

export class InventoryItem extends PXView  {

	InventoryCD : PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
	initNewRow: true,
	autoRepaint: ["QCOrderLotStatus", "AcceptedQTYInventoryDistribution", "RejectedQTYInventoryDistribution",
		"ScrappedQTYInventoryDistribution", "DestructiveQTYInventoryDistribution"],

})
export class EWQCOrderLotDetail extends PXView  {

	lotAttributes: PXActionState;
	@columnConfig({ width: 180 }) LotSerNumVal: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) INSite__SiteCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) INLocation__LocationCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) TestQTY: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) BaseUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) AcceptedQTY: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) RejectedQTY: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) RejectionCode: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) ScappedQTY: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) ScrapCode: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) DestructiveQTY: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) ActualResult: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) Remarks: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
})
export class EWQCOrderLotStatus extends PXView  {

	@columnConfig({ width: 180 }) LotSerialNbr: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	@columnConfig({ width: 180 }) SiteID: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	@columnConfig({ width: 180 }) LocationID: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	@columnConfig({ width: 180 }) QtyAvail: PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	@columnConfig({ width: 180 }) AcceptedQty: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) RejectedQty: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) ScappedQTY: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) DestructiveQty: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		addLineDetails: { index: 0, config: { commandName: "addLineDetails", text: "Line Detail" } },
		lotAttributestest: { index: 1, config: { commandName: "lotAttributestest" } }
}
})
export class EWQCOrderLotDistributionDetail extends PXView  {

	addLineDetails: PXActionState;
	lotAttributestest: PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 108 }) EWQCOrderLotDetail__BaseUOM : EWQCOrderLotDistributionDetailType;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		addLineDetails: { index: 0, config: { commandName: "addLineDetails", text: "Line Detail" } },
		lotAttributestest: { index: 1, config: { commandName: "lotAttributestest" } }
}
})
export class EWQCOrderLotDistributionDetail2 extends PXView  {

	addLineDetails: PXActionState;
	lotAttributestest: PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 108 }) EWQCOrderLotDetail__BaseUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		addLineDetails: { index: 0, config: { commandName: "addLineDetails", text: "Line Detail" } },
		lotAttributestest: { index: 1, config: { commandName: "lotAttributestest" } }
}
})
export class EWQCOrderLotDistributionDetail3 extends PXView  {

	addLineDetails: PXActionState;
	lotAttributestest: PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 108 }) EWQCOrderLotDetail__BaseUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
		addLineDetails: { index: 0, config: { commandName: "addLineDetails", text: "Line Detail" } },
		lotAttributestest: { index: 1, config: { commandName: "lotAttributestest" } }
}
})
export class EWQCOrderLotDistributionDetail4 extends PXView  {

	addLineDetails: PXActionState;
	lotAttributestest: PXActionState;
	@columnConfig({width: 108})	SamplingSerailNum : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	FromLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToWarehouseID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ToLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Qty : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 108 }) EWQCOrderLotDetail__BaseUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108, editorConfig : {}})	ReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 108})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCOrderLotSerialDistributionDetail extends PXView  {

	@columnConfig({width: 50})SerialNumber: PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({width: 100, allowCheckAll: true })itemcheck: PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({width: 100, allowCheckAll: true })itemcheckrejected: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100, allowCheckAll: true })itemcheckscrapped: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100, allowCheckAll: true }) itemcheckdestructive: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Attributes
})
export class INItemLotSerialAttribute extends PXView {
	@columnConfig({ width: 135, allowShowHide: GridColumnShowHideMode.False, textAlign: TextAlign.Left })
	AttributeID: PXFieldState<PXFieldOptions.Disabled>;
	@columnConfig({ width: 80 }) Required: PXFieldState<PXFieldOptions.Disabled>;
	@columnConfig({ width: 185 }) Value: PXFieldState<PXFieldOptions.Disabled>;
}
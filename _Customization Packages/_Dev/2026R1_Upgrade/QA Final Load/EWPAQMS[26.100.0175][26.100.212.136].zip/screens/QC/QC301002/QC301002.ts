import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, CellCssHandlerArgs } from "client-controls";
import { EWQCOrder, InventoryItem, EWQCOrderLotDetail, EWQCOrderLotDistributionDetail, EWQCOrderLotDistributionDetail2, EWQCOrderLotDistributionDetail3, EWQCOrderLotDistributionDetail4, EWQCOrderLotSerialDistributionDetail, EWQCOrderLotStatus, INItemLotSerialAttribute } from "./views";

@graphInfo({ graphType: "EW.QC.EWQCOrderPostLotStatus", primaryView: "QCOrders", pageLoadBehavior: PXPageLoadBehavior.GoLastRecord, showActivitiesIndicator: true})
export class QC301002 extends PXScreen {

	QCOrders = createSingle(EWQCOrder);
	InventoryDetails = createSingle(InventoryItem);
   	@viewInfo({containerName: "Disposition Details"})
	QCOrderDetails = createCollection(EWQCOrderLotDetail);
	@viewInfo({containerName: "Lot Details"})
	QCOrderLotStatus = createCollection(EWQCOrderLotStatus);
   	@viewInfo({containerName: "Accepted Item"})
	AcceptedQTYInventoryDistribution = createCollection(EWQCOrderLotDistributionDetail);
   	@viewInfo({containerName: "Rejected Item"})
	RejectedQTYInventoryDistribution = createCollection(EWQCOrderLotDistributionDetail2);
   	@viewInfo({containerName: "Scrapped Item"})
	ScrappedQTYInventoryDistribution = createCollection(EWQCOrderLotDistributionDetail3);
   	@viewInfo({containerName: "Destructive Item"})
	DestructiveQTYInventoryDistribution = createCollection(EWQCOrderLotDistributionDetail4);
   	@viewInfo({containerName: "Add Line Details"})
    QCOrderLotDetailsSmartPanel = createCollection(EWQCOrderLotSerialDistributionDetail);
    @viewInfo({ containerName: "Attributes" })
    LotSerialAttributes = createCollection(INItemLotSerialAttribute);

    @handleEvent(CustomEventType.GetCellCss, { view: "QCOrderDetails", column: "ActualResult" })
    getActualResultCss(args: CellCssHandlerArgs<PXViewCollection<EWQCOrderLotDetail>>) {
        const row = args?.selector?.row;
        if (row?.ActualResult.value === "F")
            return "FailTest";
        else if (row?.ActualResult.value === "P")
            return "PassTest";
        else
            return undefined;
    }
 
  
 
}
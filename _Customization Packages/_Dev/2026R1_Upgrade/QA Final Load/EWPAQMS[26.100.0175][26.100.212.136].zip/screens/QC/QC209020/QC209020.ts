import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCServQC, FSEquipment, EWQCServPlan, EWQCServPlanVar, EWQCServChkGrp, EWQCServChkList, EWQCEvent, EWQCPlanTestTool, EWQCTestComboValues } from "./views";

@graphInfo({graphType: "EW.QC.EWQCServiceQCMaint", primaryView: "ServQC", bpEventsIndicator: true})
export class QC209020 extends PXScreen {

	ServQC = createSingle(EWQCServQC);
	FsEquipment = createSingle(FSEquipment);
   	@viewInfo({containerName: "Plan"})
	ServPlan = createCollection(EWQCServPlan);
   	@viewInfo({containerName: "Tests"})
	ServPlanVar = createCollection(EWQCServPlanVar);
   	@viewInfo({containerName: "Checklist Group"})
	ServChkGrp = createCollection(EWQCServChkGrp);
   	@viewInfo({containerName: "Checklists"})
	ServChkList = createCollection(EWQCServChkList);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
   	@viewInfo({containerName: "QC Tool"})
	ToolSteps = createCollection(EWQCPlanTestTool);
   	@viewInfo({containerName: "Combo Values"})
	TestComboValues = createCollection(EWQCTestComboValues);
}
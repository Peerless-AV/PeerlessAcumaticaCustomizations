import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC209020 } from "./QC209020";

export class FSEquipmentType {
	Descr : PXFieldState<PXFieldOptions.Disabled>;	
}
export class EWQCServPlanType {
	Status : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCServPlanVarType {
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
	DataType : PXFieldState<PXFieldOptions.CommitChanges>;	
	Equation : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCServChkGrpType {
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
}
export class EWQCServChkListType {
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCServQC extends PXView  {
    @actionConfig({ popupCommand: "OK" })
	EWQCComboSaveButton: PXActionState;

	ServItemType : PXFieldState<PXFieldOptions.CommitChanges>;
	EquipmentId : PXFieldState<PXFieldOptions.CommitChanges>;
	CreatedOn : PXFieldState<PXFieldOptions.CommitChanges>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class FSEquipment extends PXView  {

	Descr : PXFieldState<PXFieldOptions.Disabled>;
	InventoryID : PXFieldState<PXFieldOptions.Disabled>;
	InventoryItem : FSEquipmentType;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	
})
export class EWQCServPlan extends PXView  {
	@linkCommand("EWQCViewPlanMaster")
	@columnConfig({width: 180, editorConfig : {displayMode:"text",fastFilterFields:["RevisionNo","Name"]}})	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	EWQCPlan : EWQCServPlanType;
	@columnConfig({width: 70})	ResultCriteria : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCServPlanVar extends PXView  {

	@columnConfig({width: 120})	AddInReports : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({width: 180, editorConfig : {fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Name :  PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoToolSteps")
	@columnConfig({width: 180})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 180, editorConfig : {fastFilterFields:["Name","Description"]}})	TestGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true, width: 140, editorConfig : {fastFilterFields:["Name","Description"]}})	SeverityLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Description :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCTestCategory__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	CalculationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 220, editorConfig : {allowEdit:true}})	UOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	QCOperator : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	BitGoNoGo : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	AlphaValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCVariable__Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCAddCombo")
	@columnConfig({width: 150})	ComboValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
    autoRepaint: ["ServChkList"],
})
export class EWQCServChkGrp extends PXView  {

	@linkCommand("EWQCViewChecklistGroup")
	@columnConfig({width: 70, editorConfig : {allowEdit:true}})	ChkGrpID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCChecklistGroup : EWQCServChkGrpType;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCServChkList extends PXView  {

	@linkCommand("EWQCViewCheckListItem")
	@columnConfig({width: 180})	ChecklistID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EWQCChecklist : EWQCServChkListType;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({width: 180})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 240})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({hideViewLink: true, width: 180})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	allowDelete : false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCPlanTestTool extends PXView  {

	ToolGaugeID : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCTestComboValues extends PXView  {

	TestComboCD : PXFieldState<PXFieldOptions.CommitChanges>;
	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	ComboCheck : PXFieldState<PXFieldOptions.CommitChanges>;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter } from "client-controls";
import { EWQCTnCOrder, EWQCTnCOrderChkList, EWQCTnCChkListTask, EWQCEvent } from "./views";

@graphInfo({graphType: "EW.QC.EWQCToolsManagementOrderEntry", primaryView: "ToolsManagementOrders", bpEventsIndicator: true, showActivitiesIndicator: true, showUDFIndicator: true})
export class QC301020 extends PXScreen {

	ToolsManagementOrders = createSingle(EWQCTnCOrder);
   	@viewInfo({containerName: "CheckList "})
	ChecklistGroupVariable = createCollection(EWQCTnCOrderChkList);
   	@viewInfo({containerName: "Tasks"})
	TnCChkListTask = createCollection(EWQCTnCChkListTask);
   	@viewInfo({containerName: "Event History"})
	EventHistory = createCollection(EWQCEvent);
}
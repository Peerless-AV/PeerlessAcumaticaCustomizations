import { PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, actionConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, PXActionState, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility, ISelectorControlConfig, ControlParameter } from "client-controls";
import { QC301020 } from "./QC301020";

export class EWQCTnCOrderChkListType {
	ChecklistCD : PXFieldState<PXFieldOptions.CommitChanges>;	
	Name : PXFieldState<PXFieldOptions.CommitChanges>;	
	Description : PXFieldState<PXFieldOptions.CommitChanges>;	
}

// Views

export class EWQCTnCOrder extends PXView  {

	OrderType : PXFieldState<PXFieldOptions.Disabled>;
	TnCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	OrderDate : PXFieldState<PXFieldOptions.Disabled>;
	ClosingDateTime : PXFieldState<PXFieldOptions.Disabled>;
	OnHold : PXFieldState<PXFieldOptions.CommitChanges>;
	Status : PXFieldState<PXFieldOptions.Disabled>;
	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
	CalibrationScheduledType : PXFieldState<PXFieldOptions.Disabled>;
	ToolSource : PXFieldState<PXFieldOptions.Disabled>;	
    @controlConfig({ allowEdit: true, linkCommand: "ViewToolID" })
	ToolID : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	Description : PXFieldState<PXFieldOptions.Disabled>;
	ToolStatus : PXFieldState<PXFieldOptions.Disabled>;
	@controlConfig({allowEdit:true})
	CalibrationChecklistID : PXFieldState<PXFieldOptions.CommitChanges | PXFieldOptions.Disabled>;
	ChkgroupDesc : PXFieldState<PXFieldOptions.CommitChanges>;
	@controlConfig({ allowEdit: true, linkCommand: "RefDocNumbers" })
	RefDocumentNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	DocType : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
   autoRepaint: ["TnCChkListTask"],
})
export class EWQCTnCOrderChkList extends PXView  {

	@linkCommand("ViewCheckListItem")
	@columnConfig({width: 180})	EWQCChecklist__ChecklistCD : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180}) EWQCChecklist__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180}) EWQCChecklist__Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 90})	Completed : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150 ,hideViewLink : true})	ExecutedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ExecutedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Remarks : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete : false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	
})
export class EWQCTnCChkListTask extends PXView  {

	@columnConfig({width: 180})	Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({allowSort: false, width: 90 ,allowCheckAll:true})Completed : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150 ,hideViewLink : true})	ExecutedBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	ExecutedDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 500})	Remark : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCEvent extends PXView  {

	@columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 240})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180 ,hideViewLink:true})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}
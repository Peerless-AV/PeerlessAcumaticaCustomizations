import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
  createCollection
} from "client-controls";
import { SO303000, ARTran } from "src/screens/SO/SO303000/SO303000";

export interface SO303000_EWPAQMS_generated extends SO303000 {}
export class SO303000_EWPAQMS_generated {  
  @viewInfo({
    containerName: "SOShipline Split(EWQCReadSOShiplineInvoiceView)"
  })
  EWQCReadSOShiplineInvoiceView = createCollection(EWQCSOShiplineSplit);
}

export interface ARTran_EWPAQMS_generated extends ARTran {}
export class ARTran_EWPAQMS_generated {
	@placeAfterProperty("SOOrderNbr")
 UsrEWQCRequired: PXFieldState<PXFieldOptions.CommitChanges>;
   @placeAfterProperty("SOOrderNbr")
 UsrEWQCSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
 @placeAfterProperty("SOOrderNbr")
 UsrEWQCLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
 
 @linkCommand("EWQCViewQCOrder")
 @placeAfterProperty("SOOrderNbr")
 UsrEWQCOrderNumber: PXFieldState<PXFieldOptions.CommitChanges>;
  
 @linkCommand("eWQCgotoQCOrders")
 @placeAfterProperty("SOOrderNbr")
 UsrEWQCOrders: PXFieldState<PXFieldOptions.CommitChanges>;
 
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
})
export class EWQCSOShiplineSplit extends PXView {
 @linkCommand("EWQCViewQCOrders")	
  QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
  EWQCOrder__Status : PXFieldState<PXFieldOptions.CommitChanges>;
}

import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
  createCollection
} from "client-controls";
import {
  FS300200,
  FSAppointmentDetail
} from "src/screens/FS/FS300200/FS300200";

export interface FS300200_EWPAQMS_generated extends FS300200 {}
export class FS300200_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Service QC Order(EWQCServQCOrders)" })
  EWQCServQCOrders = createCollection(EWQCServQCOrder);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "ChkList Order(EWQCServChkOrders)" })
  EWQCServChkOrders = createCollection(EWQCChkListOrder);
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})

export class EWQCServQCOrder extends PXView {
@linkCommand("EWQCViewQCOrder")
	QCOrderCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Status :  PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocSource :  PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocSourceID :  PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})

export class EWQCChkListOrder extends PXView {
 @linkCommand("EWQCViewChkQCOrder")
	QCChkListOrderCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	Status :  PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentSrc :  PXFieldState<PXFieldOptions.CommitChanges>;
	RefDocumentID :  PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface FSAppointmentDetail_EWPAQMS_generated
  extends FSAppointmentDetail {}
export class FSAppointmentDetail_EWPAQMS_generated {
	@placeAfterProperty("EquipmentLineRef")
  UsrEWQCRequired:  PXFieldState<PXFieldOptions.CommitChanges>;
 @placeAfterProperty("EquipmentLineRef")
	@linkCommand("EWQCQCOrders")
  UsrEWQCOrder:  PXFieldState<PXFieldOptions.CommitChanges>;
  @placeAfterProperty("EquipmentLineRef")
   @linkCommand("EWQCChkOrders")
  UsrEWQCChkOrder:  PXFieldState<PXFieldOptions.CommitChanges>;
}

import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
    createCollection,
    PXActionState
} from "client-controls";
import { AM516000, UnapprovedTrans } from "src/screens/AM/AM516000/AM516000";

export interface AM516000_EWPAQMS_generated extends AM516000 {}
export class AM516000_EWPAQMS_generated {
	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({ containerName: "IN Process Order(EWQCInProcessQCDetail)" })
	EWQCInProcessQCDetail = createCollection(EWQCINProcessOrder);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Clock Entry Details(EWQCClockEntrySplitLotDetails)"
  })
  EWQCClockEntrySplitLotDetails = createCollection(EWQCClockEntryLotDetails);
}

@gridConfig({
	syncPosition: true,
})
export class EWQCINProcessOrder extends PXView {
	@linkCommand("EWQCGotoInprocessQCOrders")
	QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoInprocessQCRef")
	QCReference: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCRegenerateQC")
	@columnConfig({ width: 150 }) RegenerateQC: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,

})

export class EWQCClockEntryLotDetails extends PXView {
	@columnConfig({ width: 80, allowCheckAll: true }) LotSelected: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120, editorConfig: {} }) QCLotSerialNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) Qty: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface UnapprovedTrans_EWPAQMS_generated extends UnapprovedTrans {}
export class UnapprovedTrans_EWPAQMS_generated {

	@columnConfig({ width: 140 }) UsrEWQCRequired: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 140 }) UsrEWQCSiteID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 140 }) UsrEWQCLocationID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewQCOrder")
	@columnConfig({ width: 280 }) UsrEWQCOrderNumber: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoQCOrders")
	@columnConfig({ width: 120 }) UsrEWQCInProcessOrderList: PXFieldState<PXFieldOptions.CommitChanges>;
}

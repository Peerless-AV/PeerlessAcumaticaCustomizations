import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
  createCollection,
  PXActionState
} from "client-controls";
import { AM301000, AMMTran } from "src/screens/AM/AM301000/AM301000";

export interface AM301000_EWPAQMS_generated extends AM301000 {}
export class AM301000_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "IN Process Order(EWQCInProcessQCDetailLabor)" })
  EWQCInProcessQCDetailLabor = createCollection(EWQCINProcessOrder);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Move Lot Details(EWQCProductionOrderSplitLotDetails)"
  })
  EWQCProductionOrderSplitLotDetails = createCollection(EWQCMoveLotDetails);
}

export interface AMMTran_EWPAQMS_generated extends AMMTran {}
export class AMMTran_EWPAQMS_generated {
	
  EWQCAddProductionLotDetails : PXActionState;
	EWQCToolUsage:PXActionState;
	@columnConfig({editorConfig : {allowEdit:true}})	UsrEWQCInspectionOrderNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 140})	UsrEWQCStatus : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 140})	UsrEWQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 140})	UsrEWQCSiteID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 140})	UsrEWQCLocationID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewQCOrder")
	@columnConfig({width: 280})	UsrEWQCOrderNumber : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoQCOrdersLabor")
	@columnConfig({width: 120})	UsrEWQCInProcessOrderList : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCINProcessOrder extends PXView {
  @linkCommand("EWQCGotoInprocessQCOrders")
	QCOrderCD : PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCOrder__Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoInprocessQCRef")
	QCReference : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCRegenerateQC")
	@columnConfig({width: 150})	RegenerateQC : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})

export class EWQCMoveLotDetails extends PXView {
	@columnConfig({width: 80})	LotSelected : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120, editorConfig : {}})	QCLotSerialNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 120})	QtyToMove : PXFieldState<PXFieldOptions.CommitChanges>;

}

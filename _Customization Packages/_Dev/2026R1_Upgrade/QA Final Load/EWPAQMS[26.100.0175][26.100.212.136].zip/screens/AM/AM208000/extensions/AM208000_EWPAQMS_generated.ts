import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
    createCollection,
    PXActionState,
    actionConfig
} from "client-controls";
import { AM208000, AMBomOper } from "src/screens/AM/AM208000/AM208000";

export interface AM208000_EWPAQMS_generated extends AM208000 {}
export class AM208000_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "BOM Oper Variable(EWQCBOMVariables)" })
  EWQCBOMVariables = createCollection(EWQCBOMOperVariable);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Associate Inspection Plan(EWQCInspectionPlanDetail)"
  })
  EWQCInspectionPlanDetail = createCollection(EWQCAssociateInspectionPlan);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName:
      "Associate Inspection Plan Variable(EWQCAssociateInspectionPlanVariables)"
  })
  EWQCAssociateInspectionPlanVariables = createCollection(
    EWQCAssociateInspectionPlanVariable
  );

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Associate Checklist Group(EWQCAssociateChecklistGroups)"
  })
  EWQCAssociateChecklistGroups = createCollection(EWQCAssociateChecklistGroup);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName:
      "Associate Checklist Group Variable(EWQCAssociateChecklistGroupVariables)"
  })
  EWQCAssociateChecklistGroupVariables = createCollection(
    EWQCAssociateChecklistGroupVariable
  );

  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Plan Test Tool(EWQCToolSteps)" })
  EWQCToolSteps = createCollection(EWQCPlanTestTool);

  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({
    containerName: "Inspection Plan Test Tool(EWQCToolInspectionSteps)"
  })
  EWQCToolInspectionSteps = createCollection(EWQCInspectionPlanTestTool);

    @gridConfig({ preset: GridPreset.ReadOnly })  
    EWQCComboSaveButton: PXActionState;  
    @viewInfo({ containerName: "Test Combo Values(EWQCTestComboValues)" })
    EWQCTestComboValues = createCollection(EWQCTestComboValues);

    @gridConfig({ preset: GridPreset.ReadOnly })  
    EWQCComboInspectionPlanSaveButton: PXActionState;
    @viewInfo({
        containerName: "Test Combo Values(EWQCInspectionTestComboValues)"
    })
    EWQCInspectionTestComboValues = createCollection(EWQCTestComboValues);


}


export interface AMBomOper_EWPAQMS_generated extends AMBomOper { }

@gridConfig({
	preset: GridPreset.Details,
	pagerMode: GridPagerMode.NextPrevFirstLast,
	adjustPageSize: true,
	autoRepaint: ["BomMatlRecords", "BomStepRecords", "BomToolRecords", "BomOvhdRecords", "OutsideProcessingOperationSelected", "CurySettings_AMBomOper" ,"EWQCBOMVariables", "EWQCInspectionPlanDetail", "EWQCAssociateChecklistGroups"],
})
export class AMBomOper_EWPAQMS_generated {
    @placeAfterProperty("WcID")
UsrEWQCRequired: PXFieldState<PXFieldOptions.CommitChanges>;
    @placeAfterProperty("WcID")
@linkCommand("EWQCViewPlanMaster")
  UsrEWQCPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
    @placeAfterProperty("WcID")
  UsrEWQCResultCriteria: PXFieldState<PXFieldOptions.CommitChanges>;
    @placeAfterProperty("WcID")
  UsrEWQCInspectionType: PXFieldState<PXFieldOptions.CommitChanges>;
    @placeAfterProperty("WcID")
@linkCommand("EWQCViewSamplingMaster")
  UsrEWQCSamplingPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
    autoRepaint: ["EWQCToolSteps"],
    repaintColumns: true,
})
export class EWQCBOMOperVariable extends PXView {
  AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
  
@linkCommand("EWQCViewTestMaster")
  VariableID: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCGotoToolSteps")

  ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCViewTestGroupMaster")

  TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCViewSeverityMaster")

  SeverityLevel: PXFieldState<PXFieldOptions.CommitChanges>;

    CalculationType: PXFieldState<PXFieldOptions.CommitChanges>;

    @columnConfig({ editorConfig: { fastFilterFields: ["AttributeID", "Description"] } }) AttributeID: PXFieldState<PXFieldOptions.CommitChanges>;

  QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;

  NumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;

  NumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;

  TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Unit: PXFieldState<PXFieldOptions.CommitChanges>;
  
@linkCommand("EWQCViewTestMethod")
  EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;
  
@linkCommand("EWQCViewTestCategoryMaster")
    EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;

    BitGoNoGo: PXFieldState<PXFieldOptions.CommitChanges>

  EWQCVariable__Equation: PXFieldState<PXFieldOptions.CommitChanges>;

  OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;

  OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;

  LeadTimeDurationType: PXFieldState<PXFieldOptions.CommitChanges>;

  LeadTimeDuration: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCAddCombo")
  ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
    syncPosition: true,
    autoAdjustColumns: true,
    showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.Details,
    //initNewRow: true,
    autoRepaint: ["EWQCAssociateInspectionPlanVariables"],
})

export class EWQCAssociateInspectionPlan extends PXView {
  PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
    autoRepaint: ["EWQCToolInspectionSteps"],
    repaintColumns: true,
})
export class EWQCAssociateInspectionPlanVariable extends PXView {
 AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
  
@linkCommand("EWQCInspectionViewTestMaster")
  VariableID: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__TestMethodID: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__TestCategoryID: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
  
@linkCommand("EWQCViewTestGroupMaster")
  TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
  
@linkCommand("ewqcgotoToolInspectionSteps")
  ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;

  QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;

  NumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;

  NumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;

  TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;

  BitGoNoGo: PXFieldState<PXFieldOptions.CommitChanges>;

  AlphaValue: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Equation: PXFieldState<PXFieldOptions.CommitChanges>;

  LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;

  OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;

  OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Unit: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCaddInspectionPlanCombo")
  ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;

}

@gridConfig({
    syncPosition: true,
    autoAdjustColumns: true,
    showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.Details,
   //initNewRow: true,
    autoRepaint: ["EWQCAssociateChecklistGroupVariables"],
})
export class EWQCAssociateChecklistGroup extends PXView {
 @linkCommand("EWQCViewChecklistGroup")
  ChecklistGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCAssociateChecklistGroupVariable extends PXView {
 @linkCommand("EWQCViewCheckListItem")
  ChecklistID: PXFieldState<PXFieldOptions.CommitChanges>;
  
  EWQCChecklist__Name: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  allowDelete : false,
  allowInsert: false,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details
  
})
export class EWQCPlanTestTool extends PXView {
  ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;

  Description: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  allowDelete : false,
  allowInsert: false,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details
  
})
export class EWQCInspectionPlanTestTool extends PXView {
 ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;

  Description: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
  syncPosition: true,
  allowDelete : false,
  allowInsert: false,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details
  
})

export class EWQCTestComboValues extends PXView {
  TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;

  Description: PXFieldState<PXFieldOptions.CommitChanges>;

  ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
    syncPosition: true,
    allowDelete: false,
    allowInsert: false,
    autoAdjustColumns: true,
    showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.Details

})
export class EWQCTestComboValues2 extends PXView {
    TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;

    Description: PXFieldState<PXFieldOptions.CommitChanges>;

    ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}


import {
	PXFieldState,
	PXFieldOptions,
	PXView,
	updateDecorator,
	removeDecorator,
	featureInstalled,
	FeaturesSet,
	placeBeforeView,
	placeAfterView,
	placeBeforeProperty,
	placeAfterProperty,
	graphInfo,
	viewInfo,
	gridConfig,
	columnConfig,
	treeConfig,
	controlConfig,
	linkCommand,
	fieldOptions,
	fieldConfig,
	fieldInfo,
	headerDescription,
	autoRefresh,
	mappedToViewField,
	suppressLabel,
	readOnly,
	disabled,
	unbound,
	text,
	multiLine,
	primaryKey,
	type,
	ControlParameter,
	NetType,
	MenuItemRenderType,
	ScrollMode,
	TextAlign,
	GridPreset,
	GridColumnType,
	GridColumnShowHideMode,
	GridColumnDisplayMode,
	GridAutoGrowMode,
	GridPagerMode,
	GridFastFilterVisibility,
	GridNoteFilesShowMode,
	HeaderDescription,
	GridColumnGeneration,
	GridFilterBarVisibility,
	NodeSelectMode,
	PXSelectorMode,
	ApplySuggestionMode,
	ITextEditorControlConfig,
	ITimeSpanConfig,
	ISelectorControlConfig,
	ISegmentedSelectorControlConfig,
	IEditorControlConfig,
	INumberEditorControlConfig,
	IMaskEditorControlConfig,
	IMailEditorControlConfig,
	ILinkEditorControlConfig,
	IDropDownConfig,
	IDatetimeEditControlConfig,
	IColorPickerControlConfig,
	ICheckBoxControlConfig,
	ICalendarControlConfig,
	IBranchSelectorConfig,
	IBarcodeInputControlConfig,
	ITreeSelectorConfig,
	IRichTextEditorConfig,
	IFormulaEditorConfig,
	ICurrencyControlConfig,
	FieldGenerationMode,
	createCollection,
	PXActionState,
} from "client-controls";
import { AP303000 } from "src/screens/AP/AP303000/AP303000";
import { Vendor } from "src/screens/AP/AP303000/views";

export interface AP303000_EWPAQMS_generated extends AP303000 { }
export class AP303000_EWPAQMS_generated {
	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({ containerName: "Vendor Certificate(EWQCVenCertificate)" })
	EWQCVenCertificate = createCollection(EWQCVendorCertificate);

	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({ containerName: "Event(EWQCEventHistory)" })
	EWQCEventHistory = createCollection(EWQCEvent);

	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({ containerName: "Evaluate Vendor Performance Detail(EWQCVendorRating)" })
	EWQCVendorRating = createCollection(EWQCEvaluateVendorPerformanceDetail);

	@gridConfig({ preset: GridPreset.ReadOnly })
	EWQCSubmitFormula: PXActionState;
	@viewInfo({ containerName: "Vendor Certificate Master(EWQCVendorcertificatepanel)" })
	EWQCVendorcertificatepanel = createCollection(EWQCVendorCertificateMaster);


}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	topBarItems: {
		EWQCAttributes: { index: 0, config: { commandName: "EWQCAttributes", text: "Attributes" } },
	}
})

export class EWQCVendorCertificate extends PXView {

	CertificateCD: PXFieldState<PXFieldOptions.CommitChanges>;

	EffectiveFromDate: PXFieldState<PXFieldOptions.CommitChanges>;

	EffectiveToDate: PXFieldState<PXFieldOptions.CommitChanges>;

	MandatoryCertificate: PXFieldState<PXFieldOptions.CommitChanges>;

	LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface Vendor_EWPAQMS_generated extends Vendor { }
export class Vendor_EWPAQMS_generated {
	UsrEWQCQualifiedVendor: PXFieldState<PXFieldOptions.CommitChanges>;
}



@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCEvent extends PXView {
	CreatedDateTime: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	EventType: PXFieldState<PXFieldOptions.CommitChanges>;
	CreatedByID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	initNewRow: true,
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
	topBarItems: {
		EWQCEvaluateVendor: { index: 0, config: { commandName: "EWQCEvaluateVendor", text: "Evaluate Vendor" } },
	}
})
export class EWQCEvaluateVendorPerformanceDetail extends PXView {



	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;

	NewRank: PXFieldState<PXFieldOptions.CommitChanges>;

	NewScore: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	preset: GridPreset.ReadOnly
})
export class EWQCVendorCertificateMaster extends PXView {
	ParameterName: PXFieldState<PXFieldOptions.CommitChanges>;

	Description: PXFieldState<PXFieldOptions.CommitChanges>;

	Value: PXFieldState<PXFieldOptions.CommitChanges>;
}
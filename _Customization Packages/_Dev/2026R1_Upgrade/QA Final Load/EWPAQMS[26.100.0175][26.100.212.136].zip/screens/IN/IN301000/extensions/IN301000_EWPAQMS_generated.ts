import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode
} from "client-controls";
import { IN301000, INTran } from "src/screens/IN/IN301000/IN301000";

export interface IN301000_EWPAQMS_generated extends IN301000 {}
export class IN301000_EWPAQMS_generated {}

export interface INTran_EWPAQMS_generated extends INTran {}
export class INTran_EWPAQMS_generated {
   @placeAfterProperty("TranCost")
  @columnConfig({width: 80})	UsrEWQCRequired : PXFieldState;
	@linkCommand("EWQCViewQCOrder")
   @placeAfterProperty("TranCost")
	@columnConfig({width: 280})	UsrEWQCOrderNumber : PXFieldState;
   @placeAfterProperty("TranCost")
	@columnConfig({width: 140, editorConfig : {fastFilterFields:["Descr"]}})	UsrEWQCSiteID : PXFieldState<PXFieldOptions.CommitChanges>;
   @placeAfterProperty("TranCost")
	@columnConfig({width: 140, editorConfig : {fastFilterFields:["Descr"]}})	UsrEWQCLocationID : PXFieldState;
}

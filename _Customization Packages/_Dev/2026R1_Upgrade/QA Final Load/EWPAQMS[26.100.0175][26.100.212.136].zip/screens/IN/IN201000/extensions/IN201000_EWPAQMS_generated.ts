import {
	PXFieldState,
	PXFieldOptions,
	PXView,
	updateDecorator,
	removeDecorator,
	featureInstalled,
	FeaturesSet,
	placeBeforeView,
	placeAfterView,
	placeBeforeProperty,
	placeAfterProperty,
	graphInfo,
	viewInfo,
	gridConfig,
	columnConfig,
	treeConfig,
	controlConfig,
	linkCommand,
	fieldOptions,
	fieldConfig,
	fieldInfo,
	headerDescription,
	autoRefresh,
	mappedToViewField,
	suppressLabel,
	readOnly,
	disabled,
	unbound,
	text,
	multiLine,
	primaryKey,
	type,
	ControlParameter,
	NetType,
	MenuItemRenderType,
	ScrollMode,
	TextAlign,
	GridPreset,
	GridColumnType,
	GridColumnShowHideMode,
	GridColumnDisplayMode,
	GridAutoGrowMode,
	GridPagerMode,
	GridFastFilterVisibility,
	GridNoteFilesShowMode,
	HeaderDescription,
	GridColumnGeneration,
	GridFilterBarVisibility,
	NodeSelectMode,
	PXSelectorMode,
	ApplySuggestionMode,
	ITextEditorControlConfig,
	ITimeSpanConfig,
	ISelectorControlConfig,
	ISegmentedSelectorControlConfig,
	IEditorControlConfig,
	INumberEditorControlConfig,
	IMaskEditorControlConfig,
	IMailEditorControlConfig,
	ILinkEditorControlConfig,
	IDropDownConfig,
	IDatetimeEditControlConfig,
	IColorPickerControlConfig,
	ICheckBoxControlConfig,
	ICalendarControlConfig,
	IBranchSelectorConfig,
	IBarcodeInputControlConfig,
	ITreeSelectorConfig,
	IRichTextEditorConfig,
	IFormulaEditorConfig,
	ICurrencyControlConfig,
	FieldGenerationMode,
	createCollection,
	createSingle,
	PXActionState
} from "client-controls";
import {
	IN201000,
	ItemClassSettings,
	ItemClass
} from "src/screens/IN/IN201000/IN201000";

export interface IN201000_EWPAQMS_generated extends IN201000 { }
export class IN201000_EWPAQMS_generated {
	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({
		containerName: "Item Class Plan Detail(EWQCItemClassPlanDetail)"
	})
	EWQCItemClassPlanDetail = createCollection(EWQCItemClassPlanDetail);

	@viewInfo({ containerName: "Item Class(EWQCItemClass)" })
	EWQCItemClass = createSingle(INItemClass);

	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({ containerName: "Item Class Variable(EWQCItemClassVariables)" })
	EWQCItemClassVariables = createCollection(EWQCItemClassVariable);

	@viewInfo({
		containerName: "Item Class Stock Retest(EWQCStockClassRetestData)"
	})
	EWQCStockClassRetestData = createSingle(EWQCItemClassStockRetest);

	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({
		containerName: "Associate Inspection Plan(EWQCInspectionPlanDetail)"
	})
	EWQCInspectionPlanDetail = createCollection(EWQCAssociateInspectionPlan);

	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({
		containerName:
			"Associate Inspection Plan Variable(EWQCAssociateInspectionPlanVariables)"
	})
	EWQCAssociateInspectionPlanVariables = createCollection(
		EWQCAssociateInspectionPlanVariable
	);

	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({
		containerName: "Associate Checklist Group(EWQCAssociateChecklistGroup)"
	})
	EWQCAssociateChecklistGroup = createCollection(EWQCAssociateChecklistGroup);

	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({
		containerName:
			"Associate Checklist Group Variable(EWQCAssociateChecklistGroupVariables)"
	})
	EWQCAssociateChecklistGroupVariables = createCollection(
		EWQCAssociateChecklistGroupVariable
	);

	@gridConfig({ preset: GridPreset.Details })
	@viewInfo({ containerName: "Item Vendor Certificate(EWQCVendorCertificate)" })
	EWQCVendorCertificate = createCollection(EWQCItemVendorCertificate);

	@gridConfig({ preset: GridPreset.ReadOnly })
	EWQCComboInspectionPlanSaveButton: PXActionState;
	@viewInfo({
		containerName: "Test Combo Values(EWQCInspectionTestComboValues)"
	})
	EWQCInspectionTestComboValues = createCollection(EWQCTestComboValues);

	@gridConfig({ preset: GridPreset.ReadOnly })
	EWQCComboSaveButton: PXActionState;
	@viewInfo({ containerName: "Test Combo Values(EWQCTestComboValues)" })
	EWQCTestComboValues = createCollection(EWQCTestComboValues);

	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({
		containerName: "Inspection Plan Test Tool(EWQCToolInspectionSteps)"
	})
	EWQCToolInspectionSteps = createCollection(EWQCInspectionPlanTestTool);

	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({ containerName: "Plan Test Tool(EWQCToolSteps)" })
	EWQCToolSteps = createCollection(EWQCPlanTestTool);

	@gridConfig({ preset: GridPreset.ReadOnly })
	
	@viewInfo({ containerName: "Select Plan DAC(EWQCSelectPlanPanel)" })
	EWQCSelectPlanPanel = createSingle(EWQCSelectPlanDAC);

	@gridConfig({ preset: GridPreset.ReadOnly })
	
	@viewInfo({
		containerName: "Select Inspection Plan DAC(EWQCSelectInspectionPlanPanel)"
	})
	EWQCSelectInspectionPlanPanel = createSingle(EWQCSelectInspectionPlanDAC);
}

export interface ItemClassSettings_EWPAQMS_generated
	extends ItemClassSettings {}
export class ItemClassSettings_EWPAQMS_generated {
	UsrEWQCCertificateRequired: PXFieldState<PXFieldOptions.CommitChanges>;
}



export class INItemClass extends PXView {
	UsrEWQCIsQCRequired: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["EWQCItemClassVariables"],
})


export class EWQCItemClassPlanDetail extends PXView {
	@linkCommand("EWQCViewPlanMaster")
	@columnConfig({ width: 180, editorConfig: { displayMode: "text", fastFilterFields: ["RevisionNo", "Name"] } }) PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 70 }) EWQCPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 70 }) ResultCriteria: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 70 }) InspectionType: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewSamplingMaster")
	@columnConfig({ width: 180, editorConfig: { displayMode: "text", fastFilterFields: ["RevisionNo", "Name"] } }) SamplingPlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 70 }) AQLInspectionLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 70 }) EWQCSamplingPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) ReceivingQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) ShippingQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) ProductionQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) AdhocQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) KitAssemblyQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) RMAQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) WTQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) AdjustQC: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) DefaultAdhocQC: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
export class EWQCItemClassVariable extends PXView {
	EWQCAddTest: PXActionState;
	@columnConfig({ width: 170 }) AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({ width: 180, editorConfig: { fastFilterFields: ["VariableCD", "Name"] } }) VariableID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180, editorConfig: { fastFilterFields: ["Name", "Description"] } }) TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) Equation: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoToolSteps")
	@columnConfig({ width: 180 }) ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 200, editorConfig: { fastFilterFields: ["Name", "Description"] } }) SeverityLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;

	@columnConfig({ width: 70 }) CalculationType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ editorConfig: { fastFilterFields: ["AttributeID", "Description"] } }) AttributeID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) DestructiveTesting: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) DestructiveSampleSize: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 220, editorConfig: { allowEdit: true } }) UOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;
	UsrQCCSNumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;
	UsrQCCSNumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) BitGoNoGo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) AlphaValue: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) EWQCVariable__Equation: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) LeadTimeDurationType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) LeadTimeDuration: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) SampleSize: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCAddCombo")
	@columnConfig({ width: 150 }) ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;

}

export class EWQCItemClassStockRetest extends PXView {
	EWQCItemStockRetestID: PXFieldState<PXFieldOptions.CommitChanges>;

	Interval: PXFieldState<PXFieldOptions.CommitChanges>;

	InventoryID: PXFieldState<PXFieldOptions.CommitChanges>;

	NotificationDays: PXFieldState<PXFieldOptions.CommitChanges>;

	RetestFrequency: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["EWQCAssociateInspectionPlanVariables"],
})
export class EWQCAssociateInspectionPlan extends PXView {
	@linkCommand("EWQCViewInspectionPlan")
	PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
	EWQCInspectionPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
	DocType: PXFieldState<PXFieldOptions.CommitChanges>;

}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})

export class EWQCAssociateInspectionPlanVariable extends PXView {
	EWQCInspectionAddTest: PXActionState;
	@columnConfig({ width: 170 }) AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({ width: 180, editorConfig: { fastFilterFields: ["VariableCD", "Name"] } }) VariableID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__TestMethodID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180 }) EWQCVariable__TestCategoryID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 180, editorConfig: { fastFilterFields: ["Name", "Description"] } }) TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoToolSteps")
	@columnConfig({ width: 180 }) ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("ViewEquipmentMaster")
	@columnConfig({ width: 180 }) ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) NumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 120 }) BitGoNoGo: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) AlphaValue: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) EWQCVariable__Equation: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 100 }) LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) EWQCVariable__Unit: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) EWQCVariable__LeadTimeDurationType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ width: 150 }) EWQCVariable__LeadTimeDuration: PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCaddInspectionPlanCombo")
	@columnConfig({ width: 150 }) ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["EWQCAssociateChecklistGroupVariables"],
})

export class EWQCAssociateChecklistGroup extends PXView {
	@linkCommand("EWQCViewChecklistGroup")
	ChecklistGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
	DocType: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCAssociateChecklistGroupVariable extends PXView {
	@linkCommand("EWQCViewCheckListItem")
	ChecklistID: PXFieldState<PXFieldOptions.CommitChanges>;

	EWQCChecklist__Name: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCItemVendorCertificate extends PXView {
	CertificateCD: PXFieldState<PXFieldOptions.CommitChanges>;

	EWQCCertificate__Description: PXFieldState<PXFieldOptions.CommitChanges>;

	MandatoryCertificate: PXFieldState<PXFieldOptions.CommitChanges>;

	LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestComboValues extends PXView {
	TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestComboValues2 extends PXView {
	TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCInspectionPlanTestTool extends PXView {
	ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})

export class EWQCPlanTestTool extends PXView {
	ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
}
export class EWQCSelectPlanDAC extends PXView {
	PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCSelectInspectionPlanDAC extends PXView {
	PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
}

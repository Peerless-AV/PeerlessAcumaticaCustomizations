import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
  createCollection
} from "client-controls";
import { IN304000 } from "src/screens/IN/IN304000/IN304000";
import { LineSplittingDetails } from "src/screens/IN/common/line-splitting/views";

export interface IN304000_EWPAQMS_generated extends IN304000 {}
export class IN304000_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Inventory Lot Status QC(EWQCLotPanelView)" })
  EWQCLotPanelView = createCollection(EWQCInventoryLotStatusQC);
}




export class EWQCInventoryLotStatusQC extends PXView {
    QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
    @columnConfig({ hideViewLink: true }) StatusID: PXFieldState<PXFieldOptions.CommitChanges>;
    Qty: PXFieldState<PXFieldOptions.CommitChanges>;
    LotQty: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface LineSplittingDetails_EWPAQMS_generated
    extends LineSplittingDetails { }

@gridConfig({
	preset: GridPreset.Details,
    initNewRow: true,
    autoRepaint: ["EWQCLotPanelView"],
})
export class LineSplittingDetails_EWPAQMS_generated {
    
}
(function () {
	const GRID_A_ID = 'grid-LineSplitting';
	const GRID_B_ID = 'edewqclotserialstatus';

	const DIALOG_SELECTOR =
		'.dialog-body-content, .ux-dialog-body, .qp-rz-center';

	let observer: MutationObserver | null = null;
	let bodyObserver: MutationObserver | null = null;
	let rafId: number | null = null;
	let lastDialogWidth = 0;

	function getGridA(): HTMLElement | null {
		return document.getElementById(GRID_A_ID);
	}

	function getGridB(): HTMLElement | null {
		return document.getElementById(GRID_B_ID);
	}

	function getDialog(grid: HTMLElement): HTMLElement | null {
		return grid.closest(DIALOG_SELECTOR) as HTMLElement | null;
	}

	function dialogReady(dialog: HTMLElement): boolean {
		const w = dialog.clientWidth;
		const stable = w > 300 && Math.abs(w - lastDialogWidth) < 2;
		lastDialogWidth = w;
		return stable;
	}

	function isGridBVisible(): boolean {
		const gridB = getGridB();
		if (!gridB) return false;

		const style = getComputedStyle(gridB);

		return (
			style.display !== 'none' &&
			style.visibility !== 'hidden' &&
			gridB.offsetWidth > 0
		);
	}

	function applyWidths(dialog: HTMLElement): void {
		const gridA = getGridA();
		const gridB = getGridB();
		if (!gridA) return;

		const popupWidth = dialog.clientWidth - 24;
		if (popupWidth <= 0) return;

		const gridBVisible = isGridBVisible();

		let widthA = 0;
		let widthB = 0;

		if (!gridBVisible) {

			widthA = popupWidth;
			widthB = 0;
		} else {
			const minWidthA = 700;
			const minWidthB = 450;
			const offset = 220;

			widthA = Math.floor(popupWidth * 0.65);

			if (widthA > minWidthA) {
				widthA = widthA - offset;
			} else {
				widthA = minWidthA;
			}

			widthB = Math.max(popupWidth - widthA, minWidthB);

			if (widthA + widthB > popupWidth) {
				widthB = popupWidth - widthA;
			}
		}

		setGridWidth(gridA, widthA);

		if (gridB && gridBVisible) {
			setGridWidth(gridB, widthB);
		}
	}


	function setGridWidth(grid: HTMLElement, widthPx: number): void {
		const width = `${widthPx}px`;

		if (grid.style.width === width) return;

		grid.style.width = width;
		grid.style.maxWidth = width;

		grid
			.querySelectorAll<HTMLElement>(
				'.grid-header, .grid-header-table, .grid-content-table'
			)
			.forEach(el => (el.style.width = width));
	}

	function tryApply(retries = 80): void {

		const gridA = getGridA();

		if (!gridA || retries <= 0) {
			rafId = requestAnimationFrame(() => tryApply(retries - 1));
			return;
		}

		const dialog = getDialog(gridA);
		if (!dialog || !dialogReady(dialog)) {
			rafId = requestAnimationFrame(() => tryApply(retries - 1));
			return;
		}

		applyWidths(dialog);
		startWatching(dialog);
	}

	function startWatching(dialog: HTMLElement): void {
		if (observer) return;

		observer = new MutationObserver(() => {
			if (!dialogReady(dialog)) return;
			applyWidths(dialog);
		});

		observer.observe(dialog, {
			attributes: true,
			childList: true,
			subtree: true
		});

		window.addEventListener('resize', () => applyWidths(dialog));
	}

	function watchForPopup(): void {

		if (bodyObserver) return;

		bodyObserver = new MutationObserver(() => {

			const gridA = getGridA();

			if (gridA) {

				reset();
				requestAnimationFrame(() => tryApply());
			}
		});

		bodyObserver.observe(document.body, {
			childList: true,
			subtree: true
		});
	}

	function reset(): void {
		observer?.disconnect();
		observer = null;
		lastDialogWidth = 0;

		if (rafId !== null) {
			cancelAnimationFrame(rafId);
			rafId = null;
		}
	}

	window.addEventListener('beforeunload', () => {

		observer?.disconnect();
		bodyObserver?.disconnect();

		if (rafId !== null) {
			cancelAnimationFrame(rafId);
		}
	});

	watchForPopup();
	tryApply();
})();

import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
	createCollection,
	actionConfig,
	PXActionState
} from "client-controls";
import { IN202000, InventoryItem } from "src/screens/IN/IN202000/IN202000";

export interface IN202000_EWPAQMS_generated extends IN202000 {}
export class IN202000_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Inventory Item Detail(EWQCGlobalPlanDetail)" })
  EWQCGlobalPlanDetail = createCollection(EWQCInventoryItemDetail);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Inventory Item Variable(EWQCInventoryItemVariables)"
  })
  EWQCInventoryItemVariables = createCollection(EWQCInventoryItemVariable);

  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Event(EWQCEventHistory)" })
  EWQCEventHistory = createCollection(EWQCEvent);

	@gridConfig({ preset: GridPreset.ReadOnly })
	EWQCComboSaveButton: PXActionState;
	@viewInfo({ containerName: "Test Combo Values(EWQCTestComboValues)" })
	EWQCTestComboValues = createCollection(EWQCTestComboValues);

  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Plan Test Tool(EWQCToolSteps)" })
  EWQCToolSteps = createCollection(EWQCPlanTestTool);
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	initNewRow: true,
	autoRepaint: ["EWQCInventoryItemVariables"],
})
export class EWQCInventoryItemDetail extends PXView {
  @linkCommand("EWQCViewPlanMaster")
	@columnConfig({width: 180, editorConfig : {displayMode:"text",fastFilterFields:["PlanCD","Name","RevisionNo"]}}) PlanID : PXFieldState<PXFieldOptions.CommitChanges>;	
	@columnConfig({width: 70})	EWQCPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	ResultCriteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	NSQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	IntervalBy : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	Interval : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	StartDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EndDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	NotificationDays : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
	
})

export class EWQCInventoryItemVariable extends PXView {
  AddInReports: PXFieldState<PXFieldOptions.CommitChanges>;
 @linkCommand("EWQCViewTestMaster")
  VariableID: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Name: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCGotoToolSteps")
  ToolSteps: PXFieldState<PXFieldOptions.CommitChanges>;

  TestGroupID: PXFieldState<PXFieldOptions.CommitChanges>;

  SeverityLevel: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Description: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCTestCategory__Name: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCTestMethod__Name: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;

  UOM: PXFieldState<PXFieldOptions.CommitChanges>;

  CalculationType: PXFieldState<PXFieldOptions.CommitChanges>;

  QCOperator: PXFieldState<PXFieldOptions.CommitChanges>;

  NumMinValue: PXFieldState<PXFieldOptions.CommitChanges>;

  NumMaxValue: PXFieldState<PXFieldOptions.CommitChanges>;

  TestResultUOM: PXFieldState<PXFieldOptions.CommitChanges>;

  BitGoNoGo: PXFieldState<PXFieldOptions.CommitChanges>;

  AlphaValue: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCVariable__Equation: PXFieldState<PXFieldOptions.CommitChanges>;

  OptionalTest: PXFieldState<PXFieldOptions.CommitChanges>;

  OrderLevel: PXFieldState<PXFieldOptions.CommitChanges>;

  LeadTimeDurationType: PXFieldState<PXFieldOptions.CommitChanges>;

  LeadTimeDuration: PXFieldState<PXFieldOptions.CommitChanges>;
@linkCommand("EWQCAddCombo")
  ComboValue: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCEvent extends PXView {
 @columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180 ,hideViewLink:true})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface InventoryItem_EWPAQMS_generated extends InventoryItem {}
export class InventoryItem_EWPAQMS_generated {
  UsrEWQCIsQCRequired: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly

})
export class EWQCTestComboValues extends PXView {
	TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;

	Description: PXFieldState<PXFieldOptions.CommitChanges>;

	ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	allowDelete: false,
	allowInsert: false,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly

})
export class EWQCPlanTestTool extends PXView {
   ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
}

import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
	FieldGenerationMode,
	createCollection,
	PXActionState
} from "client-controls";
import { IN303000, INTran } from "src/screens/IN/IN303000/IN303000";

export interface IN303000_EWPAQMS_generated extends IN303000 {}
export class IN303000_EWPAQMS_generated {
	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({ containerName: "Inventory Lot Status QC(EWQCLotPanelView)" })
	EWQCLotPanelView = createCollection(EWQCInventoryLotStatusQC);
}

export interface INTran_EWPAQMS_generated extends INTran { }

@gridConfig({
	
	preset: GridPreset.Details,
	initNewRow: true,
	statusField: "Availability",
	autoRepaint: ["EWQCLotPanelView"],
})
export class INTran_EWPAQMS_generated {

	EWQCLineDetails: PXActionState;
  @placeAfterProperty("LocationID")
	UsrEWQCRequired : PXFieldState<PXFieldOptions.CommitChanges>;
  @placeAfterProperty("LocationID")
	@linkCommand("EWQCByOrder")
	UsrEWQCOrderNumber : PXFieldState;
  @placeAfterProperty("LocationID")
	UsrEWQCSiteID : PXFieldState<PXFieldOptions.CommitChanges>;
  @placeAfterProperty("LocationID")
	UsrEWQCLocationID : PXFieldState;
}

export class EWQCInventoryLotStatusQC extends PXView {
	QCOrderCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({ hideViewLink: true }) StatusID: PXFieldState<PXFieldOptions.CommitChanges>;
	Qty: PXFieldState<PXFieldOptions.CommitChanges>;
	LotQty: PXFieldState<PXFieldOptions.CommitChanges>;
}
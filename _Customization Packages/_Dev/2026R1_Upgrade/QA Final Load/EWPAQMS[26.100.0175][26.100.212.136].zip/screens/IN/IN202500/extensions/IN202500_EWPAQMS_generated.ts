import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
	createCollection,
	createSingle,
	PXActionState,
	actionConfig
} from "client-controls";
import { IN202500, ItemSettings } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_EWPAQMS_generated extends IN202500 {}
export class IN202500_EWPAQMS_generated {
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Inventory Detail(EWQCGlobalPlanDetail)" })
  EWQCGlobalPlanDetail = createCollection(EWQCInventoryDetail);

  @viewInfo({ containerName: "Item Stock Retest(EWQCStockRetestData)" })
  EWQCStockRetestData = createSingle(EWQCItemStockRetest);


  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Event(EWQCEventHistory)" })
  EWQCEventHistory = createCollection(EWQCEvent);

 
	@gridConfig({ preset: GridPreset.Details })

  @viewInfo({ containerName: "Inventory Variable(EWQCInventoryVariables)" })
  EWQCInventoryVariables = createCollection(EWQCInventoryVariable);

	@gridConfig({ preset: GridPreset.Details })
	
	
  @viewInfo({ containerName: "Select Plan DAC(EWQCSelectPlanPanel)" })
  EWQCSelectPlanPanel = createSingle(EWQCSelectPlanDAC);

  @gridConfig({ preset: GridPreset.ReadOnly })
  @viewInfo({ containerName: "Plan Test Tool(EWQCToolSteps)" })
  EWQCToolSteps = createCollection(EWQCPlanTestTool);

  @gridConfig({ preset: GridPreset.ReadOnly })
  EWQCComboSaveButton: PXActionState;
  @viewInfo({ containerName: "Test Combo Values(EWQCTestComboValues)" })
  EWQCTestComboValues = createCollection(EWQCTestComboValues);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Inventory Item Vendor Certificate(EWQCVendorCertificate)"
  })
  EWQCVendorCertificate = createCollection(EWQCInventoryItemVendorCertificate);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Evaluate Vendor Performance Detail(EWQCVendorRating)"})
  EWQCVendorRating = createCollection(EWQCEvaluateVendorPerformanceDetail);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Associate Inspection Plan(EWQCInspectionPlanDetail)"})
  EWQCInspectionPlanDetail = createCollection(EWQCAssociateInspectionPlan);

  
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
   containerName: "Associate Inspection Plan Variable(EWQCAssociateInspectionPlanVariables)"
  })
    EWQCAssociateInspectionPlanVariables = createCollection(EWQCAssociateInspectionPlanVariable);
  
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName: "Associate Checklist Group(EWQCAssociateChecklistGroup)"
  })
    EWQCAssociateChecklistGroup = createCollection(EWQCAssociateChecklistGroup);

  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({
    containerName:"Associate Checklist Group Variable(EWQCAssociateChecklistGroupVariables)"
  })
    EWQCAssociateChecklistGroupVariables = createCollection(EWQCAssociateChecklistGroupVariable);
  
  @gridConfig({ preset: GridPreset.Details })
  @viewInfo({ containerName: "Event(EWQCInspectionEventHistory)"

   })
	EWQCInspectionEventHistory = createCollection(EWQCEvent);

	@gridConfig({ preset: GridPreset.ReadOnly })
	@viewInfo({
		containerName: "Inspection Plan Test Tool(EWQCToolInspectionSteps)"
	})
	EWQCToolInspectionSteps = createCollection(EWQCInspectionPlanTestTool);
	
	@gridConfig({ preset: GridPreset.ReadOnly })	
	EWQCComboInspectionPlanSaveButton: PXActionState;
	@viewInfo({
		containerName: "Test Combo Values(EWQCInspectionTestComboValues)"
	})
	EWQCInspectionTestComboValues = createCollection(EWQCTestComboValues);

@gridConfig({ preset: GridPreset.ReadOnly })

  @viewInfo({
    containerName: "Select Inspection Plan DAC(EWQCSelectInspectionPlanPanel)"
  })
	EWQCSelectInspectionPlanPanel = createSingle(EWQCSelectInspectionPlanDAC);

	
}

  


export interface ItemSettings_EWPAQMS_generated extends ItemSettings {}
export class ItemSettings_EWPAQMS_generated {
  UsrEWQCIsQCRequired: PXFieldState<PXFieldOptions.CommitChanges>;

	UsrEWQCCertificateRequired: PXFieldState<PXFieldOptions.CommitChanges>;	
}

@gridConfig({
  syncPosition: true,  
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
  initNewRow: true,
  autoRepaint: ["EWQCInventoryVariables"],
})

export class EWQCInventoryDetail extends PXView {
  PlanType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewVendorMaster")
	@columnConfig({width: 140, editorConfig : {fastFilterFields:["AcctCD","AcctName"]}})	VendorID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewCustomerMaster")
	@columnConfig({width: 140, editorConfig : {fastFilterFields:["AcctCD","AcctName"]}})	CustomerID : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewPlanMaster")
	@columnConfig({width: 180, editorConfig : {displayMode:"text",fastFilterFields:["RevisionNo","Name"]}})	PlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	EWQCPlan__Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	ResultCriteria : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	InspectionType : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewSamplingMaster")
	@columnConfig({width: 180, editorConfig : {displayMode:"text",fastFilterFields:["RevisionNo","Name"]}})	SamplingPlanID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	AQLInspectionLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	EWQCSamplingPlan__Status : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	ReceivingQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	ShippingQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	ProductionQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	AdhocQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	KitAssemblyQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	RMAQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	WTQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	AdjustQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	DefaultAdhocQC : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCItemStockRetest extends PXView {
  EWQCItemStockRetestID: PXFieldState;

  Interval: PXFieldState;

  InventoryID: PXFieldState;

  NotificationDays: PXFieldState;

  RetestFrequency: PXFieldState;
}
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})

export class EWQCEvent extends PXView {
    @columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180 ,hideViewLink:true})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}


@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,

})
 
export class EWQCInventoryVariable extends PXView {
	EWQCAddTest: PXActionState;
  @columnConfig({width: 170})	AddInReports : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({width: 200, editorConfig : {fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoToolSteps")
	@columnConfig({width: 200})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200, editorConfig : {fastFilterFields:["Name","Description"]}})	TestGroupID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200, editorConfig : {fastFilterFields:["Name","Description"]}})	SeverityLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200}) EWQCTestMethod__Name : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 200}) EWQCVariable__Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200}) EWQCTestCategory__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200}) EWQCVariable__DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	CalculationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({editorConfig : {fastFilterFields:["AttributeID","Description"]}})	AttributeID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	DestructiveTesting : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	DestructiveSampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200, editorConfig : {allowEdit:true}})	UOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	QCOperator : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrQCCSNumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	UsrQCCSNumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	BitGoNoGo : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	AlphaValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCAddCombo")
	@columnConfig({width: 200})	ComboValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

export class EWQCSelectPlanDAC extends PXView {
  PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})

export class EWQCPlanTestTool extends PXView {
  
  ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;

  Description: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})

export class EWQCTestComboValues extends PXView {
  TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;
  Description: PXFieldState<PXFieldOptions.CommitChanges>;
  ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})

export class EWQCInventoryItemVendorCertificate extends PXView {
  CertificateCD: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCCertificate__Description: PXFieldState<PXFieldOptions.CommitChanges>;

  MandatoryCertificate: PXFieldState<PXFieldOptions.CommitChanges>;

  LineNbr: PXFieldState<PXFieldOptions.CommitChanges>;

}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly,
  topBarItems: {
	EWQCEvaluateVendor: {index: 0, config: {commandName: "EWQCEvaluateVendor", text: "Evaluate Vendor"}},
}
})
export class EWQCEvaluateVendorPerformanceDetail extends PXView {
 
	@columnConfig({width: 150})	BAccount__AcctCD :  PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	BAccount__AcctName : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	NewScore : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	PreviousScore : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	NewRank : PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({width: 150})	PreviousRank : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	LastEvaluationDate : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 150})	TimePeriod : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
   initNewRow: true,
  autoRepaint: ["EWQCAssociateInspectionPlanVariables"],
})
export class EWQCAssociateInspectionPlan extends PXView {
   @linkCommand("EWQCViewInspectionPlan")
  PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
  EWQCInspectionPlan__Status: PXFieldState<PXFieldOptions.CommitChanges>;
  DocType: PXFieldState<PXFieldOptions.CommitChanges>;  
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	repaintColumns: true,
})
 
export class EWQCAssociateInspectionPlanVariable extends PXView {
	EWQCInspectionAddTest: PXActionState;
 @columnConfig({width: 170})	AddInReports : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCViewTestMaster")
	@columnConfig({width: 200, editorConfig : {fastFilterFields:["VariableCD","Name"]}})	VariableID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__Name : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})EWQCVariable__DataType: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})EWQCVariable__TestMethodID : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})EWQCVariable__TestCategoryID : PXFieldState<PXFieldOptions.CommitChanges>;
	 @columnConfig({width: 200, editorConfig : {fastFilterFields:["Name","Description"]}})TestGroupID  : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCGotoToolSteps")
	@columnConfig({width: 200})	ToolSteps : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	QCOperator : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	NumMinValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	NumMaxValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	TestResultUOM : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	BitGoNoGo : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	AlphaValue : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__Equation : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 100})	LineNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__Unit : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	OptionalTest : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	OrderLevel : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__LeadTimeDurationType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	EWQCVariable__LeadTimeDuration : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 200})	SampleSize : PXFieldState<PXFieldOptions.CommitChanges>;
	@linkCommand("EWQCaddInspectionPlanCombo")
	@columnConfig({width: 200})	ComboValue : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
   initNewRow: true,
  autoRepaint: ["EWQCAssociateChecklistGroupVariables"],
})
export class EWQCAssociateChecklistGroup extends PXView {
   @linkCommand("EWQCViewChecklistGroup")
  ChecklistGroupID: PXFieldState<PXFieldOptions.CommitChanges>;
  DocType: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class EWQCAssociateChecklistGroupVariable extends PXView {
  
  @linkCommand("EWQCViewCheckListItem")
  ChecklistID: PXFieldState<PXFieldOptions.CommitChanges>;

  EWQCChecklist__Name: PXFieldState<PXFieldOptions.CommitChanges>;
}
  
@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCEvent2 extends PXView {
 @columnConfig({width: 180, format: "g"})	CreatedDateTime : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	Description : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180})	EventType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 180,hideViewLink:true})	CreatedByID : PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})

export class EWQCInspectionPlanTestTool extends PXView {
	ToolGaugeID: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
}
@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class EWQCTestComboValues2 extends PXView {
	TestComboCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	ComboCheck: PXFieldState<PXFieldOptions.CommitChanges>;
}
export class EWQCSelectInspectionPlanDAC extends PXView {
  PlanID: PXFieldState<PXFieldOptions.CommitChanges>;
} 

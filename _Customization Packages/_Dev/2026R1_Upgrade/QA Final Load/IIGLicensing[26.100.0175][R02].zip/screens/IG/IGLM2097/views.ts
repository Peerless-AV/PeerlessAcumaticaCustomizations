import {
    GridFastFilterVisibility,
    GridPreset,
    PXActionState,
    PXFieldOptions,
    PXFieldState,
    PXView,
    columnConfig,
    gridConfig
} from "client-controls";

// Views
export class IGLMLicenseInfo extends PXView {

    CustomerName: PXFieldState;
    LicenseKey: PXFieldState;
    InstallationID: PXFieldState;
    Reason: PXFieldState;
}

@gridConfig({
    syncPosition: true,
    showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.Details,
    topBarItems: {
        SaveRegistration: { index: 0, config: { commandName: "SaveRegistration", text: "Save" } },
    }
})
export class IGLMRegistration extends PXView {

    SaveRegistration: PXActionState;
    @columnConfig({ width: 280 }) ProductDescr: PXFieldState;
    @columnConfig({ width: 100 }) ReleaseLevel: PXFieldState;
    @columnConfig({ width: 90 }) ReleaseDate: PXFieldState;
    @columnConfig({ width: 200 }) SerialNumber: PXFieldState;
    @columnConfig({ width: 350 }) UnlockingKey: PXFieldState;
    @columnConfig({ width: 60 }) HasMaintenance: PXFieldState;
    @columnConfig({ width: 60 }) IsCustomization: PXFieldState;
    @columnConfig({ width: 60 }) ShowWarning: PXFieldState;
    @columnConfig({ width: 200 }) Status: PXFieldState;
    @columnConfig({ width: 100 }) TransactionCount: PXFieldState;
    @columnConfig({ width: 90 }) RenewalDate: PXFieldState;
    @columnConfig({ width: 70 }) TestMode: PXFieldState;
}

@gridConfig({
    showFastFilter: GridFastFilterVisibility.False,
    preset: GridPreset.Details
})
export class IGLMProductFeature extends PXView {

    @columnConfig({ width: 280 }) FeatureDescr: PXFieldState;
    @columnConfig({ width: 60 }) Enabled: PXFieldState;
}

export class IGLMPasswordConfirmationFilter extends PXView {

    Password: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class IGLMExtendLicenseFilter extends PXView {

    ProductCode: PXFieldState<PXFieldOptions.CommitChanges>;
    NewExpirationDate: PXFieldState<PXFieldOptions.CommitChanges>;
}
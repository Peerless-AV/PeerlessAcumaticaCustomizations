import {
    PXScreen,
    createCollection,
    createSingle,
    graphInfo,
    viewInfo
} from "client-controls";

import {
    IGLMExtendLicenseFilter,
    IGLMLicenseInfo,
    IGLMPasswordConfirmationFilter,
    IGLMProductFeature,
    IGLMRegistration
} from "./views";

@graphInfo({ graphType: "IIG.IGLMRegistrationMaint", primaryView: "DetailsView", })
export class IGLM2097 extends PXScreen {

    MasterView = createSingle(IGLMLicenseInfo);
    DetailsView = createCollection(IGLMRegistration);
    Features = createCollection(IGLMProductFeature);
    @viewInfo({ containerName: "Confirmation Password" })
    checkConfirmationPassword = createSingle(IGLMPasswordConfirmationFilter);
    @viewInfo({ containerName: "Extend Demo License" })
    extendDemoLicense = createSingle(IGLMExtendLicenseFilter);
}
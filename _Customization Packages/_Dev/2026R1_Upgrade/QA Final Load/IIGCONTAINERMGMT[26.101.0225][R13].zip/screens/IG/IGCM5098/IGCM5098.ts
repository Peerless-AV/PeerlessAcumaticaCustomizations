import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXPageLoadBehavior,
  PXView,
  PXFieldState,
  gridConfig,
  linkCommand,
  PXFieldOptions,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({
  graphType: "IGCM.IGCMPOPrintLandedCostProcess",
  primaryView: "IIGFilter",
  pageLoadBehavior: PXPageLoadBehavior.PopulateSavedValues,
})
export class IGCM5098 extends PXScreen {
  IIGFilter = createSingle(IGCMPOPrintLandedCostFilter);
  Records = createCollection(IGCMPOLandedCost);
}

export class IGCMPOPrintLandedCostFilter extends PXView {
  Action: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Inquiry,
})
export class IGCMPOLandedCost extends PXView {
  @columnConfig({  width: 60, allowNull: false, allowCheckAll: true  })
  Selected: PXFieldState<PXFieldOptions.CommitChanges>;
  LandedCostDate: PXFieldState;
  @columnConfig({ editorConfig: { linkCommand: "Details" } })
  LandedCostNbr: PXFieldState;
  Status: PXFieldState;
  ContainerNbr: PXFieldState;
  ContainerStatusID: PXFieldState;
  TotalAmount: PXFieldState;
  VendorID: PXFieldState;
}
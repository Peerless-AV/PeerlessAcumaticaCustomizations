import {
  createCollection,
  PXScreen,
  graphInfo,
  PXView,
  PXFieldState,
  gridConfig,
  columnConfig,
  GridColumnType,
  GridPreset,
  GridFastFilterVisibility,
} from "client-controls";

@graphInfo({ graphType: "IGCM.IGCMUpdateVesselInformationProc", primaryView: "Records" })
export class IGCM5097 extends PXScreen {
  Records = createCollection(IGCMPOLandedCost);
} // Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class IGCMPOLandedCost extends PXView {
  @columnConfig({ width: 60, type: GridColumnType.CheckBox, allowCheckAll: true }) Selected: PXFieldState;
  @columnConfig({ width: 140, hideViewLink: true }) LandedCostNbr: PXFieldState;
  @columnConfig({ width: 90 }) LandedCostDate: PXFieldState;
  @columnConfig({ width: 140 }) ContainerNbr: PXFieldState;
  @columnConfig({ width: 108 }) MMSI: PXFieldState;
}
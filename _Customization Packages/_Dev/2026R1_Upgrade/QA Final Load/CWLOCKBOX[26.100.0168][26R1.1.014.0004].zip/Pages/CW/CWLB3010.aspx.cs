using System;

public partial class Page_CWLB3010 : PX.Web.UI.PXPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CWLB1000.aspx.cs" Inherits="Page_CWLB1000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="SetupRecord" TypeName="Crestwood.LB.CWLBSetupMaint">
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="SetupRecord" TabIndex="700">
		<Template>
			<px:PXLayoutRule runat="server" StartRow="True" ControlSize="SM" LabelsWidth="XM"></px:PXLayoutRule>
			<px:PXSelector ID="edLockBoxPayNumberingID" runat="server"  DataField="LockBoxPayNumberingID"></px:PXSelector>
		
			<px:PXCheckBox CommitChanges="True" runat="server" ID="CWCstPXCheckBox2" DataField="UseDefaultPM" ></px:PXCheckBox>
			<px:PXSelector runat="server" ID="CWCstPXSelector1" DataField="PaymentMethodID" ></px:PXSelector>		

			<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox1" DataField="EnableFileSchema" ></px:PXCheckBox>
			<px:PXSelector ID="PXSelector1" runat="server"  DataField="FileLayoutSchema"></px:PXSelector>
		
			<px:PXCheckBox CommitChanges="True" runat="server" ID="chkRecordPaymentUnderParent" DataField="RecordPaymentUnderParent" ></px:PXCheckBox>
		</Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView>
</asp:Content>
<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CWLB3010.aspx.cs" Inherits="Page_CWLB3010" Title="Untitled Page" %> <%@
MasterType VirtualPath="~/MasterPages/FormDetail.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="PaymentRecords" TypeName="Crestwood.LB.CWLBPaymentEntry" SuspendUnloading="False">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="DocumentLookup" Visible="False" />
			<px:PXDSCallbackCommand Name="InsertDocument" Visible="False" />
			<px:PXDSCallbackCommand Name="CreateCustomerDocument" Visible="False" />
			<px:PXDSCallbackCommand Name="CreateCustomerUnappliedPayment" Visible="False" />
		</CallbackCommands>
	</px:PXDataSource>

	<%-- DocumentLookup --%>
	<px:PXSmartPanel
		ID="PanelDocumentLookup"
		runat="server"
		Key="DocumentsToSelect"
		LoadOnDemand="true"
		Width="1100px"
		Height="500px"
		Caption="Document Lookup"
		CaptionVisible="true"
		AutoRepaint="true"
		DesignView="Content"
		ShowAfterLoad="true"
	>
		<px:PXGrid
			ID="gripARInvoicesToSelect"
			runat="server"
			DataSourceID="ds"
			Style="height: 189px;"
			Width="100%"
			SkinID="Details"
			AdjustPageSize="Auto"
			AllowSearch="True"
			FilesIndicator="False"
			NoteIndicator="False"
		>
			<ActionBar PagerVisible="False">
				<PagerSettings Mode="NextPrevFirstLast" />
			</ActionBar>
			<Levels>
				<px:PXGridLevel DataMember="DocumentsToSelect">
					<Mode AllowAddNew="false" AllowDelete="false" />
					<Columns>
						<px:PXGridColumn AllowNull="False" DataField="Selected" TextAlign="Center" Type="CheckBox" AllowCheckAll="true" CommitChanges="true" />
						<px:PXGridColumn DataField="DocType" />
						<px:PXGridColumn DataField="RefNbr" />
						<px:PXGridColumn DataField="Status" />
						<px:PXGridColumn DataField="CustomerID" />
						<px:PXGridColumn DataField="CustomerLocationID" />
						<px:PXGridColumn DataField="DocDate" />
						<px:PXGridColumn DataField="DueDate" />
						<px:PXGridColumn DataField="FinPeriodID" />
						<px:PXGridColumn DataField="CuryID" />
						<px:PXGridColumn DataField="CuryOrigDocAmt" />
						<px:PXGridColumn DataField="CuryDocBal" />
						<px:PXGridColumn DataField="DocDesc" />
						<px:PXGridColumn DataField="DiscDate" />
						<px:PXGridColumn DataField="OwnerID" />
					</Columns>
				</px:PXGridLevel>
			</Levels>
			<AutoSize Enabled="true" />
		</px:PXGrid>
		<px:PXPanel ID="PXPanel6" runat="server" SkinID="Buttons">
			<px:PXButton ID="PXButton5" runat="server" CommandName="InsertDocument" CommandSourceID="ds" Text="Add" SyncVisible="false" />
			<px:PXButton ID="PXButton4" runat="server" Text="Add & Close" DialogResult="OK" />
			<px:PXButton ID="PXButton6" runat="server" DialogResult="Cancel" Text="Cancel" />
		</px:PXPanel>
	</px:PXSmartPanel>
	<%--/ DocumentLookup Selector --%>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="mainForm" runat="server" DataSourceID="ds" Style="z-index: 100" Width="100%" DataMember="PaymentRecords" TabIndex="100" DefaultControlID="edStatus" Caption="PaymentHeader">
		<Template>
			<px:PXLayoutRule runat="server" StartRow="True" ControlSize="SM" LabelsWidth="XM" StartColumn="True" />
			<px:PXSelector ID="edRefNbr" runat="server" AutoRefresh="True" DataField="RefNbr" DataSourceID="ds" />
			<px:PXDropDown ID="edStatus" runat="server" DataField="Status" />
			<px:PXNumberEdit ID="edCuryTotal" runat="server" DataField="CuryTotal" />
			<px:PXLayoutRule runat="server" ControlSize="SM" LabelsWidth="XM" StartColumn="True" />
			<px:PXNumberEdit ID="edCuryAppliedAmount" runat="server" DataField="CuryAppliedAmount" />
			<px:PXNumberEdit ID="edCuryPaymentCreateAmount" runat="server" DataField="CuryPaymentCreateAmount" />
			<px:PXLayoutRule runat="server" ControlSize="SM" LabelsWidth="XM" StartColumn="True" />
			<px:PXNumberEdit ID="edCuryAppPaymentCreateAmount" runat="server" DataField="CuryAppPaymentCreateAmount" />
			<px:PXNumberEdit ID="edCuryPaymentAndApplicationAmount" runat="server" DataField="CuryPaymentAndApplicationAmount" />
		</Template>
	</px:PXFormView>
		<px:PXUploadDialog ID="pnlNewRev" Key="PaymentRecords" runat="server" Height="120px" Style="position: static" Width="560px" Caption="Upload File" AutoSaveFile="false" RenderCheckIn="false" SessionKey="419BE88A-03D7-47C3-A7AB-3B259935F0C2" />
</asp:Content>

<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" SyncPosition="True" Height="350" AllowPaging="False">
		<Levels>
			<px:PXGridLevel DataMember="PaymentLines" DataKeyNames="RefNbr, LineNbr">
				<Columns>
					<px:PXGridColumn DataField="RefNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="LineNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="Selected" Type="CheckBox" AllowCheckAll="True" TextAlign="Center" ></px:PXGridColumn>
					<px:PXGridColumn DataField="matched" Type="CheckBox" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CheckLink" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CustomerID" CommitChanges="True" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CustomerFileDescription" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InvoiceNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="OrigInvoiceNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CuryInvoiceAmount" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CuryAppliedAmount" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CuryUnappliedAmount" ></px:PXGridColumn>
					<px:PXGridColumn DataField="PaymentDate" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CheckNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CuryCheckAmount" ></px:PXGridColumn>
					<px:PXGridColumn DataField="PaymentProcessed" Type="CheckBox" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CreatePaymentApp" Type="CheckBox" CommitChanges="True" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CreatePayment" Type="CheckBox" CommitChanges="True" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CreatePrePayment" Type="CheckBox" CommitChanges="True" ></px:PXGridColumn>
					<px:PXGridColumn DataField="BatchItemID" ></px:PXGridColumn>
					<px:PXGridColumn DataField="MatchType" ></px:PXGridColumn>
					<px:PXGridColumn DataField="BatchID" ></px:PXGridColumn>
					<px:PXGridColumn DataField="ABART" ></px:PXGridColumn>
					<px:PXGridColumn DataField="AcctNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="PaymentDocType" CommitChanges="True" ></px:PXGridColumn>
					<px:PXGridColumn DataField="PaymentRefNbr" CommitChanges="True" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CuryPaymentAmount" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CheckLinkAppNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InvoiceDate" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CustomerID_Customer_acctName" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<Mode AllowUpload="False" />
	</px:PXGrid>
	<px:PXGrid ID="grid2" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" SyncPosition="True" Height="350" AllowPaging="False">
		<Levels>
			<px:PXGridLevel DataMember="InvoiceMatched" DataKeyNames="RefNbr, LineNbr">
				<Columns>
					<px:PXGridColumn DataField="RefNbr" />
					<px:PXGridColumn DataField="LineNbr" />
					<px:PXGridColumn DataField="Selected" Type="CheckBox" AllowCheckAll="True" TextAlign="Center" />
					<px:PXGridColumn DataField="Matched" Type="CheckBox" />
					<px:PXGridColumn DataField="CheckLink" />
					<px:PXGridColumn DataField="BranchID" />
					<px:PXGridColumn DataField="CustomerCD" />
					<px:PXGridColumn DataField="CustomerName" />
					<px:PXGridColumn DataField="ARRefNbr" />
					<px:PXGridColumn DataField="CuryOrigDocAmt" />
					<px:PXGridColumn DataField="PayAmount" />
					<px:PXGridColumn DataField="DocBal" />
					<px:PXGridColumn DataField="DocDate" />
					<px:PXGridColumn DataField="DocDesc" />
					<px:PXGridColumn DataField="WOAmt" CommitChanges="True" />
					<px:PXGridColumn DataField="WriteOffReasonCode" CommitChanges="True" />
					<px:PXGridColumn DataField="DueDate" />
					<px:PXGridColumn DataField="DocType" />
					<px:PXGridColumn DataField="CuryID" />
				</Columns>
				<RowTemplate>
					<px:PXSelector ID="edARRefNbr" runat="server" DataField="ARRefNbr" AllowEdit="True" Enabled="False" />
					<px:PXSelector ID="edBranchID" runat="server" DataField="BranchID" AllowEdit="True" Enabled="False" />
				</RowTemplate>
			</px:PXGridLevel>
		</Levels>
		<Mode AllowAddNew="False" />
		<ActionBar ActionsText="False" PagerVisible="False">
			<CustomItems>
				<px:PXToolBarButton Key="cmdDocumentLookup">
					<AutoCallBack Target="ds" Command="DocumentLookup" />
				</px:PXToolBarButton>
				<px:PXToolBarButton Key="cmdCreateCustomerDocument">
					<AutoCallBack Target="ds" Command="CreateCustomerDocument" />
				</px:PXToolBarButton>
				<px:PXToolBarButton Key="cmdCreateCustomerUnappliedPayment">
					<AutoCallBack Target="ds" Command="CreateCustomerUnappliedPayment" />
				</px:PXToolBarButton>
			</CustomItems>
		</ActionBar>
	</px:PXGrid>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CWLB2010.aspx.cs" Inherits="Page_CWLB2010" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="Crestwood.LB.CWLBSchemaMaint"
        PrimaryView="Schema"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Schema" Width="100%" Height="75px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule1" StartColumn="True" ></px:PXLayoutRule>
			<px:PXSelector AutoRefresh="True" CommitChanges="True" runat="server" ID="CstPXSelector4" DataField="SchemaCd" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit3" DataField="Descr" ></px:PXTextEdit>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule2" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDropDown CommitChanges="True" Size="S" runat="server" ID="CstPXDropDown5" DataField="LayoutType" ></px:PXDropDown>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule6" StartColumn="True" ></px:PXLayoutRule>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit7" DataField="Delimiter" ></px:PXTextEdit>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit10" DataField="StartPos" ></px:PXNumberEdit>
			<px:PXNumberEdit runat="server" ID="CstPXNumberEdit9" DataField="Length" ></px:PXNumberEdit>
			<px:PXCheckBox AlignLeft="False" runat="server" ID="CstPXCheckBox8" DataField="IgnoreFirstRow" ></px:PXCheckBox></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab ID="tab" runat="server" Width="100%" Height="150px" DataSourceID="ds" AllowAutoHide="false">
		<Items>
			<px:PXTabItem Text="Records/Fields">
				<Template>
					<px:PXGrid Caption="Record Types" CaptionVisible="True" Width="900px" SyncPosition="True" Height="115px" SkinID="DetailsInTab" runat="server" ID="gridRecTypes">
						<Levels>
							<px:PXGridLevel DataMember="SchemaRecType" >
								<Columns>
									<px:PXGridColumn DataField="RecType" Width="120" CommitChanges="True" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Descr" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn Type="CheckBox" DataField="IsDetail" Width="60" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
						<AutoCallBack Command="Refresh" Target="gridFields" ActiveBehavior="True" ></AutoCallBack>
						<Mode AllowUpload="True" ></Mode></px:PXGrid>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule13" StartRow="True" />
					<px:PXGrid Caption="Fields" CaptionVisible="True" Width="1200px" runat="server" ID="gridFields" Height="115px" SkinID="DetailsInTab" SyncPosition="True">
						<Levels>
							<px:PXGridLevel DataMember="SchemaField" >
								<Columns>
									<px:PXGridColumn DataField="Enabled" Width="60" Type="CheckBox" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="FieldId" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Descr" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn CommitChanges="True" DataField="DataType" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="StartPos" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Length" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Scale" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn DataField="DateFormat" Width="140" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Mapping" Width="140" ></px:PXGridColumn></Columns>
								<RowTemplate>
									<px:PXSelector runat="server" ID="CstPXSelector2" DataField="RecType" AutoRefresh="True" ></px:PXSelector></RowTemplate></px:PXGridLevel></Levels>
						<Mode AllowUpload="True" ></Mode></px:PXGrid></Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Counters/Actions">
				<Template>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule15" StartRow="True" />
					<px:PXGrid Caption="Accumulators" CaptionVisible="True" Width="450px" SkinID="DetailsInTab" SyncPosition="True" Height="115px" runat="server" ID="gridAccums">
						<Levels>
							<px:PXGridLevel DataMember="SchemaAccum" >
								<Columns>
									<px:PXGridColumn DataField="AccumId" Width="70" CommitChanges="True" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Descr" Width="280" ></px:PXGridColumn></Columns></px:PXGridLevel></Levels>
						<AutoCallBack Command="Refresh" Target="gridActions" ActiveBehavior="True" ></AutoCallBack>
						<Mode AllowUpload="True" ></Mode></px:PXGrid>
					<px:PXLayoutRule runat="server" ID="CstPXLayoutRule16" StartRow="True" />
					<px:PXGrid Caption="Actions" CaptionVisible="True" Width="900px" SkinID="DetailsInTab" SyncPosition="True" Height="115px" runat="server" ID="gridActions">
						<Levels>
							<px:PXGridLevel DataMember="SchemaAction" >
								<Columns>
									<px:PXGridColumn Type="CheckBox" DataField="Enabled" Width="60" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Descr" Width="280" ></px:PXGridColumn>
									<px:PXGridColumn DisplayMode="Hint" DataField="RecType" Width="120" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Idx" Width="70" CommitChanges="True" ></px:PXGridColumn>
									<px:PXGridColumn DataField="Action" Width="70" ></px:PXGridColumn>
									<px:PXGridColumn TextAlign="Left" DisplayMode="Hint" DataField="FieldID" Width="150" ></px:PXGridColumn></Columns>
								<RowTemplate>
									<px:PXSelector runat="server" ID="CstPXSelector1" DataField="RecType" AutoRefresh="True" ></px:PXSelector></RowTemplate></px:PXGridLevel></Levels>
						<Mode AllowUpload="True" ></Mode></px:PXGrid></Template>
			</px:PXTabItem>
		</Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
	</px:PXTab>
</asp:Content>

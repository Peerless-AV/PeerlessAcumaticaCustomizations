<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CWLB3020.aspx.cs" Inherits="Page_CWLB3020" Title="Untitled Page" %> <%@
MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="PaymentLineImportRecords" TypeName="Crestwood.LB.CWLBPaymentLinesEntry">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="CreateNewLockboxPayment" RepaintControls="All" />
			<px:PXDSCallbackCommand Name="Insert" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
			<px:PXDSCallbackCommand Name="CopyPaste" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
			<px:PXDSCallbackCommand Name="Delete" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
			<px:PXDSCallbackCommand Name="First" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
			<px:PXDSCallbackCommand Name="Previous" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
			<px:PXDSCallbackCommand Name="Next" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
			<px:PXDSCallbackCommand Name="Last" PopupCommand="" PopupCommandTarget="" PopupPanel="" Text="" Visible="False" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>

<asp:Content ID="cont2" ContentPlaceHolderID="phL" Runat="Server">
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" SkinID="Details" AdjustPageSize="Auto" SyncPosition="True" KeepPosition="True" AllowPaging="True">
		<Levels>
			<px:PXGridLevel DataMember="PaymentLineImportRecords">
				<Columns>
					<px:PXGridColumn DataField="BatchID" ></px:PXGridColumn>
					<px:PXGridColumn DataField="BatchItemID" ></px:PXGridColumn>
					<px:PXGridColumn DataField="ABART" ></px:PXGridColumn>
					<px:PXGridColumn DataField="AcctNbr" Width="180" />
					<px:PXGridColumn DataField="PaymentDate" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InvoiceDate" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CheckNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CheckAmount" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CustomerID" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CustomerFileDescription" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InvoiceNbr" ></px:PXGridColumn>
					<px:PXGridColumn DataField="InvoiceAmount" ></px:PXGridColumn></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
		<Mode AllowUpload="True" />
	</px:PXGrid>
</asp:Content>

import {
    AR303010,
} from "src/screens/AR/AR303010/AR303010";

import {
    PXFieldState, gridConfig, GridFastFilterVisibility, GridPreset,
    PXView, columnConfig, viewInfo, createCollection
}   from "client-controls";

export interface AR303010_LockBox extends AR303010 { }
export  class AR303010_LockBox {
   	@viewInfo({containerName: "Lockbox Profiles"})
	CWLBProfiles = createCollection(CWLBCPMLBProfile);
 }

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class CWLBCPMLBProfile extends PXView  {

	@columnConfig({width: 180})	AcctNbr : PXFieldState;
	@columnConfig({width: 180})	RoutingNbr : PXFieldState;
}

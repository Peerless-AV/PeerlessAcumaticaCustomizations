import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "Crestwood.LB.CWLBPaymentEntry", primaryView: "PaymentRecords", })
export class CWLB3010 extends PXScreen {
	InsertDocument: PXActionState;

   	@viewInfo({containerName: "Document Lookup"})
	DocumentsToSelect = createCollection(ARInvoice);
   	@viewInfo({containerName: "PaymentHeader"})
	PaymentRecords = createSingle(CWLBPayment);
	PaymentLines = createCollection(CWLBPaymentLine);
	InvoiceMatched = createCollection(CWLBPaymentInvoice);
}// Views

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class ARInvoice extends PXView  {

	@columnConfig({allowNull: false, textAlign: TextAlign.Center, type: GridColumnType.CheckBox})	Selected : PXFieldState<PXFieldOptions.CommitChanges>;
	DocType : PXFieldState;
	RefNbr : PXFieldState;
	Status : PXFieldState;
	CustomerID : PXFieldState;
	CustomerLocationID : PXFieldState;
	DocDate : PXFieldState;
	DueDate : PXFieldState;
	FinPeriodID : PXFieldState;
	CuryID : PXFieldState;
	CuryOrigDocAmt : PXFieldState;
	CuryDocBal : PXFieldState;
	DocDesc : PXFieldState;
	DiscDate : PXFieldState;
	OwnerID : PXFieldState;
}

export class CWLBPayment extends PXView  {

	RefNbr : PXFieldState;
	Status : PXFieldState;
	CuryTotal : PXFieldState;
	CuryAppliedAmount : PXFieldState;
	CuryPaymentCreateAmount : PXFieldState;
	CuryAppPaymentCreateAmount : PXFieldState;
	CuryPaymentAndApplicationAmount : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class CWLBPaymentLine extends PXView  {

	RefNbr : PXFieldState;
	LineNbr : PXFieldState;
	@columnConfig({textAlign: TextAlign.Center, type: GridColumnType.CheckBox})	Selected : PXFieldState;
	@columnConfig({type: GridColumnType.CheckBox})	matched : PXFieldState;
	CheckLink : PXFieldState;
	CustomerID : PXFieldState<PXFieldOptions.CommitChanges>;
	CustomerFileDescription : PXFieldState;
	InvoiceNbr : PXFieldState;
	OrigInvoiceNbr : PXFieldState;
	CuryInvoiceAmount : PXFieldState;
	CuryAppliedAmount : PXFieldState;
	CuryUnappliedAmount : PXFieldState;
	PaymentDate : PXFieldState;
	CheckNbr : PXFieldState;
	CuryCheckAmount : PXFieldState;
	@columnConfig({type: GridColumnType.CheckBox})	PaymentProcessed : PXFieldState;
	@columnConfig({type: GridColumnType.CheckBox})	CreatePaymentApp : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({type: GridColumnType.CheckBox})	CreatePayment : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({type: GridColumnType.CheckBox})	CreatePrePayment : PXFieldState<PXFieldOptions.CommitChanges>;
	BatchItemID : PXFieldState;
	MatchType : PXFieldState;
	BatchID : PXFieldState;
	ABART : PXFieldState;
	AcctNbr : PXFieldState;
	PaymentDocType : PXFieldState<PXFieldOptions.CommitChanges>;
	PaymentRefNbr : PXFieldState<PXFieldOptions.CommitChanges>;
	CuryPaymentAmount : PXFieldState;
	CheckLinkAppNbr : PXFieldState;
	InvoiceDate : PXFieldState;
	CustomerID_Customer_acctName : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	allowInsert: false,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
	topBarItems: {
	DocumentLookup: {index: 0, config: {commandName: "DocumentLookup", text: "Document Lookup"}},
	CreateCustomerDocument: {index: 1, config: {commandName: "CreateCustomerDocument", text: "Create Customer Document"}},
	CreateCustomerUnappliedPayment: {index: 2, config: {commandName: "CreateCustomerUnappliedPayment", text: "Create Customer Unapplied Payment"}},
}
})
export class CWLBPaymentInvoice extends PXView  {

	DocumentLookup : PXActionState;
	CreateCustomerDocument : PXActionState;
	CreateCustomerUnappliedPayment : PXActionState;
	RefNbr : PXFieldState;
	LineNbr : PXFieldState;
	@columnConfig({textAlign: TextAlign.Center, type: GridColumnType.CheckBox})	Selected : PXFieldState;
	@columnConfig({type: GridColumnType.CheckBox})	Matched : PXFieldState;
	CheckLink : PXFieldState;
	BranchID : PXFieldState;
	CustomerCD : PXFieldState;
	CustomerName : PXFieldState;
	ARRefNbr : PXFieldState;
	CuryOrigDocAmt : PXFieldState;
	PayAmount : PXFieldState;
	DocBal : PXFieldState;
	DocDate : PXFieldState;
	DocDesc : PXFieldState;
	WOAmt : PXFieldState<PXFieldOptions.CommitChanges>;
	WriteOffReasonCode : PXFieldState<PXFieldOptions.CommitChanges>;
	DueDate : PXFieldState;
	DocType : PXFieldState;
	CuryID : PXFieldState;
}
import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "Crestwood.LB.CWLBPaymentLinesEntry", primaryView: "PaymentLineImportRecords", })
export class CWLB3020 extends PXScreen {

	PaymentLineImportRecords = createCollection(CWLBPaymentLineImport);
}// Views

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class CWLBPaymentLineImport extends PXView  {

	BatchID : PXFieldState;
	BatchItemID : PXFieldState;
	ABART : PXFieldState;
	@columnConfig({width: 180})	AcctNbr : PXFieldState;
	PaymentDate : PXFieldState;
	InvoiceDate : PXFieldState;
	CheckNbr : PXFieldState;
	CheckAmount : PXFieldState;
	CustomerID : PXFieldState;
	CustomerFileDescription : PXFieldState;
	InvoiceNbr : PXFieldState;
	InvoiceAmount : PXFieldState;
}
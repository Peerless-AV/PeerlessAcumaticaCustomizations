import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "Crestwood.LB.CWLBSchemaMaint", primaryView: "Schema", })
export class CWLB2010 extends PXScreen {

	Schema = createSingle(CWLBSchema);
   	@viewInfo({containerName: "Record Types"})
	SchemaRecType = createCollection(CWLBSchemaRecType);
   	@viewInfo({containerName: "Fields"})
	SchemaField = createCollection(CWLBSchemaField);
   	@viewInfo({containerName: "Accumulators"})
	SchemaAccum = createCollection(CWLBSchemaAccum);
   	@viewInfo({containerName: "Actions"})
	SchemaAction = createCollection(CWLBSchemaAction);
}// Views

export class CWLBSchema extends PXView  {

	SchemaCd : PXFieldState<PXFieldOptions.CommitChanges>;
	Descr : PXFieldState;
	LayoutType : PXFieldState<PXFieldOptions.CommitChanges>;
	Delimiter : PXFieldState;
	StartPos : PXFieldState;
	Length : PXFieldState;
	IgnoreFirstRow : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
    autoRepaint: ["SchemaField"]
})
export class CWLBSchemaRecType extends PXView  {

	@columnConfig({width: 120})	RecType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Descr : PXFieldState;
	@columnConfig({width: 60, type: GridColumnType.CheckBox})	IsDetail : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class CWLBSchemaField extends PXView  {

	@columnConfig({width: 60, type: GridColumnType.CheckBox})	Enabled : PXFieldState;
	@columnConfig({width: 70})	FieldId : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Descr : PXFieldState;
	@columnConfig({width: 70})	DataType : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	StartPos : PXFieldState;
	@columnConfig({width: 70})	Length : PXFieldState;
	@columnConfig({width: 70})	Scale : PXFieldState;
	@columnConfig({width: 140})	DateFormat : PXFieldState;
	@columnConfig({width: 140})	Mapping : PXFieldState;
	RecType : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details,
    autoRepaint: ["SchemaAction"]
})
export class CWLBSchemaAccum extends PXView  {

	@columnConfig({width: 70})	AccumId : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 280})	Descr : PXFieldState;
}

@gridConfig({
	syncPosition: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class CWLBSchemaAction extends PXView  {

	@columnConfig({width: 60, type: GridColumnType.CheckBox})	Enabled : PXFieldState;
	@columnConfig({width: 280})	Descr : PXFieldState;
	@columnConfig({width: 120})	RecType : PXFieldState;
	@columnConfig({width: 70})	Idx : PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({width: 70})	Action : PXFieldState;
	@columnConfig({width: 150, textAlign: TextAlign.Left})	FieldID : PXFieldState;
}
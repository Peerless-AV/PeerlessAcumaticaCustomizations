import { Messages as SysMessages } from "client-controls/services/messages";
import { createCollection, createSingle, PXScreen, graphInfo, PXActionState, viewInfo, handleEvent, CustomEventType, actionConfig, RowSelectedHandlerArgs, PXViewCollection, PXPageLoadBehavior, ControlParameter, PXView, PXFieldState, gridConfig, treeConfig, fieldConfig, controlConfig, headerDescription, ICurrencyInfo, disabled, PXFieldOptions, linkCommand, columnConfig, GridColumnShowHideMode, GridColumnType, TextAlign, GridPreset, GridFilterBarVisibility, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "Crestwood.LB.CWLBSetupMaint", primaryView: "SetupRecord", })
export class CWLB1000 extends PXScreen {

	SetupRecord = createSingle(CWLBSetup);
}// Views

export class CWLBSetup extends PXView  {

	LockBoxPayNumberingID : PXFieldState;
	UseDefaultPM : PXFieldState<PXFieldOptions.CommitChanges>;
	PaymentMethodID : PXFieldState;
	EnableFileSchema : PXFieldState<PXFieldOptions.CommitChanges>;
	FileLayoutSchema : PXFieldState;
	RecordPaymentUnderParent : PXFieldState<PXFieldOptions.CommitChanges>;
}
<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CWLC1000.aspx.cs" Inherits="Page_CWLC1000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="CrestwoodLicensing.CWLicensingMaint" PrimaryView="Licensing">
		<CallbackCommands>
            <px:PXDSCallbackCommand Name="Save" CommitChanges="True" />
            <px:PXDSCallbackCommand Name="Insert" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="CopyPaste" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Delete" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="First" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Previous" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Next" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
            <px:PXDSCallbackCommand Name="Last" PopupCommand="" PopupCommandTarget="" 
                PopupPanel="" Text="" Visible="False">
            </px:PXDSCallbackCommand>
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Style="z-index: 100"
        Width="100%" Height="150px" SkinID="Primary" TabIndex="1500" TemporaryFilterCaption="Filter Applied" KeepPosition="True" SyncPosition="True">
        <Levels>
            <px:PXGridLevel DataMember="Licensing" DataKeyNames="ProductID">
                <RowTemplate>
                    <px:PXTextEdit runat="server" DataField="ProductID" DefaultLocale="" AlreadyLocalized="False" ID="edProductID"></px:PXTextEdit>
                    <px:PXTextEdit runat="server" DataField="CustomerCode" DefaultLocale="" AlreadyLocalized="False" ID="edCustomerCode"></px:PXTextEdit>
                    <px:PXNumberEdit runat="server" DataField="CurrentStatus" DefaultLocale="" AlreadyLocalized="False" ID="edCurrentStatus"></px:PXNumberEdit></RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="ProductID" Width="200px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="CustomerCode" Width="250px"></px:PXGridColumn>
                    <px:PXGridColumn DataField="LicenseKey" Width="285px"></px:PXGridColumn>
                    <px:PXGridColumn TextAlign="Right" DataField="CurrentStatus"></px:PXGridColumn>
                </Columns>
            </px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" />
	</px:PXGrid>
</asp:Content>
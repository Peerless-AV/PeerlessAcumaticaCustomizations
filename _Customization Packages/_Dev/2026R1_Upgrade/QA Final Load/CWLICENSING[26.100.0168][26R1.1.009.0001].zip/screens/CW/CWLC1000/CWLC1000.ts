import { Messages as SysMessages } from "client-controls/services/messages";
import { 
	createCollection, PXScreen, graphInfo, PXView, PXFieldState, gridConfig, columnConfig,
	TextAlign, GridPreset, GridFastFilterVisibility} from "client-controls";

@graphInfo({
	graphType: "CrestwoodLicensing.CWLicensingMaint",
	primaryView: "Licensing"
})
	
export class CWLC1000 extends PXScreen {
	Licensing = createCollection(CWLicensing);
}// Views

@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Primary
})
export class CWLicensing extends PXView  {

	@columnConfig({width: 200})	ProductID : PXFieldState;
	@columnConfig({width: 250})	CustomerCode : PXFieldState;
	@columnConfig({width: 285})	LicenseKey : PXFieldState;
	@columnConfig({textAlign: TextAlign.Right})	CurrentStatus : PXFieldState;
}
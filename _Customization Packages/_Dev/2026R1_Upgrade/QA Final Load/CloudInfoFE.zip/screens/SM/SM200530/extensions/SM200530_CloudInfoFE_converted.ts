import {
  PXFieldState,
  PXFieldOptions,
  placeBeforeProperty,
  placeAfterProperty,
  columnConfig
} from "client-controls";

import {
  SM200530,
  Certificate
} from "src/screens/SM/SM200530/SM200530";

export interface SM200530_CloudInfoFE_converted extends SM200530 { }

export class SM200530_CloudInfoFE_converted { }

export interface SM200530_Certificate_CloudInfoFE_converted extends Certificate { }

export class SM200530_Certificate_CloudInfoFE_converted {
  @placeBeforeProperty("Name")
  @columnConfig({ visible: true })
  UsrPEFESelected: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFESelected")
  @columnConfig({ visible: true })
  UsrPEFEIsValid: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("Name")
  @columnConfig({ visible: true })
  UsrPEFECertificate: PXFieldState;

  @placeAfterProperty("UsrPEFECertificate")
  @columnConfig({ visible: true })
  UsrPEFEPfx: PXFieldState<PXFieldOptions.CommitChanges>;
}
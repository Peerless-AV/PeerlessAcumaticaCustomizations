import {
    PXScreen,
    createSingle,
    graphInfo,
    PXView,
    PXFieldState,
    PXFieldOptions
} from "client-controls";

@graphInfo({
    graphType: "HotFixCPayment.HotFixCPaymentEntry",
    primaryView: "Documents"
})
export class AR301199 extends PXScreen {
    Documents = createSingle(HotFixCPaymentDocument);
}

export class HotFixCPaymentDocument extends PXView {
    RefNbrCP: PXFieldState;
    StampStatus: PXFieldState;

    IssuerPostalCode: PXFieldState;
    IssuerRfc: PXFieldState;
    IssuerName: PXFieldState;
    ReceiverRfc: PXFieldState<PXFieldOptions.CommitChanges>;
    ReceiverName: PXFieldState;
    ReceiverUsoCFDI: PXFieldState;
    ReceiverMail: PXFieldState;
    Sent: PXFieldState;

    UUID: PXFieldState;
    SealDate: PXFieldState;
    CancelUUID: PXFieldState;
    CancelDate: PXFieldState;
    CancelStatus: PXFieldState;

    SealIssue: PXFieldState;
    CertificateNbr: PXFieldState;
    QrCode: PXFieldState;
    QrCodeImg: PXFieldState;
}
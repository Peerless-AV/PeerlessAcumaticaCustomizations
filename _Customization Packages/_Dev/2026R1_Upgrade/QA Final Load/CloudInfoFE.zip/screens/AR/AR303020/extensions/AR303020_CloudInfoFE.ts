import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  AR303020,
  Location
} from "src/screens/AR/AR303020/AR303020";

import {
  Address
} from "src/screens/common/form-address/form-address";

export interface AR303020_CloudInfoFE extends AR303020 { }

export class AR303020_CloudInfoFE {
}

export interface AR303020_Location_CloudInfoFE extends Location { }

export class AR303020_Location_CloudInfoFE {
  @placeAfterProperty("IsDefault")
  BCBillingOnly: PXFieldState;
}

export interface AR303020_Address_CloudInfoFE extends Address { }

export class AR303020_Address_CloudInfoFE {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("PostalCode")
  UsrPEFEAddresRefer: PXFieldState;
}
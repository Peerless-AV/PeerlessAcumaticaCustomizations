import {
  PXView,
  PXFieldState,
  PXActionState,
  createCollection,
  gridConfig,
  GridPreset,
  columnConfig,
  linkCommand,
  viewInfo,
  placeAfterProperty
} from "client-controls";

import {
  AR302000,
  ARAdjust
} from "src/screens/AR/AR302000/AR302000";

export interface AR302000_CloudInfoFE extends AR302000 { }

export class AR302000_CloudInfoFE {
  ViewCP: PXActionState;

  @viewInfo({ containerName: "Complemento Pago" })
  PaymentComplementGrid = createCollection(PaymentComplementGrid);
}

export interface AR302000_ARAdjust_CloudInfoFE extends ARAdjust { }

export class AR302000_ARAdjust_CloudInfoFE {
  @placeAfterProperty("AdjdRefNbr")
  @columnConfig({ width: 250 })
  ARInvoice__PaymentMethod: PXFieldState;
}

@gridConfig({
  preset: GridPreset.Details,
  syncPosition: true,
  allowInsert: false,
  allowDelete: false,
  allowUpdate: false
})
export class PaymentComplementGrid extends PXView {
  @linkCommand("ViewCP")
  @columnConfig({ width: 140 })
  Refnbrcp: PXFieldState;

  @columnConfig({ width: 90 })
  PEFEPaymentComp__DocDate: PXFieldState;

  @columnConfig({ width: 280 })
  PEFEPaymentComp__CustomerID_Customer_acctName: PXFieldState;

  @columnConfig({ width: 70 })
  PEFEPaymentComp__StampStatus: PXFieldState;

  @columnConfig({ width: 90 })
  PEFEPaymentComp__SealDate: PXFieldState;

  @columnConfig({ width: 180 })
  PEFEPaymentComp__CancelStatus: PXFieldState;

  @columnConfig({ width: 90 })
  PEFEPaymentComp__CancelDate: PXFieldState;

  @columnConfig({ width: 220 })
  PEFEPaymentComp__UUID: PXFieldState;

  @columnConfig({ width: 60 })
  PEFEPaymentComp__Sent: PXFieldState;
}
import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  AR303010,
  CustomerPaymentMethod
} from "src/screens/AR/AR303010/AR303010";

import {
  Address
} from "src/screens/common/form-address/form-address";

export interface AR303010_CloudInfoFE extends AR303010 { }

export class AR303010_CloudInfoFE {
}

export interface AR303010_CustomerPaymentMethod_CloudInfoFE extends CustomerPaymentMethod { }

export class AR303010_CustomerPaymentMethod_CloudInfoFE {
  @placeAfterProperty("IsActive")
  AvailableOnPortals: PXFieldState;

  @placeAfterProperty("Descr")
  UsrPEFEBancoSAT: PXFieldState;
}

export interface AR303010_Address_CloudInfoFE extends Address { }

export class AR303010_Address_CloudInfoFE {
  @placeAfterProperty("AddressLine2")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEIntNumber")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig
} from "client-controls";

import {
  AR303000,
  Customer,
  Customer2
} from "src/screens/AR/AR303000/AR303000";

import {
  AR303000_LocationDetail
} from "src/screens/AR/AR303000/extensions/AR303000_Locations";

import {
  Address
} from "src/screens/common/form-address/form-address";

import {
  Contact
} from "src/screens/common/form-contact-profile/form-contact-profile";

export interface AR303000_CloudInfoFE extends AR303000 { }

export class AR303000_CloudInfoFE {
}

export interface AR303000_Customer_CloudInfoFE extends Customer { }

export class AR303000_Customer_CloudInfoFE {
  @placeAfterProperty("CustomerClassID")
  FEEnableIedu: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface AR303000_Customer2_CloudInfoFE extends Customer2 { }

export class AR303000_Customer2_CloudInfoFE {
  @placeAfterProperty("DefPaymentMethodID")
  UsrPEFECfdi: PXFieldState;

  @placeAfterProperty("UsrPEFECfdi")
  UsrPEFETaxRegime: PXFieldState;

  @placeAfterProperty("UsrPEFETaxRegime")
  UsrPEFEpay: PXFieldState;

  @placeAfterProperty("UsrPEFEpay")
  UsrFEEnableProgramaIMMEX: PXFieldState;

  @placeAfterProperty("UsrFEEnableProgramaIMMEX")
  UsrFEIeduCURP: PXFieldState;

  @placeAfterProperty("UsrFEIeduCURP")
  UsrFEIeduGRADO: PXFieldState;

  @placeAfterProperty("UsrFEIeduGRADO")
  UsrFEIeduNIVEL: PXFieldState;

  @placeAfterProperty("UsrFEIeduNIVEL")
  UsrFEIeduRVOE: PXFieldState;
}

export interface AR303000_LocationDetail_CloudInfoFE extends AR303000_LocationDetail { }

export class AR303000_LocationDetail_CloudInfoFE {
  @columnConfig({ visible: true, hideViewLink: true })
  CSalesAcctID: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface AR303000_Address_CloudInfoFE extends Address { }

export class AR303000_Address_CloudInfoFE {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("PostalCode")
  UsrPEFEAddresRefer: PXFieldState;
}

export interface AR303000_Contact_CloudInfoFE extends Contact { }

export class AR303000_Contact_CloudInfoFE {
  @placeAfterProperty("EMail")
  UsrPEFEMailPay: PXFieldState;
}
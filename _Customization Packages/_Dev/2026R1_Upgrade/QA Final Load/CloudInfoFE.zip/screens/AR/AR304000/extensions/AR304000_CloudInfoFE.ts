import {
  PXView,
  PXFieldState,
  PXFieldOptions,
  PXActionState,
  createSingle,
  createCollection,
  gridConfig,
  GridPreset,
  columnConfig,
  placeAfterProperty,
  viewInfo
} from "client-controls";

import {
  AR304000,
  ARRegister,
  ARRegister2,
  ARTran
} from "src/screens/AR/AR304000/AR304000";

import {
  Address
} from "src/screens/common/form-address/form-address";

import {
  Contact
} from "src/screens/common/form-contact-document/form-contact-document";

export interface AR304000_CloudInfoFE extends AR304000 { }

export class AR304000_CloudInfoFE {
  @viewInfo({ containerName: "Documentos Relacionados" })
  RelatedDocuments = createCollection(PEFERelaDocument);

  @viewInfo({ containerName: "Instituciones Educativas" })
  TransactionsIEDU = createCollection(ARTranIEDU);

  @viewInfo({ containerName: "Cancelacion" })
  popUpCancelStamp = createSingle(PopUpCancelStamp);
}

export interface AR304000_ARRegister_CloudInfoFE extends ARRegister { }

export class AR304000_ARRegister_CloudInfoFE {
  @placeAfterProperty("Status")
  StampStatus: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("StampStatus")
  CancelStatus: PXFieldState;

  @placeAfterProperty("CancelStatus")
  UsrPEFENotStampable: PXFieldState;

  @placeAfterProperty("RefTranExtNbr")
  FEEnableRelatedDocuments: PXFieldState;

  @placeAfterProperty("FEEnableRelatedDocuments")
  FEEnableIedu: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface AR304000_ARRegister2_CloudInfoFE extends ARRegister2 { }

export class AR304000_ARRegister2_CloudInfoFE {
  @placeAfterProperty("AvalaraCustomerUsageType")
  ReceiverUsoCFDI: PXFieldState;

  @placeAfterProperty("ReceiverUsoCFDI")
  PaymentForm: PXFieldState;

  @placeAfterProperty("PaymentForm")
  PaymentMethod: PXFieldState;

  @placeAfterProperty("PaymentMethod")
  PostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("PostalCode")
  ReceiverTaxRegime: PXFieldState;

  @placeAfterProperty("ReceiverTaxRegime")
  SealIssue: PXFieldState;

  @placeAfterProperty("SealIssue")
  CertificateNbr: PXFieldState;

  @placeAfterProperty("CertificateNbr")
  AmountToWords: PXFieldState;

  @placeAfterProperty("AmountToWords")
  UUID: PXFieldState;

  @placeAfterProperty("UUID")
  SealDate: PXFieldState;

  @placeAfterProperty("SealDate")
  QrCodeImg: PXFieldState;

  @placeAfterProperty("QrCodeImg")
  CancelDate: PXFieldState;

  @placeAfterProperty("CancelDate")
  CancelUUID: PXFieldState;

  @placeAfterProperty("CancelUUID")
  CancelReason: PXFieldState;

  @placeAfterProperty("CancelReason")
  ReplacementFolio: PXFieldState;
}

export interface AR304000_ARTran_CloudInfoFE extends ARTran { }

export class AR304000_ARTran_CloudInfoFE {
  @placeAfterProperty("Qty")
  @columnConfig({ width: 140 })
  UsrParentID: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("TaxCategoryID")
  @columnConfig({ width: 70 })
  UsrPEFEObjectTaxSAT: PXFieldState;

  @placeAfterProperty("DiscPctDR")
  @columnConfig({ width: 280 })
  UsrFEPedimento: PXFieldState;

  @placeAfterProperty("UsrFEPedimento")
  @columnConfig({ width: 280 })
  UsrFESerie: PXFieldState;

  @placeAfterProperty("UsrFESerie")
  @columnConfig({ width: 280 })
  UsrFEAddlDescription: PXFieldState;
}

export interface AR304000_Contact_CloudInfoFE extends Contact { }

export class AR304000_Contact_CloudInfoFE {
  @placeAfterProperty("OverrideContact")
  UsrTaxRegistrationID: PXFieldState;
}

export interface AR304000_Address_CloudInfoFE extends Address { }

export class AR304000_Address_CloudInfoFE {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  preset: GridPreset.Details,
  syncPosition: true,
  allowInsert: true,
  allowDelete: true,
  allowUpdate: true
})
export class PEFERelaDocument extends PXView {
  @columnConfig({ width: 140 })
  RefNbrRela: PXFieldState;

  @columnConfig({ width: 70 })
  DocTypeRela: PXFieldState;

  @columnConfig({ width: 180 })
  Uuid: PXFieldState;

  @columnConfig({ width: 70 })
  UsrPEFEreasons: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 220 })
  UsrPEFEDescripcion: PXFieldState;
}

@gridConfig({
  preset: GridPreset.Details,
  syncPosition: true,
  allowInsert: false,
  allowDelete: false,
  allowUpdate: true
})
export class ARTranIEDU extends PXView {
  @columnConfig({ width: 280 })
  InventoryID_description: PXFieldState;

  @columnConfig({ width: 140 })
  FamiliarID: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 280 })
  FamiliarID_Customer_acctName: PXFieldState;

  @columnConfig({ width: 180 })
  CURP: PXFieldState;

  @columnConfig({ width: 180 })
  GRADO: PXFieldState;

  @columnConfig({ width: 180 })
  NIVEL: PXFieldState;

  @columnConfig({ width: 180 })
  RVOE: PXFieldState;
}

export class PopUpCancelStamp extends PXView {
  TempCancelReason: PXFieldState;
  TempReplacementFolio: PXFieldState;
}
import {
    PXScreen,
    createSingle,
    graphInfo,
    PXView,
    PXFieldState,
    PXFieldOptions,
    PXActionState
} from "client-controls";

@graphInfo({
    graphType: "HotFixInvoice.HotFixInvoiceEntry",
    primaryView: "Documents"
})
export class AR301099 extends PXScreen {
    Documents = createSingle(HotFixInvoiceDocument);
    changeProcessingStatus: PXActionState;
}

export class HotFixInvoiceDocument extends PXView {
    DocType: PXFieldState;
    RefNbr: PXFieldState;
    StampStatus: PXFieldState;

    PostalCode: PXFieldState;
    IssuerRfc: PXFieldState;
    IssuerName: PXFieldState;
    ReceiverRfc: PXFieldState<PXFieldOptions.CommitChanges>;
    ReceiverName: PXFieldState;
    ReceiverUsoCFDI: PXFieldState;
    PaymentForm: PXFieldState;
    PaymentMethod: PXFieldState;
    UsrPEFENotStampable: PXFieldState<PXFieldOptions.CommitChanges>;

    UUID: PXFieldState;
    SealDate: PXFieldState;
    CancelUUID: PXFieldState;
    CancelDate: PXFieldState;
    CancelStatus: PXFieldState;

    SealIssue: PXFieldState;
    CertificateNbr: PXFieldState;
    QrCode: PXFieldState<PXFieldOptions.CommitChanges>;
    QrCodeImg: PXFieldState;
}
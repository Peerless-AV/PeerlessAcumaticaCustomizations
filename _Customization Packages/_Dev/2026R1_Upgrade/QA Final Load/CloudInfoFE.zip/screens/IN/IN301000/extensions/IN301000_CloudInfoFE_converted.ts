import {
  PXFieldState,
  placeAfterProperty
} from "client-controls";

import {
  IN301000,
  INRegister
} from "src/screens/IN/IN301000/IN301000";

export interface IN301000_CloudInfoFE_converted extends IN301000 { }

export class IN301000_CloudInfoFE_converted { }

export interface IN301000_INRegister_CloudInfoFE_converted extends INRegister { }

export class IN301000_INRegister_CloudInfoFE_converted {
  @placeAfterProperty("ControlCost")
  UsrPEFEAduana: PXFieldState;

  @placeAfterProperty("UsrPEFEAduana")
  UsrPEFEDateImport: PXFieldState;

  @placeAfterProperty("UsrPEFEDateImport")
  UsrPEFENumberPed: PXFieldState;
}
import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  IN202000,
  InventoryItem,
  ItemSettings
} from "src/screens/IN/IN202000/IN202000";

export interface IN202000_CloudInfoFE_converted extends IN202000 { }

export class IN202000_CloudInfoFE_converted { }

export interface IN202000_InventoryItem_CloudInfoFE_converted extends InventoryItem { }

export class IN202000_InventoryItem_CloudInfoFE_converted {
  @placeAfterProperty("ProductManagerID")
  UsrPEFEProdSAT: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEProdSAT")
  UsrDangerousMaterialCD: PXFieldState;

  @placeAfterProperty("UsrDangerousMaterialCD")
  UsrPackagingCD: PXFieldState;

  @placeAfterProperty("UsrPackagingCD")
  UsrPackagingDescription: PXFieldState;

  @placeAfterProperty("UsrPackagingDescription")
  UsrFEPredialSAT: PXFieldState;

  @placeAfterProperty("UsrFEPredialSAT")
  UsrFraccAran: PXFieldState;

  @placeAfterProperty("UsrFraccAran")
  UsrMaterialType: PXFieldState;

  @placeAfterProperty("UsrMaterialType")
  UsrMaterialDescription: PXFieldState;
}

export interface IN202000_ItemSettings_CloudInfoFE_converted extends ItemSettings { }

export class IN202000_ItemSettings_CloudInfoFE_converted {
  @placeAfterProperty("MetaDescription")
  SectorCOFEPRIS: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("SectorCOFEPRIS")
  NombreIngredienteActivo: PXFieldState;

  @placeAfterProperty("NombreIngredienteActivo")
  NomQuimico: PXFieldState;

  @placeAfterProperty("NomQuimico")
  DenominacionGenericaProd: PXFieldState;

  @placeAfterProperty("DenominacionGenericaProd")
  DenominacionDistintivaProd: PXFieldState;

  @placeAfterProperty("DenominacionDistintivaProd")
  Fabricante: PXFieldState;

  @placeAfterProperty("Fabricante")
  FechaCaducidad: PXFieldState;

  @placeAfterProperty("FechaCaducidad")
  LoteMedicamento: PXFieldState;

  @placeAfterProperty("LoteMedicamento")
  FormaFarmaceutica: PXFieldState;

  @placeAfterProperty("FormaFarmaceutica")
  CondicionesEspTransp: PXFieldState;

  @placeAfterProperty("CondicionesEspTransp")
  RegistroSanitarioFolioAutorizacion: PXFieldState;

  @placeAfterProperty("RegistroSanitarioFolioAutorizacion")
  PermisoImportacion: PXFieldState;

  @placeAfterProperty("PermisoImportacion")
  FolioImpoVUCEM: PXFieldState;

  @placeAfterProperty("FolioImpoVUCEM")
  NumCAS: PXFieldState;

  @placeAfterProperty("NumCAS")
  RazonSocialEmpImp: PXFieldState;

  @placeAfterProperty("RazonSocialEmpImp")
  NumRegSanPlagCOFEPRIS: PXFieldState;

  @placeAfterProperty("NumRegSanPlagCOFEPRIS")
  DatosFabricante: PXFieldState;

  @placeAfterProperty("DatosFabricante")
  DatosFormulador: PXFieldState;

  @placeAfterProperty("DatosFormulador")
  DatosMaquilador: PXFieldState;

  @placeAfterProperty("DatosMaquilador")
  UsoAutorizado: PXFieldState;
}
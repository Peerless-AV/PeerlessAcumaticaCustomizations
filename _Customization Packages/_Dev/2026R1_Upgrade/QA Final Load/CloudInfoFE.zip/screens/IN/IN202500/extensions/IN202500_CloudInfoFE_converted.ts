import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  PXActionState,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
} from "client-controls";
import { IN202500, InventoryItem, ItemSettings } from "src/screens/IN/IN202500/IN202500";

export interface IN202500_CloudInfoFE_converted extends IN202500 {}

export class IN202500_CloudInfoFE_converted {}

export interface IN202500_InventoryItem_CloudInfoFE_converted extends InventoryItem {}
export class IN202500_InventoryItem_CloudInfoFE_converted {
  @placeAfterProperty("ChkEquipmentManagement")
  UsrPEFEProdSAT: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrDangerousMaterialCD: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrPackagingCD: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrPackagingDescription: PXFieldState;

  UsrFEPredialSAT: PXFieldState;

  UsrFraccAran: PXFieldState;

  UsrMaterialType: PXFieldState;

  UsrMaterialDescription: PXFieldState;

  UsrFEIMMEX: PXFieldState;
}
export interface IN202500_ItemSettings_CloudInfoFE_converted extends ItemSettings {}
export class IN202500_ItemSettings_CloudInfoFE_converted {
  @placeAfterProperty("MetaDescription")
  SectorCOFEPRIS: PXFieldState<PXFieldOptions.CommitChanges>;

  NombreIngredienteActivo: PXFieldState;

  NomQuimico: PXFieldState;

  DenominacionGenericaProd: PXFieldState;

  DenominacionDistintivaProd: PXFieldState;

  Fabricante: PXFieldState;

  FechaCaducidad: PXFieldState;

  LoteMedicamento: PXFieldState;

  FormaFarmaceutica: PXFieldState;

  CondicionesEspTransp: PXFieldState;

  RegistroSanitarioFolioAutorizacion: PXFieldState;

  PermisoImportacion: PXFieldState;

  FolioImpoVUCEM: PXFieldState;

  NumCAS: PXFieldState;

  RazonSocialEmpImp: PXFieldState;

  NumRegSanPlagCOFEPRIS: PXFieldState;

  DatosFabricante: PXFieldState;

  DatosFormulador: PXFieldState;

  DatosMaquilador: PXFieldState;

  UsoAutorizado: PXFieldState;
}

import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  PXActionState,
  updateDecorator,
  removeDecorator,
  featureInstalled,
  FeaturesSet,
  placeBeforeView,
  placeAfterView,
  placeBeforeProperty,
  placeAfterProperty,
  graphInfo,
  viewInfo,
  gridConfig,
  columnConfig,
  treeConfig,
  controlConfig,
  linkCommand,
  fieldOptions,
  fieldConfig,
  fieldInfo,
  headerDescription,
  autoRefresh,
  mappedToViewField,
  suppressLabel,
  readOnly,
  disabled,
  unbound,
  text,
  multiLine,
  primaryKey,
  type,
  ControlParameter,
  NetType,
  MenuItemRenderType,
  ScrollMode,
  TextAlign,
  GridPreset,
  GridColumnType,
  GridColumnShowHideMode,
  GridColumnDisplayMode,
  GridAutoGrowMode,
  GridPagerMode,
  GridFastFilterVisibility,
  GridNoteFilesShowMode,
  HeaderDescription,
  GridColumnGeneration,
  GridFilterBarVisibility,
  NodeSelectMode,
  PXSelectorMode,
  ApplySuggestionMode,
  ITextEditorControlConfig,
  ITimeSpanConfig,
  ISelectorControlConfig,
  ISegmentedSelectorControlConfig,
  IEditorControlConfig,
  INumberEditorControlConfig,
  IMaskEditorControlConfig,
  IMailEditorControlConfig,
  ILinkEditorControlConfig,
  IDropDownConfig,
  IDatetimeEditControlConfig,
  IColorPickerControlConfig,
  ICheckBoxControlConfig,
  ICalendarControlConfig,
  IBranchSelectorConfig,
  IBarcodeInputControlConfig,
  ITreeSelectorConfig,
  IRichTextEditorConfig,
  IFormulaEditorConfig,
  ICurrencyControlConfig,
  FieldGenerationMode,
} from "client-controls";
import { IN204000, INSite } from "src/screens/IN/IN204000/IN204000";
import { Contact } from "src/screens/common/form-contact-profile/form-contact-profile";
import { Address } from "src/screens/common/form-address/form-address";

export interface IN204000_CloudInfoFE_converted extends IN204000 {}

export class IN204000_CloudInfoFE_converted {}

export interface IN204000_INSite_CloudInfoFE_converted extends INSite {}
export class IN204000_INSite_CloudInfoFE_converted {
  @placeAfterProperty("FIFODefaultCost")
  UsrIssuerTaxRegime: PXFieldState;
}
export interface IN204000_Contact_CloudInfoFE_converted extends Contact {}
export class IN204000_Contact_CloudInfoFE_converted {
  @placeBeforeProperty("FullName")
  UsrTaxRegistrationID: PXFieldState;

  @placeAfterProperty("UsrTaxRegistrationID")
  FullName: PXFieldState;
}
export interface IN204000_Address_CloudInfoFE_converted extends Address {}
export class IN204000_Address_CloudInfoFE_converted {
  @placeBeforeProperty("AddressLine1")
  IsValidated: PXFieldState<PXFieldOptions.Disabled>;

  @placeAfterProperty("IsValidated")
  AddressLine1: PXFieldState;

  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEIntNumber")
  City: PXFieldState;

  State: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFECity")
  PostalCode: PXFieldState;

  @placeAfterProperty("PostalCode")
  UsrPEFEExpedido: PXFieldState<PXFieldOptions.CommitChanges>;
}

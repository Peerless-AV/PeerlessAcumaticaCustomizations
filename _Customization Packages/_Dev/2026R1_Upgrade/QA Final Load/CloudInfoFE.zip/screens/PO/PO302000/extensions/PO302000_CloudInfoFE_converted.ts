import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  PO302000,
  POReceiptHeader
} from "src/screens/PO/PO302000/PO302000";

export interface PO302000_CloudInfoFE_converted extends PO302000 { }

export class PO302000_CloudInfoFE_converted { }

export interface PO302000_POReceiptHeader_CloudInfoFE_converted extends POReceiptHeader { }

export class PO302000_POReceiptHeader_CloudInfoFE_converted {
  @placeAfterProperty("ShowLandedCostsTab")
  UsrPEFEAduana: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEAduana")
  UsrPEFEDateImport: PXFieldState;

  @placeAfterProperty("UsrPEFEDateImport")
  UsrPEFENumberPed: PXFieldState;
}
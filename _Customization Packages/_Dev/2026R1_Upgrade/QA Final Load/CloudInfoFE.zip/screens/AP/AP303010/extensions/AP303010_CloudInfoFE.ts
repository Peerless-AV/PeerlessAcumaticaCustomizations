import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  AP303010
} from "src/screens/AP/AP303010/AP303010";

import {
  Address
} from "src/screens/common/form-address/form-address";

export interface AP303010_CloudInfoFE_converted extends AP303010 { }

export class AP303010_CloudInfoFE_converted { }

export interface AP303010_Address_CloudInfoFE_converted extends Address { }

export class AP303010_Address_CloudInfoFE_converted {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
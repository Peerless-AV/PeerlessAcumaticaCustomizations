import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  AP303000
} from "src/screens/AP/AP303000/AP303000";

import {
  Vendor
} from "src/screens/AP/AP303000/views";

import {
  Address
} from "src/screens/common/form-address/form-address";

export interface AP303000_CloudInfoFE extends AP303000 { }

export class AP303000_CloudInfoFE { }

export interface AP303000_Vendor_CloudInfoFE extends Vendor { }

export class AP303000_Vendor_CloudInfoFE {
  @placeAfterProperty("LocaleName")
  UsrIsInsurer: PXFieldState;

  @placeAfterProperty("UsrIsInsurer")
  UsrIsLessee: PXFieldState;
}

export interface AP303000_Address_CloudInfoFE extends Address { }

export class AP303000_Address_CloudInfoFE {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
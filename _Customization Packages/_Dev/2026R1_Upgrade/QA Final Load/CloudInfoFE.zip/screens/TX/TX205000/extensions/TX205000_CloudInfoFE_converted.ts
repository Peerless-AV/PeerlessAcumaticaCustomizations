import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  TX205000,
  Tax
} from "src/screens/TX/TX205000/TX205000";

export interface TX205000_CloudInfoFE_converted extends TX205000 { }

export class TX205000_CloudInfoFE_converted { }

export interface TX205000_Tax_CloudInfoFE_converted extends Tax { }

export class TX205000_Tax_CloudInfoFE_converted {
  @placeAfterProperty("TaxUOM")
  UsrPEFETaxSAT: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFETaxSAT")
  UsrValorTasa: PXFieldState;
}
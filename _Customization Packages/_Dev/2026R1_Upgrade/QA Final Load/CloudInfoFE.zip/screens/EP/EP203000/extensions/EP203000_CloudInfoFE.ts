import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	Address
} from "src/screens/common/form-address/form-address";

import {
	EP203000,
	ContactDetail
} from "src/screens/EP/EP203000/EP203000";

export interface EP203000_CloudInfoFE extends EP203000 {
}

export class EP203000_CloudInfoFE {
}

export interface ContactDetail_EP203000_CloudInfoFE extends ContactDetail {
}

export class ContactDetail_EP203000_CloudInfoFE {
	@placeAfterProperty("Phone2")
	Phone3Type: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Phone3Type")
	Phone3: PXFieldState;

	@placeAfterProperty("Phone3")
	FaxType: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("FaxType")
	Fax: PXFieldState;
}

export interface Address_EP203000_CloudInfoFE extends Address {
}

export class Address_EP203000_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
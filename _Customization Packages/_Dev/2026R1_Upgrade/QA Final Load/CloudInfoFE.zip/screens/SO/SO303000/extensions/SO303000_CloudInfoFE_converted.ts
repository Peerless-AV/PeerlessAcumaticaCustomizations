import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  PXActionState,
  placeAfterProperty,
  viewInfo,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
  createSingle,
  createCollection,
} from "client-controls";

import {
  SO303000,
  ARInvoiceCurrent,
  ARInvoice,
  ARTran
} from "src/screens/SO/SO303000/SO303000";

import {
  Contact
} from "src/screens/common/form-contact-document/form-contact-document";

import {
  Address
} from "src/screens/common/form-address/form-address";

export interface SO303000_CloudInfoFE_converted extends SO303000 { }

export class SO303000_CloudInfoFE_converted {
  ShowFELineSplit: PXActionState;
  SectorCofepris: PXActionState;

  @viewInfo({ containerName: "Carta Porte" })
  shipment = createSingle(SOShipment);

  @viewInfo({ containerName: "Transportista" })
  popUp = createSingle(TransportistaFilter);

  @viewInfo({ containerName: "Comercio Exterior" })
  comerExterior = createSingle(PEFEExternalTrade);

  @viewInfo({ containerName: "Mercancias" })
  FELines = createCollection(PEFEExtTradeLine);

  @viewInfo({ containerName: "Documentos Relacionados" })
  RelatedDocuments = createCollection(PEFERelaDocuments);

  @viewInfo({ containerName: "Operadores" })
  ConsignmentNoteOperators = createCollection(SOConsignmentNoteOperators);

  @viewInfo({ containerName: "Descripcion Especifica" })
  FESplitDeta = createCollection(PEFEExtTradeLineDet);

  @viewInfo({ containerName: "Cancelacion" })
  popUpCancelStamp = createSingle(CancelStampFilter);

  @viewInfo({ containerName: "Sector COFEPRIS" })
  popUpCofepris = createSingle(CofeprisFilter);
}

export class TransportistaFilter extends PXView {
  TempTransportista: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface SO303000_ARInvoiceCurrent_CloudInfoFE_converted
  extends ARInvoiceCurrent { }

export class SO303000_ARInvoiceCurrent_CloudInfoFE_converted {
  @placeAfterProperty("CuryUnpaidBalance")
  ReceiverUsoCFDI: PXFieldState;

  PaymentForm: PXFieldState<PXFieldOptions.Disabled>;

  PaymentMethod: PXFieldState;

  StateCpny: PXFieldState<PXFieldOptions.CommitChanges>;

  PostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverTaxRegime: PXFieldState;

  SealIssue: PXFieldState;

  CertificateNbr: PXFieldState;

  AmountToWords: PXFieldState;

  Periodicity: PXFieldState;

  Months: PXFieldState;

  Year: PXFieldState;

  SealDate: PXFieldState;

  UUID: PXFieldState;

  QrCodeImg: PXFieldState;

  CancelDate: PXFieldState;

  CancelUUID: PXFieldState;

  CancelReason: PXFieldState<PXFieldOptions.Disabled>;

  ReplacementFolio: PXFieldState<PXFieldOptions.Disabled>;

  Export: PXFieldState<PXFieldOptions.CommitChanges>;

  ShipmentNbr: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class SOShipment extends PXView {
  IdCCP: PXFieldState;

  QrCCPImage: PXFieldState;

  ConsignmentNote: PXFieldState<PXFieldOptions.CommitChanges>;

  NotStampable: PXFieldState;

  StampStatus: PXFieldState;

  InternationalTransport: PXFieldState;

  DistanceTraveled: PXFieldState;

  UnitMeasurement: PXFieldState;

  ReverseLogistics: PXFieldState;

  Istmo: PXFieldState;

  CustomsRegime: PXFieldState;

  CountryOriginDestination: PXFieldState;

  EntryExit: PXFieldState;

  ViaEntryExit: PXFieldState;

  IstmoOrigin: PXFieldState;

  DateTimeOut_Date: PXFieldState<PXFieldOptions.CommitChanges>;

  DateTimeOut_Time: PXFieldState<PXFieldOptions.CommitChanges>;

  EditSender: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderRFC: PXFieldState;

  SenderName: PXFieldState;

  SenderStreet: PXFieldState;

  SenderOutNumber: PXFieldState;

  SenderIntNumber: PXFieldState;

  SenderCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderState: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderColony: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderReference: PXFieldState;

  IstmoDestination: PXFieldState;

  DateTimeArrival_Date: PXFieldState<PXFieldOptions.CommitChanges>;

  DateTimeArrival_Time: PXFieldState<PXFieldOptions.CommitChanges>;

  EditAddressee: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeRFC: PXFieldState;

  AddresseeName: PXFieldState;

  AddresseeStreet: PXFieldState;

  AddresseeOutNumber: PXFieldState;

  AddresseeIntNumber: PXFieldState;

  AddresseeCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeState: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeColony: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeReference: PXFieldState;

  VehicleUnitID: PXFieldState<PXFieldOptions.CommitChanges>;

  EditVehicleUnit: PXFieldState<PXFieldOptions.CommitChanges>;

  VehicleUnitPermissionSCT: PXFieldState;

  VehicleUnitPermitNumber: PXFieldState;

  VehicleUnitCivilLiabilityInsurer: PXFieldState;

  VehicleUnitCivilLiabilityPolicy: PXFieldState;

  VehicleUnitEnvironmentalInsurer: PXFieldState;

  VehicleUnitEnvironmentalPolicy: PXFieldState;

  VehicleUnitFreightTransportationInsurer: PXFieldState;

  VehicleUnitFreightTransportationPolicy: PXFieldState;

  VehicleUnitTransportID: PXFieldState;

  VehicleWeight: PXFieldState;

  VehicleUnitAutomobileRegistration: PXFieldState;

  VehicleUnitModelYear: PXFieldState;

  VehicleUnitPartOwnedOrLeased: PXFieldState;

  VehicleUnitPartTransport: PXFieldState;

  VehicleUnitIsTrailer: PXFieldState<PXFieldOptions.CommitChanges>;

  VehicleUnitTypeTrailerID: PXFieldState;

  VehicleUnitTrailerRegistration: PXFieldState;

  VehicleUnitIsDoubleTrailer: PXFieldState<PXFieldOptions.CommitChanges>;

  VehicleUnitTypeDoubleTrailerID: PXFieldState;

  VehicleUnitDoubleTrailerRegistration: PXFieldState;

  TransportOwnerID: PXFieldState<PXFieldOptions.CommitChanges>;

  EditTransportOwner: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerRFC: PXFieldState;

  TransportOwnerName: PXFieldState;

  TransportOwnerStreet: PXFieldState;

  TransportOwnerOutNumber: PXFieldState;

  TransportOwnerIntNumber: PXFieldState;

  TransportOwnerCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerState: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerColony: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerReference: PXFieldState;

  MultiOperators: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorID: PXFieldState<PXFieldOptions.CommitChanges>;

  EditOperator: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorRFC: PXFieldState;

  OperatorName: PXFieldState;

  OperatorDriverLicense: PXFieldState;

  OperatorStreet: PXFieldState;

  OperatorOutNumber: PXFieldState;

  OperatorIntNumber: PXFieldState;

  OperatorCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorState: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorColony: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorReference: PXFieldState;
}

export class PEFEExternalTrade extends PXView {
  ForeignTrade: PXFieldState<PXFieldOptions.CommitChanges>;

  EtCuryRate: PXFieldState<PXFieldOptions.CommitChanges>;

  EtOperationType: PXFieldState;

  EtRequestKey: PXFieldState;

  EtIncoterm: PXFieldState;

  EtTransferReason: PXFieldState;

  EtIsOriginCert: PXFieldState;

  EtOriginCertNbr: PXFieldState;

  EtTrustworthyExporterNbr: PXFieldState;

  EtDescription: PXFieldState;

  EtUsdTotal: PXFieldState<
    PXFieldOptions.CommitChanges | PXFieldOptions.Disabled
  >;

  EtHasAddressed: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverName: PXFieldState;

  ReceiverRFC: PXFieldState;

  ReceiverCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverStreet: PXFieldState;

  ReceiverOutNbr: PXFieldState;

  ReceiverMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverState: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverLocation: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverZipCode: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
  topBarItems: {
    ShowFELineSplit: {
      index: 0,
      config: {
        commandName: "ShowFELineSplit",
        text: "Descripcion Especifica"
      }
    },
  },
})
export class PEFEExtTradeLine extends PXView {
  ShowFELineSplit: PXActionState;

  @columnConfig({ width: 220 })
  Identification: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 96 })
  TariffFraction: PXFieldState;

  @columnConfig({ width: 70 })
  Uom: PXFieldState;

  @columnConfig({ width: 100 })
  Qty: PXFieldState;

  @columnConfig({ width: 100 })
  UnitPrice: PXFieldState;

  @columnConfig({ width: 100 })
  TotalAmt: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class PEFERelaDocuments extends PXView {
  @columnConfig({ width: 140 })
  RefNbrRela: PXFieldState;

  @columnConfig({ width: 70 })
  DocTypeRela: PXFieldState;

  @columnConfig({ width: 180 })
  UUID: PXFieldState;

  @columnConfig({ width: 70 })
  UsrPEFEreasons: PXFieldState;

  @columnConfig({ width: 220 })
  UsrPEFEDescripcion: PXFieldState;
}

@gridConfig({
  initNewRow: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Empty,
})
export class SOConsignmentNoteOperators extends PXView {
  @columnConfig({ width: 140 })
  OperatorCD: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 140 })
  RFC: PXFieldState;

  @columnConfig({ width: 280 })
  Name: PXFieldState;

  @columnConfig({ width: 180 })
  DriverLicense: PXFieldState;

  @columnConfig({ width: 280 })
  Street: PXFieldState;

  @columnConfig({ width: 140 })
  OutNumber: PXFieldState;

  @columnConfig({ width: 140 })
  IntNumber: PXFieldState;

  @columnConfig({ width: 70 })
  CountryID: PXFieldState;

  @columnConfig({ width: 70 })
  StateID: PXFieldState;

  @columnConfig({ width: 70 })
  MunicipalityID: PXFieldState;

  @columnConfig({ width: 120 })
  ZipCode: PXFieldState;

  @columnConfig({ width: 70 })
  SettlementID: PXFieldState;

  @columnConfig({ width: 70 })
  LocalityID: PXFieldState;

  @columnConfig({ width: 280 })
  Reference: PXFieldState;
}

@gridConfig({
  initNewRow: true,
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class PEFEExtTradeLineDet extends PXView {
  @columnConfig({ width: 220 })
  Identification: PXFieldState;

  @columnConfig({ width: 220 })
  Brand: PXFieldState;

  @columnConfig({ width: 220 })
  Model: PXFieldState;

  @columnConfig({ width: 180 })
  SubModel: PXFieldState;

  @columnConfig({ width: 180 })
  SerieNbr: PXFieldState;
}

export class CancelStampFilter extends PXView {
  TempCancelReason: PXFieldState;

  TempReplacementFolio: PXFieldState;
}

export class CofeprisFilter extends PXView {
  OverrideSectorCOFEPRIS: PXFieldState<PXFieldOptions.CommitChanges>;

  SectorCOFEPRIS: PXFieldState<PXFieldOptions.CommitChanges>;

  NombreIngredienteActivo: PXFieldState;

  NomQuimico: PXFieldState;

  DenominacionGenericaProd: PXFieldState;

  DenominacionDistintivaProd: PXFieldState;

  Fabricante: PXFieldState;

  FechaCaducidad: PXFieldState;

  LoteMedicamento: PXFieldState;

  FormaFarmaceutica: PXFieldState;

  CondicionesEspTransp: PXFieldState;

  RegistroSanitarioFolioAutorizacion: PXFieldState;

  PermisoImportacion: PXFieldState;

  FolioImpoVUCEM: PXFieldState;

  NumCAS: PXFieldState;

  RazonSocialEmpImp: PXFieldState;

  NumRegSanPlagCOFEPRIS: PXFieldState;

  DatosFabricante: PXFieldState;

  DatosFormulador: PXFieldState;

  DatosMaquilador: PXFieldState;

  UsoAutorizado: PXFieldState;
}

export interface SO303000_ARInvoice_CloudInfoFE_converted
  extends ARInvoice { }

export class SO303000_ARInvoice_CloudInfoFE_converted {
  @placeAfterProperty("Status")
  UsrPEFENotStampable: PXFieldState;

  @placeAfterProperty("DocDesc")
  StampStatus: PXFieldState;

  @placeAfterProperty("StampStatus")
  CancelStatus: PXFieldState<PXFieldOptions.Disabled>;

  @placeAfterProperty("CuryOrigDiscAmt")
  FEEnableRelatedDocuments: PXFieldState<PXFieldOptions.Hidden>;

  @placeAfterProperty("FEEnableComercioExterior")
  FEEnableComercioExterior: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface SO303000_ARTran_CloudInfoFE_converted
  extends ARTran { }

export class SO303000_ARTran_CloudInfoFE_converted {
  @placeAfterProperty("CuryTranAmt")
  @columnConfig({ width: 220 })
  UsrFEIdentification: PXFieldState;

  @placeAfterProperty("DefScheduleID")
  @columnConfig({ width: 70 })
  UsrPEFEObjectTaxSAT: PXFieldState;

  @placeAfterProperty("BlanketNbr")
  @columnConfig({ width: 280 })
  UsrFEAddlDescription: PXFieldState;
}

export interface SO303000_Contact_CloudInfoFE_converted
  extends Contact { }

export class SO303000_Contact_CloudInfoFE_converted {
  @placeAfterProperty("OverrideContact")
  UsrTaxRegistrationID: PXFieldState;
}

export interface SO303000_Address_CloudInfoFE_converted
  extends Address { }

export class SO303000_Address_CloudInfoFE_converted {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
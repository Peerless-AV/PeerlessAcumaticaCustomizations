import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  columnConfig
} from "client-controls";

import {
  SO301000,
  SOLine
} from "src/screens/SO/SO301000/SO301000";

import {
  Contact
} from "src/screens/common/form-contact-document/form-contact-document";

import {
  Address
} from "src/screens/common/form-address/form-address";

export interface SO301000_CloudInfoFE_converted extends SO301000 { }

export class SO301000_CloudInfoFE_converted { }

export interface SO301000_SOLine_CloudInfoFE_converted extends SOLine { }

export class SO301000_SOLine_CloudInfoFE_converted {
  @placeAfterProperty("LocationID")
  @columnConfig({
    width: 220
  })
  UsrFEIdentification: PXFieldState;
}

export interface SO301000_Contact_CloudInfoFE_converted extends Contact { }

export class SO301000_Contact_CloudInfoFE_converted {
  @placeAfterProperty("OverrideContact")
  UsrTaxRegistrationID: PXFieldState;
}

export interface SO301000_Address_CloudInfoFE_converted extends Address { }

export class SO301000_Address_CloudInfoFE_converted {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
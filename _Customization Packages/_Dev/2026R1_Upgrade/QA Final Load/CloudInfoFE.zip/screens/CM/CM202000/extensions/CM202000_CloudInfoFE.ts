import {
  PXFieldState,
  placeAfterProperty
} from "client-controls";

import {
  CM202000,
  CurrencyList
} from "src/screens/CM/CM202000/CM202000";

export interface CM202000_CloudInfoFE extends CM202000 { }

export class CM202000_CloudInfoFE {
}

export interface CM202000_CurrencyList_CloudInfoFE extends CurrencyList { }

export class CM202000_CurrencyList_CloudInfoFE {
  @placeAfterProperty("IsFinancial")
  UsrPEFECodModSAT: PXFieldState;
}
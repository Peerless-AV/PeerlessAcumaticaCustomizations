import {
	PXFieldOptions,
	PXFieldState,
	controlConfig,
	ISelectorControlConfig,
	placeAfterProperty
} from "client-controls";

import {
	CR301000,
	CRLead
} from "src/screens/CR/CR301000/CR301000";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CR301000_CloudInfoFE extends CR301000 {
}

export class CR301000_CloudInfoFE {
}

export interface CRLead_CR301000_CloudInfoFE extends CRLead {
}

export class CRLead_CR301000_CloudInfoFE {
	@placeAfterProperty("DisplayName")
	@controlConfig<ISelectorControlConfig>({ allowEdit: true })
	ClassID: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Phone2")
	Phone3Type: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Phone3Type")
	Phone3: PXFieldState;

	@placeAfterProperty("Phone3")
	FaxType: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("FaxType")
	Fax: PXFieldState;
}

export interface Address_CR301000_CloudInfoFE extends Address {
}

export class Address_CR301000_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
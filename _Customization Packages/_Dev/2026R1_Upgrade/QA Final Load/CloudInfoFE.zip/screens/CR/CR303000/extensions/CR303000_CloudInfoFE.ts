import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	CR303000
} from "src/screens/CR/CR303000/CR303000";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CR303000_CloudInfoFE extends CR303000 {
}

export class CR303000_CloudInfoFE {
}

export interface Address_CR303000_CloudInfoFE extends Address {
}

export class Address_CR303000_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
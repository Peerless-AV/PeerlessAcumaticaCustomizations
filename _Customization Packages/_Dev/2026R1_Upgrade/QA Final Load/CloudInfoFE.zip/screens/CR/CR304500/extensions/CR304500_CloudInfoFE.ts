import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	CR304500
} from "src/screens/CR/CR304500/CR304500";

import {
	ContactDetail
} from "src/screens/CR/CR304500/extensions/CR304500_Contact";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CR304500_CloudInfoFE extends CR304500 {
}

export class CR304500_CloudInfoFE {
}

export interface ContactDetail_CR304500_CloudInfoFE extends ContactDetail {
}

export class ContactDetail_CR304500_CloudInfoFE {
	@placeAfterProperty("Phone2")
	Phone3Type: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Phone3Type")
	Phone3: PXFieldState;

	@placeAfterProperty("Phone3")
	FaxType: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("FaxType")
	Fax: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface Address_CR304500_CloudInfoFE extends Address {
}

export class Address_CR304500_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
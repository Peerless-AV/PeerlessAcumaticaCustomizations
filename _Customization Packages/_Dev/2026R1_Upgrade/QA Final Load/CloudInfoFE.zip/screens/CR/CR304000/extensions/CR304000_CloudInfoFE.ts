import {
	PXFieldOptions,
	PXFieldState,
	PXView,
	createSingle,
	placeAfterProperty,
	viewInfo
} from "client-controls";

import {
	CR304000
} from "src/screens/CR/CR304000/CR304000";

import {
	ContactDetail
} from "src/screens/CR/CR304000/extensions/CR304000_Contact";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CR304000_CloudInfoFE extends CR304000 {
}

export class CR304000_CloudInfoFE {
	@viewInfo({ containerName: "Carrier Data" })
	CarrierData = createSingle(CarrierData);
}

export interface ContactDetail_CR304000_CloudInfoFE extends ContactDetail {
}

export class ContactDetail_CR304000_CloudInfoFE {
	@placeAfterProperty("Phone2")
	Phone3Type: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Phone3Type")
	Phone3: PXFieldState;

	@placeAfterProperty("Phone3")
	FaxType: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("FaxType")
	Fax: PXFieldState;
}

export interface Address_CR304000_CloudInfoFE extends Address {
}

export class Address_CR304000_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class CarrierData extends PXView {
	AdditionalHandling: PXFieldState;
	LiftGate: PXFieldState;
	InsideDelivery: PXFieldState;
	LimitedAccess: PXFieldState;
}
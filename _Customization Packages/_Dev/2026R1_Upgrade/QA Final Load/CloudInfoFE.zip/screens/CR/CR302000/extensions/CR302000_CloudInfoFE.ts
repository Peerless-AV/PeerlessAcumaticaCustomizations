import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty,
	columnConfig
} from "client-controls";

import {
	CR302000,
	ContactDetail
} from "src/screens/CR/CR302000/CR302000";


import {
	CRCampaignMembers
} from "src/screens/CR/common/tabs/tab-campaigns/tab-campaigns";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CR302000_CloudInfoFE extends CR302000 {
}

export class CR302000_CloudInfoFE {
}

export interface ContactDetail_CR302000_CloudInfoFE extends ContactDetail {
}

export class ContactDetail_CR302000_CloudInfoFE {
	@placeAfterProperty("Phone2")
	Phone3Type: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Phone3Type")
	Phone3: PXFieldState;

	@placeAfterProperty("Phone3")
	FaxType: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("FaxType")
	Fax: PXFieldState;
}


export interface CRCampaignMembers_CR302000_CloudInfoFE extends CRCampaignMembers {
}

export class CRCampaignMembers_CR302000_CloudInfoFE {
	@placeAfterProperty("CRCampaign__OwnerID")
	@columnConfig({ visible: true })
	Contact__ContactType: PXFieldState;

	@placeAfterProperty("Contact__ContactType")
	@columnConfig({ visible: true })
	Contact__FullName: PXFieldState;
}

export interface Address_CR302000_CloudInfoFE extends Address {
}

export class Address_CR302000_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
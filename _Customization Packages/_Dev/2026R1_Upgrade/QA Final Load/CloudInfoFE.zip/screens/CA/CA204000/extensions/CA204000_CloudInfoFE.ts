import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty
} from "client-controls";

import {
  CA204000,
  PaymentMethod
} from "src/screens/CA/CA204000/CA204000";

export interface CA204000_CloudInfoFE extends CA204000 { }

export class CA204000_CloudInfoFE {
}

export interface CA204000_PaymentMethod_CloudInfoFE extends PaymentMethod { }

export class CA204000_PaymentMethod_CloudInfoFE {
  @placeAfterProperty("Descr")
  UsrPEFEMethodPayment: PXFieldState<PXFieldOptions.CommitChanges>;
}
import {
  PXView,
  PXFieldState,
  PXFieldOptions,
  createSingle,
  placeAfterProperty,
  viewInfo
} from "client-controls";

import {
  CA202000,
  CashAccount
} from "src/screens/CA/CA202000/CA202000";

export interface CA202000_CloudInfoFE extends CA202000 { }

export class CA202000_CloudInfoFE {
  @viewInfo({ containerName: "Cash Account Summary -> Bank Feed" })
  BankFeed = createSingle(BankFeed);
}

export interface CA202000_CashAccount_CloudInfoFE extends CashAccount { }

export class CA202000_CashAccount_CloudInfoFE {
  @placeAfterProperty("StatementImportTypeName")
  UsrPEFEBancoSAT: PXFieldState<PXFieldOptions.CommitChanges>;
}

export class BankFeed extends PXView {
  StatementImportSource: PXFieldState;
}
import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	CS102000
} from "src/screens/CS/CS102000/CS102000";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CS102000_CloudInfoFE extends CS102000 {
}

export class CS102000_CloudInfoFE {
}

export interface Address_CS102000_CloudInfoFE extends Address {
}

export class Address_CS102000_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
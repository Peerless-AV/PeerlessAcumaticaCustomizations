import {
	PXFieldOptions,
	PXFieldState,
	columnConfig,
	placeAfterProperty
} from "client-controls";

import {
	CS204000,
	Country,
	CountryStates
} from "src/screens/CS/CS204000/CS204000";

export interface CS204000_CloudInfoFE extends CS204000 {
}

export class CS204000_CloudInfoFE {
}

export interface Country_CS204000_CloudInfoFE extends Country {
}

export class Country_CS204000_CloudInfoFE {
	@placeAfterProperty("AddressValidatorPluginID")
	UsrPEFECodPais: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface CountryStates_CS204000_CloudInfoFE extends CountryStates {
}

export class CountryStates_CS204000_CloudInfoFE {
	@placeAfterProperty("SalesTerritoryID")
	UsrPEFEStadoSAT: PXFieldState;

	@placeAfterProperty("SalesTerritoryID_Description")
	@columnConfig({ visible: true })
	StateRegexp: PXFieldState;

	@placeAfterProperty("StateRegexp")
	@columnConfig({ visible: true })
	NonTaxable: PXFieldState;

	@placeAfterProperty("NonTaxable")
	LocationCode: PXFieldState;
}
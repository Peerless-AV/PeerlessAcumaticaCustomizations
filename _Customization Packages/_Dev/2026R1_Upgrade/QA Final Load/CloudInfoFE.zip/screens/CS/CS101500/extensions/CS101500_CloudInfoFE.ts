import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	CS101500
} from "src/screens/CS/CS101500/CS101500";

import {
	BAccount
} from "src/screens/CS/CS101500/views";

import {
	Address
} from "src/screens/common/form-address/form-address";

export interface CS101500_CloudInfoFE extends CS101500 {
}

export class CS101500_CloudInfoFE {
}

export interface BAccount_CS101500_CloudInfoFE extends BAccount {
}

export class BAccount_CS101500_CloudInfoFE {
	@placeAfterProperty("AcctName")
	UsrPEFETaxRegime: PXFieldState;

	@placeAfterProperty("UsrPEFETaxRegime")
	UsrPEFECertName: PXFieldState;

	@placeAfterProperty("UsrPEFECertName")
	UsrPEFEFacAtrAdq: PXFieldState;

	@placeAfterProperty("UsrPEFEFacAtrAdq")
	FEEnableDonat: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("FEEnableDonat")
	UsrFEGenerateDonat: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEGenerateDonat")
	UsrFENoAtorizacion: PXFieldState;

	@placeAfterProperty("UsrFENoAtorizacion")
	UsrFEFechaAutorizacion: PXFieldState;

	@placeAfterProperty("UsrFEFechaAutorizacion")
	UsrFELeyenda: PXFieldState;
}

export interface Address_CS101500_CloudInfoFE extends Address {
}

export class Address_CS101500_CloudInfoFE {
	@placeAfterProperty("AddressLine2")
	UsrPEFEExtNumber: PXFieldState;

	@placeAfterProperty("UsrPEFEExtNumber")
	UsrPEFEIntNumber: PXFieldState;

	@placeAfterProperty("State")
	UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrPEFEMunicipality")
	UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFEPostalCode")
	UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UsrFELocality")
	UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}
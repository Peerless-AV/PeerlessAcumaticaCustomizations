import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	CS100000
} from "src/screens/CS/CS100000/CS100000";

import {
	FeaturesSet
} from "src/screens/CS/CS100000/views";

export interface CS100000_CloudInfoFE extends CS100000 {
}

export class CS100000_CloudInfoFE {
}

export interface CS100000_FeaturesSet_CloudInfoFE extends FeaturesSet {
}

export class CS100000_FeaturesSet_CloudInfoFE {
	@placeAfterProperty("ValidUntill")
	UsrActivarModulo: PXFieldState<PXFieldOptions.CommitChanges>;
}
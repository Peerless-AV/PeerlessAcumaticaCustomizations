import {
	PXFieldOptions,
	PXFieldState,
	placeAfterProperty
} from "client-controls";

import {
	CS203100,
	INUnit
} from "src/screens/CS/CS203100/CS203100";

export interface CS203100_CloudInfoFE extends CS203100 {
}

export class CS203100_CloudInfoFE {
}

export interface INUnit_CS203100_CloudInfoFE extends INUnit {
}

export class INUnit_CS203100_CloudInfoFE {
	@placeAfterProperty("UnitRate")
	UsrPEFEUnitSAT: PXFieldState<PXFieldOptions.CommitChanges>;
}
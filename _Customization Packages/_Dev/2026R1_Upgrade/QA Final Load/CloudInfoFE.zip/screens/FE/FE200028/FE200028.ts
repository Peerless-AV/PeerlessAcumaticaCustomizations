import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEWeigthUnitSATMaint", primaryView: "WeigthUnit" })
export class FE200028 extends PXScreen {
  WeigthUnit = createCollection(PEFEWeigthUnitSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEWeigthUnitSAT extends PXView {
  @columnConfig({
    width: 70,
  })
  UnitCD: PXFieldState;
  @columnConfig({
    width: 250,
  })
  Name: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Note: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Flag: PXFieldState;
  @columnConfig({
    width: 180,
  })
  Symbol: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "CI.Objects.FE.FECorrectionInvoicesMaint", primaryView: "CorrectionInvoices" })
export class FE900000 extends PXScreen {
  CorrectionInvoices = createCollection(FECorrecctionInvoices);
}
// Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class FECorrecctionInvoices extends PXView {
  @columnConfig({
    width: 140,
  })
  RefNbr: PXFieldState;
  @columnConfig({
    width: 120,
  })
  DocType: PXFieldState;
  @columnConfig({
    width: 100,
  })
  CuryLineTotal: PXFieldState;
  @columnConfig({
    width: 100,
  })
  CuryTaxTotal: PXFieldState;
  @columnConfig({
    width: 100,
  })
  CuryOrigDocAmt: PXFieldState;
  @columnConfig({
    width: 140,
  })
  IssuerRfc: PXFieldState;
  @columnConfig({
    width: 140,
  })
  ReceiverRfc: PXFieldState;
  @columnConfig({
    width: 180,
  })
  UUID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  SealDate: PXFieldState;
  @columnConfig({
    width: 180,
  })
  CancelUUID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  CancelDate: PXFieldState;
  @columnConfig({
    width: 180,
  })
  CorrectionUUID: PXFieldState;
  @columnConfig({
    width: 90,
  })
  SealCorectionDate: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEFederalTrasportationSATMaint", primaryView: "FederalTrasportation" })
export class FE200025 extends PXScreen {
  FederalTrasportation = createCollection(PEFEFederalTrasportationSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEFederalTrasportationSAT extends PXView {
  @columnConfig({
    width: 84,
  })
  NomenclatureCD: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 70,
  })
  NumberShafts: PXFieldState;
  @columnConfig({
    width: 70,
  })
  NumberTires: PXFieldState;
  @columnConfig({
    width: 70,
  })
  Trailer: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
}

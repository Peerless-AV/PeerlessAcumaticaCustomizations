import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEColoniesSATMaint", primaryView: "ColoniesSATs" })
export class FE200010 extends PXScreen {
  ColoniesSATs = createCollection(PEFEColoniesSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEColoniesSAT extends PXView {
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  ColoniesCD: PXFieldState;
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  ZipCodeCD: PXFieldState;
  @columnConfig({
    width: 280,
    allowFastFilter: true,
  })
  Name: PXFieldState;
  Erpmatica: PXFieldState;
}

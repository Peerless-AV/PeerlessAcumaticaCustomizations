import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEInvoiceProcess", primaryView: "Filter" })
export class FE501000 extends PXScreen {
  Filter = createSingle(PEFEInvoiceProcessFilter);
  Invoices = createCollection(PEFEDescargaCFDI);
}
// Views

export class PEFEInvoiceProcessFilter extends PXView {
  Action: PXFieldState;
  DocType: PXFieldState<PXFieldOptions.Hidden>;
}

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class PEFEDescargaCFDI extends PXView {
  @columnConfig({
    width: 60,
  })
  Selected: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 70,
  })
  Doctype: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Referencia: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Rfc: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Nombre: PXFieldState;
  @columnConfig({
    width: 100,
    timeMode: false,
  })
  Monto: PXFieldState;
  @columnConfig({
    width: 90,
  })
  SealDate_Date: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Uuid: PXFieldState;
}

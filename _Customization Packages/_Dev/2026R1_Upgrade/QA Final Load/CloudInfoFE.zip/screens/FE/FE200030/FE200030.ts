import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEPeriodicitySATMaint", primaryView: "Periodicity" })
export class FE200030 extends PXScreen {
  Periodicity = createCollection(PEFEPeriodicitySAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEPeriodicitySAT extends PXView {
  @columnConfig({
    width: 70,
  })
  PeriodicityCD: PXFieldState;
  @columnConfig({
    width: 280,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Use: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  @columnConfig({
    width: 60,
  })
  IsDefaultGlobal: PXFieldState;
}

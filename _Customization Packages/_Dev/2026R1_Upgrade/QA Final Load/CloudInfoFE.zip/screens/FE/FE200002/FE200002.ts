import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEInventorySATMaint", primaryView: "InventorySATs" })
export class FE200002 extends PXScreen {
  InventorySATs = createCollection(PEFEInventorySAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEInventorySAT extends PXView {
  @columnConfig({
    width: 96,
    allowFastFilter: true,
  })
  InventoryCD: PXFieldState;
  @columnConfig({
    width: 280,
    allowFastFilter: true,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  @columnConfig({
    width: 140,
  })
  TransferredIVA: PXFieldState;
  @columnConfig({
    width: 140,
  })
  TransferredIEPS: PXFieldState;
  @columnConfig({
    width: 180,
  })
  IncludeComplement: PXFieldState;
  @columnConfig({
    width: 220,
  })
  SimilarWords: PXFieldState;
  @columnConfig({
    width: 70,
  })
  DangerousMaterial: PXFieldState;
  Erpmatica: PXFieldState;
}

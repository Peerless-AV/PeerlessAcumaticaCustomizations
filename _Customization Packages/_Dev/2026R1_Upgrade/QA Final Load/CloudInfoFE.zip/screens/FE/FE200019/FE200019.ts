import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEMethodpaymentSATMaint", primaryView: "Formapago" })
export class FE200019 extends PXScreen {
  Formapago = createCollection(PEFEMethodPaymentSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEMethodPaymentSAT extends PXView {
  @columnConfig({
    width: 70,
  })
  Paymentmethod: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 70,
  })
  Banked: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Operationnumber: PXFieldState;
  @columnConfig({
    width: 140,
  })
  AccountIssuer: PXFieldState;
  @columnConfig({
    width: 140,
  })
  OrderingAccount: PXFieldState;
  @columnConfig({
    width: 140,
  })
  PatteOrderaccount: PXFieldState;
  @columnConfig({
    width: 140,
  })
  IssuerBeneficiary: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Beneficiaryaccount: PXFieldState;
  @columnConfig({
    width: 140,
  })
  BeneficiaryEmployer: PXFieldState;
  @columnConfig({
    width: 120,
  })
  ChainType: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Namebank: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
}

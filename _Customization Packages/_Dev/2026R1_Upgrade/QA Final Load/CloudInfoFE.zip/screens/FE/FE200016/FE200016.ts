import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFETypeTaxSATMaint", primaryView: "taxes" })
export class FE200016 extends PXScreen {
  taxes = createCollection(PEFETypeTaxSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFETypeTaxSAT extends PXView {
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  CodTaxCD: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 60,
  })
  Retention: PXFieldState;
  @columnConfig({
    width: 60,
  })
  Transfer: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Localfederal: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
}

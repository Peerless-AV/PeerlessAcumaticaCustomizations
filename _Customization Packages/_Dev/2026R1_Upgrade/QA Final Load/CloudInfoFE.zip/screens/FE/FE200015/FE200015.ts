import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFETyPevoucherSATMAint", primaryView: "voucher" })
export class FE200015 extends PXScreen {
  voucher = createCollection(PEFETypeVoucherSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFETypeVoucherSAT extends PXView {
  @columnConfig({
    width: 70,
  })
  TyPevoucherCD: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 180,
  })
  Maximumvalue: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  @columnConfig({
    width: 70,
  })
  TDocumAR: PXFieldState<PXFieldOptions.CommitChanges>;
}

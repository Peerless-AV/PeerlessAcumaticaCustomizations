import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEVehicleUnitsMaint", primaryView: "VehicleUnits" })
export class FE203000 extends PXScreen {
  VehicleUnits = createSingle(PEFEVehicleUnits);
  CurrentVehicleUnits = createSingle(PEFEVehicleUnits2);
}
// Views

export class PEFEVehicleUnits extends PXView {
  UnitCD: PXFieldState;
  Description: PXFieldState;
}

export class PEFEVehicleUnits2 extends PXView {
  PermissionSCT: PXFieldState<PXFieldOptions.CommitChanges>;
  PermitNumber: PXFieldState;
  TransportID: PXFieldState;
  VehicleWeight: PXFieldState;
  AutomobileRegistration: PXFieldState;
  ModelYear: PXFieldState;
  OwnedOrLeased: PXFieldState<PXFieldOptions.CommitChanges>;
  ProviderRentTheVehicle: PXFieldState<PXFieldOptions.CommitChanges>;
  PartTransport: PXFieldState;
  IsTrailer: PXFieldState<PXFieldOptions.CommitChanges>;
  TypeTrailerID: PXFieldState;
  TrailerRegistration: PXFieldState;
  IsDoubleTrailer: PXFieldState<PXFieldOptions.CommitChanges>;
  TypeDoubleTrailerID: PXFieldState;
  DoubleTrailerRegistration: PXFieldState;
  CivilLiabilityInsurerID: PXFieldState;
  CivilLiabilityPolicyNumber: PXFieldState;
  EnvironmentalInsurerID: PXFieldState;
  EnvironmentalPolicyNumber: PXFieldState;
  FreightTransportationInsurerID: PXFieldState;
  FreightTransportationPolicyNumber: PXFieldState;
}

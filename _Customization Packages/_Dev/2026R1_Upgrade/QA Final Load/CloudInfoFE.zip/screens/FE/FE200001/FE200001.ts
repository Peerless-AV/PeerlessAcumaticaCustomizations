import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFECfdiSATMaint", primaryView: "CfdiSATs" })
export class FE200001 extends PXScreen {
  CfdiSATs = createCollection(PEFECfdiSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFECfdiSAT extends PXView {
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  CfdiCD: PXFieldState;
  @columnConfig({
    width: 280,
    allowFastFilter: true,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 60,
  })
  PersonNatural: PXFieldState;
  @columnConfig({
    width: 60,
  })
  PersonMoral: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  @columnConfig({
    width: 280,
  })
  ReceiverTaxRegime: PXFieldState;
  Erpmatica: PXFieldState;
}

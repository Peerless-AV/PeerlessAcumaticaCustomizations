import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFELocationSATMaint", primaryView: "Location" })
export class FE200018 extends PXScreen {
  Location = createCollection(PEFELocationSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFELocationSAT extends PXView {
  @columnConfig({
    width: 70,
  })
  CodLocal: PXFieldState;
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  State: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  Description: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEInvoiceTimbrar", primaryView: "Document" })
export class FE502000 extends PXScreen {
  Document = createCollection(ARInvoice);
}
// Views

@gridConfig({
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class ARInvoice extends PXView {
  @columnConfig({
    width: 60,
  })
  Selected: PXFieldState;
  @columnConfig({
    width: 220,
  })
  CustomerID_description: PXFieldState;
  @columnConfig({
    width: 90,
  })
  DocDate: PXFieldState;
  @columnConfig({
    width: 70,
  })
  DocType: PXFieldState;
  @columnConfig({
    width: 140,
  })
  RefNbr: PXFieldState;
  @columnConfig({
    width: 100,
  })
  CuryOrigDocAmt: PXFieldState;
  @columnConfig({
    width: 280,
  })
  DocDesc: PXFieldState;
}

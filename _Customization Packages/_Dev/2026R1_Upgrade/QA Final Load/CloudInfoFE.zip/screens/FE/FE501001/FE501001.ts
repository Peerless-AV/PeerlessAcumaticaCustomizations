import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  PXView,
  PXFieldState,
  PXFieldOptions,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
  linkCommand
} from "client-controls";

@graphInfo({
  graphType: "CI.Objects.FE.DW.FEDownloadCFDIProcess",
  primaryView: "Filter"
})
export class FE501001 extends PXScreen {
  ViewDocument: PXActionState;

  Filter = createSingle(PEFEInvoiceProcessFilter);
  Documents = createCollection(PEFEDescargaCFDI);
}

export class PEFEInvoiceProcessFilter extends PXView {
  Action: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Inquiry
})
export class PEFEDescargaCFDI extends PXView {
  @columnConfig({
    width: 60
  })
  Selected: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({
    width: 140
  })
  TipoDoc: PXFieldState;

  @linkCommand("ViewDocument")
  @columnConfig({
    width: 140
  })
  Referencia: PXFieldState;

  @columnConfig({
    width: 220
  })
  Rfc: PXFieldState;

  @columnConfig({
    width: 280
  })
  Nombre: PXFieldState;

  @columnConfig({
    width: 100
  })
  Monto: PXFieldState;

  @columnConfig({
    width: 90,
    timeMode: false
  })
  SealDate_Date: PXFieldState;

  @columnConfig({
    width: 220
  })
  Uuid: PXFieldState;
}
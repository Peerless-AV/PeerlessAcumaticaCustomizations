import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEPaymentTimbar", primaryView: "Payment" })
export class FE503000 extends PXScreen {
  Payment = createCollection(PEFEPaymentComp);
}
export class PEFEPaymentCompType {
  DocType: PXFieldState;
  CuryOrigDocAmt: PXFieldState;
}

// Views

@gridConfig({
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEPaymentComp extends PXView {
  @columnConfig({
    width: 60,
    allowSort: false,
  })
  Selected: PXFieldState;
  @columnConfig({
    width: 70,
  })
  PEFEProcessPayment: PEFEPaymentCompType;
  @columnConfig({
    width: 140,
    allowFastFilter: true,
  })
  RefNbrCP: PXFieldState;
  @columnConfig({
    width: 90,
  })
  DocDate: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  CustomerID_Customer_acctName: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFECtsInformationMaint", primaryView: "PECtsInformations" })
export class FE201000 extends PXScreen {
  PECtsInformations = createCollection(PEFECustomsInformation);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFECustomsInformation extends PXView {
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  ReceptionID: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  InventoryID: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  SerieID: PXFieldState;
  @columnConfig({
    width: 220,
  })
  Customs: PXFieldState;
  @columnConfig({
    width: 90,
  })
  ImportDate: PXFieldState;
  @columnConfig({
    width: 220,
    allowFastFilter: true,
  })
  PetitionID: PXFieldState;
  Erpmatica: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEInvoiceEntry", primaryView: "Documents" })
export class FE504000 extends PXScreen {
  Documents = createSingle(ARInvoice);
}
// Views

export class ARInvoice extends PXView {
  DocType: PXFieldState;
  @controlConfig({
    fastFilterFields: ["ARInvoice__InvoiceNbr", "CustomerID", "CustomerID_Customer_AcctName"],
    parameters: null,
  })
  RefNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  ReceiverUsoCFDI: PXFieldState;
  PaymentForm: PXFieldState;
  PaymentMethod: PXFieldState;
  PostalCode: PXFieldState;
  UUID: PXFieldState;
  SealDate: PXFieldState;
  SealIssue: PXFieldState;
  CertificateNbr: PXFieldState;
  AmountToWords: PXFieldState;
  QrCodeImg: PXFieldState;
}

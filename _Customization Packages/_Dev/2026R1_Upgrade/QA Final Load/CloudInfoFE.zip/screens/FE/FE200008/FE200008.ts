import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFECountrySATMaint", primaryView: "Country" })
export class FE200008 extends PXScreen {
  Country = createCollection(PEFECountrySAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFECountrySAT extends PXView {
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  CountryCD: PXFieldState;
  @columnConfig({
    width: 280,
    allowFastFilter: true,
  })
  Name: PXFieldState;
  @columnConfig({
    width: 70,
  })
  ZipCodeCD: PXFieldState;
  @columnConfig({
    width: 120,
  })
  ForfiscalIdentity: PXFieldState;
  @columnConfig({
    width: 120,
  })
  ValfiscalIdentity: PXFieldState;
  @columnConfig({
    width: 140,
  })
  group: PXFieldState;
  Erpmatica: PXFieldState;
}

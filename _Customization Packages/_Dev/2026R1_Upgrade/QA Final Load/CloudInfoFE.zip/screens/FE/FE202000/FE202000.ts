import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEOperatorsMaint", primaryView: "Operators" })
export class FE202000 extends PXScreen {
  Operators = createSingle(PEFEOperators);
  CurrentOperators = createSingle(PEFEOperators2);
}
// Views

export class PEFEOperators extends PXView {
  OperatorCD: PXFieldState;
  Name: PXFieldState;
}

export class PEFEOperators2 extends PXView {
  Street: PXFieldState;
  OutNumber: PXFieldState;
  IntNumber: PXFieldState;
  CountryID: PXFieldState<PXFieldOptions.CommitChanges>;
  StateID: PXFieldState<PXFieldOptions.CommitChanges>;
  MunicipalityID: PXFieldState<PXFieldOptions.CommitChanges>;
  ZipCode: PXFieldState<PXFieldOptions.CommitChanges>;
  SettlementID: PXFieldState<PXFieldOptions.CommitChanges>;
  LocalityID: PXFieldState<PXFieldOptions.CommitChanges>;
  Reference: PXFieldState;
  RFC: PXFieldState;
  DriverLicense: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFESetupMaint", primaryView: "Setup" })
export class FE101000 extends PXScreen {
  Setup = createSingle(PEFESetup);
}
// Views

export class PEFESetup extends PXView {
  Provider: PXFieldState<PXFieldOptions.CommitChanges>;
  UserProd: PXFieldState;
  PwdProd: PXFieldState;
  UserProdSF: PXFieldState;
  PwdProdSF: PXFieldState;
  ApiKey: PXFieldState;
  TrialMode: PXFieldState;
  Version: PXFieldState;
  AutoSign: PXFieldState<PXFieldOptions.Disabled>;
  AdjHour: PXFieldState;
  FilesName: PXFieldState;
  EnableSeparateSeries: PXFieldState;
  EnableRemoveSeries: PXFieldState;
  PaymentRefNbr: PXFieldState;
  PaymentNotifID: PXFieldState;
  ChkItem: PXFieldState;
  CarrierCustomer: PXFieldState;
  UnitMeasurement: PXFieldState;
  EnableFractionPetition: PXFieldState;
  BUsoInfGlobal: PXFieldState;
  BCtaTerceros: PXFieldState;
  BFacAtrAdq: PXFieldState;
  EnableDonat: PXFieldState;
  EnableIedu: PXFieldState;
  UsrFEEnableLeyendasFiscales: PXFieldState;
  AccessKey: PXFieldState;
  SecretKey: PXFieldState;
  Region: PXFieldState;
  Repository: PXFieldState;
  DirectoryName: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFERateSATMaint", primaryView: "Tarifas" })
export class FE200020 extends PXScreen {
  Tarifas = createCollection(PEFERateSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFERateSAT extends PXView {
  @columnConfig({
    width: 96,
  })
  Rankcd: PXFieldState;
  @columnConfig({
    width: 100,
  })
  Minimumvalue: PXFieldState;
  @columnConfig({
    width: 100,
  })
  Maximumvalue: PXFieldState;
  @columnConfig({
    width: 140,
  })
  Tax: PXFieldState;
  @columnConfig({
    width: 120,
  })
  Factor: PXFieldState;
  @columnConfig({
    width: 72,
  })
  Transfer: PXFieldState;
  @columnConfig({
    width: 72,
  })
  Retention: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
}

import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEPedimentoSATMaint", primaryView: "Pedimentos" })
export class FE200007 extends PXScreen {
  Pedimentos = createCollection(PEFEPedimentoSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEPedimentoSAT extends PXView {
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  CustomCD: PXFieldState;
  @columnConfig({
    width: 70,
  })
  Patent: PXFieldState;
  @columnConfig({
    width: 70,
  })
  FiscalExcercise: PXFieldState;
  @columnConfig({
    width: 72,
  })
  Qty: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  Erpmatica: PXFieldState;
}

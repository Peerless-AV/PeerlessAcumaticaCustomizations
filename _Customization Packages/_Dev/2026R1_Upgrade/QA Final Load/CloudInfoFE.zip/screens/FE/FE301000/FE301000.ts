import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEPaymentEntry", primaryView: "Document" })
export class FE301000 extends PXScreen {
  @viewInfo({ containerName: "CFDI" })
  Document = createSingle(PEFEPaymentComp);
  @viewInfo({ containerName: "PAGOS" })
  DetailPay = createCollection(PEFEPaymentCompTran);
  @viewInfo({ containerName: "Documentos Relacionados" })
  RelatedDocuments = createCollection(PEFERelaDocuments);
  @viewInfo({ containerName: "Cancelacion" })
  popUpCancelStamp = createSingle(CancelStampFilter);
}
// Views

export class PEFEPaymentComp extends PXView {
  @controlConfig({ fastFilterFields: ["RefNbrCP", "ReceiverName"], parameters: null })
  RefNbrCP: PXFieldState<PXFieldOptions.CommitChanges>;
  CustomerID: PXFieldState<PXFieldOptions.CommitChanges>;
  DocDate: PXFieldState<PXFieldOptions.CommitChanges>;
  StampStatus: PXFieldState;
  CancelStatus: PXFieldState;
  Sent: PXFieldState<PXFieldOptions.Disabled>;
  ReceiverUsoCFDI: PXFieldState;
  ReceiverTaxRegime: PXFieldState;
  CertificateNbr: PXFieldState;
  SealIssue: PXFieldState;
  AmountToWords: PXFieldState<PXFieldOptions.CommitChanges>;
  Uuid: PXFieldState;
  SealDate: PXFieldState;
  QrCodeImg: PXFieldState;
  CancelDate: PXFieldState;
  CancelUUID: PXFieldState;
  CancelReason: PXFieldState<PXFieldOptions.Disabled>;
  ReplacementFolio: PXFieldState<PXFieldOptions.Disabled>;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class PEFEPaymentCompTran extends PXView {
  @columnConfig({
    width: 70,
  })
  DocType: PXFieldState;
  @columnConfig({
    editorConfig: {
      linkCommand: "ViewPayment",
    },
    width: 140,
  })
  RefNbr: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 120,
  })
  Curyid: PXFieldState;
  @columnConfig({
    width: 100,
  })
  CuryRate: PXFieldState;
  @columnConfig({
    width: 100,
  })
  CuryOrigDocAmt: PXFieldState;
  @columnConfig({
    width: 220,
  })
  OperationNbr: PXFieldState;
}

@gridConfig({
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class PEFERelaDocuments extends PXView {
  @columnConfig({
    width: 140,
  })
  RefNbrRela: PXFieldState;
  @columnConfig({
    width: 70,
  })
  DocTypeRela: PXFieldState;
  @columnConfig({
    width: 180,
  })
  Uuid: PXFieldState;
  @columnConfig({
    width: 70,
  })
  UsrPEFEreasons: PXFieldState<PXFieldOptions.CommitChanges>;
  @columnConfig({
    width: 70,
  })
  UsrPEFEDescripcion: PXFieldState;
}

export class CancelStampFilter extends PXView {
  TempCancelReason: PXFieldState;
  TempReplacementFolio: PXFieldState;
}

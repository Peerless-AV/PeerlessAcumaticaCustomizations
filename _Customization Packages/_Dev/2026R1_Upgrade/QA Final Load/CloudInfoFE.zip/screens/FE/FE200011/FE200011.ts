import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "PEFEMX.PEFEZipCodeSATMaint", primaryView: "ZipCodeSAT" })
export class FE200011 extends PXScreen {
  ZipCodeSAT = createCollection(PEFEZipCodeSAT);
}
// Views

@gridConfig({
  autoAdjustColumns: true,
  fastFilterByAllFields: false,
  showFastFilter: GridFastFilterVisibility.ToolBar,
  statusField: "Erpmatica",
  mergeToolbarWith: "ScreenToolbar",
  preset: GridPreset.Primary,
})
export class PEFEZipCodeSAT extends PXView {
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  ZipCodeCD: PXFieldState;
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  State: PXFieldState;
  @columnConfig({
    width: 70,
    allowFastFilter: true,
  })
  Municipality: PXFieldState;
  @columnConfig({
    width: 70,
  })
  Location: PXFieldState;
  @columnConfig({
    width: 70,
  })
  BorderStripStimulus: PXFieldState;
  @columnConfig({
    width: 90,
  })
  StartDate: PXFieldState;
  @columnConfig({
    width: 90,
  })
  EndDate: PXFieldState;
  @columnConfig({
    width: 180,
  })
  TimeZoneDescription: PXFieldState;
  @columnConfig({
    width: 140,
  })
  MonthSummerTimeStart: PXFieldState;
  @columnConfig({
    width: 140,
  })
  StartDaySummerTime: PXFieldState;
  @columnConfig({
    width: 70,
  })
  SummerTimeDifference: PXFieldState;
  @columnConfig({
    width: 140,
  })
  MonthStartWinterHours: PXFieldState;
  @columnConfig({
    width: 140,
  })
  StartDayWinterHours: PXFieldState;
  @columnConfig({
    width: 70,
  })
  WinterTimeDifference: PXFieldState;
  Erpmatica: PXFieldState;
}

import {
  PXFieldState,
  PXFieldOptions,
  placeAfterProperty,
  
  columnConfig
} from "client-controls";

import { PO301000, POLine } from "src/screens/PO/PO301000/PO301000";

export interface PO301000_PLPOLot extends PO301000 {}

export class PO301000_PLPOLot {}

export interface PO301000_POLine_PLPOLot extends POLine {}
export class PO301000_POLine_PLPOLot {
  @placeAfterProperty("TranDesc")
  @columnConfig({
    width: 220,
  })
  UsrLotSerialNbr: PXFieldState;

  
}

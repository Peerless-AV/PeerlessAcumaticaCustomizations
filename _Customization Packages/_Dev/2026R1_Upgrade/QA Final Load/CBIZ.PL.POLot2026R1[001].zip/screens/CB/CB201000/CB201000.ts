import { Messages as SysMessages } from "client-controls/services/messages";
import {
  createCollection,
  createSingle,
  PXScreen,
  graphInfo,
  PXActionState,
  viewInfo,
  handleEvent,
  CustomEventType,
  actionConfig,
  RowSelectedHandlerArgs,
  PXViewCollection,
  PXPageLoadBehavior,
  ControlParameter,
  PXView,
  PXFieldState,
  gridConfig,
  treeConfig,
  fieldConfig,
  controlConfig,
  headerDescription,
  ICurrencyInfo,
  disabled,
  PXFieldOptions,
  linkCommand,
  columnConfig,
  GridColumnShowHideMode,
  GridColumnType,
  TextAlign,
  GridPreset,
  GridFilterBarVisibility,
  GridFastFilterVisibility,
  ISelectorControlConfig,
} from "client-controls";

@graphInfo({ graphType: "CBIZ.PL.POLot.CBItemLotMaint", primaryView: "MasterView" })
export class CB201000 extends PXScreen {
  MasterView = createSingle(CBItemCurrentLot);
}
// Views

export class CBItemCurrentLot extends PXView {
  InventoryID: PXFieldState;
  LotSerialNbr: PXFieldState;
  Description: PXFieldState;
  StartDate: PXFieldState;
  EndDate: PXFieldState;
}

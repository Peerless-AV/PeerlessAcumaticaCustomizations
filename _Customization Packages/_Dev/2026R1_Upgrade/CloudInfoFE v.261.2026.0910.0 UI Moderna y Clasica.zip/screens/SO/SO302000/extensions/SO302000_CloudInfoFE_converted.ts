import {
  PXFieldState,
  PXFieldOptions,
  PXView,
  PXActionState,
  placeAfterProperty,
  viewInfo,
  gridConfig,
  columnConfig,
  GridPreset,
  GridFastFilterVisibility,
  createSingle,
  createCollection,
} from "client-controls";

import {
  SO302000,
  SOShipmentHeader,
  SOShipment,
  Transactions
} from "src/screens/SO/SO302000/SO302000";

import {
  Contact
} from "src/screens/common/form-contact-document/form-contact-document";

import {
  Address
} from "src/screens/common/form-address/form-address";

import {
  SOShipLineSplit
} from "src/screens/SO/SO302000/extensions/SO302000_LineSplitting";

export interface SO302000_CloudInfoFE_converted extends SO302000 { }

export class SO302000_CloudInfoFE_converted {
  SectorCofepris: PXActionState;
  printPickListAction: PXActionState;
  stamp: PXActionState;
  cancelar: PXActionState;

  @viewInfo({ containerName: "Transportista" })
  popUp = createSingle(TransportistaFilter);

  @viewInfo({ containerName: "Operadores" })
  operators = createCollection(SOConsignmentNoteOperators);

  @viewInfo({ containerName: "Comercio Exterior" })
  comerExterior = createSingle(SOExternalTrade);

  @viewInfo({ containerName: "Mercancias" })
  SOLines = createCollection(SOExtTradeLine);

  @viewInfo({ containerName: "Cancelacion" })
  popUpCancelStamp = createSingle(CancelStampFilter);

  @viewInfo({ containerName: "Sector COFEPRIS" })
  popUpCofepris = createSingle(CofeprisFilter);

  @viewInfo({ containerName: "Descripcion Especifica" })
  SOSplitDeta = createCollection(SOExtTradeLineDet);
}

export class TransportistaFilter extends PXView {
  TempTransportista: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  initNewRow: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Empty,
})
export class SOConsignmentNoteOperators extends PXView {
  @columnConfig({ width: 140 })
  OperatorCD: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 140 })
  RFC: PXFieldState;

  @columnConfig({ width: 280 })
  Name: PXFieldState;

  @columnConfig({ width: 180 })
  DriverLicense: PXFieldState;

  @columnConfig({ width: 280 })
  Street: PXFieldState;

  @columnConfig({ width: 140 })
  OutNumber: PXFieldState;

  @columnConfig({ width: 140 })
  IntNumber: PXFieldState;

  @columnConfig({ width: 70 })
  CountryID: PXFieldState;

  @columnConfig({ width: 70 })
  StateID: PXFieldState;

  @columnConfig({ width: 70 })
  MunicipalityID: PXFieldState;

  @columnConfig({ width: 120 })
  ZipCode: PXFieldState;

  @columnConfig({ width: 70 })
  SettlementID: PXFieldState;

  @columnConfig({ width: 70 })
  LocalityID: PXFieldState;

  @columnConfig({ width: 280 })
  Reference: PXFieldState;
}

export class SOExternalTrade extends PXView {
  ForeignTrade: PXFieldState<PXFieldOptions.CommitChanges>;

  EtCuryRate: PXFieldState<PXFieldOptions.CommitChanges>;

  EtOperationType: PXFieldState;

  EtRequestKey: PXFieldState;

  EtIncoterm: PXFieldState;

  EtTransferReason: PXFieldState;

  EtIsOriginCert: PXFieldState;

  EtOriginCertNbr: PXFieldState;

  EtTrustworthyExporterNbr: PXFieldState;

  EtDescription: PXFieldState;

  EtUsdTotal: PXFieldState;

  EtHasAddressed: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverName: PXFieldState;

  ReceiverRFC: PXFieldState;

  ReceiverCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverStreet: PXFieldState;

  ReceiverOutNbr: PXFieldState;

  ReceiverMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverState: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverLocation: PXFieldState<PXFieldOptions.CommitChanges>;

  ReceiverZipCode: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  syncPosition: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.ReadOnly,
  topBarItems: {
    ShowSOLineSplit: {
      index: 0,
      config: {
        commandName: "ShowSOLineSplit",
        text: "Descripcion Especifica"
      }
    },
  },
})
export class SOExtTradeLine extends PXView {
  ShowSOLineSplit: PXActionState;

  @columnConfig({ width: 220 })
  Identification: PXFieldState;

  @columnConfig({ width: 120 })
  TariffFraction: PXFieldState;

  @columnConfig({ width: 70 })
  Uom: PXFieldState;

  @columnConfig({ width: 100 })
  Qty: PXFieldState;

  @columnConfig({ width: 100 })
  UnitPrice: PXFieldState;

  @columnConfig({ width: 100 })
  TotalAmt: PXFieldState;
}

export class CancelStampFilter extends PXView {
  TempCancelReason: PXFieldState;

  TempReplacementFolio: PXFieldState;
}

export class CofeprisFilter extends PXView {
  OverrideSectorCOFEPRIS: PXFieldState<PXFieldOptions.CommitChanges>;

  SectorCOFEPRIS: PXFieldState<PXFieldOptions.CommitChanges>;

  NombreIngredienteActivo: PXFieldState;

  NomQuimico: PXFieldState;

  DenominacionGenericaProd: PXFieldState;

  DenominacionDistintivaProd: PXFieldState;

  Fabricante: PXFieldState;

  FechaCaducidad: PXFieldState;

  LoteMedicamento: PXFieldState;

  FormaFarmaceutica: PXFieldState;

  CondicionesEspTransp: PXFieldState;

  RegistroSanitarioFolioAutorizacion: PXFieldState;

  PermisoImportacion: PXFieldState;

  FolioImpoVUCEM: PXFieldState;

  NumCAS: PXFieldState;

  RazonSocialEmpImp: PXFieldState;

  NumRegSanPlagCOFEPRIS: PXFieldState;

  DatosFabricante: PXFieldState;

  DatosFormulador: PXFieldState;

  DatosMaquilador: PXFieldState;

  UsoAutorizado: PXFieldState;
}

@gridConfig({
  initNewRow: true,
  syncPosition: true,
  autoAdjustColumns: true,
  showFastFilter: GridFastFilterVisibility.False,
  preset: GridPreset.Details,
})
export class SOExtTradeLineDet extends PXView {
  @columnConfig({ width: 220 })
  Identification: PXFieldState;

  @columnConfig({ width: 220 })
  Brand: PXFieldState;

  @columnConfig({ width: 220 })
  Model: PXFieldState;

  @columnConfig({ width: 180 })
  SubModel: PXFieldState;

  @columnConfig({ width: 180 })
  SerieNbr: PXFieldState;
}

export interface SO302000_SOShipmentHeader_CloudInfoFE_converted
  extends SOShipmentHeader { }

export class SO302000_SOShipmentHeader_CloudInfoFE_converted {
  @placeAfterProperty("Status")
  StampStatus: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("StampStatus")
  CancelStatus: PXFieldState<
    PXFieldOptions.CommitChanges | PXFieldOptions.Disabled
  >;
}

export interface SO302000_SOShipment_CloudInfoFE_converted
  extends SOShipment { }

export class SO302000_SOShipment_CloudInfoFE_converted {
  @placeAfterProperty("Installed")
  ReceiverUsoCFDI: PXFieldState;

  PostalCode: PXFieldState;

  ReceiverTaxRegime: PXFieldState;

  SealIssue: PXFieldState;

  CertificateNbr: PXFieldState;

  UUID: PXFieldState;

  SealDate: PXFieldState;

  IdCCP: PXFieldState;

  QrCCPImage: PXFieldState;

  QrCodeImg: PXFieldState;

  CancelDate: PXFieldState;

  CancelUUID: PXFieldState;

  CancelReason: PXFieldState<PXFieldOptions.Disabled>;

  ReplacementFolio: PXFieldState<PXFieldOptions.Disabled>;

  ConsignmentNote: PXFieldState<PXFieldOptions.CommitChanges>;

  NotStampable: PXFieldState;

  InternationalTransport: PXFieldState<PXFieldOptions.CommitChanges>;

  DistanceTraveled: PXFieldState<PXFieldOptions.CommitChanges>;

  UnitMeasurement: PXFieldState;

  ReverseLogistics: PXFieldState;

  Istmo: PXFieldState<PXFieldOptions.CommitChanges>;

  CustomsRegime: PXFieldState;

  CountryOriginDestination: PXFieldState;

  EntryExit: PXFieldState;

  ViaEntryExit: PXFieldState;

  IstmoOrigin: PXFieldState;

  DateTimeOut_Date: PXFieldState<PXFieldOptions.CommitChanges>;

  DateTimeOut_Time: PXFieldState<PXFieldOptions.CommitChanges>;

  EditSender: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderRFC: PXFieldState;

  SenderName: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderStreet: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderOutNumber: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderIntNumber: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderState: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderColony: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  SenderReference: PXFieldState<PXFieldOptions.CommitChanges>;

  IstmoDestination: PXFieldState;

  DateTimeArrival_Date: PXFieldState<PXFieldOptions.CommitChanges>;

  DateTimeArrival_Time: PXFieldState<PXFieldOptions.CommitChanges>;

  EditAddressee: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeRFC: PXFieldState;

  AddresseeName: PXFieldState;

  AddresseeStreet: PXFieldState;

  AddresseeOutNumber: PXFieldState;

  AddresseeIntNumber: PXFieldState;

  AddresseeCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeState: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeColony: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  AddresseeReference: PXFieldState;

  VehicleUnitID: PXFieldState<PXFieldOptions.CommitChanges>;

  EditVehicleUnit: PXFieldState<PXFieldOptions.CommitChanges>;

  VehicleUnitPermissionSCT: PXFieldState;

  VehicleUnitPermitNumber: PXFieldState;

  VehicleUnitCivilLiabilityInsurer: PXFieldState;

  VehicleUnitCivilLiabilityPolicy: PXFieldState;

  VehicleUnitEnvironmentalInsurer: PXFieldState;

  VehicleUnitEnvironmentalPolicy: PXFieldState;

  VehicleUnitFreightTransportationInsurer: PXFieldState;

  VehicleUnitFreightTransportationPolicy: PXFieldState;

  VehicleUnitTransportID: PXFieldState;

  VehicleWeight: PXFieldState;

  VehicleUnitAutomobileRegistration: PXFieldState;

  VehicleUnitModelYear: PXFieldState;

  VehicleUnitPartOwnedOrLeased: PXFieldState;

  VehicleUnitPartTransport: PXFieldState;

  VehicleUnitIsTrailer: PXFieldState<PXFieldOptions.CommitChanges>;

  VehicleUnitTypeTrailerID: PXFieldState;

  VehicleUnitTrailerRegistration: PXFieldState;

  VehicleUnitIsDoubleTrailer: PXFieldState<PXFieldOptions.CommitChanges>;

  VehicleUnitTypeDoubleTrailerID: PXFieldState;

  VehicleUnitDoubleTrailerRegistration: PXFieldState;

  TransportOwnerID: PXFieldState<PXFieldOptions.CommitChanges>;

  EditTransportOwner: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerRFC: PXFieldState;

  TransportOwnerName: PXFieldState;

  TransportOwnerStreet: PXFieldState;

  TransportOwnerOutNumber: PXFieldState;

  TransportOwnerIntNumber: PXFieldState;

  TransportOwnerCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerState: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerColony: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  TransportOwnerReference: PXFieldState;

  MultiOperators: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorID: PXFieldState<PXFieldOptions.CommitChanges>;

  EditOperator: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorRFC: PXFieldState;

  OperatorName: PXFieldState;

  OperatorDriverLicense: PXFieldState;

  OperatorStreet: PXFieldState;

  OperatorOutNumber: PXFieldState;

  OperatorIntNumber: PXFieldState;

  OperatorCountry: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorState: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorTownship: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorZipCode: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorColony: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorLocality: PXFieldState<PXFieldOptions.CommitChanges>;

  OperatorReference: PXFieldState;

  Export: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface SO302000_Transactions_CloudInfoFE_converted
  extends Transactions { }

export class SO302000_Transactions_CloudInfoFE_converted {
  @placeAfterProperty("AssociatedOrderLineNbr")
  @columnConfig({ width: 100 })
  UnitWeigth: PXFieldState;

  @placeAfterProperty("UnitWeigth")
  GiftMessage: PXFieldState;

  @placeAfterProperty("TranDesc")
  @columnConfig({ width: 120 })
  UsrPEFEProdSAT: PXFieldState;

  @columnConfig({ width: 70 })
  UsrPEFEObjectTaxSAT: PXFieldState;

  @columnConfig({ width: 70 })
  UsrDangerousMaterialCD: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 70 })
  UsrPackagingCD: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 220 })
  UsrPackagingDescription: PXFieldState;

  @placeAfterProperty("UsrPackagingDescription")
  BlanketNbr: PXFieldState;

  @placeAfterProperty("PMTranID")
  @columnConfig({ width: 140 })
  UsrPEFENumberPed: PXFieldState;

  @columnConfig({ width: 120 })
  UsrFraccAran: PXFieldState;

  @columnConfig({ width: 120 })
  UsrDocumentType: PXFieldState;

  @columnConfig({ width: 250 })
  UsrCustomsDocumentIdentifier: PXFieldState;

  @columnConfig({ width: 140 })
  UsrRFCImpo: PXFieldState;

  @columnConfig({ width: 120 })
  UsrMaterialType: PXFieldState;

  @columnConfig({ width: 180 })
  UsrMaterialDescription: PXFieldState;
}

export interface SO302000_Contact_CloudInfoFE_converted
  extends Contact { }

export class SO302000_Contact_CloudInfoFE_converted {
  @placeAfterProperty("OverrideContact")
  UsrTaxRegistrationID: PXFieldState;
}

export interface SO302000_Address_CloudInfoFE_converted
  extends Address { }

export class SO302000_Address_CloudInfoFE_converted {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface SO302000_SOShipLineSplit_CloudInfoFE_converted
  extends SOShipLineSplit { }

export class SO302000_SOShipLineSplit_CloudInfoFE_converted {
  @placeAfterProperty("InventoryID_InventoryItem_descr")
  @columnConfig({ width: 140 })
  UsrPEFEPedimentNbr: PXFieldState;
}
import {
  PXScreen,
  PXView,
  PXFieldState,
  PXFieldOptions,
  createSingle,
  createCollection,
  gridConfig,
  GridPreset,
  columnConfig,
  placeAfterProperty,
  viewInfo
} from "client-controls";

import {
  AR301000,
  ARInvoice,
  ARInvoice2,
  ARTran
} from "src/screens/AR/AR301000/AR301000";

import {
  Address
} from "src/screens/common/form-address/form-address";

import {
  Contact
} from "src/screens/common/form-contact-document/form-contact-document";

export interface AR301000_CloudInfoFE extends AR301000 { }

export class AR301000_CloudInfoFE {
  @viewInfo({ containerName: "Documentos Relacionados" })
  RelatedDocuments = createCollection(PEFERelaDocument);

  @viewInfo({ containerName: "Instituciones Educativas" })
  TransactionsIEDU = createCollection(ARTranIEDU);

  @viewInfo({ containerName: "Leyendas Fiscales" })
  LeyendasFiscales = createCollection(FELeyendaFiscal);

  @viewInfo({ containerName: "Cancelacion" })
  CancelStampPopup = createSingle(CancelStampPopupFilter);
}

export interface AR301000_ARInvoice_CloudInfoFE extends ARInvoice { }

export class AR301000_ARInvoice_CloudInfoFE {
  @placeAfterProperty("Status")
  StampStatus: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("StampStatus")
  CancelStatus: PXFieldState;

  @placeAfterProperty("CancelStatus")
  UsrPEFENotStampable: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("CuryOrigDiscAmt")
  FEEnableRelatedDocuments: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("FEEnableRelatedDocuments")
  FEEnableDonat: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("FEEnableDonat")
  FEEnableIedu: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("FEEnableIedu")
  UsrFEEnableLeyendasFiscales: PXFieldState<PXFieldOptions.CommitChanges>;
}

export interface AR301000_ARInvoice2_CloudInfoFE extends ARInvoice2 { }

export class AR301000_ARInvoice2_CloudInfoFE {
  @placeAfterProperty("AvalaraCustomerUsageType")
  ReceiverUsoCFDI: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("ReceiverUsoCFDI")
  PaymentForm: PXFieldState;

  @placeAfterProperty("PaymentForm")
  PaymentMethod: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("PaymentMethod")
  StateCpny: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("StateCpny")
  PostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("PostalCode")
  ReceiverTaxRegime: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("ReceiverTaxRegime")
  SealIssue: PXFieldState;

  @placeAfterProperty("SealIssue")
  CertificateNbr: PXFieldState;

  @placeAfterProperty("CertificateNbr")
  AmountToWords: PXFieldState;

  @placeAfterProperty("AmountToWords")
  UUID: PXFieldState;

  @placeAfterProperty("UUID")
  SealDate: PXFieldState;

  @placeAfterProperty("SealDate")
  QrCodeImg: PXFieldState;

  @placeAfterProperty("QrCodeImg")
  CancelDate: PXFieldState;

  @placeAfterProperty("CancelDate")
  CancelUUID: PXFieldState;

  @placeAfterProperty("CancelUUID")
  CancelReason: PXFieldState;

  @placeAfterProperty("CancelReason")
  ReplacementFolio: PXFieldState;

  @placeAfterProperty("ReplacementFolio")
  UsrFEGenerateDonat: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEGenerateDonat")
  UsrFENoAtorizacion: PXFieldState;

  @placeAfterProperty("UsrFENoAtorizacion")
  UsrFEFechaAutorizacion: PXFieldState;

  @placeAfterProperty("UsrFEFechaAutorizacion")
  UsrFELeyenda: PXFieldState;
}

export interface AR301000_ARTran_CloudInfoFE extends ARTran { }

export class AR301000_ARTran_CloudInfoFE {
  @placeAfterProperty("TranDesc")
  @columnConfig({ width: 140 })
  UsrParentID: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("TaxCategoryID")
  @columnConfig({ width: 70 })
  UsrPEFEObjectTaxSAT: PXFieldState;

  @placeAfterProperty("Commissionable")
  @columnConfig({ width: 120 })
  UsrInvtSAT: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrInvtSAT")
  @columnConfig({ width: 70 })
  UsrUnitSAT: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrUnitSAT")
  @columnConfig({ width: 280 })
  UsrUnitDescrSAT: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrUnitDescrSAT")
  @columnConfig({ width: 280 })
  UsrFEAddlDescription: PXFieldState;
}

export interface AR301000_Contact_CloudInfoFE extends Contact { }

export class AR301000_Contact_CloudInfoFE {
  @placeAfterProperty("OverrideContact")
  UsrTaxRegistrationID: PXFieldState;
}

export interface AR301000_Address_CloudInfoFE extends Address { }

export class AR301000_Address_CloudInfoFE {
  @placeAfterProperty("AddressLine2")
  UsrPEFEExtNumber: PXFieldState;

  @placeAfterProperty("UsrPEFEExtNumber")
  UsrPEFEIntNumber: PXFieldState;

  @placeAfterProperty("State")
  UsrPEFEMunicipality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrPEFEMunicipality")
  UsrFEPostalCode: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFEPostalCode")
  UsrFELocality: PXFieldState<PXFieldOptions.CommitChanges>;

  @placeAfterProperty("UsrFELocality")
  UsrFECity: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
  preset: GridPreset.Details,
  syncPosition: true,
  allowInsert: true,
  allowDelete: true,
  allowUpdate: true
})
export class PEFERelaDocument extends PXView {
  @columnConfig({ width: 140 })
  RefNbrRela: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 70 })
  DocTypeRela: PXFieldState;

  @columnConfig({ width: 180 })
  UUID: PXFieldState;

  @columnConfig({ width: 70 })
  UsrPEFEreasons: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 220 })
  UsrPEFEDescripcion: PXFieldState;
}

@gridConfig({
  preset: GridPreset.Details,
  syncPosition: true,
  allowInsert: false,
  allowDelete: false,
  allowUpdate: true
})
export class ARTranIEDU extends PXView {
  @columnConfig({ width: 280 })
  InventoryID_description: PXFieldState;

  @columnConfig({ width: 140 })
  FamiliarID: PXFieldState<PXFieldOptions.CommitChanges>;

  @columnConfig({ width: 280 })
  FamiliarID_Customer_acctName: PXFieldState;

  @columnConfig({ width: 180 })
  CURP: PXFieldState;

  @columnConfig({ width: 180 })
  GRADO: PXFieldState;

  @columnConfig({ width: 180 })
  NIVEL: PXFieldState;

  @columnConfig({ width: 180 })
  RVOE: PXFieldState;
}

@gridConfig({
  preset: GridPreset.Details,
  syncPosition: true,
  allowInsert: false,
  allowDelete: false,
  allowUpdate: true
})
export class FELeyendaFiscal extends PXView {
  @columnConfig({ width: 500 })
  TextoLeyenda: PXFieldState;

  @columnConfig({ width: 220 })
  Norma: PXFieldState;

  @columnConfig({ width: 120 })
  DisposicionFiscal: PXFieldState;

  @columnConfig({ width: 120 })
  IsSelected: PXFieldState;
}

export class CancelStampPopupFilter extends PXView {
  TempCancelReason: PXFieldState<PXFieldOptions.CommitChanges>;
  TempReplacementFolio: PXFieldState<PXFieldOptions.CommitChanges>;
}
import {
  PXFieldState,
  
} from "client-controls";
import { SO302000, SOShipmentHeader } from "src/screens/SO/SO302000/SO302000";

export interface SO302000_CampoPalletShipment_converted extends SO302000 {}

export class SO302000_CampoPalletShipment_converted {}

export interface SO302000_SOShipmentHeader_CampoPalletShipment_converted extends SOShipmentHeader {}
export class SO302000_SOShipmentHeader_CampoPalletShipment_converted {
  
  UsrPallet: PXFieldState;

  
}
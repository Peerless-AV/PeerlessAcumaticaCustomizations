import { PXFieldState } from "client-controls";
import { AR303000, Customer2 } from "src/screens/AR/AR303000/AR303000";

export interface AR303000_InterastarDD extends AR303000 {}
export class AR303000_InterastarDD {}

export interface AR303000_Customer2_InterastarDD extends Customer2 {}
export class AR303000_Customer2_InterastarDD {
  UsrAddendumID: PXFieldState;
}

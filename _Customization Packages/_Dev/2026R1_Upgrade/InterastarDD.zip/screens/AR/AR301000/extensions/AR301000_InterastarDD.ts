import { PXFieldState } from "client-controls";
import { AR301000, ARInvoice } from "src/screens/AR/AR301000/AR301000";

export interface AR301000_InterastarDD extends AR301000 {}
export class AR301000_InterastarDD {}

export interface AR301000_ARInvoice_InterastarDD extends ARInvoice {}
export class AR301000_ARInvoice_InterastarDD {
  UsrAddendumInclude: PXFieldState;
}

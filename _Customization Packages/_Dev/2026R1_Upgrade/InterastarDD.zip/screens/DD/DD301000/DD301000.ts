import { PXScreen, PXView, PXFieldState, graphInfo, createSingle } from "client-controls";

@graphInfo({graphType: "IS.Objects.DD.ISDDUniInsurgentesEntry", primaryView: "AddendumView" })
export class DD301000 extends PXScreen {
	AddendumView = createSingle(ISDDUniInsurgentes);
}

// Views
export class ISDDUniInsurgentes extends PXView  {
	DocType: PXFieldState;
	RefNbr: PXFieldState;
	ProviderNbr: PXFieldState;
	BuyOrderNbr: PXFieldState;
	BuyOrderDate: PXFieldState;
	DocDate: PXFieldState;
}
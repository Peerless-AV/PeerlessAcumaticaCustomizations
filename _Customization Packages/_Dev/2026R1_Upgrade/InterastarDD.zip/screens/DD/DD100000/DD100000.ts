import { PXScreen, PXView, PXFieldState, PXFieldOptions, graphInfo, createSingle } from "client-controls";

@graphInfo({graphType: "IS.Objects.DD.ISDDAddendumDefSetup", primaryView: "Definitions" })
export class DD100000 extends PXScreen {
	Definitions = createSingle(ISDDAddendumDef);
}

// Views
export class ISDDAddendumDef extends PXView  {
	AddendumCD: PXFieldState<PXFieldOptions.CommitChanges>;
	Type: PXFieldState;
	GenericInq: PXFieldState;
	Description: PXFieldState;
	Xslt: PXFieldState;
}
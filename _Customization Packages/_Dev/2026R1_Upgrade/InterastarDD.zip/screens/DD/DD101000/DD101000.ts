import { PXScreen, PXView, PXFieldState, PXActionState, PXFieldOptions, GridFastFilterVisibility, GridPreset, viewInfo, createCollection, graphInfo, gridConfig } from "client-controls";

@graphInfo({graphType: "IS.Objects.DD.ISDDGeneralAddendumSetup", primaryView: "GeneralAddendumGrid" })
export class DD101000 extends PXScreen {
	GeneralAddendumGrid = createCollection(ISDDGeneralAddendum);
}

// Views
@gridConfig({ preset: GridPreset.Details })
export class ISDDGeneralAddendum extends PXView  {
	AddendumCD: PXFieldState;
	Type: PXFieldState;
	GenericInq: PXFieldState;
	Description: PXFieldState;
}
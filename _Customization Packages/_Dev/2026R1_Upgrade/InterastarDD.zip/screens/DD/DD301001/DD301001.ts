import { PXScreen, PXView, PXFieldState, graphInfo, createSingle } from "client-controls";

@graphInfo({graphType: "IS.Objects.DD.ISDDLiverpoolEntry", primaryView: "AddendumView", })
export class DD301001 extends PXScreen {
	AddendumView = createSingle(ISDDLiverpoolEntry);
}

// Views
export class ISDDLiverpoolEntry extends PXView  {
	DocType: PXFieldState;
	RefNbr: PXFieldState;
	AmountInvoice: PXFieldState;
	InstructionType: PXFieldState;
	Instruction: PXFieldState;
	OrderNbr: PXFieldState;
	OrderDate: PXFieldState;
	AdditionalOrderNbr: PXFieldState;
	AdditionalOrderType: PXFieldState;
	ReceiptNbr: PXFieldState;
	ReceiptDate: PXFieldState;
	GLNLiverpool: PXFieldState;
	Department: PXFieldState;
	SpecialServicesType: PXFieldState;
	SpecialServicesPercentage: PXFieldState;
	AllowanceType: PXFieldState;
	AllowanceSubType: PXFieldState;
	AllowanceAmount: PXFieldState;
}
import { PXFieldState } from "client-controls";
import { SO303000, ARInvoice } from "src/screens/SO/SO303000/SO303000";

export interface SO303000_InterastarDD extends SO303000 {}
export class SO303000_InterastarDD {}

export interface SO303000_ARInvoice_InterastarDD extends ARInvoice {}
export class SO303000_ARInvoice_InterastarDD {
  UsrAddendumInclude: PXFieldState;
}

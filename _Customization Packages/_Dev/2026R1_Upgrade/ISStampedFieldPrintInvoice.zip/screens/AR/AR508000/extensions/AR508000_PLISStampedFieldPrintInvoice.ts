﻿
import { PXFieldState,
	placeAfterProperty,
	 columnConfig,
	 GridColumnShowHideMode,

} from "client-controls";

import { AR508000, ARInvoice } from "src/screens/AR/AR508000/AR508000";

export interface AR508000_PLISStamped extends AR508000 {}

export class AR508000_PLISStamped {}


export interface ARInvoice_PLISStamped extends ARInvoice { }

export class ARInvoice_PLISStamped {
	
  @placeAfterProperty("Status")
  @columnConfig({
    width: 70,
    
  })
  StampStatus: PXFieldState;

 

}


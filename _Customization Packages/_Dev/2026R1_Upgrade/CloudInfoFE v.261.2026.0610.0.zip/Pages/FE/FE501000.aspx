<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="FE501000.aspx.cs" Inherits="Page_FE501000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource SkinID="" ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="PEFEMX.PEFEInvoiceProcess"
        PrimaryView="Filter"
        >
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="ViewDocument" Visible="false" DependOnGrid="grid" /></CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%" Height="100px" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartRow="True"></px:PXLayoutRule>
			<px:PXDropDown runat="server" ID="CstPXDropDown1" DataField="Action" ></px:PXDropDown>
			<px:PXDropDown Visible="False" runat="server" ID="CstPXDropDown2" DataField="DocType" ></px:PXDropDown></Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXGrid TabIndex="4500" ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="400px" SkinID="Details" AllowAutoHide="false">
		<Levels>
			<px:PXGridLevel DataKeyNames="Doctype,Referencia" DataMember="Invoices">
			    <Columns>
				<px:PXGridColumn CommitChanges="True" Type="CheckBox" TextAlign="Center" DataField="Selected" Width="60" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Doctype" Width="70" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Referencia" Width="140" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Rfc" Width="220" ></px:PXGridColumn>
				<px:PXGridColumn DataField="Nombre" Width="280" ></px:PXGridColumn>
				<px:PXGridColumn TimeMode="False" DataField="Monto" Width="100" ></px:PXGridColumn>
				<px:PXGridColumn DataField="SealDate_Date" Width="90" />
				<px:PXGridColumn DataField="Uuid" Width="220" /></Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="150" ></AutoSize>
		<ActionBar >
		</ActionBar>
	</px:PXGrid>
</asp:Content>

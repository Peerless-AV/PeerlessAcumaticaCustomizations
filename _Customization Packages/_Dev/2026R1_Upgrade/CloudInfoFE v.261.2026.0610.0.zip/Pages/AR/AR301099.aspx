<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="AR301099.aspx.cs" Inherits="Page_AR301099" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="HotFixInvoice.HotFixInvoiceEntry"
        PrimaryView="Documents"
        >
		<CallbackCommands>

		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Documents" Width="100%" AllowAutoHide="false">
		<Template>
			<px:PXLayoutRule ControlSize="M" GroupCaption="" runat="server" ID="CstPXLayoutRule17" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule LabelsWidth="SM" ControlSize="M" ColumnWidth="" GroupCaption="Documento" runat="server" ID="CstPXLayoutRule22" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDropDown runat="server" ID="CstPXDropDown6" DataField="DocType" ></px:PXDropDown>
			<px:PXSelector runat="server" ID="CstPXSelector7" DataField="RefNbr" ></px:PXSelector>
			<px:PXDropDown runat="server" ID="CstPXDropDown33" DataField="StampStatus" ></px:PXDropDown>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule35" StartRow="True" ></px:PXLayoutRule>
			<px:PXLayoutRule ControlSize="M" LabelsWidth="SM" runat="server" ID="CstPXLayoutRule36" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule runat="server" ID="CstPXLayoutRule38" StartGroup="True" GroupCaption="CFDI" ></px:PXLayoutRule>
			<px:PXSelector runat="server" ID="CstPXSelector24" DataField="PostalCode" ></px:PXSelector>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit42" DataField="IssuerRfc" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit41" DataField="IssuerName" ></px:PXTextEdit>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit23" DataField="ReceiverRfc" ></px:PXTextEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit40" DataField="ReceiverName" ></px:PXTextEdit>
			<px:PXSelector runat="server" ID="CstPXSelector14" DataField="ReceiverUsoCFDI" ></px:PXSelector>
			<px:PXSelector runat="server" ID="CstPXSelector15" DataField="PaymentForm" ></px:PXSelector>
			<px:PXSelector runat="server" ID="CstPXSelector16" DataField="PaymentMethod" ></px:PXSelector>
			<px:PXCheckBox CommitChanges="True" runat="server" ID="CstPXCheckBox32" DataField="UsrPEFENotStampable" ></px:PXCheckBox>
			<px:PXLayoutRule LabelsWidth="SM" ControlSize="M" runat="server" ID="CstPXLayoutRule37" StartColumn="True" ></px:PXLayoutRule>
			<px:PXLayoutRule GroupCaption="Timbrado Fiscal Digital" runat="server" ID="CstPXLayoutRule39" StartGroup="True" ></px:PXLayoutRule>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit4" DataField="UUID" ></px:PXTextEdit>
			<px:PXDateTimeEdit Size="M" runat="server" ID="CstPXDateTimeEdit43" DataField="SealDate" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit29" DataField="CancelUUID" ></px:PXTextEdit>
			<px:PXDateTimeEdit Size="M" runat="server" ID="CstPXDateTimeEdit44" DataField="CancelDate" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit30" DataField="CancelStatus" ></px:PXTextEdit>
			<px:PXLayoutRule LabelsWidth="SM" ControlSize="M" runat="server" ID="CstPXLayoutRule18" StartRow="True" GroupCaption="" ></px:PXLayoutRule>
			<px:PXLayoutRule GroupCaption="Sello" StartGroup="True" runat="server" ID="CstPXLayoutRule27" StartColumn="True" ></px:PXLayoutRule>
			<px:PXDateTimeEdit Size="M" runat="server" ID="CstPXDateTimeEdit46" DataField="SealIssue" ></px:PXDateTimeEdit>
			<px:PXTextEdit runat="server" ID="CstPXTextEdit20" DataField="CertificateNbr" ></px:PXTextEdit>
			<px:PXTextEdit CommitChanges="True" runat="server" ID="CstPXTextEdit26" DataField="QrCode" ></px:PXTextEdit>
			<px:PXLayoutRule GroupCaption="Codigo QR" LabelsWidth="" runat="server" ID="CstPXLayoutRule12" StartColumn="True" ></px:PXLayoutRule>
			<px:PXImageView runat="server" Width="200px" Height="200px" DataField="QrCodeImg" ID="edQrCodeImg" Style='width:200px;height:200px;' ></px:PXImageView></Template>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" ></AutoSize>
	</px:PXFormView></asp:Content>


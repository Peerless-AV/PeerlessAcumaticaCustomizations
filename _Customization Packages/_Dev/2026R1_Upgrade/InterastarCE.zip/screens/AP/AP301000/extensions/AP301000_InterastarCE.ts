import {
	PXFieldState,
	PXFieldOptions,
	fieldOptions,
	createCollection,
	PXActionState,
	PXView,
} from "client-controls";
import { AP301000, APInvoice, APTaxTran } from "src/screens/AP/AP301000/AP301000";

export interface AP301000_InterastarCE extends AP301000 {}
export class AP301000_InterastarCE {
	Vouchers = createCollection(Vouchers);
}

// Views
export class Vouchers extends PXView {
	DocType: PXFieldState;
	Folio: PXFieldState;
	StampStatus: PXFieldState;
	StampDate: PXFieldState;
	Uuid: PXFieldState;
	IssuerTaxRegistrationID: PXFieldState;
	Receiver: PXFieldState;
	UseCfdi: PXFieldState;
	ReceiverTaxRegistrationID: PXFieldState;
	BaseP: PXFieldState;
	ImporteP: PXFieldState;
	BaseDR: PXFieldState;
	ImporteDR: PXFieldState;
	TasaOCuotaDR: PXFieldState;
}
import {
	PXFieldState,
	PXFieldOptions,
	placeAfterProperty,
	columnConfig,
	PXView,
	createSingle,
} from "client-controls";
import { AP304000 } from "src/screens/AP/AP304000/AP304000";
import { APQuickCheck, APTran } from "src/screens/AP/AP304000/views";

export interface AP304000_InterastarCE extends AP304000 {}
export class AP304000_InterastarCE {
	VoucherQuickCheck = createSingle(VoucherQuickCheck);
}

// Views
export interface AP304000_APTran_InterastarCE extends APTran {}
export class AP304000_APTran_InterastarCE {
	@placeAfterProperty("TaxCategoryID")
	@columnConfig({
		width: 60,
	})
  UsrFromCFDI: PXFieldState;
}

export class VoucherQuickCheck extends PXView {
	Serie: PXFieldState;
	PaymentForm: PXFieldState;
	PaymentMethod: PXFieldState;
	PaymentTerms: PXFieldState;
	CertificateNbr: PXFieldState;
	SealDate: PXFieldState;
	StampDate: PXFieldState;
	Uuid: PXFieldState;
}
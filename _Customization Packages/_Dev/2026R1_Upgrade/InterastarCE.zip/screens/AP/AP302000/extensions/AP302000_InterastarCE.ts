import {
	PXFieldState,
	PXFieldOptions,
	PXView,
	PXActionState,
	placeAfterProperty,
	columnConfig,
	viewInfo,
	createCollection,
} from "client-controls";
import { AP302000 } from "src/screens/AP/AP302000/AP302000";

export interface AP302000_InterastarCE extends AP302000 {}
export class AP302000_InterastarCE {
	Vouchers = createCollection(Vouchers);
}

// Views
export class Vouchers extends PXView {
	DocType: PXFieldState;
	Folio: PXFieldState;
	StampStatus: PXFieldState;
	StampDate: PXFieldState;
	Uuid: PXFieldState;
	IssuerTaxRegistrationID: PXFieldState;
	Receiver: PXFieldState;
	UseCfdi: PXFieldState;
	ReceiverTaxRegistrationID: PXFieldState;
	BaseP: PXFieldState;
	ImporteP: PXFieldState;
	BaseDR: PXFieldState;
	ImporteDR: PXFieldState;
	TasaOCuotaDR: PXFieldState;
}


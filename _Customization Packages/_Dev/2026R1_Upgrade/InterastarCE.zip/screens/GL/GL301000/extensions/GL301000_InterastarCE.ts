import {
	PXFieldState,
	PXFieldOptions,
	PXView,
	fieldOptions,
	createCollection,
} from "client-controls";
import { GL301000, Batch } from "src/screens/GL/GL301000/GL301000";

export interface GL301000_InterastarCE extends GL301000 {}
export class GL301000_InterastarCE {
	VoucherView = createCollection(ISMXVoucher);
}

// Views
export class ISMXVoucher extends PXView {
	DocDateTime: PXFieldState;
	VoucherTotal: PXFieldState<PXFieldOptions.CommitChanges>;
	VoucherSubTotal: PXFieldState;
	Uuid: PXFieldState;
	TaxTransferredTotal: PXFieldState;
	TaxHoldingTotal: PXFieldState;
	ReceiverTaxRegistrationID: PXFieldState;
	IssuerTaxRegistrationID: PXFieldState;
}

export interface GL301000_Batch_InterastarCE extends Batch {}
export class GL301000_Batch_InterastarCE {
	@fieldOptions({ commitChanges: true })
  CuryDebitTotal: PXFieldState<PXFieldOptions.Disabled>;

	@fieldOptions({ commitChanges: true })
  CuryCreditTotal: PXFieldState<PXFieldOptions.Disabled>;
}

import {
	PXFieldState,
	PXFieldOptions,
	placeAfterProperty,
} from "client-controls";
import { GL401000, GLHistoryEnqFilter } from "src/screens/GL/GL401000/GL401000";

export interface GL401000_InterastarCE extends GL401000 {}

export class GL401000_InterastarCE {}

export interface GL401000_GLHistoryEnqFilter_InterastarCE extends GLHistoryEnqFilter {}
export class GL401000_GLHistoryEnqFilter_InterastarCE {
	@placeAfterProperty("FinPeriodID")
  Closing: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("UseMasterCalendar")
  Complement: PXFieldState<PXFieldOptions.CommitChanges>;
}

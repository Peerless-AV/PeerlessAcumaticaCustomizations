import {
	PXFieldState,
	placeAfterProperty,
} from "client-controls";
import { GL102000, GLSetupRecord } from "src/screens/GL/GL102000/GL102000";

export interface GL102000_InterastarCE extends GL102000 {}
export class GL102000_InterastarCE {}

export interface GL102000_GLSetupRecord_InterastarCE extends GLSetupRecord {}
export class GL102000_GLSetupRecord_InterastarCE {
	@placeAfterProperty("DefaultSubID")
  UsrDefaultExpenseAcctID: PXFieldState;

	@placeAfterProperty("UsrDefaultExpenseAcctID")
	UsrEnableValidation: PXFieldState;

	@placeAfterProperty("UsrEnableValidation")
	UsrExemptTaxCategory: PXFieldState;
}

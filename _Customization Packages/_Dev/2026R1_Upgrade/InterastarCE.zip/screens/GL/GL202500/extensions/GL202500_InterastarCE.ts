import {
	PXFieldState,
	PXFieldOptions,
	placeAfterProperty,
	columnConfig,
	TextAlign,
	GridColumnType,
} from "client-controls";
import { GL202500, AccountRecords } from "src/screens/GL/GL202500/GL202500";

export interface GL202500_InterastarCE extends GL202500 {}

export class GL202500_InterastarCE {}

export interface GL202500_AccountRecords_InterastarCE extends AccountRecords {}
export class GL202500_AccountRecords_InterastarCE {
	// @placeAfterProperty("ControlAccountModule")
  // CuryID: PXFieldState<PXFieldOptions.CommitChanges>;

	// @placeAfterProperty("CuryID")
  // RequireUnits: PXFieldState;

	// @placeAfterProperty("RequireUnits")
  // NoSubDetail: PXFieldState;

	// @placeAfterProperty("NoSubDetail")
  // IsCashAccount: PXFieldState;

	// @placeAfterProperty("IsCashAccount")
  // AllowManualEntry: PXFieldState<PXFieldOptions.CommitChanges>;

	// @placeAfterProperty("PostOption")
  // Secured: PXFieldState;

	// @placeAfterProperty("Secured")
  // AccountGroupID: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("TaxCategoryID")
	@columnConfig({
		width: 70,
		textAlign: TextAlign.Center,
	})
  GroupingCodeCD: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("GroupingCodeCD")
	@columnConfig({
		width: 70,
		textAlign: TextAlign.Center,
	})
  Level: PXFieldState<PXFieldOptions.CommitChanges>;

	@placeAfterProperty("Level")
	@columnConfig({
		width: 120,
		textAlign: TextAlign.Center,
	})
  ParentID: PXFieldState<PXFieldOptions.CommitChanges>;

	// @placeAfterProperty("ParentID")
  // COAOrder: PXFieldState;

	// @placeAfterProperty("COAOrder")
  // GLConsolAccountCD: PXFieldState;

	// @placeAfterProperty("GLConsolAccountCD")
  // RevalCuryRateTypeId: PXFieldState;

	@placeAfterProperty("RevalCuryRateTypeId")
	@columnConfig({
		type: GridColumnType.CheckBox,
		width: 60,
	})
  Avoid: PXFieldState<PXFieldOptions.CommitChanges>;
}

import {
	PXFieldState,
	placeAfterProperty,
} from "client-controls";
import { TX205000, Tax } from "src/screens/TX/TX205000/TX205000";

export interface TX205000_InterastarCE extends TX205000 {}

export class TX205000_InterastarCE {}

export interface TX205000_Tax_InterastarCE extends Tax {}
export class TX205000_Tax_InterastarCE {
	@placeAfterProperty("TaxUOM")
  UsrCETaxValue: PXFieldState;
}

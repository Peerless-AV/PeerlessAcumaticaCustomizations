import { PXView, PXFieldState, gridConfig, PXFieldOptions, createCollection, PXScreen, graphInfo, PXActionState, actionConfig, ControlParameter, columnConfig, TextAlign, GridPreset, GridFastFilterVisibility } from "client-controls";

@graphInfo({graphType: "IS.Objects.CE.ISMXAccountMaint", primaryView: "SatAccountList", })
export class CE100000 extends PXScreen {
	SatAccountList = createCollection(ISMXAccountList);
}

// Views
@gridConfig({
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.ReadOnly
})
export class ISMXAccountList extends PXView  {
	@columnConfig({
		width: 72,
		textAlign: TextAlign.Center
	})
	GroupingCodeCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({
		textAlign: TextAlign.Center
	})
	Level: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({
		width: 280,
		textAlign: TextAlign.Center
	})
	Description: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({
		width: 72,
		textAlign: TextAlign.Center
	})
	ParentGroupingCodeCD: PXFieldState<PXFieldOptions.CommitChanges>;
	@columnConfig({
		textAlign: TextAlign.Center
	})
	GroupingCodeID: PXFieldState<PXFieldOptions.CommitChanges>;
}
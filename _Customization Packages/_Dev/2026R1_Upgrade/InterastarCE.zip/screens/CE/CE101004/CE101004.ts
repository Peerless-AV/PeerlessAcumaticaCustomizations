import { PXView, PXFieldState, gridConfig, createCollection, createSingle, PXScreen, graphInfo, CustomEventType, actionConfig, PXFieldOptions, columnConfig, PXActionState, GridPreset, GridFastFilterVisibility, ControlParameter } from "client-controls";

@graphInfo({graphType: "IS.Objects.CE.ISCEAuxReportsMaint", primaryView: "Filter", })
export class CE101004 extends PXScreen {
	GenerateAuxAccounts: PXActionState;
	GeneratePolicyAux: PXActionState;
	GeneratePolicy: PXActionState;

	Filter = createSingle(ISCEAuxReportFilter);
	Reports = createCollection(ISCEReportsHistory);
}

// Views
export class ISCEAuxReportFilter extends PXView  {
	ReportType: PXFieldState<PXFieldOptions.CommitChanges>;
	RequestType: PXFieldState<PXFieldOptions.CommitChanges>;
	OrderNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	TransactNbr: PXFieldState<PXFieldOptions.CommitChanges>;
	FinPeriod: PXFieldState<PXFieldOptions.CommitChanges>;
	AccountID: PXFieldState<PXFieldOptions.CommitChanges>;
}

@gridConfig({
	syncPosition: true,
	autoAdjustColumns: true,
	showFastFilter: GridFastFilterVisibility.False,
	preset: GridPreset.Details
})
export class ISCEReportsHistory extends PXView  {
	ReportType: PXFieldState;
	ReportName: PXFieldState;
	OrderNbr: PXFieldState;
	TransactNbr: PXFieldState;
	GeneratedBy: PXFieldState;
	@columnConfig({
		width: 90
	})
	GenerationDate: PXFieldState;
	Period: PXFieldState;
	StampStatus: PXFieldState;
}
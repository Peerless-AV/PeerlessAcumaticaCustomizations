﻿import {
    PXFieldState,
    columnConfig,
    SortDirection
} from "client-controls";

import {
    IN401000,
    ISERecords
} from "src/screens/IN/IN401000/IN401000";


export interface IN401000_PLAvailableSort
    extends IN401000
{
}

export class IN401000_PLAvailableSort
{
}


export interface ISERecords_PLAvailableSort
    extends ISERecords
{
}

export class ISERecords_PLAvailableSort
{
    @columnConfig({
        sortDirection: SortDirection.Descending
    })
    QtyAvail: PXFieldState;
}
﻿import { PXFieldState, PXFieldOptions, columnConfig, QpSelectorCustomElement, SelectorService, SortDirection, registerControl } from "client-controls";
import { TaskQueue, useView } from "aurelia-framework";
import { IN302000, INTran } from "src/screens/IN/IN302000/IN302000";
import { LSNullText } from "src/screens/IN/common/line-splitting/views";

// Column of the standard Location lookup that holds Qty On Hand (LocationAvail attribute): INLocationStatusByCostCenter__qtyOnHand.
const QTY_ON_HAND_FIELD = "qtyonhand";
const isQtyOnHand = (field?: string) => !!field && field.toLowerCase().replace(/_/g, "").includes(QTY_ON_HAND_FIELD);

// Location editor for the Issues lines: same lookup as qp-selector, opening sorted by Qty On Hand descending.
// Registered with registerControl so the grid cell editor (qp-inline-field -> enhanced-compose) can resolve it by name;
// without a global registration enhanced-compose falls back to qp-text-editor and shows "[object Object]".
// Not tied to the HCPK license: the sort stays active without it.
@registerControl("hcpa-location-selector")
@useView("client-controls/controls/simple/selector/qp-selector.html")
export class HCPALocationSelectorCustomElement extends QpSelectorCustomElement {
    get gridColumns() {
        return super.gridColumns?.map(column => isQtyOnHand(column.field)
            ? { ...column, sortDirection: SortDirection.Descending }
            : column);
    }

    // The lookup dialog always sends a searchField to the server (SelectorService: searchField || valueField, i.e. the key
    // column). GridDataHandler.PrepareSearchSorting then clears the sort of every other column and sorts by that field
    // ascending, so the Qty On Hand order is lost. It also applies the current value (e.g. "R1S1") as a search against the
    // sorted column. Use Qty On Hand as the search field and drop the search value when it is empty or just the current
    // value; a text typed by the user still filters the lookup with the standard behavior.
    async openSelector(e?: MouseEvent) {
        const self = this as any;
        self.selectorService ??= new SelectorService(self.container.get(TaskQueue));
        const service = self.selectorService;
        const getSelectorValue = service.getSelectorValue;
        const qtyField = this.gridColumns?.find(column => isQtyOnHand(column.field))?.field;
        service.getSelectorValue = (args: any) => {
            const searchValue = args?.searchValue?.toString().trim();
            const isDefaultSearch = !searchValue || searchValue === this.value?.id?.toString().trim();
            return getSelectorValue.call(service, qtyField && isDefaultSearch
                ? { ...args, searchValue: undefined, searchField: qtyField }
                : args);
        };
        try {
            return await super.openSelector(e);
        }
        finally {
            service.getSelectorValue = getSelectorValue;
        }
    }
}

export interface IN302000_HCPA extends IN302000 {}
export class IN302000_HCPA {}

export interface INTran_HCPA extends INTran {}
export class INTran_HCPA {
    @columnConfig({ hideViewLink: true, nullText: LSNullText.Split, editorType: "hcpa-location-selector" })
    LocationID: PXFieldState<PXFieldOptions.CommitChanges>;
}
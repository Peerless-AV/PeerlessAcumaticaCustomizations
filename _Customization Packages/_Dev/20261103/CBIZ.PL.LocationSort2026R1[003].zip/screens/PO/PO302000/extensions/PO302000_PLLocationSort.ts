﻿import {
    PXFieldState,
    PXFieldOptions,
    columnConfig,
    QpSelectorCustomElement,
    SelectorService,
    SortDirection,
    registerControl
} from "client-controls";

import {
    TaskQueue,
    useView
} from "aurelia-framework";

import {
    PO302000,
    POReceiptLine
} from "src/screens/PO/PO302000/PO302000";


import {
    LSNullText
} from "src/screens/IN/common/line-splitting/views";


const QTY_ON_HAND_FIELD = "qtyonhand";


const isQtyOnHand = (field?: string) =>
    !!field &&
    field
        .toLowerCase()
        .replace(/_/g, "")
        .includes(QTY_ON_HAND_FIELD);


/*
 * Custom Location selector.
 *
 * Uses the standard Acumatica selector UI and opens the
 * Location lookup sorted by Qty On Hand descending.
 */
@registerControl("pl-location-qty-selector")
@useView("client-controls/controls/simple/selector/qp-selector.html")
export class PLLocationQtySelectorCustomElement
    extends QpSelectorCustomElement
{
    get gridColumns()
    {
        return super.gridColumns?.map(column =>
            isQtyOnHand(column.field)
                ? {
                    ...column,
                    sortDirection: SortDirection.Descending
                }
                : column
        );
    }


    async openSelector(e?: MouseEvent)
    {
        const self = this as any;

        self.selectorService ??=
            new SelectorService(
                self.container.get(TaskQueue)
            );

        const service = self.selectorService;

        const getSelectorValue =
            service.getSelectorValue;

        const qtyField =
            this.gridColumns?.find(
                column =>
                    isQtyOnHand(column.field)
            )?.field;

        service.getSelectorValue =
            (args: any) =>
            {
                const searchValue =
                    args?.searchValue
                        ?.toString()
                        .trim();

                const currentValue =
                    this.value?.id
                        ?.toString()
                        .trim();

                const isDefaultSearch =
                    !searchValue ||
                    searchValue === currentValue;

                return getSelectorValue.call(
                    service,
                    qtyField && isDefaultSearch
                        ? {
                            ...args,
                            searchValue: undefined,
                            searchField: qtyField
                        }
                        : args
                );
            };

        try
        {
            return await super.openSelector(e);
        }
        finally
        {
            service.getSelectorValue =
                getSelectorValue;
        }
    }
}


/*
 * PO302000 screen extension.
 */
export interface PO302000_PLLocationSort
    extends PO302000
{
}

export class PO302000_PLLocationSort
{
}


/*
 * Extend Purchase Receipt Details.
 */
export interface POReceiptLine_PLLocationSort
    extends POReceiptLine
{
}

export class POReceiptLine_PLLocationSort
{
    @columnConfig({
        hideViewLink: true,
        nullText: LSNullText.Split,
        editorType: "pl-location-qty-selector"
    })
    LocationID:
        PXFieldState<PXFieldOptions.CommitChanges>;
}
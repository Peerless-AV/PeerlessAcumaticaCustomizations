<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CE101004.aspx.cs" Inherits="Page_CE101004" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.CE.ISCEAuxReportsMaint" PrimaryView="Filter">
    <CallbackCommands>
      <px:PXDSCallbackCommand Name="GenerateAuxAccounts" Visible="true" DependOnGrid="grid">
      </px:PXDSCallbackCommand>
        <px:PXDSCallbackCommand Name="GeneratePolicyAux" Visible="true" DependOnGrid="grid">
      </px:PXDSCallbackCommand>
        <px:PXDSCallbackCommand Name="GeneratePolicy" Visible="true" DependOnGrid="grid">
      </px:PXDSCallbackCommand>
    </CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView FilesIndicator="True" NoteIndicator="True" ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" DataMember="Filter"
    Width="100%" TabIndex="1700">
    <Template>
      <px:PXLayoutRule runat="server" StartRow="True" GroupCaption="REPORTES" StartColumn="True" StartGroup="True" ></px:PXLayoutRule>
        <px:PXDropDown CommitChanges="True" ID="edReportType" runat="server" DataField="ReportType">
        </px:PXDropDown>
        <px:PXDropDown ID="edRequestType" runat="server" CommitChanges="True" DataField="RequestType">
        </px:PXDropDown>
        <px:PXMaskEdit ID="edOrderNbr" runat="server" AlreadyLocalized="False" DataField="OrderNbr" CommitChanges="True" DefaultLocale="">
        </px:PXMaskEdit>
        <px:PXMaskEdit ID="edTransactNbr" runat="server" AlreadyLocalized="False" CommitChanges="True" DataField="TransactNbr">
        </px:PXMaskEdit>
        <px:PXSelector CommitChanges="True" ID="edFinPeriod" runat="server" DataField="FinPeriod">
        </px:PXSelector>
        <px:PXSegmentMask ID="edAccountID" runat="server" DataField="AccountID" CommitChanges="True">
        </px:PXSegmentMask>
    </Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
  <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
    AllowPaging="True"  AdjustPageSize="Auto" DataSourceID="ds" SkinID="Details" TabIndex="4500" SyncPosition="True" AutoAdjustColumns="True">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
    <Levels>
      <px:PXGridLevel DataMember="Reports">
          <RowTemplate>
              <px:PXTextEdit ID="edReportType" runat="server" AlreadyLocalized="False" DataField="ReportType">
              </px:PXTextEdit>
              <px:PXTextEdit ID="edReportName" runat="server" AlreadyLocalized="False" DataField="ReportName" DefaultLocale="">
              </px:PXTextEdit>
              <px:PXTextEdit ID="edOrderNbr" runat="server" AlreadyLocalized="False" DataField="OrderNbr" DefaultLocale="">
              </px:PXTextEdit>
              <px:PXTextEdit ID="edTransactNbr" runat="server" AlreadyLocalized="False" DataField="TransactNbr" DefaultLocale="">
              </px:PXTextEdit>
              <px:PXTextEdit ID="edGeneratedBy" runat="server" AlreadyLocalized="False" DataField="GeneratedBy">
              </px:PXTextEdit>
              <px:PXDateTimeEdit ID="edGenerationDate" runat="server" AlreadyLocalized="False" DataField="GenerationDate">
              </px:PXDateTimeEdit>
              <px:PXTextEdit ID="edPeriod" runat="server" AlreadyLocalized="False" DataField="Period">
              </px:PXTextEdit>
              <px:PXTextEdit ID="edStampStatus" runat="server" AlreadyLocalized="False" DataField="StampStatus">
              </px:PXTextEdit>
          </RowTemplate>
          <Columns>
              <px:PXGridColumn DataField="ReportType">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="ReportName">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="OrderNbr">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="TransactNbr">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="GeneratedBy">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="GenerationDate" Width="90px">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="Period">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="StampStatus">
              </px:PXGridColumn>
          </Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="200" />
  </px:PXGrid>
</asp:Content>
<asp:Content ID="Content1" runat="server" contentplaceholderid="phDialogs"></asp:Content>

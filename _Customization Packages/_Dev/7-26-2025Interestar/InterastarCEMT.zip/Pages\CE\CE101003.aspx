<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CE101003.aspx.cs" Inherits="Page_CE101003" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.CE.ISCEAuxAccountsMaint" PrimaryView="Filter">
    <CallbackCommands>
      <px:PXDSCallbackCommand Name="GenerateAuxAccounts" Visible="true" DependOnGrid="grid">
      </px:PXDSCallbackCommand>
    </CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
  <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" DataMember="Filter"
    Width="100%" TabIndex="1700">
    <Template>
      <px:PXLayoutRule runat="server" StartRow="True" GroupCaption="Auxiliar de cuentas" StartColumn="True" StartGroup="True" />
        <px:PXDropDown ID="edRequestType" runat="server" CommitChanges="True" DataField="RequestType">
        </px:PXDropDown>
        <px:PXMaskEdit ID="edOrderNbr" runat="server" AlreadyLocalized="False" DataField="OrderNbr" CommitChanges="True">
        </px:PXMaskEdit>
        <px:PXMaskEdit ID="edTransactNbr" runat="server" AlreadyLocalized="False" CommitChanges="True" DataField="TransactNbr" DefaultLocale="">
        </px:PXMaskEdit>
        <px:PXSelector ID="edFinPeriodID" runat="server" CommitChanges="True" DataField="FinPeriodoID">
        </px:PXSelector>
        <px:PXSegmentMask ID="edAccountID" runat="server" DataField="AccountID" CommitChanges="True">
        </px:PXSegmentMask>
    </Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
  <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
    AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="PrimaryInquire" FastFilterFields="FinPeriodID" TabIndex="4500" TemporaryFilterCaption="Filter Applied" SyncPosition="True" AutoAdjustColumns="True">
    <Levels>
      <px:PXGridLevel DataMember="BatchTransactionsByPeriod">
          <RowTemplate>
              <px:PXDropDown ID="edModule" runat="server" DataField="Module" Enabled="False">
              </px:PXDropDown>
              <px:PXTextEdit ID="edBatchNbr" runat="server" AlreadyLocalized="False" DataField="BatchNbr" Enabled="False" DefaultLocale="">
              </px:PXTextEdit>
              <px:PXSegmentMask ID="edAccountID" runat="server" DataField="AccountID" Enabled="False">
              </px:PXSegmentMask>
              <px:PXNumberEdit ID="edCuryDebitAmt" runat="server" AlreadyLocalized="False" DataField="CuryDebitAmt" Enabled="False">
              </px:PXNumberEdit>
              <px:PXNumberEdit ID="edCuryCreditAmt" runat="server" AlreadyLocalized="False" DataField="CuryCreditAmt" Enabled="False">
              </px:PXNumberEdit>
          </RowTemplate>
          <Columns>
              <px:PXGridColumn DataField="Module">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="BatchNbr">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="AccountID">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="CuryDebitAmt" TextAlign="Right" Width="100px">
              </px:PXGridColumn>
              <px:PXGridColumn DataField="CuryCreditAmt" TextAlign="Right" Width="100px">
              </px:PXGridColumn>
          </Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="200" />
  </px:PXGrid>
</asp:Content>
<asp:Content ID="Content1" runat="server" contentplaceholderid="phDialogs">
</asp:Content>

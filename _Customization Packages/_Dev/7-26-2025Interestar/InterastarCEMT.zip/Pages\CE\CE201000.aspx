<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="CE201000.aspx.cs" Inherits="Page_CE201000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.CE.ISCEImportVoucherMaint" PrimaryView="CFDIs">
        <CallbackCommands>

        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView Width="100%" DataMember="CFDIs" runat="server" ID="InvoicesForm" DataSourceID="ds" TabIndex="1300">
        <Template>
            
            <px:PXLayoutRule runat="server" StartRow="True" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXSelector ID="edVoucherID" runat="server" AlreadyLocalized="False" DataField="VoucherID" CommitChanges="True" LabelWidth="140px">
            </px:PXSelector>
            <px:PXTextEdit ID="edFolio" runat="server" AlreadyLocalized="False" DataField="Folio" LabelWidth="140px">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" GroupCaption="Datos Generales" StartGroup="True">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edVersion" runat="server" AlreadyLocalized="False" DataField="Version" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDropDown ID="edDocType" runat="server" AlreadyLocalized="False" DataField="DocType" LabelWidth="140px" DefaultLocale="">
            </px:PXDropDown>
            <px:PXTextEdit ID="edSerie" runat="server" AlreadyLocalized="False" DataField="Serie" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDropDown ID="edPaymentForm" runat="server" DataField="PaymentForm" LabelWidth="140px">
            </px:PXDropDown>
            <px:PXSelector ID="edPaymentMethod" runat="server" DataField="PaymentMethod" LabelWidth="140px">
            </px:PXSelector>
            <px:PXTextEdit ID="edPaymentTerms" runat="server" AlreadyLocalized="False" DataField="PaymentTerms" LabelWidth="140px">
            </px:PXTextEdit>
            <px:PXSelector ID="edZipCode" runat="server" AlreadyLocalized="False" DataField="ZipCode" LabelWidth="140px" DefaultLocale="">
            </px:PXSelector>
            <px:PXLayoutRule runat="server" Merge="True">
            </px:PXLayoutRule>
            <px:PXCheckBox ID="edIsGenericInvoice" runat="server" AlreadyLocalized="False" DataField="IsGenericInvoice" Text="Publico en General" AlignLeft="True">
            </px:PXCheckBox>
            <px:PXCheckBox ID="edHasExternalTrade" runat="server" AlreadyLocalized="False" DataField="HasExternalTrade" Text="Comercio Exterior">
            </px:PXCheckBox>
           
            <px:PXLayoutRule runat="server" EndGroup="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" GroupCaption=" " StartGroup="True">
            </px:PXLayoutRule>
            <px:PXSelector ID="edCuryID" runat="server" AlreadyLocalized="False" DataField="CuryID" LabelWidth="140px" DefaultLocale="">
            </px:PXSelector>
            <px:PXNumberEdit ID="edCuryRate" runat="server" AlreadyLocalized="False" DataField="CuryRate" LabelWidth="140px" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edDisccountAmt" runat="server" AlreadyLocalized="False" DataField="DisccountAmt" LabelWidth="140px" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edVoucherSubTotal" runat="server" AlreadyLocalized="False" DataField="VoucherSubTotal" LabelWidth="140px" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edVoucherTotal" runat="server" AlreadyLocalized="False" DataField="VoucherTotal" LabelWidth="140px" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXTextEdit ID="edAmountInWords" runat="server" AlreadyLocalized="False" DataField="AmountInWords" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXMaskEdit ID="edPacConfirmation" runat="server" AlreadyLocalized="False" DataField="PacConfirmation" LabelWidth="140px" DefaultLocale="">
            </px:PXMaskEdit>
            <px:PXLayoutRule runat="server" EndGroup="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" GroupCaption="Certificados">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edCertificateNbr" runat="server" AlreadyLocalized="False" DataField="CertificateNbr" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edCertificate" runat="server" AlreadyLocalized="False" DataField="Certificate" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDateTimeEdit ID="edSealDate" runat="server" AlreadyLocalized="False" DataField="SealDate" LabelWidth="140px" DefaultLocale="">
            </px:PXDateTimeEdit>
            <px:PXTextEdit ID="edSeal" runat="server" AlreadyLocalized="False" DataField="Seal" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDateTimeEdit ID="edStampDate" runat="server" AlreadyLocalized="False" DataField="StampDate" LabelWidth="140px" DefaultLocale="">
            </px:PXDateTimeEdit>
            <px:PXTextEdit ID="edStamp" runat="server" AlreadyLocalized="False" DataField="Stamp" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edSatCertificateNbr" runat="server" AlreadyLocalized="False" DataField="SatCertificateNbr" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edQrCode" runat="server" AlreadyLocalized="False" DataField="QrCode" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edStampString" runat="server" AlreadyLocalized="False" DataField="StampString" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDocumentString" runat="server" AlreadyLocalized="False" DataField="DocumentString" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" EndGroup="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" GroupCaption="ESTATUS">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edCancelStatus" runat="server" AlreadyLocalized="False" DataField="CancelStatus" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDateTimeEdit ID="edCancelDate" runat="server" AlreadyLocalized="False" DataField="CancelDate" LabelWidth="140px" DefaultLocale="">
            </px:PXDateTimeEdit>
            <px:PXLayoutRule runat="server" EndGroup="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" StartColumn="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" GroupCaption="Datos Fiscales">
            </px:PXLayoutRule>
            <px:PXDropDown ID="edStampStatus" runat="server" DataField="StampStatus">
            </px:PXDropDown>
            <px:PXTextEdit ID="edUuid" runat="server" AlreadyLocalized="False" DataField="Uuid" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edIssuerTaxRegistrationID" runat="server" AlreadyLocalized="False" DataField="IssuerTaxRegistrationID" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edIssuer" runat="server" AlreadyLocalized="False" DataField="Issuer" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edReceiverTaxRegistrationID" runat="server" AlreadyLocalized="False" DataField="ReceiverTaxRegistrationID" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edReceiver" runat="server" AlreadyLocalized="False" DataField="Receiver" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edUseCfdi" runat="server" AlreadyLocalized="False" DataField="UseCfdi" LabelWidth="140px" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXNumberEdit ID="edTaxTransferredTotal" runat="server" AlreadyLocalized="False" DataField="TaxTransferredTotal" LabelWidth="200px" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXNumberEdit ID="edTaxHoldingTotal" runat="server" AlreadyLocalized="False" DataField="TaxHoldingTotal" LabelWidth="200px" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXTextEdit ID="edQrCodeImg" runat="server" AlreadyLocalized="False" DataField="QrCodeImg" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXLayoutRule runat="server" EndGroup="True">
            </px:PXLayoutRule>
            <px:PXLayoutRule runat="server" GroupCaption="Relaci�n">
            </px:PXLayoutRule>
            <px:PXTextEdit ID="edModule" runat="server" AlreadyLocalized="False" DataField="Module" LabelWidth="140px">
            </px:PXTextEdit>
           <px:PXTextEdit ID="edDocRef" runat="server" AlreadyLocalized="False" DataField="DocRef" LabelWidth="140px">
            </px:PXTextEdit>
            <px:PXDropDown ID="edRelationType" runat="server" DataField="RelationType">
            </px:PXDropDown>
            <px:PXLayoutRule runat="server" EndGroup="True">
            </px:PXLayoutRule>
           
        </Template>
        <AutoSize Container="Window" Enabled="True" />

    </px:PXFormView>
</asp:Content>


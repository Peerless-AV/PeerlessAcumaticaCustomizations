<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CE101002.aspx.cs" Inherits="Page_CE101002" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
  <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.CE.ISCEAuxPoliciesMaint" PrimaryView="Policies">
    <CallbackCommands>
      <px:PXDSCallbackCommand Name="GeneratePolicyAux" Visible="true" DependOnGrid="grid">
      </px:PXDSCallbackCommand>
    </CallbackCommands>
  </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" runat="Server">
  <px:PXFormView ID="form" runat="server" DataSourceID="ds" Style="z-index: 100" DataMember="Policies"
    Width="100%" TabIndex="1700">
    <Template>
      <px:PXLayoutRule runat="server" StartRow="True" GroupCaption="Poliza" StartColumn="True" StartGroup="True" />
        <px:PXDropDown ID="edRequestType" runat="server" CommitChanges="True" DataField="RequestType">
        </px:PXDropDown>
        <px:PXMaskEdit ID="edOrderNbr" runat="server" AlreadyLocalized="False" DataField="OrderNbr" CommitChanges="True">
        </px:PXMaskEdit>
        <px:PXMaskEdit ID="edTransactNbr" runat="server" AlreadyLocalized="False" CommitChanges="True" DataField="TransactNbr" DefaultLocale="">
        </px:PXMaskEdit>
        <px:PXSelector ID="edFinPeriod" runat="server" CommitChanges="True" DataField="FinPeriod">
        </px:PXSelector>
    </Template>
  </px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" runat="Server">
  <px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
    AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="PrimaryInquire" FastFilterFields="FinPeriodID" TabIndex="4500" TemporaryFilterCaption="Filter Applied" SyncPosition="True" AutoAdjustColumns="True">
    <Levels>
      <px:PXGridLevel DataKeyNames="DocType,RefNbr" DataMember="GetAllAPinvoiceByPeriod">
          <RowTemplate>
              <px:PXDropDown ID="edDocType" runat="server" CommitChanges="True" DataField="DocType">
              </px:PXDropDown>
              <px:PXSelector ID="edRefNbr" runat="server" CommitChanges="True" DataField="RefNbr">
              </px:PXSelector>
              <px:PXSelector ID="edFinPeriodID" runat="server" CommitChanges="True" DataField="FinPeriodID">
              </px:PXSelector>
          </RowTemplate>
        <Columns>
            <px:PXGridColumn CommitChanges="True" DataField="DocType">
            </px:PXGridColumn>
            <px:PXGridColumn CommitChanges="True" DataField="RefNbr">
            </px:PXGridColumn>
            <px:PXGridColumn CommitChanges="True" DataField="FinPeriodID">
            </px:PXGridColumn>
        </Columns>
      </px:PXGridLevel>
    </Levels>
    <AutoSize Container="Window" Enabled="True" MinHeight="200" />
  </px:PXGrid>
</asp:Content>
<asp:Content ID="Content1" runat="server" contentplaceholderid="phDialogs">
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="CE100000.aspx.cs" Inherits="Page_CE100000" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="SatAccountList" TypeName="IS.Objects.CE.ISMXAccountMaint" >
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
	<px:PXGrid ID="grid" runat="server" Height="400px" Width="100%" Style="z-index: 100"
		AllowPaging="True" AllowSearch="True" AdjustPageSize="Auto" DataSourceID="ds" SkinID="Inquire" TabIndex="100">
<EmptyMsg ComboAddMessage="No records found.
Try to change filter or modify parameters above to see records here." NamedComboMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." NamedComboAddMessage="No records found as &#39;{0}&#39;.
Try to change filter or modify parameters above to see records here." FilteredMessage="No records found.
Try to change filter to see records here." FilteredAddMessage="No records found.
Try to change filter to see records here." NamedFilteredMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." NamedFilteredAddMessage="No records found as &#39;{0}&#39;.
Try to change filter to see records here." AnonFilteredMessage="No records found.
Try to change filter to see records here." AnonFilteredAddMessage="No records found.
Try to change filter to see records here."></EmptyMsg>
		<Levels>
			<px:PXGridLevel DataKeyNames="GroupingCodeCD" DataMember="SatAccountList">
			    <RowTemplate>
                    <px:PXMaskEdit ID="edGroupingCodeCD" runat="server" AlreadyLocalized="False" DataField="GroupingCodeCD" CommitChanges="True" DefaultLocale="">
                    </px:PXMaskEdit>
                    <px:PXNumberEdit ID="edLevel" runat="server" AlreadyLocalized="False" DataField="Level" CommitChanges="True" DefaultLocale="">
                    </px:PXNumberEdit>
                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" CommitChanges="True" DefaultLocale="" TextAlign="Left">
                    </px:PXTextEdit>
                    <px:PXTextEdit ID="edParentGroupingCodeCD" runat="server" AlreadyLocalized="False" DataField="ParentGroupingCodeCD" CommitChanges="True" DefaultLocale="">
                    </px:PXTextEdit>
                    <px:PXNumberEdit ID="edGroupingCodeID" runat="server" AlreadyLocalized="False" DataField="GroupingCodeID" CommitChanges="True" DefaultLocale="">
                    </px:PXNumberEdit>
                </RowTemplate>
			    <Columns>
                    <px:PXGridColumn DataField="GroupingCodeCD" Width="72px" CommitChanges="True" TextAlign="Center">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Level" TextAlign="Center" CommitChanges="True">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="Description" Width="280px" CommitChanges="True" TextAlign="Center">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="ParentGroupingCodeCD" Width="72px" CommitChanges="True" TextAlign="Center">
                    </px:PXGridColumn>
                    <px:PXGridColumn DataField="GroupingCodeID" TextAlign="Center" CommitChanges="True">
                    </px:PXGridColumn>
                </Columns>
			</px:PXGridLevel>
		</Levels>
		<AutoSize Container="Window" Enabled="True" MinHeight="200" />
        <Mode AllowUpdate="True" AllowUpload="True" ></Mode>
	</px:PXGrid>
</asp:Content>

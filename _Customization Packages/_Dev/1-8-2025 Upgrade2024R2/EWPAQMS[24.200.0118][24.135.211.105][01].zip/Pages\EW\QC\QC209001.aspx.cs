using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_QC209001 : PX.Web.UI.PXPage {
    protected void Page_Init(object sender, EventArgs e)
    {
    }
}

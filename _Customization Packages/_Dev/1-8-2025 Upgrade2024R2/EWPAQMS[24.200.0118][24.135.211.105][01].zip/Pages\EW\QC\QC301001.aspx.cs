using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Drawing;
using EW.QC;

public partial class Page_QC301001 : PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e)
    {
        AddStyle("rowred", "Red", "White", false);
        AddStyle("rowgreen", "forestgreen", "White", false);
        AddStyle("rowDsiabled", "#D3D3D3", null, false); // #F5F7F8" #D3D3D3
    }

    private void AddStyle(string name, string backColor, string foreColor, bool bold)
    {
        Style style = new Style();
        if (!string.IsNullOrEmpty(backColor))
            style.BackColor = Color.FromName(backColor + " !important");

        if (!string.IsNullOrEmpty(foreColor))
            style.ForeColor = Color.FromName(foreColor);
        style.Font.Bold = bold;

        this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
    }

    protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e)
    {
        Object value = e.Row.Cells["ActualResult"].Value;
        Object statusVal = e.Row.Cells["Status"].Value;

        if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Fail)
            e.Row.Cells["ActualResult"].Style.CssClass = "rowred";
        else if (value != null && Convert.ToString(value) == EW.QC.EWQCResultType.Pass)
            e.Row.Cells["ActualResult"].Style.CssClass = "rowgreen";

        if (statusVal != null && Convert.ToString(statusVal) == EW.QC.QCOrderStatus.Posted)
            e.Row.Style.CssClass = "rowDsiabled";



        //Object finalRalue = e.Row.Cells["FinalResult"].Value;
        //if(finalRalue != null && Convert.ToString(finalRalue) == EW.QC.QCResultType.Fail)
        //    e.Row.Cells["FinalResult"].Style.CssClass = "rowred";
        //else if(finalRalue != null && Convert.ToString(finalRalue) == EW.QC.QCResultType.Pass)
        //    e.Row.Cells["FinalResult"].Style.CssClass = "rowgreen";
    }

}

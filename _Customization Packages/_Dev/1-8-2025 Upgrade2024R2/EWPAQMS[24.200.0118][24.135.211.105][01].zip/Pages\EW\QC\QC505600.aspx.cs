using EW.QC;
using PX.Data;
using System;
using System.Drawing;
using System.Web.UI.WebControls;

public partial class Page_QC505600:PX.Web.UI.PXPage {
	protected void Page_Load(object sender, EventArgs e) {
		AddStyle("rowred", "#f59898", "White", false);
		EWQCStabilityProcess processGraph = PXGraph.CreateInstance<EWQCStabilityProcess>();
		processGraph.Stablitydata();
	}
	private void AddStyle(string name, string backColor, string foreColor, bool bold) {
		Style style = new Style();
		if(!string.IsNullOrEmpty(backColor))
			style.BackColor = Color.FromName(backColor + " !important");

		if(!string.IsNullOrEmpty(foreColor))
			style.ForeColor = Color.FromName(foreColor);
		style.Font.Bold = bold;

		this.Page.Header.StyleSheet.CreateStyleRule(style, this, "." + name);
	}
	protected void grid_RowDataBound(object sender, PX.Web.UI.PXGridRowEventArgs e) {
		Object value = e.Row.Cells["QCOrderCreation"].Value;
		if(value != null && Convert.ToString(value) == EW.QC.EWQCQCOrderCreation.Automatic)
			e.Row.Style.CssClass = "rowred";
	}
}

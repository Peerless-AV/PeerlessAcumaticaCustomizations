using System;

public partial class Page_QC101100:PX.Web.UI.PXPage {
    protected void Page_Load(object sender, EventArgs e) {
    }
}

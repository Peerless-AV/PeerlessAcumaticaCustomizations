<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="DD301001.aspx.cs" Inherits="Page_DD301001" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.DD.ISDDLiverpoolEntry" PrimaryView="AddendumView">
        <CallbackCommands>
            
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView Width="100%" DataMember="AddendumView" runat="server" ID="LiverpoolForm" DataSourceID="ds" TabIndex="1300">
        <Template>
            
            <px:PXLayoutRule runat="server" GroupCaption="Adenda Liverpool" StartRow="True">
            </px:PXLayoutRule>
            
            <px:PXDropDown ID="edDocType" runat="server" DataField="DocType">
            </px:PXDropDown>
            <px:PXSelector ID="edRefNbr" runat="server" DataField="RefNbr">
            </px:PXSelector>
            <px:PXNumberEdit ID="edAmountInvoice" runat="server" AlreadyLocalized="False" CommitChanges="True" DataField="AmountInvoice" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXDropDown ID="edInstructionType" runat="server" AlreadyLocalized="False" DataField="InstructionType" DefaultLocale="" CommitChanges="True">
            </px:PXDropDown>
            <px:PXTextEdit ID="edInstruction" runat="server" AlreadyLocalized="False" DataField="Instruction" CommitChanges="True" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edOrderNbr" runat="server" AlreadyLocalized="False" DataField="OrderNbr" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDateTimeEdit ID="edOrderDate" runat="server" AlreadyLocalized="False" DataField="OrderDate" DefaultLocale="">
            </px:PXDateTimeEdit>
            <px:PXTextEdit ID="edAdditionalOrderNbr" runat="server" AlreadyLocalized="False" DataField="AdditionalOrderNbr" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDropDown ID="edAdditionalOrderType" runat="server" AlreadyLocalized="False" DataField="AdditionalOrderType">
            </px:PXDropDown>
            <px:PXTextEdit ID="edReceiptNbr" runat="server" AlreadyLocalized="False" DataField="ReceiptNbr" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDateTimeEdit ID="edReceiptDate" runat="server" AlreadyLocalized="False" DataField="ReceiptDate" DefaultLocale="">
            </px:PXDateTimeEdit>
            <px:PXTextEdit ID="edGLNLiverpool" runat="server" AlreadyLocalized="False" DataField="GLNLiverpool" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edDepartment" runat="server" AlreadyLocalized="False" DataField="Department" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDropDown ID="edSpecialServicesType" runat="server" AlreadyLocalized="False" DataField="SpecialServicesType">
            </px:PXDropDown>
            <px:PXNumberEdit ID="edSpecialServicesPercentage" runat="server" AlreadyLocalized="False" DataField="SpecialServicesPercentage" DefaultLocale="">
            </px:PXNumberEdit>
            <px:PXDropDown ID="edAllowanceType" runat="server" AlreadyLocalized="False" DataField="AllowanceType">
            </px:PXDropDown>
            <px:PXDropDown  ID="edAllowanceSubType" runat="server" AlreadyLocalized="False" DataField="AllowanceSubType">
            </px:PXDropDown>
            <px:PXNumberEdit ID="edAllowanceAmount" runat="server" AlreadyLocalized="False" DataField="AllowanceAmount" DefaultLocale="">
            </px:PXNumberEdit>
            
        </Template>
        <AutoSize Container="Window" Enabled="True"></AutoSize>
    </px:PXFormView>
</asp:Content>
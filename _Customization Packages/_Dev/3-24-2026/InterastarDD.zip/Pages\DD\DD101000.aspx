<%@ Page Language="C#" MasterPageFile="~/MasterPages/ListView.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="DD101000.aspx.cs" Inherits="Page_DD101000"
    Title="Configuraci�n Adendas" EnableSessionState="True" %>

<%@ MasterType VirtualPath="~/MasterPages/ListView.master" %>
<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" PrimaryView="GeneralAddendumGrid" TypeName="IS.Objects.DD.ISDDGeneralAddendumSetup">
        <CallbackCommands>
            <px:PXDSCallbackCommand CommitChanges="True" Name="Save" />
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phL" runat="Server">
    <px:PXGrid ID="gridGeneral" runat="server" SkinID="DetailsInTab" Width="100%" Height="200px" Caption="Adendas" AdjustPageSize="Auto" AllowPaging="True" TabIndex="300" DataSourceID="ds" KeepPosition="True" TemporaryFilterCaption="Filter Applied" FilesIndicator="True" NoteIndicator="True" SyncPosition="True" AutoAdjustColumns="true">
        <AutoCallBack Target="gridDetail" Command="Refresh" />
        <Levels>
            <px:PXGridLevel DataMember="GeneralAddendumGrid">
                <RowTemplate>
                    <px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
                    <px:PXTextEdit ID="edAddendumCD" runat="server" AlreadyLocalized="False" DataField="AddendumCD" CommitChanges="True" DefaultLocale="">
                    </px:PXTextEdit>
                    <px:PXDropDown ID="edType" runat="server" DataField="Type" CommitChanges="True">
                    </px:PXDropDown>
                    <px:PXSelector ID="edGenericInq" runat="server" AlreadyLocalized="False" DataField="GenericInq" CommitChanges="True" DefaultLocale="">
                    </px:PXSelector>
                    <px:PXTextEdit ID="edDescription" runat="server" AlreadyLocalized="False" DataField="Description" CommitChanges="True" DefaultLocale="">
                    </px:PXTextEdit>
                </RowTemplate>
                <Columns>
                    <px:PXGridColumn DataField="AddendumCD" Width="40px" />
                    <px:PXGridColumn DataField="Type" Width="60px" />
                    <px:PXGridColumn DataField="GenericInq" Width="100px" AutoCallBack="True" />
                    <px:PXGridColumn DataField="Description" Width="200px" />
                </Columns>
            </px:PXGridLevel>
        </Levels>
        <AutoSize Enabled="True" Container="Window"/>
    </px:PXGrid>
</asp:Content>

<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="DD100000.aspx.cs" Inherits="Page_DD100000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.DD.ISDDAddendumDefSetup" PrimaryView="Definitions">
        <CallbackCommands>
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView Width="100%" DataMember="Definitions" runat="server" ID="AddendumSetupForm" DataSourceID="ds" TabIndex="1300">
        <Template>
            <px:PXLayoutRule runat="server" GroupCaption="Definiciones de Adendas / Complementos" StartRow="True" LabelsWidth="M" ControlSize="SM">
            </px:PXLayoutRule>
            <px:PXDropDown ID="edAddendumCD" runat="server" CommitChanges="True" DataField="AddendumCD" Size="XS">
            </px:PXDropDown>
            <px:PXDropDown ID="edType" runat="server" CommitChanges="True" DataField="Type" >
            </px:PXDropDown>
            <px:PXSelector ID="edGenericInq" runat="server" CommitChanges="True" DataField="GenericInq">
            </px:PXSelector>
            <px:PXTextEdit ID="edDescription" runat="server" CommitChanges="True" DataField="Description" Width="400px" ControlSize="XM" >
            </px:PXTextEdit>
            <px:PXTextEdit ID="edContent" runat="server" CommitChanges="False" TextMode="MultiLine" Height="300px" Width="400px" ControlSize="XL" DataField="Xslt">
            </px:PXTextEdit>
        </Template>
        <AutoSize Container="Window" Enabled="True"></AutoSize>
    </px:PXFormView>
</asp:Content>
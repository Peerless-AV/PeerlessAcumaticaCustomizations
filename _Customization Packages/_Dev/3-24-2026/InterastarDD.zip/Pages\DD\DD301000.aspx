<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true"
    ValidateRequest="false" CodeFile="DD301000.aspx.cs" Inherits="Page_DD301000" Title="Untitled Page" %>

<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" runat="Server">
    <px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%" TypeName="IS.Objects.DD.ISDDUniInsurgentesEntry" PrimaryView="AddendumView">
        <CallbackCommands>
            
        </CallbackCommands>
    </px:PXDataSource>
</asp:Content>

<asp:Content ID="Content1" ContentPlaceHolderID="phF" runat="Server">
    <px:PXFormView Width="100%" DataMember="AddendumView" runat="server" ID="UniInsurgentesForm" DataSourceID="ds" TabIndex="1300">
        <Template>
            
            <px:PXLayoutRule runat="server" GroupCaption="Adenda Universidad Insurgentes" StartRow="True">
            </px:PXLayoutRule>
            <px:PXSelector ID="edRefNbr" runat="server" AlreadyLocalized="False" DataField="RefNbr" DefaultLocale="">
            </px:PXSelector>
            <px:PXDropDown ID="edDocType" runat="server" AlreadyLocalized="False" DataField="DocType" DefaultLocale="">
            </px:PXDropDown>
            <px:PXTextEdit ID="edProviderNbr" runat="server" AlreadyLocalized="False" DataField="ProviderNbr" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXTextEdit ID="edBuyOrderNbr" runat="server" AlreadyLocalized="False" DataField="BuyOrderNbr" DefaultLocale="">
            </px:PXTextEdit>
            <px:PXDateTimeEdit ID="edBuyOrderDate" runat="server" AlreadyLocalized="False" DataField="BuyOrderDate" DefaultLocale="">
            </px:PXDateTimeEdit>
            <px:PXDateTimeEdit ID="edDocDate" runat="server" AlreadyLocalized="False" DataField="DocDate" DefaultLocale="">
            </px:PXDateTimeEdit>
            
        </Template>
        <AutoSize Container="Window" Enabled="True"></AutoSize>
    </px:PXFormView>
</asp:Content>